@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" scripts\desktop_bootstrap.py %*
) else if exist "configs\python-path.txt" (
  set "MS_PYTHON="
  set /p "MS_PYTHON="<"configs\python-path.txt"
  call :run_configured %*
) else (
  py -3.12 scripts\desktop_bootstrap.py %*
)
set MS_EXIT=%errorlevel%
if not "%MS_EXIT%"=="0" (
  echo Startup failed. Read the error above or data\start-all.log.
  pause
)
exit /b %MS_EXIT%
:run_configured
if not defined MS_PYTHON (
  echo Python path is empty in configs\python-path.txt. Set a Python 3.11-3.13 executable path.
  exit /b 2
)
if not exist "%MS_PYTHON%" (
  echo Python executable configured in configs\python-path.txt does not exist. Update that file.
  exit /b 2
)
"%MS_PYTHON%" scripts\desktop_bootstrap.py %*
exit /b %errorlevel%
