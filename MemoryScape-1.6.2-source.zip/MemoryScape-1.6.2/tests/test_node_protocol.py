"""Model backends here are explicit CPU protocol doubles, never GPU benchmarks."""
import io,json,time,threading
import httpx
import pytest
from fastapi.testclient import TestClient
from node.gateway import create_app
from memoryscape.geometry import procedural_glb
from memoryscape.media import encode_wav
from memoryscape.schemas import *
from memoryscape.pipeline import Pipeline
from memoryscape.providers import Providers
from memoryscape.jobs import Worker,JobContext
from memoryscape.errors import AppError

TOKEN='protocol-test-node-token-not-for-deployment'

class Stub:
 def __init__(self,kind):self.kind=kind;self.calls=0;self.fail=False
 def run(self,cap,path,work,prompt,options):
  self.calls+=1
  if self.fail:raise RuntimeError('injected explicit protocol failure')
  if cap=='audio.describe':return {'description':'协议测试报告：音频存在；这不是模型听辨结果。','timestamp_precision':'segment'}
  out=work/('output.glb' if self.kind=='geometry' else 'output.png')
  out.write_bytes(procedural_glb('cake') if self.kind=='geometry' else path.read_bytes());return out

def node(tmp_path,kind):
 stub=Stub(kind);app=create_app(kind=kind,root=tmp_path/kind,token=TOKEN,backend=stub,start_worker=False)
 return app,TestClient(app,headers={'Authorization':'Bearer '+TOKEN}),stub

def test_node_auth_assets_idempotency_and_download(tmp_path,png):
 app,c,stub=node(tmp_path,'geometry')
 with c:
  assert c.get('/v1/capabilities',headers={'Authorization':'Bearer wrong'}).status_code==401
  assert c.get('/health').json()['execution_mode']=='contract-test'
  a=c.post('/v1/assets',files={'file':('ref.png',png)}).json()
  b=c.post('/v1/assets',files={'file':('ref.png',png)}).json();assert a['id']==b['id']
  payload={'capability':'geometry.generate','input_asset':a['id'],'options':{'steps':5}}
  j=c.post('/v1/jobs',json=payload,headers={'Idempotency-Key':'one'}).json()
  assert c.post('/v1/jobs',json=payload,headers={'Idempotency-Key':'one'}).json()['id']==j['id']
  assert c.post('/v1/jobs',json={**payload,'options':{'steps':6}},headers={'Idempotency-Key':'one'}).status_code==409
  assert app.state.run_one();assert stub.calls==1
  r=c.get('/v1/jobs/'+j['id']).json();assert r['status']=='succeeded'
  assert c.get('/v1/assets/'+r['result']['asset']['id']).content[:4]==b'glTF'
  assert c.post('/v1/jobs/'+j['id']+'/retry').status_code==409

def test_node_rejects_unsupported_geometry_prompt_and_params(tmp_path,png):
 app,c,_=node(tmp_path,'geometry')
 with c:
  a=c.post('/v1/assets',files={'file':('ref.png',png)}).json()
  req={'capability':'geometry.generate','input_asset':a['id'],'prompt':'write a fantasy world'}
  assert c.post('/v1/jobs',json=req,headers={'Idempotency-Key':'one'}).status_code==422
  req['prompt']='';req['options']={'exec':'shell'}
  # Validation errors must produce a bounded 4xx, not a server traceback.
  r=c.post('/v1/jobs',json=req,headers={'Idempotency-Key':'two'});assert r.status_code==422

def test_texture_node_binds_both_inputs_and_uses_the_existing_mesh(tmp_path,png):
 app,c,stub=node(tmp_path,'geometry')
 seen=[]
 def texture(cap,path,work,prompt,options):
  seen.append((cap,path.read_bytes(),(work/'reference.png').read_bytes()))
  out=work/'output.glb';out.write_bytes(path.read_bytes());return out
 stub.run=texture
 with c:
  assert 'geometry.texture' in c.get('/v1/capabilities').json()['capabilities']
  a=c.post('/v1/assets',files={'file':('shape.glb',procedural_glb('box'))}).json()
  ref=c.post('/v1/assets',files={'file':('ref.png',png)}).json()
  req={'capability':'geometry.texture','input_asset':a['id'],'reference_asset':ref['id'],'options':{'steps':4}}
  assert c.post('/v1/jobs',json={k:v for k,v in req.items() if k!='reference_asset'},headers={'Idempotency-Key':'missing'}).status_code==422
  assert c.post('/v1/jobs',json={**req,'input_asset':ref['id']},headers={'Idempotency-Key':'wrong-kind'}).status_code==422
  assert c.post('/v1/jobs',json={**req,'reference_asset':a['id']},headers={'Idempotency-Key':'wrong-ref'}).status_code==422
  j=c.post('/v1/jobs',json=req,headers={'Idempotency-Key':'texture'}).json()
  assert c.post('/v1/jobs',json=req,headers={'Idempotency-Key':'texture'}).json()['id']==j['id']
  assert app.state.run_one() and seen[0][0]=='geometry.texture'
  assert seen[0][1]==procedural_glb('box') and seen[0][2][:8]==b'\x89PNG\r\n\x1a\n'
  # Normalization may deduplicate identical pixels; use a distinct image.
  from PIL import Image
  out=io.BytesIO();Image.new('RGB',(16,16),'red').save(out,format='PNG')
  req['reference_asset']=c.post('/v1/assets',files={'file':('different.png',out.getvalue())}).json()['id']
  assert c.post('/v1/jobs',json=req,headers={'Idempotency-Key':'texture'}).status_code==409

def test_texture_provider_resumes_same_two_input_job_without_duplicate_generation(service,settings,monkeypatch,png,tmp_path):
 monkeypatch.setenv('TEST_NODE_TOKEN',TOKEN)
 settings.test_models={'geo':{'enabled':True,'url':'http://geometry.local','allow_plain_http':True,'token_env':'TEST_NODE_TOKEN','capabilities':['geometry.generate','geometry.texture']}}
 app,c,stub=node(tmp_path,'geometry');requests=[]
 def route(req):
  requests.append((req.method,req.url.path))
  if req.method=='GET' and '/v1/jobs/' in req.url.path:app.state.run_one()
  response=c.request(req.method,req.url.path,headers=dict(req.headers),content=req.read())
  return httpx.Response(response.status_code,content=response.content,headers=dict(response.headers))
 pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
 service.enqueue(pid,'edit',{});worker=Worker(service,lambda c:{});ctx=JobContext(service,worker.claim(),worker.owner)
 provider=Providers(service,transport=httpx.MockTransport(route))
 def call(ref=png):return provider.remote(ctx,'texture','geometry.texture',data=procedural_glb('box'),reference_data=ref,filename='shape.glb',options=GeometryOptions(steps=4).model_dump())
 with c:
  assert ctx.step('texture',{'source':1},lambda:len(call()['data']))>20;remote_id=ctx.remote_ref('texture')['job_id']
  assert call()['data'][:4]==b'glTF' and ctx.remote_ref('texture')['job_id']==remote_id
  assert stub.calls==1 and requests.count(('POST','/v1/jobs'))==1
  assert requests.count(('POST','/v1/assets'))==2
  with pytest.raises(AppError,match='输入或模型版本已经变化'):call(png+b'changed')

def test_node_failure_retry_and_cancel(tmp_path,png):
 app,c,stub=node(tmp_path,'image')
 with c:
  a=c.post('/v1/assets',files={'file':('ref.png',png)}).json()
  j=c.post('/v1/jobs',json={'capability':'image.edit','input_asset':a['id'],'prompt':'single cake'},headers={'Idempotency-Key':'image'}).json()['id']
  stub.fail=True;app.state.run_one();assert c.get('/v1/jobs/'+j).json()['status']=='failed'
  c.post('/v1/jobs/'+j+'/retry');stub.fail=False;app.state.run_one();assert c.get('/v1/jobs/'+j).json()['status']=='succeeded'
  k=c.post('/v1/jobs',json={'capability':'image.edit','input_asset':a['id'],'prompt':'two'},headers={'Idempotency-Key':'other'}).json()['id']
  c.post('/v1/jobs/'+k+'/cancel');assert not app.state.run_one();assert c.get('/v1/jobs/'+k).json()['status']=='cancelled'

def test_node_cancel_marker_is_removed_only_on_explicit_retry(tmp_path,png):
 app,c,stub=node(tmp_path,'image')
 with c:
  a=c.post('/v1/assets',files={'file':('ref.png',png)}).json()
  j=c.post('/v1/jobs',json={'capability':'image.edit','input_asset':a['id'],'prompt':'one'},headers={'Idempotency-Key':'cancel-marker'}).json()['id']
  assert c.post('/v1/jobs/'+j+'/cancel').json()['status']=='cancelled'
  work=app.state.store.root/j;marker=work/'cancel.requested'
  assert marker.is_file()
  artifact=work/'diagnostic.txt';artifact.write_text('retain private evidence')
  assert c.post('/v1/jobs/'+j+'/retry').json()['id']==j
  assert not marker.exists() and artifact.read_text()=='retain private evidence'
  assert app.state.run_one() and stub.calls==1
  assert c.get('/v1/jobs/'+j).json()['status']=='succeeded'

def test_node_restart_preserves_cancelled_running_jobs(tmp_path,png):
 app,c,stub=node(tmp_path,'image')
 with c:
  a=c.post('/v1/assets',files={'file':('ref.png',png)}).json()
  ids=[c.post('/v1/jobs',json={'capability':'image.edit','input_asset':a['id'],'prompt':str(i)},headers={'Idempotency-Key':str(i)}).json()['id'] for i in range(2)]
  with app.state.store.connect() as db:
   db.execute('UPDATE jobs SET status="running" WHERE id=?',(ids[0],))
   db.execute('UPDATE jobs SET status="cancelling",cancel=1 WHERE id=?',(ids[1],))
 # Simulated restart, no model backend or GPU work.
 app2,c2,_=node(tmp_path,'image')
 with c2:
  assert c2.get('/v1/jobs/'+ids[0]).json()['status']=='failed'
  assert 'explicit retry required' in c2.get('/v1/jobs/'+ids[0]).json()['error']
  assert c2.get('/v1/jobs/'+ids[1]).json()['status']=='cancelled'
  assert not app2.state.run_one()
  assert c2.get('/v1/capabilities').json()['cancellation']=='queued-immediate; running-discard-on-finish'

def test_native_image_fingerprint_and_cancellation_contract(tmp_path,monkeypatch):
 monkeypatch.setenv('IMAGE_THINKING_MODE','false')
 monkeypatch.setenv('IMAGE_REFLECTION_MODE','false')
 app=create_app(kind='image',root=tmp_path/'native-image',token=TOKEN,start_worker=False)
 with TestClient(app,headers={'Authorization':'Bearer '+TOKEN}) as c:
  caps=c.get('/v1/capabilities').json()
  assert caps['execution_mode']=='native'
  assert caps['cancellation']=='queued-immediate; running-at-diffusion-step'
  assert len(caps['fingerprint']['driver_sha256'])==64
  assert caps['fingerprint']['profile']['IMAGE_THINKING_MODE']=='false'
  assert caps['fingerprint']['profile']['IMAGE_REFLECTION_MODE']=='false'

def test_real_route_contract_multiphoto_audio_image_geometry(service,settings,monkeypatch,png,wav,tmp_path):
 """Same production orchestrator and HTTP protocol; CPU doubles are explicitly injected."""
 monkeypatch.setenv('TEST_NODE_TOKEN',TOKEN)
 settings.test_models={
  'brain':{'enabled':True,'protocol':'chat','url':'http://brain.local/v1','allow_plain_http':True,'token_env':'TEST_NODE_TOKEN','model':'contract-test-only','capabilities':['brain.plan'],'max_images':12},
  **{k:{'enabled':True,'url':f'http://{k}.local','allow_plain_http':True,'token_env':'TEST_NODE_TOKEN','capabilities':[cap],'protocol':'node-v1','revision':'test-double'} for k,cap in [('image','image.edit'),('geometry','geometry.generate'),('audio','audio.describe')]}}
 p=service.create_project(ProjectCreate(title='协议回归',mode='real',remote_consent=True,audio_mode='describe'))
 a=service.add_source(p['id'],png,'scene.png','scene',rights=True);b=service.add_source(p['id'],png,'cake.png','object',rights=True);sound=service.add_source(p['id'],wav,'original.wav','audio',rights=True)
 scene=Scene(objects=[SceneObject(id='table',label='桌子',generation=Generation(primitive='table'),transform=Transform(size=[3,1,2])),SceneObject(id='cake',label='蛋糕',kind='food',generation=Generation(strategy='generate3d',primary_source=b['id'],image_mode='edit',image_prompt='single cake',image_model='image',geometry_model='geometry'),reference_ids=[a['id'],b['id']],transform=Transform(size=[.7,.7,.7]))],relations=[Relation(type='on',subject='cake',target='table')],audio=[AudioTrack(id='original',label='原声',source_id=sound['id'])])
 plan=ScenePlan(summary='协议测试，不是模型质量评价',scene=scene)
 nodes={k:node(tmp_path,k) for k in ('image','geometry','audio')};messages=[]
 def transport(req):
  if req.url.host=='brain.local':
   data=json.loads(req.read());messages.append(data)
   return httpx.Response(200,json={'choices':[{'message':{'content':plan.model_dump_json()},'finish_reason':'stop'}]})
  kind=req.url.host.split('.')[0];app,c,_=nodes[kind]
  if req.method=='GET' and '/v1/jobs/' in req.url.path:app.state.run_one()
  response=c.request(req.method,req.url.path,headers=dict(req.headers),content=req.read())
  return httpx.Response(response.status_code,headers=dict(response.headers),content=response.content)
 providers=Providers(service,transport=httpx.MockTransport(transport));worker=Worker(service,Pipeline(service,providers))
 p=service.project(p['id']);job=service.enqueue(p['id'],'plan',{'base_version':0,'input_revision':p['input_revision']});worker.run_once()
 result=service.job(job['id']);assert result['status']=='succeeded',result['error'];assert nodes['audio'][2].calls==1
 assert len([x for x in messages[0]['messages'][1]['content'] if x['type']=='image_url'])==2
 assert 'audio_reports' in messages[0]['messages'][1]['content'][0]['text']
 build=service.confirm_plan(p['id'],result['result']['plan_id'],0,p['input_revision']);worker.run_once();out=service.job(build['id'])
 assert out['status']=='succeeded',out['error'];assert nodes['image'][2].calls==1;assert nodes['geometry'][2].calls==1
 assembled=service.scene(p['id'])['scene'];assert assembled['objects'][1]['status']=='ready';assert assembled['audio'][0]['asset_id']==sound['id']
 steps=service.steps(build['id']);assert any(s['remote'] for s in steps);assert assembled['objects'][1]['transform']['position'][1]==assembled['objects'][0]['transform']['size'][1]
 # The real branch is tested, but this result MUST remain a contract-test record.
 metrics=service.assets.get(assembled['objects'][1]['asset_id'])['meta']['metrics'];assert metrics['execution_mode']=='contract-test'
 for app,c,stub in nodes.values():c.close()

def test_download_failure_resumes_same_remote_job(service,settings,project,monkeypatch,png,tmp_path):
 settings.connection_grace_seconds=0  # Also retain explicit/manual recovery coverage.
 monkeypatch.setenv('TEST_NODE_TOKEN',TOKEN);settings.test_models={'geo':{'enabled':True,'url':'http://geometry.local','allow_plain_http':True,'token_env':'TEST_NODE_TOKEN','capabilities':['geometry.generate']}}
 pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id'];app,c,stub=node(tmp_path,'geometry');failed_download=[False]
 def route(req):
  if req.method=='GET' and '/v1/jobs/' in req.url.path:app.state.run_one()
  if req.method=='GET' and '/v1/assets/' in req.url.path and not failed_download[0]:failed_download[0]=True;raise httpx.ReadTimeout('injected')
  response=c.request(req.method,req.url.path,headers=dict(req.headers),content=req.read());return httpx.Response(response.status_code,content=response.content,headers=dict(response.headers))
 prov=Providers(service,transport=httpx.MockTransport(route));j=service.enqueue(pid,'edit',{'retry_generation':0});w=Worker(service,lambda c:{});ctx=JobContext(service,w.claim(),w.owner)
 def run():return prov.remote(ctx,'geometry','geometry.generate',data=png,filename='ref.png',options=GeometryOptions(steps=4).model_dump())
 with pytest.raises(AppError):ctx.step('geometry',{'source':1},lambda:len(run()['data']))
 remote_id=ctx.remote_ref('geometry')['job_id']
 assert ctx.step('geometry',{'source':1},lambda:len(run()['data']))>20
 assert stub.calls==1;assert ctx.remote_ref('geometry')['job_id']==remote_id;c.close()
