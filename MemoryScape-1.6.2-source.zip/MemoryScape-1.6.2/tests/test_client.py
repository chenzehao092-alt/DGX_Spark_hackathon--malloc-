import pytest
from memoryscape.client import Client,ident

@pytest.mark.parametrize('value',['../node','https://server','a/b','','a?secret'])
def test_identifier_rejects_paths(value):
    with pytest.raises(ValueError):ident(value)

def test_client_disallows_untrusted_plain_http():
    with pytest.raises(ValueError):Client('http://remote.internal:8000',token='test-'+('x'*30))

def test_mcp_optional_constructs():
    pytest.importorskip('mcp.server.fastmcp')
    from memoryscape.mcp_server import build_server
    assert build_server().name=='MemoryScape'
