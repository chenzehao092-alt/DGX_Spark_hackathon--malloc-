import io,json,zipfile,hashlib
import pytest
from memoryscape.exporting import export_project,import_project,scene_glb
from memoryscape.backup import backup
from memoryscape.media import glb_info
from memoryscape.errors import AppError
from test_service import built

def test_export_import_and_offline_player(service):
 p,_=built(service);raw=export_project(service,p['id'],True)
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  manifest=json.loads(z.read('manifest.json'));doc=json.loads(z.read('project.json'))
  assert len(doc['scene']['objects'])==13;assert 'player/player.js' in manifest
  for name,sha in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
  assert b'access-token' not in z.read('project.json')
 imported=import_project(service,raw);assert imported['remote_consent'] is False
 sc=service.scene(imported['id'])['scene'];assert len(sc['objects'])==13
 for o in sc['objects']:assert service.assets.get(o['asset_id'],imported['id'])['kind']=='model'
 assert glb_info(scene_glb(service,imported['id']))['triangles']>0

def test_export_without_originals_is_playable_and_minimizes_sources(service):
 p,_=built(service);raw=export_project(service,p['id'],False)
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  doc=json.loads(z.read('project.json'));assert doc['sources']==[];assert 'diary' in doc
 imported=import_project(service,raw);assert len(service.scene(imported['id'])['scene']['audio'])==1

def test_import_manifest_tamper_rejected_before_creation(service):
 p,_=built(service);raw=export_project(service,p['id']);new=io.BytesIO()
 with zipfile.ZipFile(io.BytesIO(raw)) as original,zipfile.ZipFile(new,'w') as z:
  for name in original.namelist():z.writestr(name,original.read(name)+(b' ' if name=='project.json' else b''))
 count=len(service.projects())
 with pytest.raises(AppError):import_project(service,new.getvalue())
 assert len(service.projects())==count

@pytest.mark.parametrize('path',['../escape','/absolute','a\\b','C:secret'])
def test_zip_traversal(service,path):
 b=io.BytesIO()
 with zipfile.ZipFile(b,'w') as z:z.writestr(path,b'x')
 with pytest.raises(AppError):import_project(service,b.getvalue())

def test_backup_contains_consistent_database_and_no_auth_token(service,settings,tmp_path):
 p,_=built(service);file=backup(settings,tmp_path/'backup.zip')
 with zipfile.ZipFile(file) as z:
  assert 'memoryscape.sqlite3' in z.namelist();assert 'access-token' not in z.namelist()
  manifest=json.loads(z.read('manifest.json'))
  for n,sha in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha

def test_incomplete_scene_cannot_be_exported_as_complete_glb(service,project):
 with pytest.raises(AppError):scene_glb(service,project['id'])

def test_whole_object_color_replaces_red_vertex_color(service,project):
 import numpy as np,trimesh
 from memoryscape.geometry import procedural_glb
 from memoryscape.schemas import Scene,SceneObject
 raw=procedural_glb('sphere','#ff0000')
 asset=service.assets.put(project['id'],raw,'red.glb','original')
 service.publish(project['id'],Scene(objects=[SceneObject(id='ball',label='球',asset_id=asset['id'],tint='#D7AD70',status='ready')]),0,'test')
 output=trimesh.load(io.BytesIO(scene_glb(service,project['id'])),file_type='glb',force='scene')
 mesh=next(iter(output.geometry.values()))
 assert np.all(mesh.visual.vertex_colors[:,:3]==[215,173,112])
 assert service.assets.read(asset['id'],project['id'])==raw

def test_whole_object_color_neutralizes_texture_rgb_and_preserves_alpha(service,project):
 import numpy as np,trimesh
 from PIL import Image
 from memoryscape.geometry import photo_glb
 from memoryscape.schemas import Scene,SceneObject
 pixels=Image.new('RGBA',(16,16),(255,0,0,128));buf=io.BytesIO();pixels.save(buf,format='PNG')
 raw=photo_glb(buf.getvalue());asset=service.assets.put(project['id'],raw,'red.glb','original')
 service.publish(project['id'],Scene(objects=[SceneObject(id='ball',label='球',asset_id=asset['id'],tint='#D7AD70',status='ready')]),0,'test')
 output=trimesh.load(io.BytesIO(scene_glb(service,project['id'])),file_type='glb',force='scene')
 mat=next(iter(output.geometry.values())).visual.material
 assert list(mat.baseColorFactor[:3])==[215,173,112]
 assert np.all(np.asarray(mat.baseColorTexture)[:,:,:3]==255)
 assert np.all(np.asarray(mat.baseColorTexture)[:,:,3]==128)
