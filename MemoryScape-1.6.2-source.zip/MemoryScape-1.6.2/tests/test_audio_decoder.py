import subprocess
import sys
import types
from pathlib import Path

import numpy as np
import pytest

from memoryscape import media
from memoryscape.errors import AppError


def test_system_ffmpeg_takes_precedence(monkeypatch):
    monkeypatch.setattr(media.shutil, 'which', lambda _: '/deployed/ffmpeg')
    monkeypatch.setitem(sys.modules, 'imageio_ffmpeg', None)
    assert media.ffmpeg_executable() == '/deployed/ffmpeg'


def test_bundled_decoder_does_not_require_path(monkeypatch):
    monkeypatch.setattr(media.shutil, 'which', lambda _: None)
    package = types.SimpleNamespace(get_ffmpeg_exe=lambda: '/venv/bundled-ffmpeg')
    monkeypatch.setitem(sys.modules, 'imageio_ffmpeg', package)
    assert media.ffmpeg_executable() == '/venv/bundled-ffmpeg'


def test_missing_decoder_is_specific_and_actionable(monkeypatch):
    monkeypatch.setattr(media.shutil, 'which', lambda _: None)
    monkeypatch.setitem(sys.modules, 'imageio_ffmpeg', None)
    with pytest.raises(AppError, match='一键启动') as caught:
        media.canonical_audio(b'invalid compressed data', '.mp3')
    assert caught.value.code == 'audio_decoder_unavailable'


def test_unusable_bundled_decoder_reports_dependency_problem(monkeypatch):
    monkeypatch.setattr(media.shutil, 'which', lambda _: None)

    def missing():
        raise RuntimeError('no platform binary')

    monkeypatch.setitem(sys.modules, 'imageio_ffmpeg', types.SimpleNamespace(get_ffmpeg_exe=missing))
    with pytest.raises(AppError) as caught:
        media.ffmpeg_executable()
    assert caught.value.code == 'audio_decoder_unavailable'


def test_pcm_wav_stays_offline_without_ffmpeg(monkeypatch):
    def forbidden():
        raise AssertionError('PCM WAV must not need FFmpeg')

    monkeypatch.setattr(media, 'ffmpeg_executable', forbidden)
    raw = media.encode_wav(np.zeros(16000))
    assert media.wav_info(media.canonical_audio(raw))['duration'] == 1


def test_compressed_copy_uses_bounded_offline_decode(monkeypatch):
    monkeypatch.setattr(media, 'ffmpeg_executable', lambda: '/venv/ffmpeg')
    original = b'original-mp3-bytes'
    converted = media.encode_wav(np.zeros(16000))

    def decode(args, **kwargs):
        assert Path(args[args.index('-i') + 1]).read_bytes() == original
        assert args[args.index('-protocol_whitelist') + 1] == 'file,pipe'
        assert args[args.index('-t') + 1] == '1801'
        assert args[args.index('-ar') + 1] == '16000'
        assert args[args.index('-ac') + 1] == '1'
        assert kwargs['check'] and kwargs['timeout'] == 90
        assert kwargs['stdout'] == subprocess.DEVNULL
        Path(args[-1]).write_bytes(converted)

    monkeypatch.setattr(media.subprocess, 'run', decode)
    kind, mime, metadata = media.inspect(original, 'birthday.MP3')
    assert kind == 'audio' and mime == 'audio/mpeg'
    assert metadata['duration'] == 1 and metadata['needs_conversion']
    assert original == b'original-mp3-bytes'


def test_decoder_failure_does_not_expose_process_stderr(monkeypatch):
    monkeypatch.setattr(media, 'ffmpeg_executable', lambda: '/venv/ffmpeg')

    def fail(args, **kwargs):
        raise subprocess.CalledProcessError(1, args, stderr=b'private input path')

    monkeypatch.setattr(media.subprocess, 'run', fail)
    with pytest.raises(AppError, match='音频解码失败') as caught:
        media.canonical_audio(b'invalid', '.mp3')
    assert 'private input path' not in str(caught.value)
