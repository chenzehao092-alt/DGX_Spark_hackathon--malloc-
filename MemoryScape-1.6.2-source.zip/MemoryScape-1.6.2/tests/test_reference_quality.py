"""Visual-review orchestration contracts use synthetic images and an explicit critic double.

These are not evidence that any real photo/LLM/model met the quality thresholds.
"""
from types import SimpleNamespace
import pytest
from pydantic import ValidationError
from memoryscape.config import Settings
from memoryscape.errors import AppError,ProviderError
from memoryscape.db import dumps,digest
from memoryscape.geometry import procedural_glb
from memoryscape.jobs import Worker
from memoryscape.pipeline import Pipeline
from memoryscape.reference_quality import ReferenceReview,rejection_reasons
from memoryscape.schemas import ProjectCreate,Scene,SceneObject,Generation,GeometryOptions


def accepted(**updates):
    return dict(object_id='table',verdict='accept',target_present=True,target_count=1,
                other_subjects=[],appearance_preserved=True,parts_complete=True,
                background_clean=True,reasons=['单一桌子及自身桌布、桌腿'],**updates)


@pytest.mark.parametrize('update',[
    {'verdict':'reject'},{'verdict':'uncertain'},{'target_present':False},
    {'target_count':0},{'target_count':2},{'other_subjects':['瓶子','礼物']},
    {'appearance_preserved':False},{'parts_complete':False},{'background_clean':False},
    {'object_id':'wrong'},
])
def test_accept_flag_cannot_override_a_failed_condition(update):
    report=ReferenceReview.model_validate({**accepted(),**update})
    assert rejection_reasons(report,'table')


@pytest.mark.parametrize('update',[
    {'target_present':'true'},{'target_count':'1'},{'other_subjects':['x'*301]},
    {'reasons':['x'*501]},{'reasons':[]},{'command':'run arbitrary code'},
])
def test_critic_protocol_is_strict_and_bounded(update):
    with pytest.raises(ValidationError):ReferenceReview.model_validate({**accepted(),**update})


def seed(service,png):
    pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    src=service.add_source(pid,png,'source.png','scene',rights=True)
    ref=service.assets.put(pid,png,'table-reference.png','generated',[src['id']])
    obj=SceneObject(id='table',label='桌子',kind='furniture',generation=Generation(
        strategy='generate3d',primary_source=src['id'],geometry_model='geometry',
        options=GeometryOptions(textured=False)))
    return pid,src,ref,obj


class Critic:
    def __init__(self,report):self.report=report;self.calls=0;self.remote_calls=[];self.images=None
    def chat(self,project,system,user,images):
        self.calls+=1;self.images=images
        if isinstance(self.report,Exception):raise self.report
        return self.report
    def remote(self,ctx,name,capability,**kw):
        self.remote_calls.append(capability)
        return {'data':procedural_glb('box'),'model':'contract-test-only'}


class Context:
    def __init__(self,pid):self.project=pid;self.events=[]
    def check(self):pass
    def emit(self,kind,body):self.events.append((kind,body))


def test_valid_report_checks_both_images_and_records_automated_scope(service,png):
    pid,src,ref,obj=seed(service,png);provider=Critic(accepted());ctx=Context(pid)
    report=Pipeline(service,provider).review_reference(ctx,obj,ref['id'])
    assert len(provider.images)==2 and provider.calls==1
    assert report['reference_asset_id']==ref['id']
    assert 'not-perfect' in report['scope']
    assert ctx.events[0][0]=='reference.review_accepted'


def test_content_rejection_does_not_retry_until_the_critic_agrees(service,png):
    pid,src,ref,obj=seed(service,png)
    provider=Critic({**accepted(),'other_subjects':['瓶子','餐具']});ctx=Context(pid)
    with pytest.raises(AppError,match='未继续生成三维模型') as err:
        Pipeline(service,provider).review_reference(ctx,obj,ref['id'])
    assert err.value.code=='reference_quality_failed'
    assert provider.calls==1 and provider.remote_calls==[]
    assert service.assets.read(ref['id'],pid)==png
    assert ctx.events[-1][0]=='reference.review_rejected'


def test_critic_503_is_not_schema_retried_or_replaced_with_procedural_geometry(service,png):
    pid,src,ref,obj=seed(service,png);provider=Critic(ProviderError('HTTP 503',code='provider_transient'))
    with pytest.raises(ProviderError):Pipeline(service,provider).review_reference(Context(pid),obj,ref['id'])
    assert provider.calls==1 and provider.remote_calls==[]


def test_build_quality_gate_runs_before_geometry_even_with_cached_asset(service,settings,png):
    settings.reference_review=True
    settings.reference_review_policy='strict'
    pid,src,ref,obj=seed(service,png);p=service.project(pid)
    scene=Scene(objects=[obj]);provider=Critic({**accepted(),'parts_complete':False})
    job=service.enqueue(pid,'build',{'scene':scene.model_dump(),'base_version':0,
        'input_revision':p['input_revision'],'source_meta':service.sources(pid)})
    old=service.assets.put(pid,procedural_glb('box'),'cached.glb','generated')
    data={'object':obj.model_dump(),'style':p['style'],'mode':p['mode']}
    data['object']['generation'].pop('frame_target',None)
    for name,value in [('reference:table',{'asset_id':ref['id']}),
                       ('asset:table',{'asset_id':old['id'],'provenance':'generated'})]:
        service.db.execute('INSERT INTO steps(job,name,input_hash,status,result,attempt,updated) VALUES(?,?,?,?,?,1,0)',
            (job['id'],name,digest(data),'succeeded',dumps(value)))
    assert Worker(service,Pipeline(service,provider)).run_once()
    out=service.job(job['id'])
    assert provider.calls==1 and provider.remote_calls==[]
    assert out['status']!='succeeded'
    assert out['result']['failures']['asset:table']
    assert out['result']['scene']['objects'][0]['asset_id'] is None
    assert any(s['name']=='quality:table' and s['status']=='failed' for s in out['steps'])


def test_valid_critic_allows_geometry_and_is_checkpointed(service,settings,png):
    settings.reference_review=True
    pid,src,ref,obj=seed(service,png);p=service.project(pid);provider=Critic(accepted())
    job=service.enqueue(pid,'build',{'scene':Scene(objects=[obj]).model_dump(),'base_version':0,
        'input_revision':p['input_revision'],'source_meta':service.sources(pid)})
    assert Worker(service,Pipeline(service,provider)).run_once()
    out=service.job(job['id']);assert out['status']=='succeeded',out['error']
    assert provider.calls==1 and provider.remote_calls==['geometry.generate']
    assert any(s['name']=='quality:table' and s['status']=='succeeded' for s in out['steps'])


def test_isolated_generation_does_not_inherit_whole_scene_style(service,png):
    pid,src,ref,obj=seed(service,png)
    obj.generation.image_mode='edit';obj.generation.image_model='image'
    obj.generation.image_prompt='只保留原图桌子，完整桌腿，不含蛋糕'
    obj.description='落地完整桌子，补全不可见的桌腿'
    captured=[]
    provider=SimpleNamespace(remote=lambda ctx,name,capability,**kw:
        (captured.append(kw['prompt']) or {'data':png,'model':'image'}))
    ctx=SimpleNamespace(project=pid,job={'payload':{}})
    p={**service.project(pid),'style':'生日派对环境、礼物、气球和蜡烛'}
    Pipeline(service,provider)._reference(ctx,obj,p)
    assert '不是创作一个完整场景' in captured[0]
    assert p['style'] not in captured[0]
    assert '本次唯一主体：桌子' in captured[0]
    assert obj.description in captured[0]


@pytest.mark.parametrize('mode',['edit','text2image'])
def test_generated_3d_reference_appends_oblique_contract_and_stores_actual_prompt(service,png,mode):
    pid,src,ref,obj=seed(service,png)
    obj.generation.image_mode=mode;obj.generation.image_model='image'
    obj.generation.image_prompt='只生成正视图（冲突的导演描述，仅用于测试执行端覆盖）'
    if mode=='text2image':obj.generation.primary_source=None
    calls=[]
    provider=SimpleNamespace(remote=lambda ctx,name,capability,**kw:
        (calls.append((capability,kw)) or {'data':png,'model':'image-double'}))
    ctx=SimpleNamespace(project=pid,job={'payload':{}})
    out=Pipeline(service,provider)._reference(ctx,obj,service.project(pid))
    prompt=calls[0][1]['prompt'];meta=service.assets.get(out['asset_id'],pid)['meta']
    assert calls[0][0]==('image.edit' if mode=='edit' else 'image.generate')
    assert prompt.index('执行端建模视角要求')>prompt.index('只生成正视图')
    assert '三分之四斜视图' in prompt and '30–45' in prompt and '10–20' in prompt
    assert '不是纯正视' in prompt and '不是' in prompt and '单张' in prompt
    assert meta['prompt']==prompt and meta['view_requirement']['mode']=='three_quarter'
    assert meta['view_requirement']['unseen_surfaces']=='inferred-not-source-evidence'


@pytest.mark.parametrize('strategy,mode,stage,expected',[
    ('generate3d','original',None,None),('generate3d','crop',None,None),
    ('photo','edit',None,None),('generate3d','edit','retexture','preserve'),
])
def test_original_flat_assets_and_shape_preserving_texture_do_not_force_camera(service,png,strategy,mode,stage,expected):
    pid,src,ref,obj=seed(service,png)
    obj.generation.strategy=strategy;obj.generation.image_mode=mode
    obj.generation.image_prompt='保留指定主体' if mode=='edit' else ''
    payload={'repair_actions':{'table':{'stage':stage}}} if stage else {}
    calls=[]
    provider=SimpleNamespace(remote=lambda ctx,name,capability,**kw:
        (calls.append(kw) or {'data':png,'model':'image-double'}))
    ctx=SimpleNamespace(project=pid,job={'payload':payload})
    out=Pipeline(service,provider)._reference(ctx,obj,service.project(pid))
    meta=service.assets.get(out['asset_id'],pid)['meta']
    assert meta.get('view_requirement',{}).get('mode')==expected
    assert all('执行端建模视角要求' not in call['prompt'] for call in calls)
    if stage=='retexture':assert '保持来源图片的镜头视角' in calls[0]['prompt']


@pytest.mark.parametrize('view,evidence',[
    ('front','只有正面'),('side','只有侧面'),('top','只有顶面'),
    ('multiview','拼贴'),('uncertain','看不清'),('three_quarter',''),
])
def test_accept_flag_cannot_override_missing_oblique_evidence(view,evidence):
    report=ReferenceReview.model_validate({**accepted(),'view':view,'view_evidence':evidence})
    assert not rejection_reasons(report,'table')  # Unchanged original photos remain supported.
    assert rejection_reasons(report,'table',require_oblique=True)


@pytest.mark.parametrize('view',['front','three_quarter'])
def test_reference_critic_receives_actual_view_contract_without_extra_paid_retry(service,png,view):
    pid,src,ref,obj=seed(service,png)
    ref=service.assets.put(pid,png,'oblique.png','generated',[src['id']],
        {'view_requirement':{'mode':'three_quarter'}})
    class CapturingCritic(Critic):
        def chat(self,project,system,user,images):
            import json
            self.user=json.loads(user)
            return super().chat(project,system,user,images)
    provider=CapturingCritic({**accepted(),'view':view,'view_evidence':'对应可见表面的测试证据'})
    pipeline=Pipeline(service,provider)
    if view=='front':
        with pytest.raises(AppError,match='斜视图'):pipeline.review_reference(Context(pid),obj,ref['id'])
    else:
        assert pipeline.review_reference(Context(pid),obj,ref['id'])['view_requirement']['mode']=='three_quarter'
    assert provider.user['view_requirement']['mode']=='three_quarter'
    assert provider.calls==1 and provider.remote_calls==[]


def test_reference_review_is_required_by_default_in_production():
    assert Settings().reference_review is True


@pytest.mark.parametrize('brain',[None,['brain.plan'],['brain.plan','vision.understand']])
def test_missing_visual_director_is_blocked_before_allocating_gpu_work(service,settings,png,brain):
    settings.reference_review=True
    settings.reference_review_policy='strict'
    pid,src,ref,obj=seed(service,png)
    settings.test_models={'geometry':{'enabled':True,'url':'http://127.0.0.1:9103',
        'capabilities':['geometry.generate'],'require_token':False}}
    if brain is not None:
        settings.test_models['brain']={'enabled':True,'url':'http://127.0.0.1:9101/v1',
            'protocol':'chat','capabilities':brain,'require_token':False}
    if brain is None or 'vision.understand' not in brain:
        with pytest.raises(AppError):service.check_build_capabilities(Scene(objects=[obj]))
    else:service.check_build_capabilities(Scene(objects=[obj]))
    assert service.project(pid)['head']==0

@pytest.mark.parametrize('report',[
    {**accepted(),'other_subjects':['凳子']},
    ProviderError('HTTP 503',code='provider_transient'),
])
def test_workflow_first_quality_warning_still_runs_real_branch_contract(service,settings,png,report):
    settings.reference_review=True;settings.reference_review_policy='warn'
    pid,src,ref,obj=seed(service,png);p=service.project(pid);provider=Critic(report)
    job=service.enqueue(pid,'build',{'scene':Scene(objects=[obj]).model_dump(),'base_version':0,
        'input_revision':p['input_revision'],'source_meta':service.sources(pid)})
    assert Worker(service,Pipeline(service,provider)).run_once()
    out=service.job(job['id'])
    assert out['status']=='succeeded' and provider.remote_calls==['geometry.generate']
    assert out['result']['quality_warnings'][0]['quality_accepted'] is False
    assert out['result']['quality_policy']=='warn'
    assert any(s['name']=='quality:table' and s['status']=='succeeded' for s in out['steps'])

def test_quality_warning_never_swallows_cancellation(service,settings,png):
    from memoryscape.errors import Cancelled
    settings.reference_review_policy='warn'
    pid,src,ref,obj=seed(service,png)
    with pytest.raises(Cancelled):Pipeline(service,Critic(Cancelled())).check_reference(Context(pid),obj,ref['id'])

def test_reference_review_policy_rejects_typo(tmp_path):
    with pytest.raises(ValueError,match='strict or warn'):
        Settings(data_dir=tmp_path,reference_review_policy='ignored').initialize()
