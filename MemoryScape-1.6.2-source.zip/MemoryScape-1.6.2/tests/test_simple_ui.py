"""RC2 compatibility and novice-screen support. Does not use GPU model weights."""
import json
from memoryscape.schemas import Scene, SceneObject, Generation
from memoryscape.db import uid, dumps


def test_simple_page_has_one_prompt_and_no_inspector(client):
    html=client.get('/').text
    assert 'id="chatInput"' in html
    for old in ['id="objectTab"','id="sourceRole"','id="nodeButton"','data-right=','id="reviewButton"']:
        assert old not in html
    for key in ['undoButton','historyButton','exportButton','uploadButton']:
        assert f'id="{key}"' in html
    assert client.get('/web/simple.js').status_code==200
    assert client.get('/web/app.js').headers['cache-control']=='no-store'


def test_remove_unused_source_preserves_immutable_file_and_advances_inputs(client,png):
    p=client.post('/api/projects',json={'title':'简单回忆'}).json();b='/api/projects/'+p['id']
    s=client.post(b+'/sources',files={'file':('photo.png',png,'image/png')},data={'rights_confirmed':'true'}).json()
    before=client.get(b).json()['input_revision']
    assert client.delete(b+'/sources/'+s['id']).json()['original_retained']
    assert client.get(b+'/sources').json()==[]
    assert client.get(b+'/assets/'+s['id']).content==png
    assert client.get(b).json()['input_revision']==before+1


def test_remove_source_cannot_cross_projects(client,png):
    p=client.post('/api/projects',json={}).json();q=client.post('/api/projects',json={}).json()
    s=client.post('/api/projects/'+p['id']+'/sources',files={'file':('x.png',png)},data={'rights_confirmed':'true'}).json()
    assert client.delete('/api/projects/'+q['id']+'/sources/'+s['id']).status_code==404
    assert len(client.get('/api/projects/'+p['id']+'/sources').json())==1


def test_running_work_protects_its_sources(client):
    p=client.post('/api/demo').json();b='/api/projects/'+p['id'];s=client.get(b+'/sources').json()[0]
    client.post(b+'/plan')
    assert client.delete(b+'/sources/'+s['id']).status_code==409


def test_historical_sources_cannot_be_removed(client):
    p=client.post('/api/demo').json();b='/api/projects/'+p['id']
    j=client.post(b+'/plan').json();client.app.state.worker.run_once()
    plan=client.get('/api/jobs/'+j['id']).json()['result']
    client.post(b+'/plans/'+plan['plan_id']+'/confirm',json={'expected_version':0,'expected_input_revision':p['input_revision']})
    client.app.state.worker.run_once()
    scene=client.get(b+'/scene').json()['scene'];source=next(o['reference_ids'][0] for o in scene['objects'] if o['reference_ids'])
    r=client.delete(b+'/sources/'+source)
    assert r.status_code==400 and '已经用于' in r.json()['message']
    assert client.get(b+'/assets/'+source).status_code==200


def test_plan_stores_user_prompt_for_recovered_conversation(client):
    p=client.post('/api/demo').json();b='/api/projects/'+p['id']
    j=client.post(b+'/plan').json()
    assert j['payload']['ui_prompt']==p['requirements']
    client.app.state.worker.run_once()
    assert client.get(b+'/plans').json()[0]['status']=='pending'


def test_dismissing_proposal_is_persistent_idempotent_and_cannot_apply(client):
    p=client.post('/api/projects',json={}).json();b='/api/projects/'+p['id'];s=client.app.state.service
    pid=uid('edit_');body={'base_version':0,'explanation':'保持原样','operations':[]}
    s.db.execute('INSERT INTO proposals(id,project,body,status,created) VALUES(?,?,?,"pending",?)',(pid,p['id'],dumps(body),1))
    assert client.post(b+'/proposals/'+pid+'/dismiss').json()['status']=='dismissed'
    assert client.post(b+'/proposals/'+pid+'/dismiss').status_code==200
    assert client.get(b+'/proposals').json()[0]['status']=='dismissed'
    assert client.post(b+'/proposals/'+pid+'/apply').status_code==409
    assert client.get(b).json()['head']==0


def test_dismiss_cannot_cross_project_or_reject_accepted(client):
    p=client.post('/api/projects',json={}).json();q=client.post('/api/projects',json={}).json();s=client.app.state.service
    pid=uid('edit_');s.db.execute('INSERT INTO proposals(id,project,body,status,created) VALUES(?,?,?,"accepted",?)',(pid,p['id'],dumps({'base_version':0,'explanation':'','operations':[]}),1))
    assert client.post('/api/projects/'+q['id']+'/proposals/'+pid+'/dismiss').status_code==404
    assert client.post('/api/projects/'+p['id']+'/proposals/'+pid+'/dismiss').status_code==409


def test_no_real_configuration_still_does_not_fake_generation(client):
    p=client.post('/api/projects',json={'mode':'real','remote_consent':True}).json()
    assert client.post('/api/projects/'+p['id']+'/plan').status_code==502
    assert client.get('/api/projects/'+p['id']+'/scene').json()['scene']['objects']==[]
