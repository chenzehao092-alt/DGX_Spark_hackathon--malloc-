import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from desktop_node import validate_project_path


@pytest.mark.parametrize('path', [
    '/data/chenzh/experiments/memoryscape-1.5',
    '/home/spark-user/apps/memoryscape-1.5',
    '/srv/memoryscape-demo',
])
def test_explicit_dedicated_remote_directory_is_portable(path):
    assert validate_project_path(path) == path


@pytest.mark.parametrize('path', [
    '/', '/home/user', '/data', '/memoryscape-1.5', 'memoryscape-1.5',
    '/home/user/../memoryscape-1.5', '/home/user/./memoryscape-1.5',
    '/home//memoryscape-1.5', '/home/user/memoryscape-1.5/',
    '/home/user/memoryscape-', '/home/user/memoryscape-1.5;echo-bad',
    '/home/user/memoryscape-1.5\n', None,
])
def test_broad_relative_or_ambiguous_remote_paths_are_rejected(path):
    with pytest.raises(ValueError):
        validate_project_path(path)
