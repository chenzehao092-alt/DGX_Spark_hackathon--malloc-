"""Loopback-only auto-login (/auth/local) tests.

Uses httpx AsyncClient + ASGITransport with an explicit TCP peer so we can
simulate a browser on 127.0.0.1 as well as a non-loopback client. Covers:
fresh auto-login (302 + ms_session cookie + clean redirect), cookie reuse for
API, wrong/missing token rejection, non-loopback rejection, manual no-session
visit creating a private cookie, remote/cross-site requests not creating one,
and the existing POST /api/session flow.
"""
import asyncio

import httpx
import pytest

from memoryscape.config import Settings
from memoryscape.api import create_app

TOKEN = 'test-only-random-looking-access-token-2026'


def _settings(tmp_path):
    return Settings(data_dir=tmp_path / 'data',
                    config_file=tmp_path / 'models.toml',
                    token=TOKEN,
                    start_worker=False).initialize()


async def _scenario(settings, fn, peer='127.0.0.1', host='127.0.0.1'):
    async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=create_app(settings), client=(peer, 54321)),
            base_url=f'http://{host}') as c:
        return await fn(c)


def _run(settings, fn, **kwargs):
    return asyncio.run(_scenario(settings, fn, **kwargs))


def test_auth_local_success_redirects_and_sets_cookie(tmp_path):
    settings = _settings(tmp_path)

    async def fn(c):
        r = await c.get(f'/auth/local?token={settings.token}')
        return r.status_code, r.headers.get('location'), r.headers.get('set-cookie', '')

    status, location, set_cookie = _run(settings, fn)
    assert status == 302
    assert location == '/'
    assert 'ms_session=' in set_cookie
    assert 'HttpOnly' in set_cookie
    assert 'SameSite=strict' in set_cookie


def test_auth_local_cookie_works_for_api(tmp_path):
    settings = _settings(tmp_path)

    async def fn(c):
        await c.get(f'/auth/local?token={settings.token}')
        r = await c.get('/api/config')
        return r.status_code

    assert _run(settings, fn) == 200


def test_auth_local_redirect_target_is_clean(tmp_path):
    settings = _settings(tmp_path)

    async def fn(c):
        r = await c.get(f'/auth/local?token={settings.token}')
        assert r.headers['location'] == '/'  # no token in the redirect target
        page = await c.get(r.headers['location'])
        return page.status_code, str(page.url)

    status, final_url = _run(settings, fn)
    assert status == 200
    assert 'token=' not in final_url


def test_auth_local_wrong_token_rejected(tmp_path):
    settings = _settings(tmp_path)

    async def fn(c):
        r = await c.get('/auth/local?token=wrong-token-value')
        api = await c.get('/api/config')
        return r.status_code, r.headers.get('set-cookie'), api.status_code

    status, set_cookie, api_status = _run(settings, fn)
    assert status == 403
    assert set_cookie is None
    assert api_status == 401  # no session was created


def test_auth_local_missing_token_rejected(tmp_path):
    settings = _settings(tmp_path)

    async def fn(c):
        return (await c.get('/auth/local')).status_code

    assert _run(settings, fn) == 403


def test_auth_local_non_loopback_rejected(tmp_path):
    settings = _settings(tmp_path)

    async def fn(c):
        r = await c.get(f'/auth/local?token={settings.token}')
        return r.status_code, r.headers.get('set-cookie')

    status, set_cookie = _run(settings, fn, peer='192.168.1.5')
    assert status == 403
    assert set_cookie is None


def test_direct_local_visit_automatically_establishes_private_session(tmp_path):
    settings = _settings(tmp_path)

    async def fn(c):
        page = await c.get('/')
        api = await c.get('/api/config')
        return page.status_code, page.text, api.status_code

    status, text, api_status = _run(settings, fn)
    assert status == 200
    assert 'login' in text  # index.html keeps the login section
    assert api_status == 200  # root navigation creates a session, not public API access
    assert TOKEN not in text

def test_direct_api_without_local_navigation_is_still_protected(tmp_path):
    async def fn(c):return (await c.get('/api/config')).status_code
    assert _run(_settings(tmp_path),fn)==401

def test_remote_root_does_not_create_automatic_session(tmp_path):
    async def fn(c):
        page=await c.get('/')
        return page.headers.get('set-cookie'),(await c.get('/api/config')).status_code
    assert _run(_settings(tmp_path),fn,peer='192.168.1.5')==(None,401)

@pytest.mark.parametrize('headers',[
    {'Sec-Fetch-Site':'cross-site'}, {'Sec-Fetch-Dest':'iframe'},
    {'Sec-Fetch-Mode':'cors'}, {'Origin':'https://evil.example'},
    {'X-Forwarded-For':'127.0.0.1'}, {'Forwarded':'for=127.0.0.1'},
])
def test_embedded_or_forwarded_local_request_cannot_auto_login(tmp_path,headers):
    async def fn(c):
        page=await c.get('/',headers=headers)
        return page.headers.get('set-cookie'),(await c.get('/api/config')).status_code
    assert _run(_settings(tmp_path),fn)==(None,401)

def test_local_auto_login_can_be_disabled(tmp_path):
    settings=_settings(tmp_path);settings.local_auto_login=False
    async def fn(c):
        await c.get('/')
        return (await c.get('/api/config')).status_code
    assert _run(settings,fn)==401


def test_existing_login_still_works(tmp_path):
    settings = _settings(tmp_path)

    async def fn(c):
        r = await c.post('/api/session', headers={'Authorization': 'Bearer ' + settings.token})
        api = await c.get('/api/config')
        return r.status_code, r.headers.get('set-cookie', ''), api.status_code

    status, set_cookie, api_status = _run(settings, fn)
    assert status == 200
    assert 'ms_session' in set_cookie
    assert api_status == 200
