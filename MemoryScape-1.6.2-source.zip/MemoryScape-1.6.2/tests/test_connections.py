import io
import json
import socket
from types import SimpleNamespace

import httpx
import pytest

from memoryscape.connections import ConnectionMonitor, probe_model, retry_delay
from memoryscape.config import Settings

NATIVE={'capabilities':['geometry.generate'],'execution_mode':'native',
        'fingerprint':{'runtime_revision':'memoryscape-1.5-desktop'}}
REMOTE={'project':'/srv/apps/memoryscape-test','ssh_target':'tester@spark',
        'local_port':19103,'node_port':9103,'lifecycle':'reuse'}
CONF={'enabled':True,'protocol':'node-v1','url':'http://127.0.0.1:19103',
      'token_env':'TEST_CONNECTION_TOKEN','capabilities':['geometry.generate']}


def test_connection_probe_is_read_only_and_redacts_credentials(settings,monkeypatch):
    monkeypatch.setenv('TEST_CONNECTION_TOKEN','private-test-credential')
    calls=[]
    def request(req):
        calls.append(req)
        assert req.method=='GET' and req.url.path=='/v1/capabilities'
        assert req.headers['Authorization']=='Bearer private-test-credential'
        return httpx.Response(200,json=NATIVE)
    result=probe_model(settings,'geometry',CONF,httpx.MockTransport(request))
    assert result['state']=='connected' and not result['inference_verified']
    assert len(calls)==1 and 'private-test' not in json.dumps(result)
    assert '127.0.0.1' not in json.dumps(result)


@pytest.mark.parametrize('code',[401,403])
def test_authentication_failure_is_not_treated_as_transient(settings,monkeypatch,code):
    monkeypatch.setenv('TEST_CONNECTION_TOKEN','test-token')
    result=probe_model(settings,'geometry',CONF,httpx.MockTransport(lambda _:httpx.Response(code)))
    assert result['state']=='needs_configuration' and result['reason']=='authentication_failed'


def test_missing_credential_does_not_send_anonymous_requests(settings,monkeypatch):
    monkeypatch.delenv('TEST_CONNECTION_TOKEN',raising=False)
    def forbidden(_):raise AssertionError('must not send')
    assert probe_model(settings,'geometry',CONF,httpx.MockTransport(forbidden))['reason']=='credential_missing'


@pytest.mark.parametrize('metadata',[
    {**NATIVE,'execution_mode':'contract-test'},
    {**NATIVE,'fingerprint':{'runtime_revision':'foreign-runtime'}},
    {**NATIVE,'capabilities':[]},
])
def test_foreign_runtime_or_capabilities_are_not_accepted(settings,monkeypatch,metadata):
    monkeypatch.setenv('TEST_CONNECTION_TOKEN','test-token')
    result=probe_model(settings,'geometry',CONF,httpx.MockTransport(lambda _:httpx.Response(200,json=metadata)))
    assert result['state']=='needs_configuration'


def test_backoff_is_bounded_and_does_not_collapse_to_busy_retry():
    assert retry_delay(1,jitter=lambda a,b:b)==2
    assert retry_delay(2,jitter=lambda a,b:b)==4
    for attempt in range(1,100):assert 1.6<=retry_delay(attempt)<=30


def test_cloud_checks_share_metadata_and_do_not_send_user_material(settings,monkeypatch):
    settings.test_models={k:{'enabled':True,'url':'https://example.test/v1','protocol':protocol,
        'token_env':'TEST_CONNECTION_TOKEN'} for k,protocol in [('director','chat'),('image','stepfun-images')]}
    monkeypatch.setenv('TEST_CONNECTION_TOKEN','never-print-this-token')
    calls=[]
    def request(req):
        calls.append(req);assert req.method=='GET' and not req.content
        return httpx.Response(200,json={'data':[]})
    monitor=ConnectionMonitor(settings,httpx.MockTransport(request));monitor.tick();monitor.tick()
    assert len(calls)==1
    assert all(x['state']=='connected' for x in monitor.snapshot()['models'])
    assert 'never-print' not in (settings.data_dir/'connection-status.json').read_text(encoding='utf-8')


def test_monitor_recovers_only_tunnel_not_remote_models(settings,monkeypatch):
    import memoryscape.connections as connections
    import scripts.desktop_node as node
    settings.test_models={'geometry':CONF}
    monkeypatch.setenv('TEST_CONNECTION_TOKEN','test-only-token')
    states=iter([{'model':'geometry','state':'offline'},{'model':'geometry','state':'connected'}])
    monkeypatch.setattr(connections,'probe_model',lambda *args:next(states))
    repairs=[]
    monkeypatch.setattr(node,'ensure_tunnel',lambda *args:repairs.append(args))
    monkeypatch.setattr(node,'ensure_node',lambda *args:pytest.fail('must not deploy/restart models'))
    monitor=ConnectionMonitor(settings);monkeypatch.setattr(monitor,'tunnel_config',lambda *args:REMOTE)
    monitor.tick()
    assert len(repairs)==1 and monitor.snapshot()['reconnections']==1
    assert monitor.snapshot()['models'][0]['state']=='connected'


def test_monitor_refuses_to_repair_authentication_or_protocol_failure(settings,monkeypatch):
    import memoryscape.connections as connections
    import scripts.desktop_node as node
    settings.test_models={'geometry':CONF}
    monkeypatch.setattr(connections,'probe_model',lambda *args:{'model':'geometry','state':'needs_configuration'})
    monkeypatch.setattr(node,'ensure_tunnel',lambda *args:pytest.fail('must not repair credentials/protocol'))
    monitor=ConnectionMonitor(settings);monkeypatch.setattr(monitor,'tunnel_config',lambda *args:REMOTE)
    monitor.tick();assert monitor.snapshot()['models'][0]['state']=='needs_configuration'


def test_connection_endpoint_is_authenticated_without_external_requests(client):
    assert client.get('/api/connectivity').status_code==200
    assert client.get('/api/connectivity',headers={'Authorization':''}).status_code==401


def test_monitor_thread_stops_with_application(settings):
    monitor=ConnectionMonitor(settings);monitor.start();monitor.stop()
    assert not monitor.thread.is_alive()


def test_healthy_tunnel_is_reused_without_spawning(settings,monkeypatch):
    import scripts.desktop_node as node
    opener=SimpleNamespace(open=lambda *a,**k:io.BytesIO(json.dumps(NATIVE).encode()))
    monkeypatch.setattr(node.urllib.request,'build_opener',lambda *a:opener)
    monkeypatch.setattr(node.subprocess,'Popen',lambda *a,**k:pytest.fail('must not duplicate SSH'))
    assert node.ensure_tunnel(settings,REMOTE,'test-only-token')=={'reused':True}


def test_foreign_port_is_never_stolen(settings,monkeypatch):
    import scripts.desktop_node as node
    def offline(*a,**k):raise OSError('not our gateway')
    monkeypatch.setattr(node.urllib.request,'build_opener',lambda *a:SimpleNamespace(open=offline))
    monkeypatch.setattr(node.subprocess,'Popen',lambda *a,**k:pytest.fail('must not duplicate/steal port'))
    with socket.socket() as listener:
        listener.bind(('127.0.0.1',0));listener.listen(1)
        conf={**REMOTE,'local_port':listener.getsockname()[1]}
        with pytest.raises(RuntimeError,match='占用'):node.ensure_tunnel(settings,conf,'test-only-token')


def test_spawned_forward_has_keepalive_and_never_disables_host_key_check(settings,monkeypatch):
    import scripts.desktop_node as node
    probes=iter([False,True]);calls=[]
    def check(*a,**k):
        if not next(probes):raise OSError('disconnected')
        return io.BytesIO(json.dumps(NATIVE).encode())
    monkeypatch.setattr(node.urllib.request,'build_opener',lambda *a:SimpleNamespace(open=check))
    monkeypatch.setattr(node,'record_process',lambda *a:None)
    process=SimpleNamespace(pid=4321,poll=lambda:None,terminate=lambda:None)
    monkeypatch.setattr(node.subprocess,'Popen',lambda args,**kwargs:calls.append((args,kwargs)) or process)
    with socket.socket() as reserve:
        reserve.bind(('127.0.0.1',0));port=reserve.getsockname()[1]
    assert node.ensure_tunnel(settings,{**REMOTE,'local_port':port},'test-only-token')['reused'] is False
    args,kwargs=calls[0]
    assert 'ServerAliveInterval=10' in args and 'ServerAliveCountMax=3' in args
    assert 'ExitOnForwardFailure=yes' in args and '-T' in args
    assert not any('StrictHostKeyChecking=no' in x for x in args)
    assert 'test-only-token' not in str(args)
