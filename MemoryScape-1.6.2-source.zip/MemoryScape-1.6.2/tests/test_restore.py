import importlib.util,json,zipfile
from pathlib import Path
import pytest
from memoryscape.backup import backup
from memoryscape.schemas import ProjectCreate
from memoryscape.service import Service
from memoryscape.config import Settings

spec=importlib.util.spec_from_file_location('restore_script',Path(__file__).parents[1]/'scripts/restore_backup.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

def test_private_backup_restore(tmp_path):
    settings=Settings(data_dir=tmp_path/'original',token='restore-test-token-'+'x'*24,start_worker=False,test_models={}).initialize()
    svc=Service(settings);p=svc.create_project(ProjectCreate(title='恢复验证'))
    a=svc.add_source(p['id'],b'private test diary','test.txt','diary',rights=True)
    j=svc.enqueue(p['id'],'plan',{'base_version':0,'input_revision':1})
    archive=backup(settings,tmp_path/'private.zip');target=module.restore(archive,tmp_path/'restored')
    restored=Service(Settings(data_dir=target,token='new-restore-test-token-'+'x'*24,start_worker=False,test_models={}).initialize())
    assert restored.project(p['id'])['title']=='恢复验证'
    assert restored.assets.read(a['id'],p['id'])==b'private test diary'
    assert restored.job(j['id'])['status']=='cancelled'
    with pytest.raises(ValueError):module.restore(archive,target)

def test_restore_rejects_extra_path_before_writing(tmp_path):
    source=tmp_path/'bad.zip'
    with zipfile.ZipFile(source,'w') as z:z.writestr('../attack','no');z.writestr('manifest.json','{}')
    with pytest.raises(ValueError):module.restore(source,tmp_path/'target')
    assert not (tmp_path/'target').exists() and not (tmp_path/'attack').exists()
