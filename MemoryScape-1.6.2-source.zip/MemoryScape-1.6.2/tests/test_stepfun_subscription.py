from types import SimpleNamespace

import httpx
import pytest

from memoryscape.config import Settings
from memoryscape.errors import ProviderError
from memoryscape.providers import Providers
from memoryscape.schemas import ProjectCreate
from memoryscape.service import Service
from memoryscape.settings_api import StepFunUpdate, apply_stepfun, STEP_PLAN_URL, STEPFUN_URL


def configured(tmp_path, monkeypatch, image_url=STEPFUN_URL):
    monkeypatch.setenv('DIRECTOR_TOKEN', 'test-only-saved-stepfun-key')
    path = tmp_path / 'models.toml'
    path.write_text(f'''[models.director]
enabled=true
url="{STEPFUN_URL}"
model="step-1o-turbo-vision"
[models.image]
enabled=true
protocol="stepfun-images"
url="{image_url}"
model="step-image-edit-2"
token_env="DIRECTOR_TOKEN"
capabilities=["image.edit"]
''', encoding='utf-8')
    return Settings(data_dir=tmp_path/'data', config_file=path).initialize()


def test_step_plan_switch_preserves_vision_director_and_secret(tmp_path, monkeypatch):
    settings = configured(tmp_path, monkeypatch)
    view = apply_stepfun(settings, StepFunUpdate(image_api_mode='step_plan'))
    assert view['image']['base_url'] == STEP_PLAN_URL
    assert view['image']['api_mode'] == 'step_plan'
    assert view['director']['base_url'] == STEPFUN_URL
    assert view['director']['model'] == 'step-1o-turbo-vision'
    assert view['image']['token_configured']
    assert 'test-only-saved-stepfun-key' not in str(view)


@pytest.mark.parametrize('url', [STEP_PLAN_URL, 'https://api.stepfun.ai/step_plan/v1'])
def test_refresh_key_does_not_reset_subscription_url(tmp_path, monkeypatch, url):
    settings = configured(tmp_path, monkeypatch, url)
    apply_stepfun(settings, StepFunUpdate(api_key='test-only-new-stepfun-key'))
    assert settings.models()['image']['url'] == url


def test_explicit_standard_selection_restores_standard_path(tmp_path, monkeypatch):
    settings = configured(tmp_path, monkeypatch, STEP_PLAN_URL)
    apply_stepfun(settings, StepFunUpdate(image_api_mode='standard'))
    assert settings.models()['image']['url'] == STEPFUN_URL


def test_blank_key_without_saved_secret_makes_no_config_changes(tmp_path, monkeypatch):
    monkeypatch.delenv('DIRECTOR_TOKEN', raising=False)
    settings = Settings(data_dir=tmp_path/'data', config_file=tmp_path/'models.toml').initialize()
    with pytest.raises(ValueError, match='API Key'):
        apply_stepfun(settings, StepFunUpdate(image_api_mode='step_plan'))
    assert not settings.config_file.exists()


def test_subscription_post_is_real_path_without_billing_fallback(tmp_path, monkeypatch, png):
    import base64
    settings = configured(tmp_path, monkeypatch, STEP_PLAN_URL)
    service = Service(settings)
    project = service.create_project(ProjectCreate(mode='real', remote_consent=True))['id']
    calls = []
    def reply(req):
        calls.append(req)
        assert req.url.path == '/step_plan/v1/images/edits'
        assert req.url.host == 'api.stepfun.com'
        return httpx.Response(200, headers={'x-request-id':'subscription-request-123'},
                              json={'data':[{'b64_json':base64.b64encode(png).decode()}]})
    provider = Providers(service, transport=httpx.MockTransport(reply))
    result = provider.stepfun_image('image', SimpleNamespace(project=project, check=lambda:None), 'image.edit', png, '保留蛋糕', {})
    assert result['remote_id'] == 'subscription-request-123'
    assert len(calls) == 1
    assert provider.inference_status('image')['http_status'] == 200


def test_explicit_international_region_is_supported_without_switching_director(tmp_path, monkeypatch):
    settings = configured(tmp_path, monkeypatch)
    view = apply_stepfun(settings, StepFunUpdate(image_api_mode='step_plan',image_api_region='international'))
    assert view['image']['base_url'] == 'https://api.stepfun.ai/step_plan/v1'
    assert view['image']['api_region'] == 'international'
    assert view['director']['base_url'] == STEPFUN_URL


def test_billing_switch_keeps_existing_international_region(tmp_path, monkeypatch):
    settings = configured(tmp_path, monkeypatch, 'https://api.stepfun.ai/v1')
    view = apply_stepfun(settings, StepFunUpdate(image_api_mode='step_plan'))
    assert view['image']['base_url'] == 'https://api.stepfun.ai/step_plan/v1'


@pytest.mark.parametrize('status', [402, 403, 429, 503])
def test_error_diagnostics_are_bounded_redacted_and_not_replayed(tmp_path, monkeypatch, png, status):
    import base64
    settings = configured(tmp_path, monkeypatch, STEP_PLAN_URL)
    service = Service(settings)
    project = service.create_project(ProjectCreate(mode='real', remote_consent=True))['id']
    secret = 'test-only-saved-stepfun-key'
    calls = []
    def reply(req):
        calls.append(req)
        return httpx.Response(status, headers={'x-request-id':'request-for-support-123'}, json={
            'error': {'code':'subscription_quota_exceeded', 'message':
                      f'Bearer {secret}\n{settings.token} {base64.b64encode(secret.encode()).decode()} ' + 'a'*20000}})
    provider = Providers(service, transport=httpx.MockTransport(reply))
    with pytest.raises(ProviderError) as exc:
        provider.stepfun_image('image', SimpleNamespace(project=project, check=lambda:None), 'image.edit', png, '生日蛋糕', {})
    assert f'HTTP {status}' in str(exc.value)
    assert 'request-for-support-123' in str(exc.value)
    assert len(calls) == 1
    # Oversized JSON is deliberately omitted, but the request ID is retained.
    assert secret not in str(exc.value) and settings.token not in str(exc.value)
    assert len(str(exc.value)) < 800
    state = provider.inference_status('image')
    assert state['request_id'] == 'request-for-support-123'
    assert secret not in str(state) and settings.token not in str(state)


def test_structured_upstream_message_survives_without_secrets(tmp_path, monkeypatch, png):
    settings = configured(tmp_path, monkeypatch, STEP_PLAN_URL)
    service = Service(settings)
    project = service.create_project(ProjectCreate(mode='real', remote_consent=True))['id']
    provider = Providers(service, transport=httpx.MockTransport(lambda r:httpx.Response(503,
        headers={'x-request-id':'rid-safe'}, json={'error':{'code':'overloaded',
            'message':'Capacity unavailable: Bearer test-only-saved-stepfun-key'}})))
    with pytest.raises(ProviderError, match='overloaded') as exc:
        provider.stepfun_image('image', SimpleNamespace(project=project, check=lambda:None), 'image.edit', png, '生日蛋糕', {})
    assert 'Capacity unavailable' in str(exc.value)
    assert 'test-only-saved-stepfun-key' not in str(exc.value)
    assert provider.inference_status('image')['error_code'] == 'overloaded'


def test_html_error_body_is_not_persisted(tmp_path, monkeypatch, png):
    settings = configured(tmp_path, monkeypatch, STEP_PLAN_URL)
    service = Service(settings)
    project = service.create_project(ProjectCreate(mode='real', remote_consent=True))['id']
    provider = Providers(service, transport=httpx.MockTransport(lambda r:httpx.Response(503,
        headers={'x-request-id':'rid-html'}, text='<html>private prompt and token</html>')))
    with pytest.raises(ProviderError) as exc:
        provider.stepfun_image('image', SimpleNamespace(project=project, check=lambda:None), 'image.edit', png, '生日蛋糕', {})
    assert '<html>' not in str(exc.value)
    assert 'error_message' not in provider.inference_status('image')


def test_concurrent_references_send_only_one_request_to_overloaded_engine(tmp_path, monkeypatch, png):
    import threading
    import time
    from concurrent.futures import ThreadPoolExecutor
    settings = configured(tmp_path, monkeypatch, STEP_PLAN_URL)
    service = Service(settings)
    project = service.create_project(ProjectCreate(mode='real', remote_consent=True))['id']
    calls=[]
    gate=threading.Barrier(3)
    def reply(req):
        calls.append(req)
        time.sleep(.05)
        return httpx.Response(503,json={'error':{'code':'engine_overloaded'}})
    def run(_):
        # Distinct Providers instances still serialize the same endpoint.
        provider=Providers(service,transport=httpx.MockTransport(reply))
        gate.wait(timeout=2)
        with pytest.raises(ProviderError):
            provider.stepfun_image('image',SimpleNamespace(project=project,check=lambda:None),'image.edit',png,'生日蛋糕',{})
    with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,range(3)))
    assert len(calls)==1


def test_waiting_image_request_can_be_cancelled_without_sending(tmp_path, monkeypatch, png):
    import threading
    from concurrent.futures import ThreadPoolExecutor
    from memoryscape.errors import Cancelled
    settings=configured(tmp_path,monkeypatch,STEP_PLAN_URL)
    service=Service(settings)
    project=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    entered=threading.Event();release=threading.Event();calls=[]
    def reply(req):
        calls.append(req);entered.set()
        assert release.wait(3)
        return httpx.Response(503,json={'error':{'code':'engine_overloaded'}})
    provider=Providers(service,transport=httpx.MockTransport(reply))
    def first():
        with pytest.raises(ProviderError):
            provider.stepfun_image('image',SimpleNamespace(project=project,check=lambda:None),'image.edit',png,'生日蛋糕',{})
    with ThreadPoolExecutor(max_workers=1) as pool:
        future=pool.submit(first)
        assert entered.wait(2)
        checked=0
        def check():
            nonlocal checked
            checked+=1
            if checked>=2:raise Cancelled()
        try:
            with pytest.raises(Cancelled):
                provider.stepfun_image('image',SimpleNamespace(project=project,check=check),'image.edit',png,'寿星',{})
        finally:release.set()
        future.result()
    assert len(calls)==1
