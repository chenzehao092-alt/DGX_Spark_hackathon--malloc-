"""Ordinary setup/start must never echo the private session signing secret."""
import sys
import uvicorn
import pytest
from memoryscape import cli
from memoryscape.config import Settings

@pytest.mark.parametrize('command',['setup','serve'])
def test_launcher_does_not_echo_private_token(tmp_path,monkeypatch,capsys,command):
    settings=Settings(data_dir=tmp_path/'data',config_file=tmp_path/'models.toml',
                      token='private-test-signing-key-not-a-production-secret',start_worker=False).initialize()
    monkeypatch.setattr(cli,'Settings',lambda **kwargs:settings)
    monkeypatch.setattr(sys,'argv',['memoryscape',command])
    monkeypatch.setattr(uvicorn,'run',lambda *args,**kwargs:None)
    cli.main()
    output=capsys.readouterr().out
    assert settings.token not in output
    assert 'no access-token input is needed' in output
    assert 'Private administrator token file:' not in output
    assert (settings.data_dir/'access-token').exists() is False  # supplied secret stays private
