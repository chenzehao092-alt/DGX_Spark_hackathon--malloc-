"""Preflight structured status tests using lightweight local fake servers.

Never touches real model providers; only GET /models and /v1/capabilities
metadata endpoints are probed.
"""
import json
import os
import threading
import http.server

import pytest


class _FakeHandler(http.server.BaseHTTPRequestHandler):
    mode = 'ok'

    def do_GET(self):
        if self.mode == 'unauthorized':
            body = json.dumps({'error': 'invalid api key'}).encode()
            self.send_response(401)
        elif self.mode == 'invalid':
            body = b'this is not json'
            self.send_response(200)
        elif self.path == '/models':
            body = json.dumps({'models': [{'id': 'fake-director'}]}).encode()
            self.send_response(200)
        elif self.path == '/v1/capabilities':
            body = json.dumps({'capabilities': ['geometry.generate']}).encode()
            self.send_response(200)
        else:
            body = b'{}'
            self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


class _FakeServer:
    def __init__(self, mode='ok'):
        self.server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), _FakeHandler)
        _FakeHandler.mode = mode
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    @property
    def url(self):
        return f'http://127.0.0.1:{self.server.server_port}'

    def close(self):
        self.server.shutdown()
        self.server.server_close()


@pytest.fixture
def fake_ok():
    srv = _FakeServer('ok')
    yield srv
    srv.close()


@pytest.fixture
def fake_unauthorized():
    srv = _FakeServer('unauthorized')
    yield srv
    srv.close()


@pytest.fixture
def fake_invalid():
    srv = _FakeServer('invalid')
    yield srv
    srv.close()


def _make_settings(tmp_path, toml: str):
    from memoryscape.config import Settings
    path = tmp_path / 'models.toml'
    path.write_text(toml, encoding='utf-8')
    return Settings(data_dir=tmp_path / 'data', config_file=path,
                    token='test-only-random-looking-access-token-2026',
                    start_worker=False).initialize()


def _make_client(settings):
    from memoryscape.api import create_app
    from fastapi.testclient import TestClient
    client = TestClient(create_app(settings), headers={'Authorization': 'Bearer ' + settings.token})
    return client


def test_fake_director_connected(tmp_path, fake_ok, monkeypatch):
    monkeypatch.setenv('DIRECTOR_TOKEN', 'fake-token-abc')
    settings = _make_settings(tmp_path, f"""
[models.director]
enabled = true
protocol = "chat"
url = "{fake_ok.url}"
token_env = "DIRECTOR_TOKEN"
model = "fake-director"
require_token = true
""")
    with _make_client(settings) as client:
        data = client.post('/api/settings/preflight', json={}).json()['checks']
        assert data['director']['status'] == 'connected'
        assert data['director']['token_configured'] is True


def test_fake_geometry_connected(tmp_path, fake_ok, monkeypatch):
    monkeypatch.setenv('GEOMETRY_NODE_TOKEN', 'fake-token-xyz')
    settings = _make_settings(tmp_path, f"""
[models.geometry]
enabled = true
protocol = "node-v1"
url = "{fake_ok.url}"
token_env = "GEOMETRY_NODE_TOKEN"
require_token = true
""")
    with _make_client(settings) as client:
        data = client.post('/api/settings/preflight', json={}).json()['checks']
        assert data['geometry']['status'] == 'connected'


def test_fake_401_is_unauthorized(tmp_path, fake_unauthorized, monkeypatch):
    monkeypatch.setenv('DIRECTOR_TOKEN', 'fake-token-abc')
    settings = _make_settings(tmp_path, f"""
[models.director]
enabled = true
protocol = "chat"
url = "{fake_unauthorized.url}"
token_env = "DIRECTOR_TOKEN"
model = "fake-director"
require_token = true
""")
    with _make_client(settings) as client:
        data = client.post('/api/settings/preflight', json={}).json()['checks']
        assert data['director']['status'] == 'unauthorized'


def test_non_json_response_is_invalid_response(tmp_path, fake_invalid, monkeypatch):
    monkeypatch.setenv('DIRECTOR_TOKEN', 'fake-token-abc')
    settings = _make_settings(tmp_path, f"""
[models.director]
enabled = true
protocol = "chat"
url = "{fake_invalid.url}"
token_env = "DIRECTOR_TOKEN"
model = "fake-director"
require_token = true
""")
    with _make_client(settings) as client:
        data = client.post('/api/settings/preflight', json={}).json()['checks']
        assert data['director']['status'] == 'invalid_response'


def test_dead_address_is_unreachable(tmp_path, monkeypatch):
    monkeypatch.setenv('DIRECTOR_TOKEN', 'fake-token-abc')
    settings = _make_settings(tmp_path, """
[models.director]
enabled = true
protocol = "chat"
url = "http://127.0.0.1:1"
token_env = "DIRECTOR_TOKEN"
model = "fake-director"
require_token = true
""")
    with _make_client(settings) as client:
        data = client.post('/api/settings/preflight', json={}).json()['checks']
        assert data['director']['status'] == 'unreachable'


def test_disabled_model_is_not_configured(tmp_path):
    settings = _make_settings(tmp_path, """
[models.director]
enabled = false
protocol = "chat"
url = "http://127.0.0.1:9101"
""")
    with _make_client(settings) as client:
        data = client.post('/api/settings/preflight', json={}).json()['checks']
        assert data['director']['status'] == 'not_configured'
