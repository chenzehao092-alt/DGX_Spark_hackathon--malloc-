import json,time
import pytest
from memoryscape.schemas import *
from memoryscape.errors import AppError,Cancelled,ProviderError
from memoryscape.demo import seed_project
from memoryscape.pipeline import Pipeline
from memoryscape.jobs import Worker,JobContext
from memoryscape.db import dumps
from memoryscape.geometry import procedural_glb


def built(service):
 p=seed_project(service);pipe=Pipeline(service);w=Worker(service,pipe)
 j=service.enqueue(p['id'],'plan',{'base_version':0,'input_revision':p['input_revision']})
 assert w.run_once();j=service.job(j['id']);assert j['status']=='succeeded',j['error']
 b=service.confirm_plan(p['id'],j['result']['plan_id'],0,p['input_revision']);assert w.run_once()
 assert service.job(b['id'])['status']=='succeeded',service.job(b['id'])['error']
 return service.project(p['id']),w

def test_demo_complete_and_source_labels(service):
 p,w=built(service);sc=service.scene(p['id'])['scene'];assert p['head']==2;assert len(sc['objects'])==13
 assert sum(o['kind']=='person' for o in sc['objects'])==5
 assert all(o['status']=='ready' for o in sc['objects']);assert all(o['provenance']=='procedural' for o in sc['objects'])
 audio=sc['audio'][0];assert audio['asset_id']==audio['source_id']
 assert all('model' not in service.assets.get(o['asset_id'])['meta'] for o in sc['objects'])
def test_locks_conflicts_and_local_edit(service):
 p,w=built(service);pid=p['id'];sc=service.scene(pid)['scene'];person=sc['objects'][2];person_id=person['id']
 service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='lock',object_id=person_id,locked=True)]))
 with pytest.raises(AppError,match='锁定'):service.apply_patch(pid,Patch(base_version=3,operations=[Operation(type='tint',object_id=person_id,color='#ff0000')]))
 with pytest.raises(AppError,match='旧版本'):service.apply_patch(pid,Patch(base_version=2,operations=[]))
 balloons=[o for o in sc['objects'] if o['generation']['primitive']=='balloon'];balloon=balloons[0]
 service.apply_patch(pid,Patch(base_version=3,operations=[Operation(type='tint',object_id=balloon['id'],color='#d3b56b')]))
 now=service.scene(pid)['scene'];assert next(o for o in now['objects'] if o['id']==person_id)['asset_id']==person['asset_id']
 assert next(o for o in now['objects'] if o['id']==balloon['id'])['tint']=='#d3b56b'
 assert service.scene(pid,2)['scene']['objects'][2]['locked'] is False
 with pytest.raises(AppError):service.restore(pid,2,4)
 service.apply_patch(pid,Patch(base_version=4,operations=[Operation(type='lock',object_id=person_id,locked=False)]))
 service.restore(pid,2,5);assert service.project(pid)['head']==6

def test_plan_invalidation_on_input_or_scene_change(service):
 p=seed_project(service);w=Worker(service,Pipeline(service));j=service.enqueue(p['id'],'plan',{'base_version':0,'input_revision':p['input_revision']});w.run_once();pid=service.job(j['id'])['result']['plan_id']
 service.publish(p['id'],Scene(title='用户改过的布局'),0,'edit')
 with pytest.raises(AppError):service.confirm_plan(p['id'],pid,1,p['input_revision'])

def test_old_build_cannot_overwrite_current_version(service):
 p=seed_project(service);w=Worker(service,Pipeline(service));j=service.enqueue(p['id'],'plan',{'base_version':0,'input_revision':p['input_revision']});w.run_once();b=service.confirm_plan(p['id'],service.job(j['id'])['result']['plan_id'],0,p['input_revision'])
 scene=service.scene(p['id'])['scene'];oid=scene['objects'][0]['id']
 service.apply_patch(p['id'],Patch(base_version=1,operations=[Operation(type='caption',object_id=oid,caption='后来编辑')]))
 w.run_once();result=service.job(b['id']);assert result['status']=='needs_review';assert result['result']['candidate_only']
 assert service.project(p['id'])['head']==2;assert service.scene(p['id'])['scene']['objects'][0]['caption']=='后来编辑'

def test_checkpoint_and_job_idempotency(service,project):
 pid=project['id'];job=service.enqueue(pid,'edit',{'prompt':'test'},'key1')
 assert service.enqueue(pid,'edit',{'prompt':'test'},'key1')['id']==job['id']
 with pytest.raises(AppError):service.enqueue(pid,'edit',{'prompt':'other'},'key1')
 w=Worker(service,lambda ctx:{});j=w.claim();ctx=JobContext(service,j,w.owner);calls=[]
 assert ctx.step('one',{'x':1},lambda:calls.append(1) or {'ok':1})=={'ok':1}
 assert ctx.step('one',{'x':1},lambda:calls.append(2) or {})=={'ok':1};assert calls==[1]
 with pytest.raises(AppError):ctx.step('one',{'x':2},lambda:{})
 service.db.execute('UPDATE jobs SET cancel=1 WHERE id=?',(j['id'],))
 with pytest.raises(Cancelled):ctx.check()

def test_expired_lease_recovery(service,project):
 j=service.enqueue(project['id'],'edit',{'prompt':'x'});w=Worker(service,lambda c:{'ok':True});claim=w.claim()
 service.db.execute('UPDATE jobs SET lease=? WHERE id=?',(time.time()-1,j['id']))
 other=Worker(service,lambda c:{'ok':True});assert other.run_once();assert service.job(j['id'])['attempts']==2;assert service.job(j['id'])['status']=='succeeded'

def test_adopt_existing_asset_preserves_every_other_object(service):
 p,w=built(service);old=service.scene(p['id']);aid=service.assets.put(p['id'],procedural_glb('box'),'box.glb','original')['id']
 result=service.adopt_asset(p['id'],old['scene']['objects'][1]['id'],aid,old['version'])
 assert result['scene']['objects'][1]['provenance']=='imported'
 assert result['scene']['objects'][0]==old['scene']['objects'][0]

def test_local_regeneration_preserves_unrelated_assets(service):
 p,w=built(service);sc=service.scene(p['id']);oid=sc['scene']['objects'][-2]['id']
 result=service.apply_patch(p['id'],Patch(base_version=sc['version'],operations=[Operation(type='regenerate',object_id=oid,prompt='')]))
 assert result['job_id'];w.run_once();assert service.job(result['job_id'])['status']=='succeeded'
 new=service.scene(p['id'])['scene'];assert [o['asset_id'] for o in new['objects'] if o['id']!=oid]==[o['asset_id'] for o in sc['scene']['objects'] if o['id']!=oid]

def test_model_cannot_unlock(service):
 p,w=built(service);sc=service.scene(p['id']);oid=sc['scene']['objects'][0]['id']
 with pytest.raises(AppError):service.apply_patch(p['id'],Patch(base_version=sc['version'],operations=[Operation(type='lock',object_id=oid,locked=False)]),from_model=True)

def test_user_updates_revision_and_snapshot(service,project):
 p=service.update_project(project['id'],ProjectUpdate(expected_input_revision=0,diary='新日记'))
 assert p['input_revision']==1
 with pytest.raises(AppError):service.update_project(project['id'],ProjectUpdate(expected_input_revision=0,diary='旧客户端'))
 j=service.enqueue(p['id'],'plan',{'base_version':0,'input_revision':0});Worker(service,Pipeline(service)).run_once();assert service.job(j['id'])['status']=='failed'

class GeometryOnlyProviders:
 def __init__(self,patch=None):self.patch=patch
 def cards(self):
  return {'director':{'capabilities':['brain.plan']},'geometry':{'capabilities':['geometry.generate']}}
 def chat(self,*args,**kwargs):return self.patch.model_dump()
 def remote(self,*args,**kwargs):raise ProviderError('geometry failed')

def real_ball_project(service,png):
 p=service.create_project(ProjectCreate(title='红球',mode='real',remote_consent=True,
  budget=Budget(max_objects=1,max_generated_assets=1,max_parallel=1,max_review_rounds=0)))
 src=service.add_source(p['id'],png,'ball.png','object','红色球','红色球','',True)
 scene=Scene(title='红球测试',objects=[SceneObject(id='red_toy_ball',label='红色球',kind='prop',status='ready',
  asset_id=service.assets.put(p['id'],procedural_glb('sphere'),'ball.glb','generated')['id'],
  provenance='generated',generation=Generation(strategy='generate3d',primary_source=src['id'],geometry_model='geometry',
  image_mode='original',options=GeometryOptions(steps=4,max_faces=10000)))])
 service.publish(p['id'],scene,0,'已有红球')
 return service.project(p['id'])

def test_geometry_only_edit_adapts_color_and_blocks_reference_repaint(service,png):
 p=real_ball_project(service,png);pid=p['id']
 gold=Patch(base_version=1,explanation='把红色球改成金色。',operations=[Operation(type='tint',object_id='red_toy_ball',color='#d3b56b')])
 w=Worker(service,Pipeline(service,GeometryOnlyProviders(gold)))
 j=service.enqueue(pid,'edit',{'base_version':1,'prompt':'把球改成金色','selected_object':None});assert w.run_once()
 patch=service.job(j['id'])['result']['patch'];assert patch['operations'][0]['type']=='tint';assert patch['operations'][0]['color']=='#d3b56b'
 smooth=Patch(base_version=1,explanation='去掉球的凹凸不平。',operations=[Operation(type='regenerate',object_id='red_toy_ball',prompt='光滑的红色球')])
 w=Worker(service,Pipeline(service,GeometryOnlyProviders(smooth)))
 j=service.enqueue(pid,'edit',{'base_version':1,'prompt':'把球的凹凸不平去掉','selected_object':None});assert w.run_once()
 patch=service.job(j['id'])['result']['patch'];assert patch['operations']==[];assert '未接通图片编辑节点' in patch['explanation']

def test_all_failed_target_build_does_not_publish_failed_version(service,png):
 p=real_ball_project(service,png);pid=p['id'];scene=service.scene(pid)['scene'];scene['objects'][0]['status']='planned'
 j=service.enqueue(pid,'build',{'scene':scene,'base_version':1,'targets':['red_toy_ball'],'input_revision':p['input_revision'],
  'production':{k:v for k,v in p.items() if k in ProjectCreate.model_fields},'source_meta':service.sources(pid)})
 assert Worker(service,Pipeline(service,GeometryOnlyProviders())).run_once()
 job=service.job(j['id']);assert job['status']=='failed';assert job['result']['candidate_only'] is True
 assert service.project(pid)['head']==1

@pytest.mark.parametrize('prompt',['光滑的金色球','去掉蓝色球凹凸','金色玩具球'])
def test_unsupported_regenerate_never_silently_becomes_tint(service,png,prompt):
 p=real_ball_project(service,png)
 patch=Patch(base_version=1,operations=[Operation(type='regenerate',object_id='red_toy_ball',prompt=prompt)])
 out=Pipeline(service,GeometryOnlyProviders()).adapt_patch_to_capabilities(patch,service.memory(p['id']))
 assert out.operations==[]

def test_unsupported_direct_patch_and_empty_patch_do_not_commit(service,png):
 p=real_ball_project(service,png)
 with pytest.raises(ProviderError):
  service.apply_patch(p['id'],Patch(base_version=1,operations=[Operation(type='regenerate',object_id='red_toy_ball',prompt='去凹凸')]))
 with pytest.raises(AppError,match='没有可执行'):
  service.apply_patch(p['id'],Patch(base_version=1,operations=[]))
 assert service.project(p['id'])['head']==1
 assert not service.db.all('SELECT id FROM jobs WHERE project=?',(p['id'],))

def test_failed_regeneration_keeps_original_version_and_asset(service):
 p,w=built(service);pid=p['id'];before=service.scene(pid)
 oid=before['scene']['objects'][0]['id']
 result=service.apply_patch(pid,Patch(base_version=before['version'],operations=[Operation(type='regenerate',object_id=oid,prompt='')]))
 assert result['version']==before['version'];assert service.scene(pid)==before
 def fail_reference(*args,**kwargs):raise ProviderError('controlled failure')
 import unittest.mock
 with unittest.mock.patch('memoryscape.pipeline.procedural_glb',side_effect=fail_reference):assert w.run_once()
 assert service.job(result['job_id'])['status']=='failed'
 assert service.scene(pid)==before
