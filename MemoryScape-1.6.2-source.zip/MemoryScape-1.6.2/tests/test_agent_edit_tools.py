"""Executable contracts: restoration evidence, exact dimensions and isolation."""
import json
import pytest
from pydantic import ValidationError
from memoryscape.schemas import Scene,SceneObject,Generation,Transform,Relation,Patch,Operation,SizeEdit,ProjectCreate,ScenePlan
from memoryscape.geometry import procedural_glb
from memoryscape.edit_tools import resized_transform
from memoryscape.layout import validate_plan
from memoryscape.memory import validate_edit_intent
from memoryscape.errors import AppError
from memoryscape.pipeline import Pipeline
from memoryscape.jobs import Worker


def history(service):
    pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    asset=service.assets.put(pid,procedural_glb('box'),'base.glb','procedural')
    base=SceneObject(id='base',label='底座',asset_id=asset['id'],status='ready',
        transform=Transform(size=[1.8,.1,.6],fit='stretch'),tint='#998877')
    poster=SceneObject(id='poster',label='海报',generation=Generation(strategy='photo'),
        transform=Transform(position=[0,.1,0],size=[1.5,2.25,.01]))
    scene=Scene(objects=[poster,base],relations=[Relation(type='on',subject='poster',target='base')])
    service.publish(pid,scene,0,'历史底座')
    service.apply_patch(pid,Patch(base_version=1,operations=[Operation(type='remove',object_id='base')]))
    return pid,base


@pytest.mark.parametrize('text',['把底座加回来','恢复底座','还原之前的底座','把支座找回来','恢复底座原来的尺寸','把底座恢复到第1版','把底座恢复到删除前的原始尺寸和外观，海报和边框保持不变。'])
def test_restore_retrieves_full_snapshot_and_ignores_wrong_selected_object(service,text):
    pid,base=history(service);m=service.memory(pid,'poster',text)
    assert m['restore_intent']['required']=={'base':1}
    assert not m['edit_intent']['remove_authorized']
    assert m['historical_objects'][0]['object']==base.model_dump()
    good=Patch(base_version=2,operations=[Operation(type='restore_object',object_id='base',source_version=1)])
    validate_edit_intent(good,m)
    result=service.apply_patch(pid,good)
    assert result['job_id'] is None and result['version']==3
    assert result['scene']['objects'][-1]==base.model_dump()
    assert result['scene']['objects'][0]==service.scene(pid,2)['scene']['objects'][0]
    assert result['scene']['relations'][0]['offset']==[0,0,0]
    assert service.scene(pid,2)['scene']['objects'][0]['id']=='poster'


def test_readded_bad_replacement_still_recalls_pre_deletion_original(service):
    pid,base=history(service);sc=Scene.model_validate(service.scene(pid)['scene'])
    bad=base.model_copy(deep=True);bad.transform=Transform(size=[.1,.1,.1]);bad.tint=None
    sc.objects.append(bad);service.publish(pid,sc,2,'旧缺陷的小底座')
    m=service.memory(pid,query='恢复底座原来的尺寸')
    assert m['restore_intent']['required']=={'base':1}
    result=service.apply_patch(pid,Patch(base_version=3,operations=[Operation(type='restore_object',object_id='base',source_version=1)]))
    assert result['scene']['objects'][-1]==base.model_dump()
    assert len(result['scene']['objects'])==2


@pytest.mark.parametrize('text',[
    '把刚才删除的底座加回来，恢复它原来的网格、宽高深、位置和颜色，不要重新计算大小。海报和其他内容保持不变。',
    '恢复底座，不要移动海报，也不要放大底座',
    '恢复底座不要重新计算大小',
    '不要移动海报，恢复底座',
])
def test_restore_preservation_negation_is_not_a_recovery_veto(service,text):
    pid,base=history(service);m=service.memory(pid,'poster',text)
    assert m['restore_intent']['authorized']
    assert m['restore_intent']['required']=={'base':1}
    assert m['restore_intent']['restore_only']
    assert not m['edit_intent']['remove_authorized']
    patch=Patch(base_version=2,operations=[Operation(type='restore_object',object_id='base',source_version=1)])
    validate_edit_intent(patch,m)
    applied=service.apply_patch(pid,patch)
    assert applied['scene']['objects'][-1]==base.model_dump()


@pytest.mark.parametrize('text',['不要恢复底座','底座别加回来','不要把底座加回去','恢复底座，但不要恢复底座','do not restore base','可以恢复底座吗？'])
def test_explicit_recovery_veto_or_question_never_authorizes_restore(service,text):
    pid,_=history(service);m=service.memory(pid,'poster',text)
    assert not m['restore_intent']['authorized']
    patch=Patch(base_version=2,operations=[Operation(type='restore_object',object_id='base',source_version=1)])
    with pytest.raises(AppError):validate_edit_intent(patch,m)


@pytest.mark.parametrize('text',['不要恢复底座','是否恢复底座？','恢复海报上的文字','恢复不存在的物品'])
def test_restore_cannot_guess_or_execute_negation(service,text):
    pid,_=history(service);m=service.memory(pid,query=text)
    with pytest.raises(AppError):validate_edit_intent(Patch(base_version=2,operations=[Operation(type='restore_object',object_id='base',source_version=1)]),m)
    validate_edit_intent(Patch(base_version=2),m)


@pytest.mark.parametrize('ops',[
    [Operation(type='add',object_id='base',new_object=SceneObject(id='base',label='底座'))],
    [Operation(type='restore_object',object_id='base',source_version=0)],
    [Operation(type='restore_object',object_id='base',source_version=1),Operation(type='transform',object_id='poster',transform=Transform())],
    []])
def test_restore_intent_rejects_guesses_extra_changes_or_empty_success(service,ops):
    pid,_=history(service);m=service.memory(pid,query='把底座加回来')
    with pytest.raises(AppError):validate_edit_intent(Patch(base_version=2,operations=ops),m)


@pytest.mark.parametrize('source,oid',[(2,'base'),(0,'base'),(1,'unknown')])
def test_restore_bad_snapshot_is_atomic(service,source,oid):
    pid,_=history(service);before=service.scene(pid)
    with pytest.raises(AppError):service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='restore_object',object_id=oid,source_version=source)]))
    assert service.scene(pid)==before


def test_restore_keeps_later_user_positions_and_no_rebuild_jump(service):
    from memoryscape.layout import solve_layout
    pid,_=history(service);sc=Scene.model_validate(service.scene(pid)['scene']);sc.objects[0].transform.position=[2,3,1]
    service.publish(pid,sc,2,'用户后来挪了海报')
    result=service.apply_patch(pid,Patch(base_version=3,operations=[Operation(type='restore_object',object_id='base',source_version=1)]))
    assert result['scene']['objects'][0]['transform']['position']==[2,3,1]
    assert solve_layout(Scene.model_validate(result['scene'])).objects[0].transform.position==[2,3,1]


def test_restore_budget_lock_duplicate_and_noop_guards(service):
    pid,_=history(service)
    restore=Operation(type='restore_object',object_id='base',source_version=1)
    with pytest.raises(AppError):service.apply_patch(pid,Patch(base_version=2,operations=[restore,restore]))
    service.apply_patch(pid,Patch(base_version=2,operations=[restore]))
    with pytest.raises(AppError,match='实际变化'):service.apply_patch(pid,Patch(base_version=3,operations=[restore]))
    service.apply_patch(pid,Patch(base_version=3,operations=[Operation(type='lock',object_id='base',locked=True)]))
    with pytest.raises(AppError,match='锁定'):service.apply_patch(pid,Patch(base_version=4,operations=[restore]))


def test_restore_rejects_missing_asset_and_missing_dependencies(service):
    pid,_=history(service)
    sc=Scene.model_validate(service.scene(pid,1)['scene']);sc.objects[1].generation=Generation(strategy='reuse',reuse_object='poster')
    service.publish(pid,sc,2,'依赖海报的历史模型')
    service.apply_patch(pid,Patch(base_version=3,operations=[Operation(type='remove',object_id='base'),Operation(type='remove',object_id='poster')]))
    with pytest.raises((AppError,ValidationError)):service.apply_patch(pid,Patch(base_version=4,operations=[Operation(type='restore_object',object_id='base',source_version=3)]))
    assert service.project(pid)['head']==4


@pytest.mark.parametrize('data',[{}, {'scale':1.2,'width':2}, {'width':0}, {'depth':float('nan')}, {'scale':float('inf')}])
def test_size_edit_rejects_invalid_input(data):
    with pytest.raises(ValidationError):SizeEdit.model_validate(data)


@pytest.mark.parametrize('op',[
    {'type':'restore_object','object_id':'base'},
    {'type':'restore_object','object_id':'base','source_version':1,'transform':{}},
    {'type':'resize','object_id':'base','size_edit':{'width':2},'source_version':1},
    {'type':'resize','object_id':'base'}])
def test_new_operations_have_no_ignored_operands(op):
    with pytest.raises(ValidationError):Operation.model_validate(op)


def test_partial_resize_preserves_pose_and_axes(service):
    pid,base=history(service);service.restore(pid,1,2)
    patch=Patch(base_version=3,operations=[Operation(type='resize',object_id='base',size_edit=SizeEdit(width=2.16))])
    m=service.memory(pid,'poster','底座宽度增加20%，其他保持不变');validate_edit_intent(patch,m)
    result=service.apply_patch(pid,patch);t=result['scene']['objects'][1]['transform']
    assert t==Transform(size=[2.16,.1,.6],fit='stretch').model_dump()
    assert result['scene']['objects'][0]==service.scene(pid,3)['scene']['objects'][0]
    assert result['scene']['objects'][1]['asset_id']==base.asset_id and result['job_id'] is None


@pytest.mark.parametrize('text,axis,value',[('底座宽度改为180厘米',0,1.8),('底座高度设为100mm',1,.1),('底座深度到0.6米',2,.6),('底座宽增加20%',0,2.16)])
def test_numeric_intent_units_and_relative(service,text,axis,value):
    pid,_=history(service);service.restore(pid,1,2)
    intent=service.memory(pid,query=text)['dimension_intent']
    assert intent['target_id']=='base' and intent['values'][axis]==pytest.approx(value)


def test_dimension_intent_rejects_wrong_axes_unrequested_pose_and_wrong_object(service):
    pid,_=history(service);service.restore(pid,1,2);m=service.memory(pid,query='底座宽度改为2米，其他不变')
    wrong=[Operation(type='resize',object_id='base',size_edit=SizeEdit(height=2)),
           Operation(type='resize',object_id='poster',size_edit=SizeEdit(scale=2)),
           Operation(type='transform',object_id='base',transform=Transform(position=[1,0,0],size=[2,.1,.6],fit='stretch'))]
    for op in wrong:
        with pytest.raises(AppError):validate_edit_intent(Patch(base_version=3,operations=[op]),m)


def test_uniform_box_size_bug_blocked_in_plan_add_and_transform(service):
    pid,_=history(service);bad=SceneObject(id='new',label='长方底座',transform=Transform(size=[1.8,.1,.6]))
    with pytest.raises(AppError,match='stretch'):service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='add',object_id='new',new_object=bad)]))
    with pytest.raises(AppError,match='stretch'):validate_plan(ScenePlan(summary='底座',scene=Scene(objects=[bad])),service.project(pid),[],{})
    service.restore(pid,1,2)
    with pytest.raises(AppError,match='stretch'):service.apply_patch(pid,Patch(base_version=3,operations=[Operation(type='transform',object_id='base',transform=bad.transform)]))


def test_photo_uniform_scale_and_overflow():
    photo=SceneObject(id='poster',label='海报',generation=Generation(strategy='photo'),transform=Transform(size=[1,2,.01]))
    assert resized_transform(photo,SizeEdit(scale=1.2)).size==[1.2,2.4,.012]
    with pytest.raises(AppError):resized_transform(photo,SizeEdit(width=2))
    with pytest.raises(AppError):resized_transform(photo,SizeEdit(scale=50))


def test_pipeline_repairs_new_guess_to_verified_restore(service):
    pid,_=history(service)
    class Provider:
        calls=0
        def cards(self):return {}
        def chat(self,project,system,user,images):
            self.calls+=1;context=json.loads(user.split('\n上一轮')[0]);m=context['memory']
            assert m['restore_intent']['required']=={'base':1} and m['skill_cards']
            if self.calls==1:return {'base_version':2,'operations':[{'type':'add','object_id':'base','new_object':{'id':'base','label':'底座'}}]}
            return {'base_version':2,'operations':[{'type':'restore_object','object_id':'base','source_version':1}]}
    provider=Provider();job=service.enqueue(pid,'edit',{'prompt':'把底座加回来','base_version':2,'selected_object':'poster'})
    assert Worker(service,Pipeline(service,provider)).run_once()
    result=service.job(job['id']);assert result['status']=='succeeded' and provider.calls==2
    patch=Patch.model_validate(result['result']['patch']);assert patch.operations[0].type=='restore_object'
    applied=service.apply_patch(pid,patch,from_model=True,proposal_id=result['result']['proposal_id'])
    assert service.scene(pid)['note']==patch.explanation and applied['job_id'] is None
    assert result['result']['validation']['restore_sources']=={'base':1}


def test_skills_endpoint_requires_authentication(client):
    assert client.get('/api/skills').status_code==200
    assert client.get('/api/skills',headers={'Authorization':''}).status_code==401


def test_restore_temporal_word_does_not_hide_actual_delete_clause(service):
    pid,_=history(service);m=service.memory(pid,query='恢复到底座删除前的尺寸，然后删除海报')
    assert m['edit_intent']['required_remove_ids']==['poster']


def test_resize_contact_constraint_uses_result_dimensions(service):
    from memoryscape.layout import validate_contact_edit
    pid,_=history(service);service.restore(pid,1,2);scene=Scene.model_validate(service.scene(pid)['scene'])
    patch=Patch(base_version=3,operations=[Operation(type='resize',object_id='base',size_edit=SizeEdit(height=.2))])
    with pytest.raises(AppError,match='紧贴'):validate_contact_edit(patch,scene,'底座高改为0.2米，海报不要悬空，紧贴顶部')


def test_preserved_object_names_are_not_modification_targets(service):
    pid,_=history(service);service.restore(pid,1,2)
    m=service.memory(pid,'poster','底座宽度增加20%，海报和边框保持不变，位置不变')
    assert m['dimension_intent']['target_id']=='base' and m['dimension_intent']['size_only']
    validate_edit_intent(Patch(base_version=3,operations=[Operation(type='resize',object_id='base',size_edit=SizeEdit(width=2.16))]),m)
    m=service.memory(pid,'poster','恢复底座到第1版，海报保持不变')
    assert m['restore_intent']['required']=={'base':1}


def test_restoration_cannot_introduce_support_cycle(service):
    pid,_=history(service);sc=Scene.model_validate(service.scene(pid)['scene'])
    sc.objects.append(SceneObject(id='base',label='新的底座'))
    sc.relations=[Relation(type='on',subject='base',target='poster')]
    service.publish(pid,sc,2,'后来用户改变了支撑方向')
    with pytest.raises(AppError,match='循环'):service.apply_patch(pid,Patch(base_version=3,operations=[Operation(type='restore_object',object_id='base',source_version=1)]))
    assert service.project(pid)['head']==3


def test_procedural_free_text_is_not_feature_evidence(service):
    pid,_=history(service);service.restore(pid,1,2)
    sc=Scene.model_validate(service.scene(pid)['scene']);sc.objects[1].generation.image_prompt='round corners'
    service.publish(pid,sc,3,'历史文字，未改变网格')
    contract=next(c for c in service.memory(pid,query='底座是圆角吗')['geometry_contracts'] if c['object_id']=='base')
    assert contract['free_text_shape_prompt_executed'] is False
    assert contract['editable_shape']=='dimensions_of_defined_primitive'


def test_audio_edit_targets_the_candidate_scene_not_old_copy(service):
    from memoryscape.schemas import AudioTrack
    pid,_=history(service);scene=Scene.model_validate(service.scene(pid)['scene'])
    scene.audio=[AudioTrack(id='sound',label='原声')];service.publish(pid,scene,2,'添加声音')
    result=service.apply_patch(pid,Patch(base_version=3,operations=[Operation(type='audio',audio_id='sound',gain=.5)]))
    assert result['scene']['audio'][0]['gain']==.5
