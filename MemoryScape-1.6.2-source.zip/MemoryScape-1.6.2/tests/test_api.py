import io,json
from fastapi.testclient import TestClient
from memoryscape.api import create_app

def test_auth_origin_and_headers(settings):
 with TestClient(create_app(settings)) as c:
  assert c.get('/health').status_code==200
  assert c.get('/api/projects').status_code==401
  assert c.post('/api/session',headers={'Authorization':'Bearer wrong'}).status_code==401
  assert c.post('/api/session',headers={'Authorization':'Bearer '+settings.token,'Origin':'https://evil.example'}).status_code==403
  r=c.post('/api/session',headers={'Authorization':'Bearer '+settings.token});assert r.status_code==200
  assert 'httponly' in r.headers['set-cookie'].lower()
  assert c.get('/api/projects').status_code==200
  r=c.get('/');assert "script-src 'self'" in r.headers['content-security-policy']
  assert c.get('/',headers={'Host':'evil.example'}).status_code==400
  c.delete('/api/session');assert c.get('/api/projects').status_code==401

def test_demo_end_to_end_api(client):
 p=client.post('/api/demo').json();pid=p['id'];base=f'/api/projects/{pid}'
 j=client.post(base+'/plan').json();assert j['status']=='queued';assert client.app.state.worker.run_once()
 plan=client.get('/api/jobs/'+j['id']).json()['result'];assert len(plan['plan']['scene']['objects'])==13
 b=client.post(base+'/plans/'+plan['plan_id']+'/confirm',json={'expected_version':0,'expected_input_revision':p['input_revision']});assert b.status_code==200
 assert client.app.state.worker.run_once();job=client.get('/api/jobs/'+b.json()['id']).json();assert job['status']=='succeeded'
 assert client.get(base+'/scene').json()['version']==2
 assert client.get(base+'/export').content[:2]==b'PK'
 assert client.get(base+'/scene.glb').content[:4]==b'glTF'
 events=client.get(base+'/events').json();assert any(e['kind']=='step.completed' for e in events)

def test_upload_clone_and_export_privacy(client,png):
 p=client.post('/api/projects',json={'title':'回忆'}).json();base='/api/projects/'+p['id']
 assert client.post(base+'/sources',files={'file':('x.png',png,'image/png')},data={'role':'person'}).status_code==422
 r=client.post(base+'/sources',files={'file':('x.png',png,'image/png')},data={'role':'person','rights_confirmed':'true'});assert r.status_code==200
 s=r.json();assert client.get(base+'/assets/'+s['id']).content==png
 assert client.post(base+'/sources/'+s['id']+'/clone',json={'subject':'主角','crop':{'x':0,'y':0,'width':.5,'height':1}}).status_code==200
 assert len(client.get(base+'/sources').json())==2

def test_no_configuration_does_not_fake_real_models(client):
 p=client.post('/api/projects',json={'mode':'real','remote_consent':True}).json()
 r=client.post('/api/projects/'+p['id']+'/plan');assert r.status_code==502;assert '没有已配置' in r.text
 assert client.post('/api/preflight').json()['checks']==[]

def test_job_cancel_queued(client):
 p=client.post('/api/demo').json();j=client.post('/api/projects/'+p['id']+'/plan').json()
 assert client.post('/api/jobs/'+j['id']+'/cancel').json()['status']=='cancelled'
 assert not client.app.state.worker.run_once()
 assert client.post('/api/jobs/'+j['id']+'/retry').json()['status']=='queued'

def test_static_modules_and_api_contract(client):
 for name in ['app.js','viewer.js','glb.js','audio.js','player.js','style.css']:
  assert client.get('/web/'+name).status_code==200
 doc=client.get('/api/openapi').json();assert '/api/projects/{id}/renders' in doc['paths']

def test_retry_missing_edit_capability_does_not_requeue(client,png):
 from test_service import real_ball_project
 from memoryscape.db import dumps
 s=client.app.state.service;p=real_ball_project(s,png);scene=s.scene(p['id'])['scene']
 scene['objects'][0]['generation']['image_mode']='edit'
 j=s.enqueue(p['id'],'build',{'scene':scene,'base_version':1,'input_revision':p['input_revision'],'targets':['red_toy_ball']})
 s.db.execute('UPDATE jobs SET status="failed" WHERE id=?',(j['id'],))
 r=client.post('/api/jobs/'+j['id']+'/retry')
 assert r.status_code==502;assert s.job(j['id'])['status']=='failed';assert s.project(p['id'])['head']==1
