"""Settings API tests: save/read model config, local-only secret storage,
backup + rollback safety, and secret non-disclosure."""
import json
import os

import pytest


def _write_models(tmp_path, text: str):
    path = tmp_path / 'models.toml'
    path.write_text(text, encoding='utf-8')
    return path


@pytest.mark.parametrize('newline',['','\n'])
def test_replacing_last_line_does_not_drop_new_fields_in_same_section(newline):
    import tomllib
    from memoryscape.settings_api import _update_toml_lines
    text='[models.image]\nenabled=false\ncapabilities=["image.edit"]'+newline
    result=tomllib.loads(_update_toml_lines(text,{'image':{'capabilities':['image.edit'],'url':'http://127.0.0.1:19112'}}))
    assert result['models']['image']['url'].endswith('19112')
    assert result['models']['image']['capabilities']==['image.edit']


def test_clean_install_cloud_settings_preserve_complete_disabled_model_cards(tmp_path):
    from memoryscape.config import Settings
    from memoryscape.settings_api import apply_stepfun, StepFunUpdate
    from memoryscape.providers import Providers
    from memoryscape.service import Service
    settings = Settings(data_dir=tmp_path/'data', config_file=tmp_path/'configs/models.toml',
                        token='test-only-clean-install-access-token-2026', start_worker=False).initialize()
    view = apply_stepfun(settings, StepFunUpdate(api_key='test-only-cloud-key-12345'))
    models = settings.models()
    assert view['director']['enabled'] and view['image']['enabled']
    providers = Providers(Service(settings))
    assert providers.choose('brain.plan') == 'director'
    assert providers.choose('image.edit') == 'image'
    assert models['geometry']['capabilities'] == ['geometry.generate','geometry.texture']
    assert not models['geometry']['enabled'] and not models['audio']['enabled']
    assert 'test-only-cloud-key-12345' not in settings.config_file.read_text('utf-8')
    assert 'test-only-cloud-key-12345' not in str(view)


_TOKEN_ENV_KEYS = ['DIRECTOR_TOKEN', 'GEOMETRY_NODE_TOKEN', 'IMAGE_NODE_TOKEN',
                   'AUDIO_NODE_TOKEN', 'ENHANCE_NODE_TOKEN', 'IMAGE_API_NODE_TOKEN']


@pytest.fixture(autouse=True)
def _clean_token_env():
    """Keep token env vars isolated between tests in this module."""
    saved = {k: os.environ.pop(k, None) for k in _TOKEN_ENV_KEYS}
    yield
    for k, v in saved.items():
        if v is not None:
            os.environ[k] = v


@pytest.fixture
def configured_settings(tmp_path):
    from memoryscape.config import Settings
    path = _write_models(tmp_path, """
[models.director]
enabled = true
label = "测试旗舰"
protocol = "chat"
url = "http://127.0.0.1:9101/v1"
token_env = "DIRECTOR_TOKEN"
model_env = "DIRECTOR_MODEL"
model = "step-1o-turbo-vision"
require_token = true
capabilities = ["brain.plan"]
custom_keep_field = "keep-me"

[models.geometry]
enabled = true
protocol = "node-v1"
url = "http://127.0.0.1:9103"
token_env = "GEOMETRY_NODE_TOKEN"
require_token = true
capabilities = ["geometry.generate"]
""")
    settings = Settings(data_dir=tmp_path / 'data', config_file=path,
                        token='test-only-random-looking-access-token-2026',
                        start_worker=False).initialize()
    return settings


@pytest.fixture
def client(configured_settings):
    from memoryscape.api import create_app
    from fastapi.testclient import TestClient
    app = create_app(configured_settings)
    with TestClient(app, headers={'Authorization': 'Bearer ' + configured_settings.token}) as c:
        yield c


def test_get_models_returns_structure_without_tokens(client):
    resp = client.get('/api/settings/models')
    assert resp.status_code == 200
    data = resp.json()
    for kind in ('director', 'geometry', 'image', 'audio'):
        assert kind in data
        assert isinstance(data[kind]['token_configured'], bool)
        assert 'token' not in data[kind]  # never a token field
        assert data[kind]['token_configured'] is False
    assert data['director']['base_url'] == 'http://127.0.0.1:9101/v1'
    assert data['director']['enabled'] is True
    # response body must not contain any secret-like value
    assert 'DIRECTOR_TOKEN' not in resp.text


def test_post_saves_models_toml_and_secrets_locally(client, configured_settings):
    secret = 'sk-local-test-secret-abc123'
    resp = client.post('/api/settings/models', json={
        'director_base_url': 'http://127.0.0.1:9999/v1',
        'director_model': 'fake-director',
        'director_token': secret,
        'geometry_url': 'http://127.0.0.1:9103',
        'geometry_token': '',
        'image_url': '',
        'image_token': '',
        'audio_url': '',
        'audio_token': '',
    })
    assert resp.status_code == 200
    assert resp.json()['director']['token_configured'] is True
    assert secret not in resp.text

    # models.toml updated, unknown field preserved
    text = configured_settings.config_file.read_text('utf-8')
    assert 'url = "http://127.0.0.1:9999/v1"' in text
    assert 'model = "fake-director"' in text
    assert 'enabled = true' in text
    assert 'custom_keep_field = "keep-me"' in text  # unknown fields kept

    # secrets file exists and contains the token, but API never returns it
    secrets_file = configured_settings.data_dir / 'local-secrets.env'
    assert secrets_file.is_file()
    stored = secrets_file.read_text('utf-8')
    assert 'DIRECTOR_TOKEN=' + secret in stored
    assert 'GEOMETRY_NODE_TOKEN=' not in stored  # empty means unchanged (not written)

    # GET still does not disclose
    again = client.get('/api/settings/models').text
    assert secret not in again


def test_post_with_backup_created(client, configured_settings):
    client.post('/api/settings/models', json={
        'director_base_url': 'http://127.0.0.1:9998/v1', 'director_token': 's2'})
    backups = list((configured_settings.data_dir).glob('settings-backup-models-*.toml'))
    assert backups, 'backup file must be created before overwrite'
    original = backups[0].read_text('utf-8')
    assert 'url = "http://127.0.0.1:9101/v1"' in original  # pre-write state


def test_clearing_url_disables_model(client, configured_settings):
    resp = client.post('/api/settings/models', json={
        'director_base_url': '', 'director_token': ''})
    assert resp.status_code == 200
    assert resp.json()['director']['enabled'] is False
    text = configured_settings.config_file.read_text('utf-8')
    assert 'enabled = false' in text


def test_invalid_url_rejected(client):
    resp = client.post('/api/settings/models', json={
        'director_base_url': 'ftp://not-http/thing', 'director_token': ''})
    assert resp.status_code == 400


def test_preflight_shape_and_not_configured(client):
    resp = client.post('/api/settings/preflight', json={})
    assert resp.status_code == 200
    data = resp.json()['checks']
    for kind in ('director', 'geometry'):
        assert kind in data
        # configured, require_token=true but token env missing -> unauthorized
        assert data[kind]['status'] == 'unauthorized'
        assert data[kind]['configured'] is True
        assert data[kind]['token_configured'] is False
    assert data['audio']['status'] == 'not_configured'
    assert data['image']['status'] == 'not_configured'


def test_preflight_does_not_send_user_materials(client):
    resp = client.post('/api/settings/preflight', json={})
    assert resp.status_code == 200
    note = resp.json()['note']
    assert '仅网络和能力检查' in note
