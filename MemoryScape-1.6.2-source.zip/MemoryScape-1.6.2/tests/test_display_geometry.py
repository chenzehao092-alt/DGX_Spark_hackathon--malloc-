"""Renderer-grounded numerical evidence; not a visual fidelity benchmark."""
import math
import pytest
from memoryscape.display_geometry import object_evidence,scene_evidence,pose_candidate,validate_review_geometry
from memoryscape.schemas import Scene,SceneObject,Generation,Transform,Relation,Operation,Patch,ProjectCreate
from memoryscape.errors import AppError
from memoryscape.geometry import procedural_glb
from memoryscape.jobs import Worker
from memoryscape.pipeline import Pipeline
from memoryscape.db import dumps


class Bounds:
    def __init__(self,values=None):self.values=values or {}
    def get(self,id,project):return {'meta':{'bounds':self.values.get(id,[[-.5,0,-.5],[.5,1,.5]])}}


def supported_scene():
    return Scene(objects=[
        SceneObject(id='table',label='桌子',asset_id='mesh_table',transform=Transform(size=[2,.8,1],fit='stretch')),
        SceneObject(id='cake',label='蛋糕',asset_id='mesh_cake',transform=Transform(position=[0,.8,0],size=[.3,.3,.3],fit='stretch'))],
        relations=[Relation(type='on',subject='cake',target='table')])


def test_uniform_actual_bounds_not_requested_height_or_geometric_centre():
    obj=SceneObject(id='table',label='桌子',transform=Transform(size=[2,8,4]))
    result=object_evidence(obj,[[-2,-1,-4],[2,1,4]])
    assert result['display_size']==[2,1,4]  # Uniform scale is .5, not [2,8,4].
    assert result['world_bounds']==[[-1,0,-2],[1,1,2]]
    assert result['floor_status']=='at_floor' and result['bottom_y']==0
    assert result['top_y']==1 and not result['visual_fidelity_verified']


@pytest.mark.parametrize('rotation,position,expected',[
    ([0,0,0],[0,0,0],[[-1,0,-3],[1,4,3]]),
    ([0,math.pi/2,0],[2,3,4],[[-1,3,3],[5,7,5]]),
    ([math.pi/2,0,0],[0,0,0],[[-1,-3,0],[1,3,4]]),
    ([0,0,math.pi/2],[0,0,0],[[-4,-1,-3],[0,1,3]])])
def test_bottom_anchor_rotation_agrees_with_renderer_axes(rotation,position,expected):
    obj=SceneObject(id='box',label='盒子',transform=Transform(position=position,rotation=rotation,size=[2,4,6],fit='stretch'))
    result=object_evidence(obj,[[-.5,-.5,-.5],[.5,.5,.5]])
    for actual,wanted in zip(result['world_bounds'],expected):assert actual==pytest.approx(wanted)


def test_missing_mesh_metadata_is_explicitly_not_actual_model_evidence():
    scene=Scene(objects=[SceneObject(id='box',label='盒子')])
    result=scene_evidence(scene,Bounds(),'test')
    assert result['objects'][0]['source']=='requested_dimensions_not_actual_mesh'
    assert result['unit']=='display_units_not_measured_metres'


def test_support_uses_uniform_display_height_not_requested_size():
    scene=supported_scene();scene.objects[0].transform.fit='uniform'
    assets=Bounds({'mesh_table':[[-1,0,-.5],[1,.4,.5]]})
    result=scene_evidence(scene,assets,'test')
    assert result['objects'][0]['top_y']==.4
    assert result['supports'][0]['gap_y']==pytest.approx(.4)
    assert result['supports'][0]['status']=='box_gap'
    assert result['supports'][0]['source']=='validated_asset_bounds'
    assert not result['supports'][0]['detailed_mesh_contact_proven']


@pytest.mark.parametrize('height',[.4,-.4])
def test_review_must_not_move_already_grounded_table_half_its_height(height):
    scene=supported_scene();after=scene.model_copy(deep=True);after.objects[0].transform.position[1]=height
    with pytest.raises(AppError) as error:validate_review_geometry(scene,after,Bounds(),'test')
    assert error.value.code=='review_geometry_conflict'


@pytest.mark.parametrize('new_height',[.5,1.2])
def test_review_resize_must_preserve_existing_cake_support_height(new_height):
    scene=supported_scene();after=scene.model_copy(deep=True);after.objects[0].transform.size[1]=new_height
    with pytest.raises(AppError) as error:validate_review_geometry(scene,after,Bounds(),'test')
    assert error.value.code=='review_geometry_conflict'


def test_joint_table_resize_and_cake_reposition_preserves_contact():
    scene=supported_scene();after=scene.model_copy(deep=True)
    after.objects[0].transform.size[1]=1.2;after.objects[1].transform.position[1]=1.2
    result=validate_review_geometry(scene,after,Bounds(),'test')
    assert result['supports'][0]['status']=='box_contact'


def test_review_can_fix_existing_below_ground_but_not_introduce_it():
    scene=Scene(objects=[SceneObject(id='box',label='盒子',transform=Transform(position=[0,-.2,0]))])
    after=scene.model_copy(deep=True);after.objects[0].transform.position[1]=0
    validate_review_geometry(scene,after,Bounds(),'test')
    with pytest.raises(AppError):validate_review_geometry(after,scene,Bounds(),'test')


def test_rotated_bounds_do_not_claim_precise_contact_or_block_uncertain_review():
    scene=supported_scene();scene.objects[0].transform.rotation[2]=.3
    after=scene.model_copy(deep=True);after.objects[0].transform.position[1]=.4
    result=validate_review_geometry(scene,after,Bounds(),'test')
    assert not result['supports'][0]['exact_for_upright_bounds']


def test_pose_simulation_is_sequential_and_does_not_mutate_input():
    scene=supported_scene();original=scene.model_dump()
    patch=Patch(base_version=1,operations=[Operation(type='resize',object_id='table',size_edit={'scale':2}),
        Operation(type='resize',object_id='table',size_edit={'scale':.5})])
    assert pose_candidate(scene,patch).model_dump()==original and scene.model_dump()==original


def add_real_table(service):
    project=service.create_project(ProjectCreate(mode='real',remote_consent=True));pid=project['id']
    table=SceneObject(id='table',label='桌子',kind='furniture',generation=Generation(primitive='table'),
        transform=Transform(size=[2,.8,1],fit='stretch'),status='ready')
    asset=service.assets.put(pid,procedural_glb('table'),'table.glb','procedural');table.asset_id=asset['id']
    service.publish(pid,Scene(objects=[table]),0,'原有落地桌子')
    return pid,table


def test_grounded_memory_includes_actual_mesh_bounds_without_inference(service):
    pid,table=add_real_table(service)
    evidence=service.memory(pid)['display_geometry']['objects'][0]
    assert evidence['asset_id']==table.asset_id and evidence['source']=='validated_asset_bounds'
    assert evidence['bottom_y']==0 and evidence['floor_status']=='at_floor'
    assert not service.db.all('SELECT * FROM jobs WHERE project=?',(pid,))


def test_legacy_bad_review_adoption_is_rejected_without_commit_or_task(service):
    pid,table=add_real_table(service);before=service.scene(pid)
    transform=table.transform.model_copy(deep=True);transform.position[1]=.4
    patch=Patch(base_version=1,operations=[Operation(type='transform',object_id='table',transform=transform)])
    job=service.enqueue(pid,'edit',{'base_version':1,'prompt':'检查当前画面的布局'})
    proposal='legacy_bad_review'
    service.db.execute('INSERT INTO proposals(id,project,body,status,created) VALUES(?,?,?,"pending",0)',(proposal,pid,dumps(patch.model_dump())))
    service.db.execute('UPDATE jobs SET kind="review",status="succeeded",result=? WHERE id=?',(dumps({'proposal_id':proposal}),job['id']))
    with pytest.raises(AppError) as error:service.apply_patch(pid,patch,from_model=True,proposal_id=proposal)
    assert error.value.code=='review_geometry_conflict'
    assert service.scene(pid)==before and service.project(pid)['head']==1
    assert service.db.one('SELECT status FROM proposals WHERE id=?',(proposal,))['status']=='pending'
    assert not service.db.all('SELECT * FROM jobs WHERE project=? AND kind="build"',(pid,))


def test_explicit_user_move_is_not_silently_overridden_by_visual_review_guard(service):
    pid,table=add_real_table(service);transform=table.transform.model_copy(deep=True);transform.position[1]=.4
    result=service.apply_patch(pid,Patch(base_version=1,operations=[Operation(type='transform',object_id='table',transform=transform)]))
    assert result['scene']['objects'][0]['transform']['position'][1]==.4


@pytest.mark.parametrize('corrects',[True,False])
def test_visual_critic_must_correct_numeric_error_within_existing_three_call_budget(service,png,corrects):
    pid,table=add_real_table(service);asset=service.assets.put(pid,png,'review.png','rendered')
    service.db.execute('INSERT INTO renders VALUES(?,?,?,?,?,?)',('numeric_review',pid,1,asset['id'],'{}',0))
    class Provider:
        calls=0
        def cards(self):return {}
        def chat(self,project,system,user,images):
            self.calls+=1
            assert 'display-geometry-v1' in user and 'bottom-centre' in user
            height=0 if corrects and self.calls>1 else .4
            transform=table.transform.model_dump();transform['position'][1]=height
            transform['position'][0]=.1
            return {'summary':'桌子位置建议','patch':{'base_version':1,'operations':[{'type':'transform','object_id':'table','transform':transform}]}}
    provider=Provider();job=service.enqueue(pid,'review',{'base_version':1,'render_ids':['numeric_review'],'prompt':'检查整体布局'})
    Worker(service,Pipeline(service,provider)).run_once();done=service.job(job['id'])
    assert provider.calls==(2 if corrects else 3)
    assert done['status']==('succeeded' if corrects else 'failed'),done['error']
    assert service.project(pid)['head']==1
    if corrects:
        assert done['result']['patch']['operations'][0]['transform']['position'][1]==0
        assert done['result']['observation']['display_geometry']['objects'][0]['bottom_y']==0
    else:
        assert not service.db.all('SELECT * FROM proposals WHERE project=?',(pid,))
