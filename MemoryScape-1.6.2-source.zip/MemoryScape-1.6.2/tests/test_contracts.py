import math
import pytest
from pydantic import ValidationError
from memoryscape.schemas import *
from memoryscape.layout import topological,solve_layout,validate_plan,task_graph,check_scene
from memoryscape.errors import AppError
from memoryscape.providers import parse_json
from memoryscape.config import endpoint

@pytest.mark.parametrize('field,value',[('position',[math.nan,0,0]),('position',[math.inf,0,0]),('position',[101,0,0]),('rotation',[90,0,0]),('size',[0,1,1]),('size',[-1,1,1]),('size',[51,1,1]),('rotation',[0,0])])
def test_transform_rejects_unsafe_values(field,value):
 with pytest.raises(ValidationError):Transform(**{field:value})
@pytest.mark.parametrize('crop',[{'x':.8,'width':.3},{'y':.9,'height':.2},{'width':0},{'x':-1},{'w':.3}])
def test_crop_contract(crop):
 with pytest.raises(ValidationError):Crop(**crop)
def test_json_rejects_duplicate_nonfinite_and_nonobject():
 for raw in ['{"a":1,"a":2}','{"a":NaN}','[]','not JSON']:
  with pytest.raises(AppError):parse_json(raw)
 assert parse_json('```json\n{"a":2}\n```')=={'a':2}
def test_extra_model_parameters_are_not_executed():
 with pytest.raises(ValidationError):GeometryOptions(shell='rm -rf /')
 with pytest.raises(ValidationError):Operation(type='shell',command='anything')
def test_dag_dependencies():
 assert topological({'a':[],'b':['a'],'c':['b']})==['a','b','c']
 for graph in [{'a':['missing']},{'a':['b'],'b':['a']}]:
  with pytest.raises(AppError):topological(graph)
def test_scene_unique_ids_and_references():
 with pytest.raises(ValidationError):Scene(objects=[SceneObject(id='a',label='A')]*2)
 with pytest.raises(ValidationError):Scene(objects=[SceneObject(id='a',label='A')],relations=[Relation(type='on',subject='a',target='b')])
def test_layout_support_and_facing():
 sc=Scene(objects=[SceneObject(id='table',label='桌',transform=Transform(size=[3,1,2])),SceneObject(id='cake',label='蛋糕'),SceneObject(id='person',label='人')],relations=[Relation(type='on',subject='cake',target='table'),Relation(type='around',subject='person',target='table',angle=0,radius=2)])
 solved=solve_layout(sc);assert solved.objects[1].transform.position==[0,1,0];assert solved.objects[2].transform.position==[0,0,2];assert check_scene(solved)==[]
 solved.objects[1].locked=True;solved.objects[1].transform.position[1]=3
 assert solve_layout(solved).objects[1].transform.position[1]==3
 assert check_scene(solved)[0]['type']=='support_mismatch'
def test_reuse_dependency_cycle():
 sc=Scene(objects=[SceneObject(id='a',label='A',generation=Generation(strategy='reuse',reuse_object='b')),SceneObject(id='b',label='B',generation=Generation(strategy='reuse',reuse_object='a'))])
 with pytest.raises(AppError):task_graph(sc)
def test_model_capability_and_reference_validation(project):
 plan=ScenePlan(summary='x',scene=Scene(objects=[SceneObject(id='cake',label='蛋糕',generation=Generation(strategy='generate3d',primary_source='photo',geometry_model='geo'))]))
 sources=[{'id':'photo','kind':'image'}]
 with pytest.raises(AppError):validate_plan(plan,project,sources,{})
 cap={'geo':{'capabilities':['geometry.generate']}}
 assert validate_plan(plan,project,sources,cap).scene.objects[0].id=='cake'
 plan.scene.objects[0].generation.image_mode='edit';plan.scene.objects[0].generation.image_model='geo'
 with pytest.raises(AppError):validate_plan(plan,project,sources,cap)
def test_generated_audio_requires_consent(project):
 plan=ScenePlan(summary='x',scene=Scene(audio=[AudioTrack(id='narration',label='旁白',strategy='tts',model='audio',prompt='hello')]))
 with pytest.raises(AppError):validate_plan(plan,project,[],{'audio':{'capabilities':['audio.tts']}})

def test_multi_object_plan_requires_isolated_scene_references(project):
 objects=[SceneObject(id=name,label=name,generation=Generation(strategy='generate3d',primary_source='photo',geometry_model='geo',options=GeometryOptions(steps=4))) for name in ['ball','cup']]
 plan=ScenePlan(summary='two objects',scene=Scene(objects=objects))
 sources=[{'id':'photo','kind':'image','role':'scene'}];caps={'geo':{'capabilities':['geometry.generate']}}
 with pytest.raises(AppError,match='未拆分'):validate_plan(plan,project,sources,caps)
 plan.scene.objects[0].generation.crop=Crop(x=0,width=.5)
 plan.scene.objects[1].generation.crop=Crop(x=.5,width=.5)
 result=validate_plan(plan,project,sources,caps)
 assert any('4 步' in w for w in result.warnings)
@pytest.mark.parametrize('url',['file:///etc/passwd','http://user:secret@localhost','http://localhost/path?q=1','ftp://localhost','http://unapproved.example:90'])
def test_operator_endpoint_guard(url):
 with pytest.raises(ValueError):endpoint({'url':url})
def test_operator_endpoint_loopback_and_https():
 assert endpoint({'url':'http://127.0.0.1:9103/'})=='http://127.0.0.1:9103'
 assert endpoint({'url':'https://models.example/v1'})=='https://models.example/v1'
