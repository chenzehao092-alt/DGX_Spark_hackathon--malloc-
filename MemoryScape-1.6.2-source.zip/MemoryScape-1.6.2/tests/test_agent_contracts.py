"""Behavioral regressions, not a visual quality benchmark or paper replication."""
import json
import time
from concurrent.futures import ThreadPoolExecutor
import pytest
from memoryscape.agent_contracts import compile_contract,target_scope,verify_local_effects,verify_build_preservation
from memoryscape.agent_budget import snapshot
from memoryscape.db import dumps
from memoryscape.errors import AppError
from memoryscape.jobs import JobContext,Worker
from memoryscape.pipeline import Pipeline
from memoryscape.schemas import Budget,Scene,SceneObject,Generation,Transform,Patch,Operation,ProjectCreate,ProjectUpdate


def scene():
    return Scene(objects=[SceneObject(id='poster',label='生日海报',generation=Generation(strategy='photo')),
        SceneObject(id='base',label='底座',transform=Transform(size=[2,.2,1],fit='stretch')),
        SceneObject(id='frame',label='海报边框',generation=Generation(primitive='frame'))])


@pytest.mark.parametrize('prompt,expected',[
    ('删除底座',['base']),('给海报边框染色',['frame']),('移动生日海报',['poster']),
    ('只放大 base',['base']),('移动base2',[]),('给框框染色',['frame']),
    ('给底座和生日海报修改配色',['base','poster']),('调整它',['poster'])])
def test_names_override_stale_selection(prompt,expected):
    result=target_scope(prompt,[o.model_dump() for o in scene().objects],'poster' if prompt=='调整它' else None)
    assert result['object_ids']==expected


@pytest.mark.parametrize('prompt',['删除底座','移动底座','调整底座','改变底座配色','给支座加宽','给托座改颜色'])
def test_contract_blocks_wrong_target(prompt):
    s=scene();memory={'objects':[o.model_dump() for o in s.objects],'current_request':prompt,'selected_object':'poster'}
    patch=Patch(base_version=1,operations=[Operation(type='tint',object_id='poster',color='#ff0000')])
    with pytest.raises(AppError) as error:compile_contract(patch,memory)
    assert error.value.code=='task_scope_violation'


@pytest.mark.parametrize('prompt',['底座放大','删除底座','底座改颜色','调整底座尺寸'])
def test_ambiguous_name_abstains_even_with_old_selection(prompt):
    objects=[o.model_dump() for o in scene().objects]+[SceneObject(id='base2',label='底座').model_dump()]
    assert target_scope(prompt,objects,'base')['needs_clarification']
    memory={'objects':objects,'current_request':prompt,'selected_object':'base'}
    with pytest.raises(AppError):compile_contract(Patch(base_version=1,operations=[Operation(type='tint',object_id='base',color='#ff0000')]),memory)
    assert compile_contract(Patch(base_version=1),memory)['scope']['needs_clarification']


@pytest.mark.parametrize('field',['label','description','caption','color','tint','locked','status','provenance','position','rotation','size','image_prompt'])
def test_unrelated_object_field_mutation_is_rejected(field):
    before=scene();after=before.model_copy(deep=True);after.objects=[o for o in after.objects if o.id!='base'];o=after.objects[0]
    if field in ('position','rotation','size'):getattr(o.transform,field)[0]+=.4
    elif field=='image_prompt':o.generation.image_prompt='not authorized'
    else:setattr(o,field,{'color':'#ff0000','tint':'#ff0000','locked':True,'status':'ready','provenance':'generated'}.get(field,'changed'))
    with pytest.raises(AppError) as error:verify_local_effects(before,after,Patch(base_version=1,operations=[Operation(type='remove',object_id='base')]))
    assert error.value.code=='task_postcondition_failed'


@pytest.mark.parametrize('field',['position','rotation','size','caption','label','color','locked','image_prompt'])
def test_tint_cannot_smuggle_other_effects(field):
    before=scene();after=before.model_copy(deep=True);o=after.objects[1];o.tint='#ff0000'
    if field in ('position','rotation','size'):getattr(o.transform,field)[0]+=.4
    elif field=='image_prompt':o.generation.image_prompt='changed'
    else:setattr(o,field,True if field=='locked' else '#ffffff' if field=='color' else 'changed')
    with pytest.raises(AppError):verify_local_effects(before,after,Patch(base_version=1,operations=[Operation(type='tint',object_id='base',color='#ff0000')]))


@pytest.mark.parametrize('field',['position','rotation','size','caption','tint','label','status','locked'])
def test_targeted_build_preserves_unrelated_object(field):
    before=scene();after=before.model_copy(deep=True);o=after.objects[0]
    if field in ('position','rotation','size'):getattr(o.transform,field)[0]+=.4
    else:setattr(o,field,True if field=='locked' else '#ff0000' if field=='tint' else 'ready' if field=='status' else 'changed')
    with pytest.raises(AppError):verify_build_preservation(before,after,{'base'})


def context(service,project,parent=None):
    job=service.enqueue(project,'edit',{},parent_job=parent)
    w=Worker(service,lambda c:{});claimed=w.claim()
    assert claimed['id']==job['id']
    return JobContext(service,claimed,w.owner)


def test_durable_root_budget_shared_with_child_after_restart(service):
    p=service.create_project(ProjectCreate(budget=Budget(max_director_calls=2,max_remote_jobs=1)))
    parent=context(service,p['id']);parent.charge('director');parent.charge('remote_job','once')
    service.db.execute('UPDATE jobs SET status="succeeded" WHERE id=?',(parent.id,))
    child=context(service,p['id'],parent.id);child.charge('director');child.charge('remote_job','once')
    with pytest.raises(AppError,match='预算'):child.charge('director')
    with pytest.raises(AppError,match='预算'):child.charge('remote_job','twice')
    assert snapshot(service,child.id)['used']=={'director':2,'remote_job':1}
    from memoryscape.service import Service
    reopened=Service(service.settings)
    assert snapshot(reopened,parent.id)['used']=={'director':2,'remote_job':1}


def test_parallel_reservation_never_exceeds_budget(service):
    p=service.create_project(ProjectCreate(budget=Budget(max_director_calls=3)))
    ctx=context(service,p['id'])
    def reserve(_):
        try:ctx.charge('director');return True
        except AppError:return False
    with ThreadPoolExecutor(max_workers=8) as pool:assert sum(pool.map(reserve,range(20)))==3
    assert snapshot(service,ctx.id)['used']['director']==3


def test_checkpoint_reuse_and_polling_cost_zero_new_calls(service,project):
    ctx=context(service,project['id']);calls=[]
    def infer():ctx.charge('director');calls.append(1);return {'ok':True}
    for _ in range(5):ctx.step('checkpoint',{},infer);ctx.check()
    assert calls==[1] and snapshot(service,ctx.id)['used']['director']==1


def test_replay_same_remote_key_does_not_reserve_twice(service,project):
    ctx=context(service,project['id'])
    with ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(lambda _:ctx.charge('remote_job','one-key'),range(20)))
    assert snapshot(service,ctx.id)['used']['remote_job']==1


def test_active_deadline_persisted_and_not_reset_by_retry(service,project):
    ctx=context(service,project['id']);ctx.check()
    service.db.execute('UPDATE agent_jobs SET started=? WHERE job=?',(time.time()-7201,ctx.id))
    with pytest.raises(AppError) as error:ctx.check()
    assert error.value.code=='agent_budget_exhausted'


def test_parent_from_other_project_is_rejected_atomically(service,project):
    parent=context(service,project['id']);other=service.create_project(ProjectCreate())
    with pytest.raises(AppError):service.enqueue(other['id'],'edit',{},parent_job=parent.id)
    assert not service.db.all('SELECT * FROM jobs WHERE project=?',(other['id'],))


def test_empty_budget_prevents_actual_chat(service):
    p=service.create_project(ProjectCreate(budget=Budget(max_director_calls=0)))
    ctx=context(service,p['id'])
    class Provider:
        def chat(self,*args):raise AssertionError('must not reach inference')
    from memoryscape.schemas import ScenePlan
    with pytest.raises(AppError) as error:Pipeline(service,Provider()).structured(ctx,'system','user',[],ScenePlan)
    assert error.value.code=='agent_budget_exhausted'


def test_review_round_cannot_reset_server_budget(service,project,png):
    pid=project['id'];asset=service.assets.put(pid,png,'render.png','rendered')
    service.db.execute('INSERT INTO renders VALUES(?,?,?,?,?,?)',('view_test',pid,0,asset['id'],'{}',time.time()))
    body={'base_version':0,'render_ids':['view_test'],'round':0}
    first=service.enqueue(pid,'review',body,'same');assert service.enqueue(pid,'review',body,'same')['id']==first['id']
    service.enqueue(pid,'review',body,'second')
    with pytest.raises(AppError) as error:service.enqueue(pid,'review',body,'third')
    assert error.value.code=='agent_budget_exhausted'


def test_review_different_project_or_old_version_cannot_consume_budget(service,project,png):
    other=service.create_project(ProjectCreate());a=service.assets.put(other['id'],png,'render.png','rendered')
    service.db.execute('INSERT INTO renders VALUES(?,?,?,?,?,?)',('other_view',other['id'],0,a['id'],'{}',time.time()))
    with pytest.raises(AppError):service.enqueue(project['id'],'review',{'base_version':0,'render_ids':['other_view']})
    assert not service.db.all('SELECT * FROM agent_reviews WHERE project=?',(project['id'],))


def test_memory_facts_cannot_be_model_claims_or_pending_candidate(service):
    p=service.create_project(ProjectCreate());pid=p['id'];service.publish(pid,scene(),0,'模型宣称删除了底座')
    service.db.remember(pid,'execution_observation',{'verified':True,'candidate_only':True,'changed_objects':[{'object_id':'poster','changed_fields':['transform']}]})
    service.db.remember(pid,'visual_review',{'claim':'底座已删除'})
    memory=service.memory(pid,query='底座在哪里？')['memory_layers']
    assert memory['facts']['version']==1 and 'base' in {o['id'] for o in memory['facts']['objects']}
    assert memory['experiences']==[]
    assert '模型宣称' not in dumps(memory['facts']) and 'claim' not in dumps(memory)


def test_verified_effect_becomes_experience_not_current_fact(service):
    p=service.create_project(ProjectCreate());pid=p['id'];service.publish(pid,scene(),0,'已有场景')
    service.apply_patch(pid,Patch(base_version=1,operations=[Operation(type='remove',object_id='base')]))
    layers=service.memory(pid,query='底座')['memory_layers']
    assert 'base' not in {o['id'] for o in layers['facts']['objects']}
    assert layers['experiences'][0]['observation']['removed_ids']==['base']
    assert layers['experiences'][0]['must_not_reexecute']


def test_legacy_project_budget_defaults_without_rewriting(service,project):
    original={'max_objects':20,'max_generated_assets':8,'max_parallel':3,'max_review_rounds':2}
    doc=service.db.one('SELECT doc FROM projects WHERE id=?',(project['id'],))['doc'];value=json.loads(doc);value['budget']=original
    service.db.execute('UPDATE projects SET doc=? WHERE id=?',(dumps(value),project['id']))
    assert service.project(project['id'])['budget']['max_director_calls']==32
    assert json.loads(service.db.one('SELECT doc FROM projects WHERE id=?',(project['id'],))['doc'])['budget']==original


@pytest.mark.parametrize('operation,wrong',[
    (Operation(type='tint',object_id='base',color='#ff0000'),{'tint':'#00ff00'}),
    (Operation(type='clear_tint',object_id='base'),{'tint':'#00ff00'}),
    (Operation(type='caption',object_id='base',caption='18岁'),{'caption':'17岁'}),
    (Operation(type='lock',object_id='base',locked=True),{'locked':False}),
    (Operation(type='resize',object_id='base',size_edit={'width':3}),{'size':[4,.2,1]})])
def test_allowed_field_but_wrong_result_value_is_rejected(operation,wrong):
    before=scene();after=before.model_copy(deep=True);obj=after.objects[1]
    if 'size' in wrong:obj.transform.size=wrong['size']
    else:
        for key,value in wrong.items():setattr(obj,key,value)
    with pytest.raises(AppError):verify_local_effects(before,after,Patch(base_version=1,operations=[operation]))


def test_review_inherits_published_build_root(service,project,png):
    ctx=context(service,project['id']);ctx.charge('director')
    service.publish(project['id'],scene(),0,'produced',ctx.id)
    service.db.execute('UPDATE jobs SET status="succeeded" WHERE id=?',(ctx.id,))
    asset=service.assets.put(project['id'],png,'view.png','rendered')
    service.db.execute('INSERT INTO renders VALUES(?,?,?,?,?,?)',('root_view',project['id'],1,asset['id'],'{}',time.time()))
    review=service.enqueue(project['id'],'review',{'base_version':1,'render_ids':['root_view'],'round':0})
    assert snapshot(service,review['id'])['root_job']==ctx.id
    assert snapshot(service,review['id'])['used']['director']==1


@pytest.mark.parametrize('field',['position','rotation','fit'])
def test_free_target_build_cannot_change_explicit_pose(field):
    before=scene();after=before.model_copy(deep=True)
    if field=='fit':after.objects[1].transform.fit='uniform'
    else:getattr(after.objects[1].transform,field)[0]+=.25
    with pytest.raises(AppError):verify_build_preservation(before,after,{'base'})


def test_review_repairs_unexecutable_axis_resize_before_showing_proposal(service,png):
    p=service.create_project(ProjectCreate(mode='real',remote_consent=True));pid=p['id']
    original=Scene(objects=[SceneObject(id='person',label='人物',generation=Generation(strategy='generate3d'),transform=Transform(size=[.5,.4,.2]))])
    service.publish(pid,original,0,'真实模型的展示尺寸')
    asset=service.assets.put(pid,png,'view.png','rendered')
    service.db.execute('INSERT INTO renders VALUES(?,?,?,?,?,?)',('review_executable',pid,1,asset['id'],'{}',time.time()))
    class Provider:
        calls=0
        def cards(self):return {}
        def chat(self,project,system,user,images):
            self.calls+=1
            edit={'height':1} if self.calls==1 else {'scale':2.5}
            return {'summary':'尺寸建议','patch':{'base_version':1,'operations':[{'type':'resize','object_id':'person','size_edit':edit}]}}
    provider=Provider();job=service.enqueue(pid,'review',{'base_version':1,'render_ids':['review_executable'],'prompt':'检查整体布局'})
    Worker(service,Pipeline(service,provider)).run_once();done=service.job(job['id'])
    assert done['status']=='succeeded',done['error']
    assert provider.calls==2 and snapshot(service,job['id'])['used']['director']==2
    patch=Patch.model_validate(done['result']['patch']);assert patch.operations[0].size_edit.scale==2.5
    assert service.project(pid)['head']==1  # No automatic edit or regeneration.
    applied=service.apply_patch(pid,patch,from_model=True,proposal_id=done['result']['proposal_id'])
    assert applied['job_id'] is None
    assert applied['scene']['objects'][0]['transform']['size']==[1.25,1.0,.5]
