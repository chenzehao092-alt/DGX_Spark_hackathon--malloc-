import pytest
from memoryscape.pipeline import Pipeline
from memoryscape.schemas import ScenePlan
from memoryscape.providers import parse_json
from memoryscape.errors import ProviderError


class Context:
    project='test-only'
    def check(self):pass
    def emit(self,*args):pass


def test_invalid_json_is_repaired_without_accepting_partial_objects(service):
    class Provider:
        calls=[]
        def chat(self,project,system,user,images):
            self.calls.append(user)
            if len(self.calls)==1:return parse_json('{"summary":"incomplete",')
            return {'summary':'完整方案','scene':{}}
    provider=Provider();value=Pipeline(service,provider).structured(Context(),'system','user',[],ScenePlan)
    assert value.summary=='完整方案' and len(provider.calls)==2
    assert 'incomplete' in provider.calls[1]


def test_invalid_json_repair_has_three_attempt_limit(service):
    class Provider:
        calls=0
        def chat(self,*a):
            self.calls+=1;return parse_json('{"duplicate":1,"duplicate":2}')
    provider=Provider()
    with pytest.raises(ProviderError,match='三次'):Pipeline(service,provider).structured(Context(),'system','user',[],ScenePlan)
    assert provider.calls==3


def test_syntax_repair_contains_location_but_never_raw_document_in_error():
    private_text='not-for-error-log'
    with pytest.raises(ProviderError) as error:parse_json('{"text":"'+private_text+'",}')
    assert '第 1 行' in str(error.value) and '列' in str(error.value)
    assert private_text not in str(error.value)
    assert private_text in error.value.invalid_document


@pytest.mark.parametrize('document',['[]','"not a plan"','null'])
def test_non_object_json_enters_bounded_repair_not_free_text_execution(document):
    with pytest.raises(ProviderError) as error:parse_json(document)
    assert error.value.code=='provider_invalid_json'


@pytest.mark.parametrize('code',['provider_transient','provider_connect','provider_timeout','provider_output_truncated'])
def test_server_network_errors_never_trigger_paid_json_repair(service,code):
    class Provider:
        calls=0
        def chat(self,*a):
            self.calls+=1;raise ProviderError('unavailable',code=code)
    provider=Provider()
    with pytest.raises(ProviderError):Pipeline(service,provider).structured(Context(),'system','user',[],ScenePlan)
    assert provider.calls==1


@pytest.mark.parametrize('effort',[None,'low','medium','high'])
def test_director_budget_is_operator_selected_and_reasoning_is_not_executed(service,effort):
    import json
    import httpx
    from memoryscape.providers import Providers
    from memoryscape.schemas import ProjectCreate
    conf={'enabled':True,'url':'https://api.stepfun.com/v1','model':'step-3.7-flash',
          'require_token':False,'capabilities':['brain.plan'],'max_tokens':24000}
    if effort is not None:conf['reasoning_effort']=effort
    service.settings.test_models={'director':conf}
    project=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    captured=[]
    def reply(request):
        captured.append(json.loads(request.content))
        return httpx.Response(200,json={'choices':[{'finish_reason':'stop','message':{
            'content':'{"summary":"完整方案","scene":{}}', 'reasoning_content':'not-executable'}}]})
    result=Providers(service,httpx.MockTransport(reply)).chat(project,'system','user')
    assert result['summary']=='完整方案' and captured[0]['max_tokens']==24000
    assert captured[0].get('reasoning_effort')==effort
    assert 'reasoning_content' not in result


@pytest.mark.parametrize('effort',['none','unlimited',0])
def test_invalid_reasoning_budget_never_reaches_api(service,effort):
    import httpx
    from memoryscape.providers import Providers
    from memoryscape.schemas import ProjectCreate
    service.settings.test_models={'director':{'enabled':True,'url':'https://api.stepfun.com/v1',
        'model':'step-3.7-flash','require_token':False,'capabilities':['brain.plan'],'reasoning_effort':effort}}
    project=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    def forbidden(request):raise AssertionError('Invalid config must not be sent')
    with pytest.raises(ProviderError,match='配置只允许'):
        Providers(service,httpx.MockTransport(forbidden)).chat(project,'system','user')
