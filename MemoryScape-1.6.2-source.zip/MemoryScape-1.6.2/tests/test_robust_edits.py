"""Regression contracts for semantic retries and bounded additive edits."""
import io
import json
import pytest
import trimesh
from PIL import Image
from pydantic import ValidationError
from memoryscape.schemas import Scene, SceneObject, Generation, Transform, Patch, Operation, ProjectCreate, Budget
from memoryscape.geometry import procedural_glb,photo_glb
from memoryscape.pipeline import Pipeline
from memoryscape.jobs import Worker
from memoryscape.errors import AppError
from memoryscape.db import digest,dumps


def existing(service, *, limit=4, photo=True):
    p=service.create_project(ProjectCreate(mode='real',remote_consent=True,budget=Budget(max_objects=limit)))
    image=io.BytesIO();Image.new('RGB',(60,90),'white').save(image,format='PNG')
    raw=photo_glb(image.getvalue()) if photo else procedural_glb('box')
    asset=service.assets.put(p['id'],raw,'existing.glb','photo' if photo else 'procedural')['id']
    scene=Scene(objects=[SceneObject(id='poster',label='原有海报',asset_id=asset,status='ready',
        provenance='photo' if photo else 'procedural',generation=Generation(strategy='photo' if photo else 'procedural'),
        transform=Transform(position=[0,.1,0],size=[1.5,2.25,.01]))])
    service.publish(p['id'],scene,0,'已有素材')
    return p['id'],service.scene(p['id'])


def frame_op(**updates):
    obj=SceneObject(id='poster_frame',label='海报框',kind='decoration',
        transform=Transform(size=[1.62,2.37,.06],position=[0,.04,0],fit='stretch'),
        generation=Generation(primitive='frame',frame_target='poster'))
    for name,value in updates.items():setattr(obj,name,value)
    return Operation(type='add',object_id=obj.id,new_object=obj)


def test_retry_edit_preserves_semantic_checkpoint_and_failed_step(client):
    s=client.app.state.service;pid,_=existing(s)
    class Provider:
        calls=0
        valid=False
        def cards(self):return {}
        def chat(self,project,system,user,images):
            self.calls+=1
            assert 'retry_generation' not in user
            return {'base_version':1,'explanation':'调整配色','operations':[
                {'type':'tint','object_id':'poster' if self.valid else 'nonexistent_frame','color':'#112233'}]}
    provider=Provider();client.app.state.worker.handler=Pipeline(s,provider)
    job=client.post(f'/api/projects/{pid}/edit',json={'prompt':'调整配色','base_version':1}).json()
    worker=client.app.state.worker
    assert worker.run_once()
    failed=s.job(job['id']);assert failed['status']=='failed';assert provider.calls==3
    original_hash=failed['steps'][0]['input_hash']
    for generation in (1,2):
        response=client.post('/api/jobs/'+job['id']+'/retry')
        assert response.status_code==200
        assert response.json()['payload']['retry_generation']==generation
        # A second click cannot reset a queued task or consume a retry.
        assert client.post('/api/jobs/'+job['id']+'/retry').status_code==409
        assert worker.run_once()
        again=s.job(job['id'])
        assert again['steps'][0]['input_hash']==original_hash
        assert '检查点' not in (again['error'] or '')
    provider.valid=True
    assert client.post('/api/jobs/'+job['id']+'/retry').status_code==200
    assert worker.run_once()
    result=s.job(job['id'])
    assert result['status']=='succeeded'
    assert result['steps'][0]['input_hash']==original_hash
    assert result['steps'][0]['attempt']==4
    assert provider.calls==10


def test_retry_stale_scene_is_rejected_and_counter_unchanged(client):
    s=client.app.state.service;pid,_=existing(s)
    job=s.enqueue(pid,'edit',{'base_version':1,'prompt':'旧请求'})
    s.db.execute('UPDATE jobs SET status="failed" WHERE id=?',(job['id'],))
    s.apply_patch(pid,Patch(base_version=1,operations=[Operation(type='caption',object_id='poster',caption='新版本')]))
    assert client.post('/api/jobs/'+job['id']+'/retry').status_code==409
    assert s.job(job['id'])['status']=='failed'
    assert 'retry_generation' not in s.job(job['id'])['payload']


def test_add_frame_publishes_only_after_real_local_mesh_success(service):
    pid,before=existing(service)
    result=service.apply_patch(pid,Patch(base_version=1,operations=[frame_op()]),from_model=True)
    assert result['version']==1 and result['job_id']
    assert service.scene(pid)==before
    worker=Worker(service,Pipeline(service));assert worker.run_once()
    job=service.job(result['job_id']);assert job['status']=='succeeded',job['error']
    after=service.scene(pid);assert after['version']==2
    assert after['scene']['objects'][0]==before['scene']['objects'][0]
    frame=after['scene']['objects'][1]
    assert frame['status']=='ready' and frame['provenance']=='procedural'
    meta=service.assets.get(frame['asset_id'],pid)['meta']
    assert meta['triangles']==48 and meta['meshes']==4
    assert meta['operation']=='deterministic-procedural'
    assert 'model' not in meta


def test_failed_addition_does_not_publish_or_change_existing_asset(service,monkeypatch):
    pid,before=existing(service)
    result=service.apply_patch(pid,Patch(base_version=1,operations=[frame_op()]))
    def fail(*args):raise RuntimeError('local geometry failure')
    monkeypatch.setattr('memoryscape.pipeline.procedural_glb',fail)
    assert Worker(service,Pipeline(service)).run_once()
    assert service.job(result['job_id'])['status']=='failed'
    assert service.scene(pid)==before


@pytest.mark.parametrize('update',[
    {'id':'poster'}, {'asset_id':'invented'}, {'reference_asset_id':'invented'},
    {'locked':True}, {'status':'ready'}, {'provenance':'generated'},
    {'reference_ids':['invented']},
    {'generation':Generation(strategy='generate3d')},
    {'generation':Generation(primitive='frame',image_mode='edit')},
    {'generation':Generation(primitive='frame',image_prompt='pretend remote')},
    {'transform':Transform(size=[1.62,2.37,.06],fit='uniform')},
])
def test_invalid_additions_cannot_mutate_scene(service,update):
    pid,before=existing(service)
    with pytest.raises(AppError):service.apply_patch(pid,Patch(base_version=1,operations=[frame_op(**update)]))
    assert service.scene(pid)==before
    assert service.db.all('SELECT id FROM jobs WHERE project=?',(pid,))==[]


def test_additions_enforce_full_scene_budget_and_duplicate_ids(service):
    pid,before=existing(service,limit=1)
    with pytest.raises(AppError,match='预算'):service.apply_patch(pid,Patch(base_version=1,operations=[frame_op()]))
    assert service.scene(pid)==before
    pid,before=existing(service)
    with pytest.raises(AppError,match='ID'):service.apply_patch(pid,Patch(base_version=1,operations=[frame_op(),frame_op()]))
    assert service.scene(pid)==before


@pytest.mark.parametrize('operation',[
    {'type':'add','object_id':'x'},
    {'type':'add','object_id':'x','new_object':{'id':'y','label':'wrong ID'}},
    {'type':'tint','object_id':'x','color':'#ffffff','prompt':'ignored instruction'},
    {'type':'transform','object_id':'x','transform':{'position':[float('nan'),0,0]}},
    {'type':'add','object_id':'x','new_object':{'id':'x','label':'x','generation':{'primitive':'not_real'}}},
])
def test_patch_operands_reject_invalid_or_ignored_fields(operation):
    with pytest.raises(ValidationError):Operation.model_validate(operation)


def test_frame_is_hollow_with_bounded_normalised_geometry():
    scene=trimesh.load(io.BytesIO(procedural_glb('frame')),file_type='glb',force='scene')
    assert len(scene.geometry)==4
    assert scene.bounds.tolist()==[[-.5,0,-.5],[.5,1,.5]]
    for mesh in scene.geometry.values():
        # Centre of the photo must not be enclosed by any solid border bar.
        lo,hi=mesh.bounds
        assert not (lo[0]<0<hi[0] and lo[1]<.5<hi[1])
    with pytest.raises(ValueError):procedural_glb('unsupported-frame-shape')


def test_procedural_free_text_shape_edit_never_claims_success(service):
    pid,before=existing(service,photo=False)
    patch=Patch(base_version=1,operations=[Operation(type='regenerate',object_id='poster',prompt='round corners')])
    with pytest.raises(AppError,match='不接受自由文字'):service.apply_patch(pid,patch)
    assert service.scene(pid)==before
    class Provider:
        def cards(self):return {'image':{'capabilities':['image.edit']}}
    adapted=Pipeline(service,Provider()).adapt_patch_to_capabilities(patch,service.memory(pid))
    assert adapted.operations==[] and '未改变形状' in adapted.explanation


def test_added_frame_is_validated_at_director_stage(service):
    pid,_=existing(service)
    patch=Patch(base_version=1,operations=[frame_op()])
    Pipeline(service).validate_model_patch(patch,service.memory(pid))
    service.validate_additions(pid,patch,Scene.model_validate(service.scene(pid)['scene']))


def test_frame_fit_is_deterministic_and_follows_photo_moves(service):
    pid,before=existing(service)
    op=frame_op(transform=Transform(position=[12,12,12],size=[1,1,.05],fit='stretch'))
    proposal=service.resolve_additions(pid,Patch(base_version=1,operations=[op]),Scene.model_validate(before['scene']))
    frame=proposal.operations[0].new_object
    assert frame.transform.size==pytest.approx([1.5/.92,2.25/.95,.05])
    assert frame.transform.position==pytest.approx([0,.1-(2.25/.95)*.025,0])
    result=service.apply_patch(pid,proposal);assert Worker(service,Pipeline(service)).run_once()
    old=service.scene(pid);photo_asset=old['scene']['objects'][0]['asset_id'];frame_asset=old['scene']['objects'][1]['asset_id']
    moved=service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='transform',object_id='poster',
        transform=Transform(position=[1,2,3],rotation=[.2,.3,.4],size=[2,3,.01]))]))
    photo,frame=moved['scene']['objects']
    assert photo['asset_id']==photo_asset and frame['asset_id']==frame_asset
    rotation=trimesh.transformations.euler_matrix(.2,.3,.4,axes='rxyz')
    assert frame['transform']['rotation']==[.2,.3,.4]
    assert frame['transform']['position']==pytest.approx([ [1,2,3][i]-rotation[i,1]*(3/.95)*.025 for i in range(3)])
    assert frame['transform']['size'][:2]==pytest.approx([2/.92,3/.95])
    assert {o['id'] for o in service.memory(pid,'poster_frame')['objects']}=={'poster','poster_frame'}


def test_frame_cannot_move_independently_or_bypass_locked_frame(service):
    pid,_=existing(service)
    result=service.apply_patch(pid,Patch(base_version=1,operations=[frame_op()]))
    assert Worker(service,Pipeline(service)).run_once()
    with pytest.raises(AppError,match='自动贴合'):service.apply_patch(pid,Patch(base_version=2,operations=[
        Operation(type='transform',object_id='poster_frame',transform=Transform(position=[5,5,5]))]))
    service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='lock',object_id='poster_frame',locked=True)]))
    with pytest.raises(AppError,match='锁定'):service.apply_patch(pid,Patch(base_version=3,operations=[
        Operation(type='transform',object_id='poster',transform=Transform(position=[2,2,2]))]))
    assert service.scene(pid)['version']==3


def test_frame_size_limit_reports_validation_error_without_publishing(service):
    pid,_=existing(service)
    service.apply_patch(pid,Patch(base_version=1,operations=[Operation(type='transform',object_id='poster',transform=Transform(size=[49,49,.01]))]))
    with pytest.raises(AppError,match='上限'):service.apply_patch(pid,Patch(base_version=2,operations=[frame_op()]))
    assert service.scene(pid)['version']==2


def test_new_optional_schema_field_keeps_legacy_build_checkpoint(service):
    pid,before=existing(service,photo=False)
    legacy=before['scene'];legacy['objects'][0]['generation'].pop('frame_target')
    job=service.enqueue(pid,'build',{'scene':legacy,'base_version':1,'input_revision':0,'targets':['poster']})
    fp=digest({'object':legacy['objects'][0],'style':service.project(pid)['style'],'mode':'real'})
    service.db.execute('INSERT INTO steps(job,name,input_hash,status,attempt,updated) VALUES(?,?,?,"failed",1,0)',(job['id'],'asset:poster',fp))
    assert Worker(service,Pipeline(service)).run_once()
    result=service.job(job['id'])
    assert result['status']=='succeeded',result['error']
    assert result['steps'][0]['input_hash']==fp and result['steps'][0]['attempt']==2


def test_new_schema_defaults_do_not_break_legacy_locked_objects(service):
    pid,before=existing(service)
    scene=Scene.model_validate(before['scene']);scene.objects[0].locked=True
    scene.objects.append(SceneObject(id='base',label='底座'))
    service.publish(pid,scene,1,'锁定海报')
    legacy=service.scene(pid)['scene']
    for obj in legacy['objects']:obj['generation'].pop('frame_target')
    service.db.execute('UPDATE versions SET scene=? WHERE project=? AND version=2',(dumps(legacy),pid))
    result=service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='tint',object_id='base',color='#112233')]))
    assert result['version']==3
    assert result['scene']['objects'][0]['locked'] is True


def test_frame_uses_visible_uniform_photo_extent_without_altering_locked_photo(service):
    pid,before=existing(service)
    scene=Scene.model_validate(before['scene']);scene.objects[0].transform.size=[1,1,.01];scene.objects[0].locked=True
    service.publish(pid,scene,1,'锁定宽高比不一致的展示包围盒')
    original=service.scene(pid)['scene']['objects'][0]
    result=service.apply_patch(pid,Patch(base_version=2,operations=[frame_op()]))
    assert Worker(service,Pipeline(service)).run_once()
    final=service.scene(pid)['scene']['objects']
    assert final[0]==original
    assert final[1]['transform']['size'][0]*.92==pytest.approx(2/3,abs=1e-6)
    assert final[1]['transform']['size'][1]*.95==pytest.approx(1)


def test_bind_existing_legacy_frame_preserves_both_meshes_and_rejects_bad_targets(service):
    pid,before=existing(service)
    old=Scene.model_validate(before['scene'])
    aid=service.assets.put(pid,procedural_glb('frame'),'frame.glb','procedural')['id']
    old.objects.append(SceneObject(id='old_frame',label='已有框',asset_id=aid,status='ready',generation=Generation(primitive='frame'),
        transform=Transform(position=[0,.075,0],size=[1.625,2.368,.05],fit='stretch')))
    service.publish(pid,old,1,'旧版本创建的框')
    with pytest.raises(AppError):service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='bind_frame',object_id='old_frame',target_id='missing')]))
    result=service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='bind_frame',object_id='old_frame',target_id='poster')]))
    assert result['version']==3 and result['job_id'] is None
    assert result['scene']['objects'][0]==before['scene']['objects'][0]
    frame=result['scene']['objects'][1]
    assert frame['asset_id']==aid and frame['generation']['frame_target']=='poster'
    assert frame['transform']['position'][1]==pytest.approx(.1-(2.25/.95)*.025)
    assert len(result['scene']['objects'])==2


@pytest.mark.parametrize('op',[{'type':'bind_frame','object_id':'frame'},
    {'type':'caption','object_id':'frame','caption':'x','target_id':'photo'},
    {'type':'bind_frame','object_id':'frame','target_id':'photo','transform':{}}])
def test_bind_frame_operands_do_not_allow_missing_or_ignored_data(op):
    with pytest.raises(ValidationError):Operation.model_validate(op)
