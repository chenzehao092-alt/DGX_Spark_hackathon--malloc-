import io,json,struct,zipfile
import numpy as np
import pytest
from PIL import Image
from memoryscape.errors import AppError
from memoryscape.media import inspect,parse_glb,glb_info,image_copy,canonical_audio,wav_info,audio_chunks,encode_wav
from memoryscape.geometry import procedural_glb,photo_glb
from memoryscape.schemas import SourceUpdate,Crop,ProjectCreate

@pytest.mark.parametrize('kind',['person','table','cake','balloon','chair','hat','box','sphere','cylinder','plane','text'])
def test_procedural_assets_are_real_parseable_meshes(kind):
 raw=procedural_glb(kind);info=glb_info(raw);assert info['triangles']>0;assert len(info['bounds'])==2
 assert raw[:4]==b'glTF'
def test_photo_asset_has_embedded_texture(png):
 doc=parse_glb(photo_glb(png));assert doc['images'][0]['bufferView']>=0
 assert glb_info(photo_glb(png))['triangles']>=2
def test_input_validation(service,project,png,wav):
 for raw,name in [(b'','x.png'),(b'not a photo','x.png'),(b'x\x00','x.txt')]:
  with pytest.raises(AppError):service.add_source(project['id'],raw,name,'scene',rights=True)
 with pytest.raises(AppError):service.add_source(project['id'],png,'x.png','scene',rights=False)
 a=service.add_source(project['id'],png,'../../secret.png','scene',rights=True)
 assert '/' not in a['filename'];assert service.assets.read(a['id'],project['id'])==png
 other=service.create_project(ProjectCreate(title='另一回忆'))
 with pytest.raises(AppError):service.assets.get(a['id'],other['id'])
 audio=service.add_source(project['id'],wav,'original.wav','audio',rights=True)
 assert audio['meta']['canonical_id']!=audio['id'];assert service.assets.read(audio['id'])==wav
 assert wav_info(service.assets.read(audio['meta']['canonical_id']))['sample_rate']==16000
def test_clone_reference_uses_same_bytes_and_independent_crop(service,project,png):
 a=service.add_source(project['id'],png,'group.png','scene',rights=True)
 b=service.clone_source(project['id'],a['id'],SourceUpdate(role='person',subject='用户确认的主角',crop=Crop(x=.1,width=.5)))
 assert a['id']!=b['id'] and a['sha']==b['sha'];assert b['crop']['width']==.5
 assert service.sources(project['id'])[0]['crop'] is None
 with pytest.raises(AppError):service.update_source(project['id'],a['id'],SourceUpdate(role=None))
def test_sha_detects_corruption(service,project,png):
 a=service.assets.put(project['id'],png,'x.png');service.assets.path(a['sha']).write_bytes(b'corrupted')
 with pytest.raises(AppError,match='校验失败'):service.assets.read(a['id'])
def test_crop_exif_safe_and_bounded(png):
 out=image_copy(png,{'x':.25,'y':0,'width':.5,'height':1})
 assert Image.open(io.BytesIO(out)).size==(48,64)
 with pytest.raises(AppError):image_copy(png,{'x':0,'y':0,'width':.01,'height':.01})

def test_transparent_reference_is_composited_for_rgb_and_preserved_for_geometry():
 im=Image.new('RGBA',(16,16),(0,0,0,0));im.putpixel((8,8),(255,0,0,255))
 raw=io.BytesIO();im.save(raw,format='PNG')
 rgb=Image.open(io.BytesIO(image_copy(raw.getvalue())))
 assert rgb.getpixel((0,0))==(255,255,255);assert rgb.getpixel((8,8))==(255,0,0)
 rgba=Image.open(io.BytesIO(image_copy(raw.getvalue(),alpha=True)))
 assert rgba.getpixel((0,0))[3]==0
def test_audio_chunks_preserve_nonspeech_and_overlap():
 raw=encode_wav(np.zeros(52*16000));chunks=list(audio_chunks(raw))
 assert [(a,b) for a,b,_ in chunks]==[(0,25),(23,48),(46,52)]
 for a,b,c in chunks:assert abs(wav_info(c)['duration']-(b-a))<.001
def test_glb_external_resource_is_rejected():
 doc={'asset':{'version':'2.0'},'meshes':[{'primitives':[]}],'buffers':[{'uri':'file:///etc/passwd','byteLength':4}]}
 chunk=json.dumps(doc).encode();chunk+=b' '*((-len(chunk))%4)
 raw=struct.pack('<4sII',b'glTF',2,20+len(chunk))+struct.pack('<II',len(chunk),0x4E4F534A)+chunk
 with pytest.raises(AppError,match='URI'):parse_glb(raw)
def test_glb_truncation():
 with pytest.raises(AppError):parse_glb(procedural_glb('box')[:-3])
