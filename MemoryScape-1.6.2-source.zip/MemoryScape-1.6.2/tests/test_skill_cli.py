import importlib.util
from pathlib import Path


def module():
    path=Path(__file__).resolve().parents[1]/'skills/memoryscape/scripts/client.py'
    spec=importlib.util.spec_from_file_location('skill_cli_test',path)
    cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
    return cli


def test_skill_cli_query_memory_is_read_only(monkeypatch,capsys):
    cli=module();calls=[]
    class Client:
        def __init__(self,url):assert url=='http://127.0.0.1:8002'
        def json(self,*args,**kwargs):calls.append((args,kwargs));return {'version':15}
    monkeypatch.setattr(cli,'Client',Client)
    monkeypatch.setattr('sys.argv',['client.py','--url','http://127.0.0.1:8002','memory','p_example','--query','把底座加回来','--selected','poster'])
    cli.main()
    assert calls==[(('GET','/api/projects/p_example/memory'),{'params':{'query':'把底座加回来','selected':'poster'}})]
    assert '15' in capsys.readouterr().out


def test_skill_cli_tools_does_not_submit_jobs(monkeypatch,capsys):
    cli=module();calls=[]
    class Client:
        def __init__(self,url):pass
        def json(self,*args,**kwargs):calls.append(args);return []
    monkeypatch.setattr(cli,'Client',Client);monkeypatch.setattr('sys.argv',['client.py','skills'])
    cli.main();assert calls==[('GET','/api/skills')]
