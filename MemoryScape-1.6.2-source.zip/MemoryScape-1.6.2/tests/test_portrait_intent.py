import json
import time
from types import SimpleNamespace
import pytest
from memoryscape.errors import AppError, ProviderError
from memoryscape.layout import validate_plan, validate_portrait_only
from memoryscape.pipeline import Pipeline
from memoryscape.schemas import ScenePlan, Scene, SceneObject, Generation, ProjectCreate

REQUEST = '单独保留人像，去掉背景和对话框，这是我在写作时激发我的灵感的一张照片'

def portrait_plan():
    return ScenePlan(summary='只展示清理后人像', scene=Scene(objects=[SceneObject(
        id='character_1', kind='person', label='主要角色', generation=Generation(
            strategy='photo', primary_source='photo', image_mode='edit', image_model='image',
            image_prompt='Remove background and speech bubbles; keep only the original character.'))]))

@pytest.mark.parametrize('primitive,kind', [('text','text'), ('frame','decoration'), ('box','prop')])
def test_portrait_only_rejects_extra_objects(project, primitive, kind):
    project['requirements'] = REQUEST
    plan = portrait_plan()
    plan.scene.objects.append(SceneObject(id='extra', label='多余对象', kind=kind,
        generation=Generation(strategy='procedural', primitive=primitive)))
    with pytest.raises(AppError, match='仅可建立人物对象'):
        validate_plan(plan, project, [{'id':'photo','kind':'image'}], {'image':{'capabilities':['image.edit']}})

def test_cleaned_portrait_passes_and_unavailable_image_is_not_faked(project):
    project['requirements'] = REQUEST
    caps = {'image':{'capabilities':['image.edit']}}
    assert validate_plan(portrait_plan(), project, [{'id':'photo','kind':'image'}], caps).scene.objects[0].id == 'character_1'
    caps['image'].update(available=False, last_http_status=503)
    with pytest.raises(AppError, match='HTTP 503'):
        validate_plan(portrait_plan(), project, [{'id':'photo','kind':'image'}], caps)

@pytest.mark.parametrize('mode', ['original','crop'])
def test_removal_cannot_be_replaced_by_unedited_photo(mode):
    plan = portrait_plan(); plan.scene.objects[0].generation.image_mode = mode
    with pytest.raises(AppError, match='image.edit'):
        validate_portrait_only(plan, {'requirements':REQUEST})

@pytest.mark.parametrize('user_prompt', ['完整保留漫画和文字', '不要只保留人物，保留背景', '是否只保留人物？'])
def test_other_or_negated_requests_are_unchanged(user_prompt):
    plan = portrait_plan()
    plan.scene.objects.append(SceneObject(id='text', label='文字'))
    assert validate_portrait_only(plan, {'requirements':user_prompt}) is plan

def test_director_correction_loop_receives_intent_error():
    bad = portrait_plan(); bad.scene.objects.append(SceneObject(id='text', label='文字'))
    requests = []
    def chat(project, system, user, images):
        requests.append(user)
        return (bad if len(requests)==1 else portrait_plan()).model_dump()
    pipeline = Pipeline(None, SimpleNamespace(chat=chat))
    ctx = SimpleNamespace(project='p', check=lambda:None, emit=lambda *args:None)
    fixed = pipeline.structured(ctx, '', '{}', [], ScenePlan,
        lambda plan:validate_portrait_only(plan, {'requirements':REQUEST}))
    assert len(fixed.scene.objects)==1
    assert len(requests)==2
    assert '仅可建立人物对象' in requests[1]

def test_stale_pending_plan_is_rejected_before_commit(service):
    project = service.create_project(ProjectCreate(title='人像', requirements=REQUEST))
    bad = portrait_plan(); bad.scene.objects.append(SceneObject(id='text', label='文字'))
    service.db.execute('INSERT INTO plans VALUES(?,?,?,?,?,?,?)',
        ('plan_bad',project['id'],0,project['input_revision'],json.dumps(bad.model_dump()),'pending',time.time()))
    with pytest.raises(AppError, match='仅可建立人物对象'):
        service.confirm_plan(project['id'],'plan_bad',0,project['input_revision'])
    assert service.project(project['id'])['head']==0
    assert service.db.one('SELECT status FROM plans WHERE id=?',('plan_bad',))['status']=='pending'
