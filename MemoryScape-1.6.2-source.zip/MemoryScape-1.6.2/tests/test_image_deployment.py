"""No real weights/GPU: regression contracts for isolated local image nodes."""
import io
import hashlib
import json
import sys
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace
import pytest
from memoryscape.connections import ConnectionMonitor
from memoryscape.config import Settings
from scripts import desktop_node


IMAGE_CONF={'kind':'image','project':'/srv/apps/memoryscape-image-v1p2',
    'ssh_target':'user@spark','python':'/srv/env/bin/python','lifecycle':'reuse',
    'local_port':19112,'node_port':9102,'model':'stepfun-ai/Step1X-Edit-v1p2','revision':'pinned'}
IMAGE_CAPS={'capabilities':['image.edit'],'execution_mode':'native',
            'fingerprint':{'runtime_revision':'memoryscape-step1xedit-v1p2'}}


def test_image_reuse_keeps_geometry_credentials_config_and_records(tmp_path,monkeypatch):
    config=tmp_path/'models.toml'
    config.write_text('[models.geometry]\nenabled=true\nurl="http://127.0.0.1:19113"\n'
                      'token_env="GEOMETRY_NODE_TOKEN"\n[models.image]\nenabled=false\ncapabilities=["image.edit"]\n')
    settings=Settings(data_dir=tmp_path/'data',config_file=config).initialize()
    (settings.data_dir/'node-connection.json').write_text('geometry-record')
    (settings.data_dir/'geometry-node-token').write_text('do-not-replace-geometry-token')
    path=tmp_path/'deployment.toml'
    path.write_text('[image_remote]\n'+''.join(k+'='+json.dumps(v)+'\n' for k,v in IMAGE_CONF.items()))
    calls=[]
    def command(argv,**kw):
        calls.append(argv)
        if argv[0]=='ssh':return json.dumps({'ready':True,'port_in_use':True}).encode()
        assert argv[0]=='scp' and '-r' not in argv and argv[-2].endswith('/node-data/image/token')
        Path(argv[-1]).write_text('private-local-image-test-token-1234')
    monkeypatch.setattr(desktop_node,'command',command)
    monkeypatch.setattr(desktop_node.urllib.request,'urlopen',lambda *a,**k:io.BytesIO(json.dumps(IMAGE_CAPS).encode()))
    desktop_node.ensure_node(tmp_path,settings,path,'image_remote')
    assert len(calls)==2
    assert (settings.data_dir/'node-connection.json').read_text()=='geometry-record'
    assert (settings.data_dir/'geometry-node-token').read_text()=='do-not-replace-geometry-token'
    assert settings.models()['geometry']['url'].endswith('19113')
    assert settings.models()['image']['url'].endswith('19112')
    assert settings.models()['image']['protocol']=='node-v1'
    assert settings.models()['image']['revision']=='pinned'
    assert settings.models()['image']['token_env']=='IMAGE_NODE_TOKEN'
    assert (settings.data_dir/'image-node-connection.json').is_file()


def test_native_image_cannot_reuse_geometry_or_foreign_runtime():
    assert desktop_node.node_ready(IMAGE_CONF,IMAGE_CAPS)
    assert not desktop_node.node_ready(IMAGE_CONF,{**IMAGE_CAPS,'execution_mode':'contract-test'})
    assert not desktop_node.node_ready(IMAGE_CONF,{**IMAGE_CAPS,'fingerprint':{'runtime_revision':'memoryscape-1.5-desktop'}})


def test_reconnect_backoff_is_independent_per_node(settings,monkeypatch):
    import memoryscape.connections as connections
    conf=lambda name:{'enabled':True,'protocol':'node-v1','url':'http://127.0.0.1:19112','require_token':False}
    settings.test_models={name:conf(name) for name in ('geometry','image')}
    monkeypatch.setattr(connections,'probe_model',lambda s,n,*a:{'model':n,'state':'offline'})
    repaired=[]
    def repair(s,c,*a):
        repaired.append(c['kind']);raise RuntimeError('bounded test offline')
    monkeypatch.setattr(desktop_node,'ensure_tunnel',repair)
    monitor=ConnectionMonitor(settings)
    monkeypatch.setattr(monitor,'tunnel_config',lambda n,*a:{**IMAGE_CONF,'kind':n})
    monitor.tick()
    assert repaired==['geometry','image']
    assert set(monitor.next_reconnect)=={'geometry','image'}


def test_image_sequential_offload_keeps_thinker_on_real_device(tmp_path,monkeypatch):
    from node.backends import ImageEditor
    calls=[]
    class Pipe:
        _exclude_from_cpu_offload=[]
        def enable_sequential_cpu_offload(self,**kw):calls.append(('offload',kw))
        def enable_vae_slicing(self):pass
        def enable_vae_tiling(self):pass
    pipe=Pipe()
    def load(path,**kw):
        assert kw['local_files_only'] is True
        return pipe
    monkeypatch.setitem(sys.modules,'torch',SimpleNamespace(bfloat16='bf16'))
    monkeypatch.setitem(sys.modules,'diffusers',SimpleNamespace(Step1XEditPipelineV1P2=SimpleNamespace(from_pretrained=load)))
    for name in ('MS_IMAGE_GPU_INDEX','MS_IMAGE_GPU_MEMORY_MIB'):monkeypatch.delenv(name,raising=False)
    monkeypatch.setenv('MODEL_PATH',str(tmp_path));monkeypatch.setenv('IMAGE_OFFLOAD_MODE','sequential')
    monkeypatch.setenv('IMAGE_SIZE_LEVEL','512')
    driver=ImageEditor()
    assert driver.size_level==512
    assert pipe._exclude_from_cpu_offload==['text_encoder']
    assert calls==[('offload',{'device':'cuda:0'})]
    assert driver.thinking_mode is False and driver.reflection_mode is False


@pytest.mark.parametrize('name',['IMAGE_THINKING_MODE','IMAGE_REFLECTION_MODE'])
def test_image_modes_reject_ambiguous_environment(name,monkeypatch):
    from node.backends import ImageEditor
    monkeypatch.setenv(name,'sometimes')
    with pytest.raises(ValueError,match=name):ImageEditor()


@pytest.mark.parametrize('name',['thinking_mode','reflection_mode'])
@pytest.mark.parametrize('value',['false',0,1,None])
def test_image_modes_require_actual_config_booleans(name,value):
    with pytest.raises(ValueError):desktop_node.validate_remote({**IMAGE_CONF,name:value})


def image_driver(tmp_path,thinking=False,reflection=False):
    """No weights/GPU: exercise native adapter arguments and cancellation only."""
    from PIL import Image
    from node.backends import ImageEditor
    calls=[]
    class Pipe:
        def __call__(self,**kwargs):
            calls.append(kwargs)
            return SimpleNamespace(final_images=[Image.new('RGB',(8,8),'white')],images=[1],
                                   reformat_prompt='x'*9000,think_info=['y'*9000]*4,best_info='ok')
        def maybe_free_model_hooks(self):calls.append('freed')
    driver=object.__new__(ImageEditor)
    driver.pipe=Pipe();driver.size_level=256
    driver.thinking_mode=thinking;driver.reflection_mode=reflection
    driver.torch=SimpleNamespace(inference_mode=nullcontext,
                                Generator=lambda:SimpleNamespace(manual_seed=lambda seed:seed))
    path=tmp_path/'input.png';Image.new('RGB',(8,8),'red').save(path)
    return driver,path,calls


@pytest.mark.parametrize('thinking,reflection',[(False,False),(True,False),(False,True),(True,True)])
def test_image_direct_reference_mode_and_private_bounded_audit(tmp_path,thinking,reflection):
    driver,path,calls=image_driver(tmp_path,thinking,reflection)
    prompt='Keep the original cartoon person, full body, without other objects.'
    result=driver.run('image.edit',path,tmp_path,prompt,{'steps':30,'guidance_scale':6,'seed':2026})
    kw=calls[0]
    assert kw['prompt']==prompt
    assert kw['enable_thinking_mode'] is thinking and kw['enable_reflection_mode'] is reflection
    assert kw['max_try_cnt']==(3 if reflection else 1)
    assert kw['image'].size==(256,256) and result.name=='output.png'
    values={'latents':'opaque-test-value'}
    assert kw['callback_on_step_end'](driver.pipe,0,123,values) is values
    assert calls[-1]=='freed'
    audit=json.loads((tmp_path/'reference-audit.json').read_text('utf-8'))
    assert audit['input_sha256']==hashlib.sha256(path.read_bytes()).hexdigest()
    assert audit['candidate_count']==1 and audit['thinking_mode'] is thinking
    assert len(audit['reformat_prompt'])==8000 and len(audit['think_info'])==3
    assert all(len(item)==8000 for item in audit['think_info'])


def test_image_cancelled_before_inference_never_calls_pipeline(tmp_path):
    from memoryscape.errors import AppError
    driver,path,calls=image_driver(tmp_path)
    (tmp_path/'cancel.requested').touch()
    with pytest.raises(AppError,match='取消'):
        driver.run('image.edit',path,tmp_path,'same reference',{'steps':30,'guidance_scale':6,'seed':2026})
    assert calls==[] and not (tmp_path/'output.png').exists()


def test_image_cancellation_at_diffusion_callback_frees_hooks(tmp_path):
    from memoryscape.errors import AppError
    driver,path,calls=image_driver(tmp_path)
    class CancellingPipe:
        def __call__(self,**kwargs):
            (tmp_path/'cancel.requested').touch()
            kwargs['callback_on_step_end'](self,0,123,{})
            pytest.fail('cancelled inference must not continue')
        def maybe_free_model_hooks(self):calls.append('freed')
    driver.pipe=CancellingPipe()
    with pytest.raises(AppError,match='取消'):
        driver.run('image.edit',path,tmp_path,'same reference',{'steps':30,'guidance_scale':6,'seed':2026})
    assert calls==['freed'] and not (tmp_path/'output.png').exists()


@pytest.mark.parametrize('kind',['audio','../image','image; bad'])
def test_desktop_kind_is_a_whitelist(kind):
    with pytest.raises(ValueError):desktop_node.validate_remote({**IMAGE_CONF,'kind':kind})
