"""One-click launcher tests: health detection, port conflicts, node reporting.

Uses local fake health servers; never launches a real model host in these
tests except where explicitly guarded by a fake /health endpoint.
"""
import json
import sys
import threading
import http.server
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))  # scripts dir
import start_all  # noqa: E402

@pytest.fixture(autouse=True)
def no_ssh_in_unit_tests(monkeypatch):
    import desktop_node
    monkeypatch.setattr(desktop_node, 'ensure_node', lambda *args: None)

class _FakeBrowser:
    def __init__(self, opened):
        self.opened = opened

    def open(self, u):
        self.opened.append(u)



class _HealthHandler(http.server.BaseHTTPRequestHandler):
    mode = 'memoryscape'  # 'memoryscape' | 'other'

    def do_GET(self):
        if self.mode == 'memoryscape':
            body = json.dumps({'app': 'MemoryScape', 'version': '1.0.0rc2', 'status': 'ok'}).encode()
            code = 200
        else:
            body = json.dumps({'app': 'SomethingElse'}).encode()
            code = 200
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


class _CapabilityHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/v1/capabilities':
            body = json.dumps({'capabilities': ['geometry.generate']}).encode()
        else:
            body = b'{}'
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


@pytest.fixture
def health_server():
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), _HealthHandler)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield srv
    srv.shutdown()
    srv.server_close()


@pytest.fixture
def fake_ok():
    srv = http.server.ThreadingHTTPServer(('127.0.0.1', 0), _CapabilityHandler)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield f'http://127.0.0.1:{srv.server_port}'
    srv.shutdown()
    srv.server_close()


def test_fetch_health_recognizes_memoryscape(health_server):
    data = start_all.fetch_health('127.0.0.1', health_server.server_port)
    assert data and data['app'] == 'MemoryScape'


def test_already_running_host_is_reused(health_server, monkeypatch, capsys):
    opened = []
    monkeypatch.setattr(start_all, 'webbrowser', _FakeBrowser(opened))
    code = start_all.main(['--host', '127.0.0.1', '--port', str(health_server.server_port), '--no-browser'])
    assert code == 0
    out = capsys.readouterr().out
    assert '已在运行' in out and '不重复启动' in out
    assert opened == []  # --no-browser


def test_loopback_auto_login_url_used_and_token_not_printed(health_server, monkeypatch, capsys):
    opened = []
    monkeypatch.setattr(start_all, 'webbrowser', _FakeBrowser(opened))
    code = start_all.main(['--host', '127.0.0.1', '--port', str(health_server.server_port)])
    assert code == 0
    assert len(opened) == 1
    assert opened[0].rstrip('/')==f'http://127.0.0.1:{health_server.server_port}'
    assert 'token=' not in opened[0]
    out = capsys.readouterr().out
    assert '[认证] 正在建立本地会话' in out
    assert '[浏览器] 已打开 MemoryScape' in out
    # the full auth URL (which embeds the token) must not be printed
    assert '/auth/local' not in out


def test_remote_bind_does_not_auto_login(monkeypatch, capsys):
    opened = []
    monkeypatch.setattr(start_all, 'webbrowser', _FakeBrowser(opened))
    monkeypatch.setattr(start_all, 'fetch_health',
                        lambda h, p, timeout=1.5: {'app': 'MemoryScape', 'version': 'x', 'status': 'ok'})
    code = start_all.main(['--host', '0.0.0.0', '--port', '8123'])
    assert code == 0
    assert len(opened) == 1
    assert '/auth/local' not in opened[0]
    out = capsys.readouterr().out
    assert '非本机地址：不做自动登录' in out


def test_foreign_process_on_port_is_error(health_server, monkeypatch):
    _HealthHandler.mode = 'other'
    try:
        code = start_all.main(['--host', '127.0.0.1', '--port', str(health_server.server_port), '--no-browser'])
        assert code == 1
    finally:
        _HealthHandler.mode = 'memoryscape'


def test_python_ok_accepts_311():
    version_info = type('V', (), {'major': 3, 'minor': 11, 'micro': 9})
    ok, _ = start_all.python_ok(version_info)
    assert ok is True
    bad = type('V', (), {'major': 3, 'minor': 14, 'micro': 0})
    ok2, msg = start_all.python_ok(bad)
    assert ok2 is False and '3.14' in msg


def test_node_report_remote_not_probed(tmp_path):
    from memoryscape.config import Settings
    path = tmp_path / 'models.toml'
    path.write_text("""
[models.director]
enabled = true
protocol = "chat"
url = "https://api.stepfun.com/v1"
token_env = "DIRECTOR_TOKEN"
require_token = true
""", encoding='utf-8')
    settings = Settings(data_dir=tmp_path / 'data', config_file=path,
                        token='test-only-random-looking-access-token-2026',
                        start_worker=False).initialize()
    report = start_all.node_report(settings)
    assert report['director']['status'] == 'configured_remote'


def test_node_report_loopback_probed(tmp_path, fake_ok):
    from memoryscape.config import Settings
    path = tmp_path / 'models.toml'
    path.write_text(f"""
[models.geometry]
enabled = true
protocol = "node-v1"
url = "{fake_ok}"
token_env = "GEOMETRY_NODE_TOKEN"
require_token = false
""", encoding='utf-8')
    settings = Settings(data_dir=tmp_path / 'data', config_file=path,
                        token='test-only-random-looking-access-token-2026',
                        start_worker=False).initialize()
    report = start_all.node_report(settings)
    assert report['geometry']['status'] == 'connected'


def test_node_report_no_models(tmp_path):
    from memoryscape.config import Settings
    path = tmp_path / 'models.toml'
    path.write_text('[models.director]\nenabled = false\n', encoding='utf-8')
    settings = Settings(data_dir=tmp_path / 'data', config_file=path,
                        token='test-only-random-looking-access-token-2026',
                        start_worker=False).initialize()
    assert start_all.node_report(settings) == {}
