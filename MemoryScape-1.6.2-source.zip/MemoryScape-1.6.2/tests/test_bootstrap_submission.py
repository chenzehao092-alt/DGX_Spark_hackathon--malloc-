"""First-run launcher contracts; all subprocess and service calls are mocked."""
import builtins
import importlib.util
import subprocess
import sys
import types
from pathlib import Path

import pytest


PROJECT = Path(__file__).resolve().parents[1]
BOOTSTRAP = PROJECT / 'scripts' / 'desktop_bootstrap.py'


def load_bootstrap():
    spec = importlib.util.spec_from_file_location('bootstrap_submission_test', BOOTSTRAP)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def bootstrap(tmp_path, monkeypatch):
    module = load_bootstrap()
    root = tmp_path / 'install'
    root.mkdir()
    (root / 'pyproject.toml').write_text('[project]\nname="test-only"\n', encoding='utf-8')
    monkeypatch.setattr(module, 'ROOT', root)
    monkeypatch.setattr(sys, 'argv', ['start_memoryscape.bat', '--no-browser'])
    monkeypatch.setattr(sys, 'path', list(sys.path))
    return module


def target_python(module):
    return module.ROOT / '.venv' / ('Scripts/python.exe' if module.os.name == 'nt' else 'bin/python')


def install_fake_locks(module, monkeypatch, on_prepare=None):
    state = {'preparing': False, 'starting': False, 'events': []}

    class PreparationLock:
        def __init__(self, path):
            assert path == module.ROOT / 'data' / 'environment-prepare.lock'

        def acquire(self):
            assert not state['preparing']
            state['preparing'] = True
            state['events'].append('prepare-acquire')
            if on_prepare:
                on_prepare()

        def release(self):
            assert state['preparing']
            state['preparing'] = False
            state['events'].append('prepare-release')

    class StartupLock:
        def __init__(self, path):
            assert path == module.ROOT / 'data' / 'desktop-start.lock'
            assert not state['preparing']

        def acquire(self):
            assert not state['starting']
            state['starting'] = True
            state['events'].append('startup-acquire')

        def release(self):
            assert state['starting']
            state['starting'] = False
            state['events'].append('startup-release')

    security = types.ModuleType('memoryscape.security')
    security.ProcessLock = StartupLock
    monkeypatch.setitem(sys.modules, 'memoryscape.security', security)
    monkeypatch.setattr(module, 'EnvironmentPreparationLock', PreparationLock)
    return state


def stub_service(monkeypatch, state, result=0):
    start_all = types.ModuleType('start_all')

    def main(argv):
        assert argv == ['--no-browser']
        assert state['starting'] and not state['preparing']
        state['events'].append('service-call')
        return result

    start_all.main = main
    monkeypatch.setitem(sys.modules, 'start_all', start_all)


def test_bootstrap_import_does_not_need_application_dependencies(monkeypatch):
    original_import = builtins.__import__

    def guarded_import(name, *args, **kwargs):
        if name.split('.')[0] in {'memoryscape', 'starlette', 'fastapi'}:
            raise AssertionError('Application dependency imported before environment setup: ' + name)
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, '__import__', guarded_import)
    module = load_bootstrap()
    assert callable(module.prepare_environment)


def test_parent_releases_preparation_lock_before_recursive_venv_call(bootstrap, monkeypatch):
    monkeypatch.setattr(sys, 'prefix', str(bootstrap.ROOT / 'external-python'))
    state = install_fake_locks(bootstrap, monkeypatch)
    target = target_python(bootstrap)

    def run(argv, **kwargs):
        assert state['preparing'] and not state['starting']
        assert argv[1:] == ['-m', 'venv', str(bootstrap.ROOT / '.venv')]
        assert kwargs == {'check': True}
        target.parent.mkdir(parents=True)
        target.touch()
        state['events'].append('venv-create')

    def call(argv, **kwargs):
        assert not state['preparing'], 'Holding this lock would deadlock the venv child.'
        assert argv == [str(target), str(BOOTSTRAP), '--no-browser']
        assert kwargs == {'cwd': bootstrap.ROOT}
        state['events'].append('venv-child')
        return 7

    monkeypatch.setattr(subprocess, 'run', run)
    monkeypatch.setattr(subprocess, 'call', call)
    assert bootstrap.main() == 7
    assert state['events'] == ['prepare-acquire', 'venv-create', 'prepare-release', 'venv-child']


def test_parent_rechecks_venv_after_waiting_for_preparation_lock(bootstrap, monkeypatch):
    monkeypatch.setattr(sys, 'prefix', str(bootstrap.ROOT / 'external-python'))
    target = target_python(bootstrap)

    def created_by_other_window():
        target.parent.mkdir(parents=True)
        target.touch()

    state = install_fake_locks(bootstrap, monkeypatch, on_prepare=created_by_other_window)
    monkeypatch.setattr(subprocess, 'run', lambda *args, **kwargs: pytest.fail('Repeated venv creation'))

    def call(*args, **kwargs):
        assert not state['preparing']
        return 0

    monkeypatch.setattr(subprocess, 'call', call)
    assert bootstrap.main() == 0
    assert state['events'] == ['prepare-acquire', 'prepare-release']


def test_dependency_install_is_serialized_and_reused_then_rechecked_on_change(bootstrap, monkeypatch):
    venv = bootstrap.ROOT / '.venv'
    venv.mkdir()
    monkeypatch.setattr(sys, 'prefix', str(venv))
    state = install_fake_locks(bootstrap, monkeypatch)
    stub_service(monkeypatch, state, result=3)
    installs = []

    def run(argv, **kwargs):
        assert state['preparing'] and not state['starting']
        assert argv[1:] == ['-m', 'pip', 'install', '-e', str(bootstrap.ROOT)]
        assert kwargs == {'check': True, 'cwd': bootstrap.ROOT}
        installs.append(argv)

    monkeypatch.setattr(subprocess, 'run', run)
    monkeypatch.setattr(subprocess, 'call', lambda *args, **kwargs: pytest.fail('Unexpected recursive child'))
    assert bootstrap.main() == 3
    assert bootstrap.main() == 3
    assert len(installs) == 1
    assert state['events'] == [
        'prepare-acquire', 'prepare-release', 'startup-acquire', 'service-call', 'startup-release',
    ] * 2
    (bootstrap.ROOT / 'pyproject.toml').write_text('[project]\nname="changed-test-only"\n', encoding='utf-8')
    assert bootstrap.main() == 3
    assert len(installs) == 2


def test_failed_install_releases_lock_without_success_marker_or_service_start(bootstrap, monkeypatch):
    venv = bootstrap.ROOT / '.venv'
    venv.mkdir()
    monkeypatch.setattr(sys, 'prefix', str(venv))
    state = install_fake_locks(bootstrap, monkeypatch)

    def run(argv, **kwargs):
        assert state['preparing']
        raise subprocess.CalledProcessError(1, argv)

    monkeypatch.setattr(subprocess, 'run', run)
    with pytest.raises(subprocess.CalledProcessError):
        bootstrap.main()
    assert not (venv / 'memoryscape-installed').exists()
    assert state['events'] == ['prepare-acquire', 'prepare-release']


def test_preparation_waits_for_busy_lock_and_releases_on_body_exception(bootstrap, monkeypatch, capsys):
    attempts = []
    released = []

    class BusyThenReady:
        def __init__(self, path):
            pass

        def acquire(self):
            attempts.append(1)
            if len(attempts) < 3:
                raise RuntimeError('busy')

        def release(self):
            released.append(1)

    monkeypatch.setattr(bootstrap, 'EnvironmentPreparationLock', BusyThenReady)
    monkeypatch.setattr(bootstrap.time, 'monotonic', lambda: 0)
    monkeypatch.setattr(bootstrap.time, 'sleep', lambda seconds: None)
    with pytest.raises(ValueError, match='body failed'):
        with bootstrap.prepare_environment():
            raise ValueError('body failed')
    assert len(attempts) == 3 and released == [1]
    assert capsys.readouterr().out.count('正在等待') == 1


def test_preparation_timeout_does_not_enter_setup_body(bootstrap, monkeypatch):
    class AlwaysBusy:
        def __init__(self, path):
            pass

        def acquire(self):
            raise RuntimeError('busy')

        def release(self):
            pytest.fail('No lock was acquired')

    clock_values = iter([0, 2])
    monkeypatch.setattr(bootstrap, 'EnvironmentPreparationLock', AlwaysBusy)
    monkeypatch.setattr(bootstrap.time, 'monotonic', lambda: next(clock_values))
    with pytest.raises(RuntimeError, match='环境准备超时'):
        with bootstrap.prepare_environment(timeout=1):
            pytest.fail('Timed-out preparation entered the setup body')


def test_contended_os_lock_closes_its_handle(bootstrap, monkeypatch):
    class FileHandle:
        closed = False

        def tell(self):
            return 1

        def seek(self, value):
            pass

        def fileno(self):
            return 123

        def close(self):
            self.closed = True

    def busy(*args):
        raise OSError('mock contention')

    handle = FileHandle()
    monkeypatch.setattr(bootstrap, 'open', lambda *args: handle, raising=False)
    if bootstrap.os.name == 'nt':
        import msvcrt
        monkeypatch.setattr(msvcrt, 'locking', busy)
    else:
        import fcntl
        monkeypatch.setattr(fcntl, 'flock', busy)
    lock = bootstrap.EnvironmentPreparationLock(bootstrap.ROOT / 'preparation.lock')
    with pytest.raises(RuntimeError, match='另一个启动窗口'):
        lock.acquire()
    assert handle.closed and lock.file is None


def test_batch_entrypoints_preserve_failures_and_validate_configured_python():
    start = (PROJECT / 'start_memoryscape.bat').read_text(encoding='utf-8')
    configured = start.split(':run_configured\n', 1)[1]
    assert 'set "MS_PYTHON="' in start
    assert configured.index('if not defined MS_PYTHON') < configured.index('"%MS_PYTHON%" scripts\\desktop_bootstrap.py')
    assert configured.index('if not exist "%MS_PYTHON%"') < configured.index('"%MS_PYTHON%" scripts\\desktop_bootstrap.py')
    assert configured.count('exit /b 2') == 2

    stop = (PROJECT / 'stop_memoryscape.bat').read_text(encoding='utf-8')
    invoke = '".venv\\Scripts\\python.exe" scripts\\desktop_stop.py'
    assert stop.index('if not exist ".venv\\Scripts\\python.exe"') < stop.index(invoke)
    assert 'No service or model was stopped.' in stop and 'exit /b 2' in stop
    capture = 'set "MS_EXIT=%errorlevel%"'
    assert stop.index(invoke) < stop.index(capture) < stop.index('if not "%MS_EXIT%"=="0"')
    assert stop.rstrip().endswith('exit /b %MS_EXIT%')
