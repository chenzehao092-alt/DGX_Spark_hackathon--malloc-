import pytest
from memoryscape.errors import AppError
from memoryscape.layout import validate_plan,validate_plan_layout,fit_plan_primitives,fit_plan_contacts,validate_plan_execution
from memoryscape.schemas import ScenePlan,Scene,SceneObject,Transform,Relation


def person(id,x=0):
    return SceneObject(id=id,label=id,kind='person',transform=Transform(position=[x,0,0]))


def project():
    return {'requirements':'保留原图的人物数量','budget':{'max_objects':20,'max_generated_assets':8},
            'allow_synthetic_audio':False}


def test_claimed_people_count_cannot_disagree_with_objects():
    plan=ScenePlan(summary='四人庆祝生日',reference_person_count=4,
                   scene=Scene(objects=[person('a'),person('b',1),person('c',2)]))
    with pytest.raises(AppError,match='人物数量不一致'):validate_plan(plan,project(),[],{})


def test_preserving_people_count_requires_explicit_reference_statistics():
    plan=ScenePlan(summary='保留人物',scene=Scene(objects=[person('a')]))
    with pytest.raises(AppError,match='reference_person_count'):validate_plan(plan,project(),[],{})


def test_four_independent_people_pass():
    plan=ScenePlan(summary='四人庆祝生日',reference_person_count=4,
                   scene=Scene(objects=[person('p'+str(i),i) for i in range(4)]))
    assert len(validate_plan(plan,project(),[],{}).scene.objects)==4


def test_new_box_uses_declared_dimensions_without_mutating_input():
    plan=ScenePlan(summary='一个长方形礼物盒',scene=Scene(objects=[
        SceneObject(id='gift',label='礼物盒',transform=Transform(size=[1,.4,.7]))]))
    fixed,changed=fit_plan_primitives(plan)
    assert changed==['gift'] and fixed.scene.objects[0].transform.fit=='stretch'
    assert fixed.scene.objects[0].transform.size==[1,.4,.7]
    assert plan.scene.objects[0].transform.fit=='uniform'
    assert validate_plan(fixed,{**project(),'requirements':''},[],{})==fixed


@pytest.mark.parametrize('strategy,locked,asset',[('generate3d',False,None),('photo',False,None),
                                                 ('procedural',True,None),('procedural',False,'a_existing')])
def test_plan_fitting_never_stretches_real_locked_or_existing_assets(strategy,locked,asset):
    from memoryscape.schemas import Generation
    plan=ScenePlan(summary='只保留现有比例',scene=Scene(objects=[
        SceneObject(id='subject',label='主体',locked=locked,asset_id=asset,
                    transform=Transform(size=[1,.4,.7]),generation=Generation(strategy=strategy))]))
    fixed,changed=fit_plan_primitives(plan)
    assert not changed and fixed.scene.objects[0].transform.fit=='uniform'


def test_same_table_center_cannot_merge_two_people():
    table=SceneObject(id='table',label='桌子')
    scene=Scene(objects=[table,person('a'),person('b',1)],relations=[
        Relation(type='on',subject='a',target='table'),Relation(type='on',subject='b',target='table')])
    with pytest.raises(AppError,match='底部位置重合'):validate_plan_layout(scene)


def table():
    from memoryscape.schemas import Generation
    return SceneObject(id='table',label='桌子',kind='furniture',generation=Generation(primitive='table'),
                       transform=Transform(size=[3,.7,2]))


def test_person_at_table_body_center_is_rejected_but_behind_table_is_valid():
    with pytest.raises(AppError,match='身体中心'):validate_plan_layout(Scene(objects=[table(),person('guest')]))
    guest=person('guest');guest.transform.position=[0,0,-1.4]
    assert validate_plan_layout(Scene(objects=[table(),guest])).objects[1].transform.position==[0,0,-1.4]


@pytest.mark.parametrize('kind',['near','around'])
def test_relation_override_error_names_effective_fields_and_preserves_original(kind):
    guest=person('guest');guest.transform.position=[0,0,-1.4]
    scene=Scene(objects=[table(),guest],relations=[Relation(type=kind,subject='guest',target='table',radius=.1)])
    before=scene.model_dump()
    with pytest.raises(AppError) as error:validate_plan_layout(scene)
    message=str(error.value)
    assert '对象 ID=guest' in message and f'{kind}(target=table' in message
    assert '会覆盖对象 transform.position' in message and '桌子 ID=table' in message
    assert scene.model_dump()==before


def test_direct_position_error_points_to_transform_without_inventing_relation():
    with pytest.raises(AppError) as error:validate_plan_layout(Scene(objects=[table(),person('guest')]))
    assert '没有定位关系' in str(error.value)


def test_new_plan_rejects_overlapping_positioning_relations_but_allows_face():
    scene=Scene(objects=[table(),person('guest')],relations=[
        Relation(type='near',subject='guest',target='table',offset=[0,0,-1.4]),
        Relation(type='around',subject='guest',target='table')])
    plan=ScenePlan(summary='桌边人物',scene=scene)
    with pytest.raises(AppError,match='多个定位关系'):validate_plan_execution(plan,{'requirements':''})
    plan.scene.relations[1].type='face'
    validate_plan_execution(plan,{'requirements':''})


def test_floating_procedural_table_without_support_is_rejected():
    obj=table();obj.transform.position[1]=.5
    with pytest.raises(AppError,match='浮空薄盒子'):validate_plan_layout(Scene(objects=[obj]))


def test_explicit_floating_table_request_is_not_overridden_by_grounding_check():
    obj=table();obj.transform.position[1]=.5
    plan=ScenePlan(summary='悬浮展示桌子',scene=Scene(objects=[obj]))
    assert validate_plan(plan,{**project(),'requirements':'让桌子悬浮展示'},[],{}).scene.objects[0].transform.position[1]==.5
    with pytest.raises(AppError,match='浮空薄盒子'):
        validate_plan(plan,{**project(),'requirements':'不要让桌子悬浮'},[],{})


def test_two_items_on_same_table_centre_are_rejected():
    cake=SceneObject(id='cake',label='蛋糕',kind='food')
    gift=SceneObject(id='gift',label='礼物',kind='prop')
    scene=Scene(objects=[table(),cake,gift],relations=[
        Relation(type='on',subject='cake',target='table'),Relation(type='on',subject='gift',target='table')])
    with pytest.raises(AppError,match='同一支撑面中心'):validate_plan_layout(scene)
    scene.relations[1].offset=[1,0,0]
    assert validate_plan_layout(scene).objects[2].transform.position==[1,.7,0]


def contact_plan():
    cake=SceneObject(id='cake',label='生日蛋糕',kind='food',transform=Transform(size=[.4,.3,.4]))
    return ScenePlan(summary='蛋糕放在桌面',scene=Scene(objects=[table(),cake],relations=[
        Relation(type='on',subject='cake',target='table',offset=[.6,.7,.2])]))


def test_new_table_contact_compiles_height_but_preserves_horizontal_placement():
    plan=contact_plan();fixed,changed=fit_plan_contacts(plan,'蛋糕放在桌面上，不要悬浮')
    assert changed==['cake'] and fixed.scene.relations[0].offset==[.6,0,.2]
    assert plan.scene.relations[0].offset==[.6,.7,.2]
    assert validate_plan_layout(fixed.scene).objects[1].transform.position==[.6,.7,.2]


@pytest.mark.parametrize('field,value',[('locked',True),('status','ready'),('asset_id','a_existing'),
                                      ('reference_asset_id','a_reference'),('kind','person')])
def test_contact_compiler_does_not_move_old_locked_or_person_objects(field,value):
    plan=contact_plan();setattr(plan.scene.objects[1],field,value)
    fixed,changed=fit_plan_contacts(plan)
    assert not changed and fixed.scene.relations[0].offset==[.6,.7,.2]


@pytest.mark.parametrize('intent',['让蛋糕悬浮在桌子上方','希望悬浮展示蛋糕','floating cake',
                                    '不要让桌子浮空，让蛋糕悬浮','不要让桌子浮空但蛋糕悬浮'])
def test_explicit_floating_intent_is_not_silently_turned_into_contact(intent):
    plan=contact_plan();fixed,changed=fit_plan_contacts(plan,intent)
    assert not changed and fixed.scene.relations[0].offset[1]==.7
    with pytest.raises(AppError,match='间隙'):validate_plan_layout(fixed.scene)


def test_full_group_photo_is_not_a_tablecloth_texture():
    from memoryscape.schemas import Generation
    obj=SceneObject(id='cloth',label='桌布花纹',generation=Generation(
        strategy='photo',primitive='plane',primary_source='source',image_mode='original'))
    plan=ScenePlan(summary='保留桌布',scene=Scene(objects=[obj]))
    with pytest.raises(AppError,match='整张场景图'):validate_plan(plan,{**project(),'requirements':''},
                                                                [{'id':'source','kind':'image','role':'scene'}],{})


@pytest.mark.parametrize('mode',['original','crop'])
@pytest.mark.parametrize('strategy',['generate3d','photo'])
def test_reference_prompts_cannot_be_silently_ignored(mode,strategy):
    from memoryscape.schemas import Generation
    plan=ScenePlan(summary='只保留原人物',scene=Scene(objects=[SceneObject(id='p',label='人物',
        generation=Generation(strategy=strategy,image_mode=mode,image_prompt='提取人物，移除桌子和其他人'))]))
    with pytest.raises(AppError,match='不会执行提示词'):validate_plan_execution(plan,{'requirements':''})
    plan.scene.objects[0].generation.image_mode='edit'
    validate_plan_execution(plan,{'requirements':''})


def test_original_reference_without_edit_promise_stays_valid():
    from memoryscape.schemas import Generation
    plan=ScenePlan(summary='完整原图',scene=Scene(objects=[SceneObject(id='p',label='原图',
        generation=Generation(strategy='photo',image_mode='original'))]))
    validate_plan_execution(plan,{'requirements':''})


def test_explicit_people_around_table_cannot_become_people_on_table():
    plan=ScenePlan(summary='人围在桌边',scene=Scene(objects=[table(),person('guest')],relations=[
        Relation(type='on',subject='guest',target='table',offset=[1,0,1])]))
    with pytest.raises(AppError,match='会站到桌面'):
        validate_plan_execution(plan,{'requirements':'人物在桌子周围而不是站在桌面'})
    validate_plan_execution(plan,{'requirements':'让玩偶站在桌上展示'})
    plan.scene.relations[0].type='near'
    validate_plan_execution(plan,{'requirements':'所有人物落地'})


def test_all_reference_and_table_contact_errors_are_reported_in_one_correction():
    from memoryscape.schemas import Generation
    guest=person('guest');guest.generation=Generation(strategy='generate3d',image_prompt='提取完整人物')
    plan=ScenePlan(summary='生日',scene=Scene(objects=[table(),guest],relations=[
        Relation(type='on',subject='guest',target='table')]))
    with pytest.raises(AppError) as error:
        validate_plan_execution(plan,{'requirements':'所有人物落地'})
    assert '不会执行提示词' in str(error.value) and '会站到桌面' in str(error.value)


def test_single_subject_generation_constraint_is_applied_only_to_real_3d(service,png):
    from memoryscape.pipeline import Pipeline
    from memoryscape.schemas import ProjectCreate,Generation
    pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    src=service.add_source(pid,png,'photo.png','scene',rights=True)
    calls=[]
    class Provider:
        def remote(self,ctx,name,capability,**kw):
            calls.append(kw['prompt']);return {'data':png,'model':'image'}
    ctx=type('Context',(),{'project':pid,'job':{'payload':{}}})()
    gen=Generation(strategy='generate3d',primary_source=src['id'],image_mode='edit',image_prompt='原图中的戴帽子人物')
    obj=SceneObject(id='a',label='戴帽子的人物',generation=gen)
    Pipeline(service,Provider())._reference(ctx,obj,service.project(pid))
    assert '本次唯一主体：戴帽子的人物' in calls[0]
    assert '只保留本次指定对象' in calls[0]
    assert '组成部分' in calls[0]
