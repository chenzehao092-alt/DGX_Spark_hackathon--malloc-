import hashlib
import importlib.util
import json
import zipfile
from pathlib import Path
import pytest

def script_module(name):
    spec=importlib.util.spec_from_file_location(name,Path(__file__).resolve().parents[1]/f'scripts/{name}.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


builder=script_module('build_submission')
updater=script_module('update_manifest')
verifier=script_module('verify_release')


def manifest(tmp_path,entries):
    path=tmp_path/'MANIFEST.sha256.json'
    path.write_text(json.dumps(entries),encoding='utf-8')
    return path


def call_tool(tool,tmp_path):
    if tool=='build':return builder.build(tmp_path,tmp_path/'release.zip')
    if tool=='refresh':return updater.refresh(tmp_path)
    return verifier.verify(tmp_path)


def test_package_allowlist_excludes_runtime_and_refuses_overwrite(tmp_path):
    (tmp_path/'app.py').write_text('print("safe")',encoding='utf-8')
    (tmp_path/'data').mkdir();(tmp_path/'data/access-token').write_text('private-value',encoding='utf-8')
    sha=hashlib.sha256((tmp_path/'app.py').read_bytes()).hexdigest()
    manifest(tmp_path,{'app.py':sha})
    report=builder.build(tmp_path,tmp_path/'release.zip')
    assert report['files']==2 and not report['contains_runtime_data']
    with zipfile.ZipFile(tmp_path/'release.zip') as z:
        assert z.namelist()==['MemoryScape-1.6.2/MANIFEST.sha256.json','MemoryScape-1.6.2/app.py']
        assert z.testzip() is None
    assert report['sha256']==hashlib.sha256((tmp_path/'release.zip').read_bytes()).hexdigest()
    with pytest.raises(ValueError,match='exists'):builder.build(tmp_path,tmp_path/'release.zip')


@pytest.mark.parametrize('tool',['build','refresh','verify'])
@pytest.mark.parametrize('name',[
    'data/access-token','DATA/private.json','NODE-DATA/result.json','ACCEPTANCE/input/photo.png',
    'configs/models.toml','CONFIGS/MODELS.TOML','configs/DEPLOYMENT.IMAGE.TOML',
    '../outside.py','nested/../../outside.py','/outside.py','C:/outside.py','C:outside.py',
    '//server/share/outside.py','scripts\\..\\outside.py',
    '.env','.ENV','.ENV.production','configs/host.ENV','data/local-secrets.env',
    'models/x.pt','weights/x.safetensors','WEIGHTS/x.SAFETENSORS','x.PT','x.GGUF','x.ONNX',
    '.image-venv/runtime.py','.VENV/Scripts/python.py','custom-venv/runtime.py',
    'upstream-diffusers/private.py','NODE_MODULES/runtime.js','package.EGG-INFO/PKG-INFO',
    'image-node-token','AUDIO-NODE-TOKEN','PYTHON-PATH.TXT','__PYCACHE__/app.PYC',
    '.PYTEST_CACHE/cache.json','.MYPY_CACHE/cache.json','.RUFF_CACHE/cache.json',
    'HTMLCOV/index.html','.coverage','.COVERAGE.machine','server.LOG','server.LOG.1','server.LOG.gz',
    '.tmp-tests/private.json','.TMP/private.json','TMP/output.json','TEST-DATA/private.png','test_results/result.json',
    'BACKUPS/app.py','private.MEMORY.ZIP','private.MEMORY.ZIP.gz','app.py.','app.py ','NUL.txt',
    'scripts/app.py:private','MANIFEST.sha256.json',
])
def test_all_release_tools_reject_private_or_unsafe_paths_before_writing(tmp_path,tool,name):
    path=manifest(tmp_path,{name:'0'*64});before=path.read_bytes()
    with pytest.raises(ValueError,match='Forbidden'):call_tool(tool,tmp_path)
    assert not (tmp_path/'release.zip').exists()
    assert not (tmp_path/'MANIFEST.sha256.json.pending').exists()
    assert path.read_bytes()==before


@pytest.mark.parametrize('tool',['build','refresh','verify'])
def test_all_paths_are_checked_before_reading_any_payload(tmp_path,monkeypatch,tool):
    (tmp_path/'app.py').write_text('safe',encoding='utf-8')
    manifest(tmp_path,{'app.py':'0'*64,'.ENV':'0'*64})
    monkeypatch.setattr(Path,'read_bytes',lambda path:pytest.fail('payload read before path validation'))
    with pytest.raises(ValueError,match='Forbidden'):call_tool(tool,tmp_path)


@pytest.mark.parametrize('tool',['build','refresh','verify'])
@pytest.mark.parametrize('destination',['outside','runtime'])
def test_resolved_aliases_cannot_escape_or_enter_runtime_data(tmp_path,monkeypatch,tool,destination):
    listed=tmp_path/'app.py';listed.write_text('safe',encoding='utf-8')
    manifest(tmp_path,{'app.py':'0'*64})
    target=tmp_path.parent/'outside.py' if destination=='outside' else tmp_path/'data/private.json'
    resolve=Path.resolve
    def resolved(path,*args,**kwargs):
        return target if path==listed else resolve(path,*args,**kwargs)
    monkeypatch.setattr(Path,'resolve',resolved)
    monkeypatch.setattr(Path,'read_bytes',lambda path:pytest.fail('unsafe resolved payload read'))
    with pytest.raises(ValueError,match='Forbidden'):call_tool(tool,tmp_path)


@pytest.mark.parametrize('tool',['build','refresh','verify'])
def test_case_aliases_are_rejected_on_every_platform(tmp_path,tool):
    (tmp_path/'app.py').write_text('safe',encoding='utf-8')
    (tmp_path/'APP.py').write_text('safe',encoding='utf-8')
    manifest(tmp_path,{'app.py':'0'*64,'APP.py':'0'*64})
    with pytest.raises(ValueError,match='Duplicate release path'):call_tool(tool,tmp_path)


@pytest.mark.parametrize('tool',['build','refresh','verify'])
def test_slash_aliases_are_rejected(tmp_path,tool):
    (tmp_path/'scripts').mkdir();(tmp_path/'scripts/app.py').write_text('safe',encoding='utf-8')
    manifest(tmp_path,{'scripts/app.py':'0'*64,'scripts\\app.py':'0'*64})
    with pytest.raises(ValueError,match='Duplicate release path'):call_tool(tool,tmp_path)


def test_examples_remain_releasable_and_refresh_normalizes_archive_paths(tmp_path):
    names=['.env.example','configs/host.env.example','configs/models.example.toml',
           'configs/deployment.image.example.toml','scripts/app.py']
    entries={}
    for name in names:
        path=tmp_path/name;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text('public example',encoding='utf-8')
        entries[name.replace('/','\\')]=hashlib.sha256(path.read_bytes()).hexdigest()
    manifest(tmp_path,entries)
    assert verifier.verify(tmp_path)==len(names)
    report=builder.build(tmp_path,tmp_path/'release.zip')
    with zipfile.ZipFile(tmp_path/'release.zip') as z:
        assert z.namelist()==['MemoryScape-1.6.2/'+name for name in sorted(names+['MANIFEST.sha256.json'])]
        assert z.testzip() is None
    assert report['files']==len(names)+1
    assert updater.refresh(tmp_path)==len(names)
    assert set(json.loads((tmp_path/'MANIFEST.sha256.json').read_text('utf-8')))==set(names)
    assert verifier.verify(tmp_path)==len(names)


def test_refresh_rejects_private_additions_without_changing_manifest(tmp_path):
    (tmp_path/'app.py').write_text('safe',encoding='utf-8')
    path=manifest(tmp_path,{'app.py':hashlib.sha256((tmp_path/'app.py').read_bytes()).hexdigest()})
    before=path.read_bytes()
    with pytest.raises(ValueError,match='Forbidden'):updater.refresh(tmp_path,['.PYTEST_CACHE/cache.json'])
    assert path.read_bytes()==before
    assert not (tmp_path/'MANIFEST.sha256.json.pending').exists()


def test_refresh_never_overwrites_an_existing_pending_file(tmp_path):
    (tmp_path/'app.py').write_text('safe',encoding='utf-8')
    path=manifest(tmp_path,{'app.py':'0'*64});before=path.read_bytes()
    pending=tmp_path/'MANIFEST.sha256.json.pending';pending.write_text('preserve',encoding='utf-8')
    with pytest.raises(FileExistsError):updater.refresh(tmp_path)
    assert path.read_bytes()==before and pending.read_text('utf-8')=='preserve'


@pytest.mark.parametrize('tool',['build','verify'])
def test_manifest_hash_mismatch_still_stops_release(tmp_path,tool):
    (tmp_path/'app.py').write_text('changed',encoding='utf-8')
    manifest(tmp_path,{'app.py':'0'*64})
    with pytest.raises(ValueError,match='[Mm]ismatch'):call_tool(tool,tmp_path)
    assert not (tmp_path/'release.zip').exists()


@pytest.mark.parametrize('tool',['build','refresh','verify'])
def test_duplicate_json_manifest_keys_are_rejected(tmp_path,tool):
    (tmp_path/'MANIFEST.sha256.json').write_text('{"app.py":"'+('0'*64)+'","app.py":"'+('1'*64)+'"}',encoding='utf-8')
    with pytest.raises(ValueError,match='Duplicate manifest entry'):call_tool(tool,tmp_path)
