import io
import numpy as np
import pytest
from PIL import Image
from memoryscape.config import Settings
from memoryscape.service import Service
from memoryscape.schemas import ProjectCreate
from memoryscape.media import encode_wav
from memoryscape.api import create_app
from fastapi.testclient import TestClient

@pytest.fixture
# Legacy transport/edit fixtures do not certify visual quality. The separate
# reference-quality suite explicitly enables and exercises the production gate.
def settings(tmp_path):return Settings(data_dir=tmp_path/'data',config_file=tmp_path/'models.toml',token='test-only-random-looking-access-token-2026',start_worker=False,remote_poll_seconds=.001,reference_review=False,asset_review=False,decomposition_required=False).initialize()
@pytest.fixture
def service(settings):return Service(settings)
@pytest.fixture
def project(service):return service.create_project(ProjectCreate(title='测试回忆',requirements='保留原声，单独编辑物品'))
@pytest.fixture
def png():
 b=io.BytesIO();Image.new('RGB',(96,64),(180,120,60)).save(b,format='PNG');return b.getvalue()
@pytest.fixture
def wav():return encode_wav(np.sin(np.arange(32000)*2*np.pi*440/16000)*1000)
@pytest.fixture
def client(settings):
 app=create_app(settings)
 with TestClient(app,headers={'Authorization':'Bearer '+settings.token}) as c:yield c
