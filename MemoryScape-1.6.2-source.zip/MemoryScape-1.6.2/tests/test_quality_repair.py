"""Typed repair lifecycle tests with explicit critic/GPU doubles, not quality scores."""
import json
import pytest
from pydantic import ValidationError
from memoryscape.quality_repair import RepairRequest, RepairAction, RepairPlan, validate_commands, candidate_scene
from memoryscape.schemas import ProjectCreate, Scene, SceneObject, Generation, GeometryOptions, Transform
from memoryscape.geometry import procedural_glb
from memoryscape.pipeline import Pipeline
from memoryscape.jobs import Worker
from memoryscape.errors import AppError, ProviderError
from memoryscape.quality_render import VIEWS
from memoryscape.view_bundle import ANGLES
from memoryscape.db import dumps


def models(texture=False):
    caps={'brain':['brain.plan','vision.understand'],'image':['image.edit'],
          'geometry':['geometry.generate']+(['geometry.texture'] if texture else [])}
    return {name:{'enabled':True,'url':'http://127.0.0.1:9999','protocol':'chat' if name=='brain' else 'node-v1',
                  'capabilities':values,'max_images':12,'model':'explicit-test-double'} for name,values in caps.items()}


def seed(service,settings,png,texture=False,policy='strict'):
    settings.asset_review_policy=policy
    settings.test_models=models(texture);settings.quality_render_edge=128
    pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    source=service.add_source(pid,png,'photo.png','scene',rights=True)
    ref=service.assets.put(pid,png,'reference.png','derived',[source['id']])
    raw=procedural_glb('box')
    if texture:
        from tests.test_multiview_quality import textured_box
        raw=textured_box()
    mesh=service.assets.put(pid,raw,'current.glb','generated',[ref['id']])
    obj=SceneObject(id='target',label='目标物品',asset_id=mesh['id'],reference_asset_id=ref['id'],status='ready',
                    provenance='generated',generation=Generation(strategy='generate3d',primary_source=source['id'],
                        image_model='image',geometry_model='geometry',options=GeometryOptions(textured=texture)))
    other=SceneObject(id='protected',label='其他物品',asset_id=mesh['id'],status='ready',
                      transform=Transform(position=[3,0,0]),locked=True)
    scene=Scene(objects=[obj,other]);service.publish(pid,scene,0,'test baseline')
    return pid,scene,png


def request(service,pid,selected='target'):
    p=service.project(pid)
    return {'base_version':p['head'],'input_revision':p['input_revision'],'selected_object':selected,
            'user_approved':True,'max_objects':1,'prompt':'检查目标物品的严重缺陷并修复，其他内容保持不变。'}


class RepairDouble:
    def __init__(self,png,stage='regenerate_geometry',after='accept',texture=False,first='reject',error=None):
        self.png,self.stage,self.after,self.texture,self.first,self.error=png,stage,after,texture,first,error
        self.calls=[];self.remote_calls=[];self.inspections=0
    def cards(self):return models(self.texture)
    def chat(self,pid,system,user,images):
        self.calls.append((system,len(images),json.loads(user)))
        if self.error:raise self.error
        if 'RepairPlan' in system:
            action={'object_id':'target','finding_indices':[0],'stage':self.stage,'explanation':'只修复已指出的缺陷',
                    'prompt':'修复背部塌陷与多余突出，保持完整主体和原图外观。'}
            if self.stage=='relayout':action.update(prompt='',transform=Transform(position=[.2,0,0]).model_dump())
            return {'base_version':1,'summary':'修复目标，保留其他物品。','actions':[action]}
        if 'ReferenceReview' in system:
            return {'object_id':'target','verdict':'accept','target_present':True,'target_count':1,'other_subjects':[],
                    'appearance_preserved':True,'parts_complete':True,'background_clean':True,'reasons':['合同测试'],
                    'view':'three_quarter','view_evidence':'正面和侧面完整可见（明确测试桩，不代表真实图片检查）'}
        self.inspections+=1
        verdict=self.first if self.inspections==1 else self.after
        category={'regenerate_geometry':'geometry','prepare_reference':'reference','retexture':'texture','relayout':'layout'}[self.stage]
        report={'verdict':verdict,'reviewed_views':list(ANGLES if 'SceneQualityReview' in system else VIEWS),
                'summary':'明确测试桩判断，不代表真实模型效果','findings':[]}
        if verdict=='reject':report['findings']=[{'object_id':'target','view':'back','severity':'major',
            'category':category,'evidence':'背面可观察缺陷（测试桩）','repair':self.stage}]
        if 'AssetReview' in system:report['object_id']='target'
        return report
    def remote(self,ctx,name,capability,**kwargs):
        self.remote_calls.append((capability,kwargs))
        if capability=='image.edit':raw=self.png
        elif capability=='geometry.texture':
            from tests.test_multiview_quality import textured_box
            raw=textured_box()
        else:raw=procedural_glb('box')
        return {'data':raw,'model':'explicit-contract-double'}


def execute(service,settings,png,policy='strict',**kwargs):
    pid,before,png=seed(service,settings,png,texture=kwargs.get('texture',False),policy=policy)
    job=service.enqueue_repair(pid,request(service,pid),'one-repair')
    critic=RepairDouble(png,**kwargs)
    Worker(service,Pipeline(service,critic)).run_once()
    return pid,before,service.job(job['id']),critic


def test_inspect_plan_execute_and_reinspect_publishes_only_accepted_candidate(service,settings,png):
    pid,before,job,critic=execute(service,settings,png)
    assert job['status']=='succeeded',job
    assert job['result']['auto_repair']['status']=='accepted' and job['result']['version']==2
    assert job['result']['auto_repair']['rounds_executed']==1
    assert [cap for cap,_ in critic.remote_calls]==['image.edit','geometry.generate']
    assert '修复背部塌陷' in critic.remote_calls[0][1]['prompt']
    assert len(job['result']['auto_repair']['before']['renders'])==6
    assert len(job['result']['auto_repair']['after']['renders'])==8
    current=Scene.model_validate(service.scene(pid)['scene'])
    assert current.objects[1]==before.objects[1]
    assert service.scene(pid,1)['scene']==before.model_dump()


def test_failed_reinspection_retains_original_and_no_second_gpu_round(service,settings,png):
    pid,before,job,critic=execute(service,settings,png,after='reject')
    assert job['status']=='needs_review' and service.scene(pid)['scene']==before.model_dump()
    assert job['result']['candidate_only'] and job['result']['auto_repair']['status']=='held'
    assert [c for c,_ in critic.remote_calls]==['image.edit','geometry.generate']
    assert len(job['result']['asset_quality']['objects']['target']['candidates'])==1


@pytest.mark.parametrize('first',['accept','uncertain'])
def test_no_generation_when_not_needed_or_not_observable(service,settings,png,first):
    pid,before,job,critic=execute(service,settings,png,first=first)
    assert critic.remote_calls==[] and len(critic.calls)==1
    assert service.project(pid)['head']==1
    assert job['result']['auto_repair']['status']==('no_repair_needed' if first=='accept' else 'held')


def test_texture_repair_does_not_regenerate_geometry(service,settings,png):
    pid,before,job,critic=execute(service,settings,png,stage='retexture',texture=True)
    assert job['status']=='succeeded',job
    assert [c for c,_ in critic.remote_calls]==['image.edit','geometry.texture']
    from memoryscape.quality_render import surface_signature
    after=Scene.model_validate(service.scene(pid)['scene'])
    assert surface_signature(service.assets.read(before.objects[0].asset_id,pid))==surface_signature(service.assets.read(after.objects[0].asset_id,pid))


def test_layout_repair_is_local_and_still_reinspected(service,settings,png):
    pid,before,job,critic=execute(service,settings,png,stage='relayout')
    assert job['status']=='succeeded',job
    assert critic.remote_calls==[]
    assert service.scene(pid)['scene']['objects'][0]['transform']['position']==[.2,0,0]
    assert len(job['result']['auto_repair']['after']['renders'])==8


def test_503_is_a_failure_not_an_automatic_model_reroll(service,settings,png):
    pid,before,job,critic=execute(service,settings,png,error=ProviderError('HTTP503',code='provider_transient'))
    assert job['status']=='failed' and job['result']['auto_repair']['code']=='provider_transient'
    assert len(critic.calls)==1 and critic.remote_calls==[] and service.project(pid)['head']==1


def test_commit_recovery_reuses_evidence_and_never_calls_models_again(service,settings,png):
    pid,before,job,critic=execute(service,settings,png)
    count=(len(critic.calls),len(critic.remote_calls))
    service.db.execute('UPDATE jobs SET status="queued",owner=NULL,result=NULL WHERE id=?',(job['id'],))
    Worker(service,Pipeline(service,critic)).run_once()
    out=service.job(job['id'])
    assert out['status']=='succeeded' and out['result']['version']==2
    assert count==(len(critic.calls),len(critic.remote_calls)) and service.project(pid)['head']==2


def test_one_allowance_per_version_and_idempotent_replay(service,settings,png):
    pid,_,_=seed(service,settings,png);req=request(service,pid)
    one=service.enqueue_repair(pid,req,'same');assert service.enqueue_repair(pid,req,'same')['id']==one['id']
    service.db.execute('UPDATE jobs SET status="needs_review" WHERE id=?',(one['id'],))
    with pytest.raises(AppError,match='已执行过'):service.enqueue_repair(pid,req,'different')
    with pytest.raises(AppError,match='不同请求'):service.enqueue_repair(pid,{**req,'max_objects':2},'same')


@pytest.mark.parametrize('update',[{'base_version':0},{'input_revision':0},{'selected_object':'invented'},{'user_approved':False},{'user_approved':1},{'user_approved':'true'}])
def test_stale_unknown_or_unapproved_requests_do_not_allocate_jobs(service,settings,png,update):
    pid,_,_=seed(service,settings,png)
    with pytest.raises((AppError,ValidationError)):service.enqueue_repair(pid,{**request(service,pid),**update})
    assert service.db.one('SELECT COUNT(*) n FROM jobs')['n']==0


@pytest.mark.parametrize('update',[{'object_id':'protected'},{'finding_indices':[9]},{'stage':'retexture'},
    {'finding_indices':[0,0]},{'transform':Transform().model_dump()}, {'command':'rm something'}])
def test_model_commands_cannot_expand_scope_or_invent_tools(service,settings,png,update):
    pid,scene,_=seed(service,settings,png)
    action={'object_id':'target','finding_indices':[0],'stage':'regenerate_geometry','explanation':'test','prompt':'fix back'}
    report={'findings':[{'object_id':'target','severity':'major','category':'geometry'}]}
    payload={**request(service,pid),'scope_ids':['target']}
    with pytest.raises((AppError,ValidationError)):
        plan=RepairPlan(base_version=1,summary='test',actions=[RepairAction.model_validate({**action,**update})])
        validate_commands(plan,scene,report,payload,models())


@pytest.mark.parametrize('count', [7, 24])
def test_one_repair_can_reference_all_bounded_same_object_findings(service,settings,png,count):
    pid,scene,_=seed(service,settings,png)
    report={'findings':[{'object_id':'target','severity':'major','category':'geometry'} for _ in range(count)]}
    action=RepairAction(object_id='target',finding_indices=list(range(count)),
                        stage='regenerate_geometry',explanation='修复同一对象的多个方向缺陷',prompt='修复完整主体，其他物体不变')
    plan=RepairPlan(base_version=1,summary='仍然只执行一个阶段',actions=[action])
    payload={**request(service,pid),'scope_ids':['target']}
    assert validate_commands(plan,scene,report,payload,models()) is plan
    assert len(plan.actions)==1


def test_bounded_multi_finding_repair_still_rejects_foreign_object_evidence(service,settings,png):
    pid,scene,_=seed(service,settings,png)
    report={'findings':[{'object_id':'target','severity':'major','category':'geometry'} for _ in range(7)]}
    report['findings'][6]['object_id']='protected'
    action=RepairAction(object_id='target',finding_indices=list(range(7)),
                        stage='regenerate_geometry',explanation='test',prompt='修复背面')
    with pytest.raises(AppError,match='对应对象'):
        validate_commands(RepairPlan(base_version=1,summary='test',actions=[action]),scene,report,
                          {**request(service,pid),'scope_ids':['target']},models())


def test_repair_evidence_bound_matches_critic_and_rejects_overflow():
    action={'object_id':'target','stage':'regenerate_geometry','explanation':'test','prompt':'修复背面'}
    assert RepairAction.model_json_schema()['properties']['finding_indices']['maxItems']==24
    with pytest.raises(ValidationError):RepairAction.model_validate({**action,'finding_indices':list(range(25))})


def test_texture_cannot_change_shape_or_publish_changed_mesh(service,settings,png):
    pid,before,_=seed(service,settings,png,texture=True)
    critic=RepairDouble(png,stage='retexture',texture=True)
    real=critic.remote
    def changed(ctx,name,capability,**kw):
        out=real(ctx,name,capability,**kw)
        if capability=='geometry.texture':
            from tests.test_multiview_quality import textured_box
            out['data']=textured_box(changed=True)
        return out
    critic.remote=changed
    j=service.enqueue_repair(pid,request(service,pid));Worker(service,Pipeline(service,critic)).run_once()
    out=service.job(j['id'])
    assert out['status']=='needs_review' and service.scene(pid)['scene']==before.model_dump()
    assert '改变了已有形状' in str(out['result']['failures'])


def test_input_changes_during_review_prevent_commit(service,settings,png):
    pid,before,_=seed(service,settings,png);critic=RepairDouble(png,stage='relayout');original=critic.chat
    def edit_inputs(*args,**kwargs):
        value=original(*args,**kwargs)
        if len(critic.calls)==3:service.db.execute('UPDATE projects SET input_revision=input_revision+1 WHERE id=?',(pid,))
        return value
    critic.chat=edit_inputs
    j=service.enqueue_repair(pid,request(service,pid));Worker(service,Pipeline(service,critic)).run_once()
    out=service.job(j['id'])
    assert out['status']=='needs_review' and out['result']['candidate_only']
    assert out['result']['auto_repair']['status']=='held' and service.scene(pid)['scene']==before.model_dump()


def test_api_requires_auth_and_explicit_request(settings,png):
    from memoryscape.api import create_app
    from fastapi.testclient import TestClient
    app=create_app(settings)
    pid,_,_=seed(app.state.service,settings,png)
    req=request(app.state.service,pid)
    with TestClient(app) as client:
        assert client.post(f'/api/projects/{pid}/quality-repair',json=req).status_code==401
        headers={'Authorization':'Bearer '+settings.token}
        assert client.post(f'/api/projects/{pid}/quality-repair',json={**req,'user_approved':False},headers=headers).status_code==422
        assert client.post(f'/api/projects/{pid}/quality-repair',json=req,headers=headers).status_code==200


def test_transport_failure_inside_execution_resumes_same_request_without_new_inspection(service,settings,png):
    pid,before,_=seed(service,settings,png);critic=RepairDouble(png);original=critic.remote;once=[True]
    def transient(ctx,name,capability,**kw):
        if once[0]:
            once[0]=False;raise ProviderError('HTTP503',code='provider_transient')
        return original(ctx,name,capability,**kw)
    critic.remote=transient
    j=service.enqueue_repair(pid,request(service,pid));Worker(service,Pipeline(service,critic)).run_once()
    failed=service.job(j['id']);assert failed['status']=='failed' and service.scene(pid)['scene']==before.model_dump()
    assert failed['result']['failure_codes']['reference:target']=='provider_transient'
    count=len(critic.calls)
    from memoryscape.api import create_app
    from fastapi.testclient import TestClient
    with TestClient(create_app(settings),headers={'Authorization':'Bearer '+settings.token}) as client:
        assert client.post('/api/jobs/'+j['id']+'/retry').status_code==200
    Worker(service,Pipeline(service,critic)).run_once()
    done=service.job(j['id'])
    assert done['status']=='succeeded',done
    assert len(critic.calls)==count+3  # reference, six-view, assembled-scene only
    assert [c for c,_ in critic.remote_calls]==['image.edit','geometry.generate']
    from memoryscape.agent_budget import snapshot
    assert snapshot(service,j['id'])['root_job']==j['id']


def test_invalid_repair_reference_stops_before_gpu_and_reports_correct_phase(service,settings,png):
    pid,before,_=seed(service,settings,png);critic=RepairDouble(png);original=critic.chat
    def reference_rejected(pid,system,user,images):
        report=original(pid,system,user,images)
        if 'ReferenceReview' in system:report.update(verdict='reject',other_subjects=['椅子'],parts_complete=False)
        return report
    critic.chat=reference_rejected
    job=service.enqueue_repair(pid,request(service,pid));Worker(service,Pipeline(service,critic)).run_once()
    out=service.job(job['id'])
    assert out['status']=='needs_review' and '参考图内容检查未通过' in out['result']['conflict']
    assert [c for c,_ in critic.remote_calls]==['image.edit']
    assert service.scene(pid)['scene']==before.model_dump()
