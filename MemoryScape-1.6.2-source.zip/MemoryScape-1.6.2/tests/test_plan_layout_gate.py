"""User acceptance regression: invalid plans fail before creating assets."""
import json
import time
import pytest
from memoryscape.errors import AppError
from memoryscape.layout import validate_plan,validate_plan_layout
from memoryscape.pipeline import Pipeline
from memoryscape.schemas import Scene,SceneObject,ScenePlan,Relation,Transform


def beach_plan(sea_y=0, lamp_gap=0):
    return ScenePlan(summary='海边的桌椅与暖灯',scene=Scene(objects=[
        SceneObject(id='table',label='小木桌'),
        SceneObject(id='lamp',label='暖灯'),
        SceneObject(id='sea',label='海背景',transform=Transform(position=[0,sea_y,0]))],
        relations=[Relation(type='on',subject='lamp',target='table',offset=[0,lamp_gap,0])]))


@pytest.mark.parametrize('sea_y,lamp_gap',[(-.1,0),(0,.1),(0,-.1)])
def test_invalid_new_layout_rejected_during_planning(project,sea_y,lamp_gap):
    with pytest.raises(AppError,match='规划布局'):
        validate_plan(beach_plan(sea_y,lamp_gap),project,[],{})


def test_valid_contact_is_solved_without_mutating_original_plan():
    plan=beach_plan()
    solved=validate_plan_layout(plan.scene)
    assert solved.objects[1].transform.position==[0,1,0]
    assert plan.scene.objects[1].transform.position==[0,0,0]


def test_director_corrects_layout_before_generation(service,project):
    pid=project['id']
    class Provider:
        calls=[]
        def chat(self,_,system,user,images):
            self.calls.append(user)
            return beach_plan(-.1,.1).model_dump() if len(self.calls)==1 else beach_plan().model_dump()
    class Context:
        project=pid
        def check(self):pass
        def emit(self,*args):pass
    provider=Provider()
    result=Pipeline(service,provider).structured(Context(),'system','user',[],ScenePlan,
        lambda value:validate_plan(value,project,[],{}))
    assert len(provider.calls)==2 and '底部低于地面' in provider.calls[1]
    assert 'offset.y 应为 0' in provider.calls[1]
    assert result.scene.objects[1].transform.position[1]==1
    assert not service.db.all('SELECT id FROM jobs')


def test_old_invalid_pending_plan_cannot_commit_draft(service,project):
    pid=project['id'];plan=beach_plan(-.1)
    service.db.execute('INSERT INTO plans VALUES(?,?,?,?,?,?,?)',
        ('plan_old',pid,0,0,json.dumps(plan.model_dump()),'pending',time.time()))
    with pytest.raises(AppError,match='规划布局'):
        service.confirm_plan(pid,'plan_old',0,0)
    assert service.project(pid)['head']==0
    assert service.db.one('SELECT status FROM plans WHERE id=?',('plan_old',))['status']=='pending'
    assert not service.db.all('SELECT id FROM jobs')
