"""State, intent, temporal retrieval and real edit-pipeline regressions."""
import json
import pytest
from pydantic import ValidationError
from memoryscape.schemas import Scene,SceneObject,Generation,Transform,Relation,AudioTrack,Patch,Operation,ProjectCreate
from memoryscape.memory import deletion_intent,validate_edit_intent,scene_delta
from memoryscape.errors import AppError
from memoryscape.pipeline import Pipeline
from memoryscape.jobs import Worker


def setup_scene(service,*,locked=False,extra_base=False):
    p=service.create_project(ProjectCreate(mode='real',remote_consent=True))
    scene=Scene(objects=[
        SceneObject(id='poster',label='相声社海报',generation=Generation(strategy='photo'),transform=Transform(position=[0,.1,0],size=[1.5,2.25,.01])),
        SceneObject(id='base',label='底座',locked=locked,transform=Transform(size=[1.8,.1,.6],fit='stretch')),
        SceneObject(id='frame',label='海报边框',generation=Generation(primitive='frame',frame_target='poster'),transform=Transform(size=[1.6,2.4,.05],fit='stretch'))],
        relations=[Relation(type='on',subject='poster',target='base')])
    scene=service.fit_bound_frames(p['id'],scene)
    if extra_base:scene.objects.append(SceneObject(id='base2',label='底座'))
    service.publish(p['id'],scene,0,'已有用户场景')
    return p['id']


@pytest.mark.parametrize('text',['删除底座','请把底座删除','删掉底座','移除这个底座','去掉支座','删除base','删除刚才的底座','删除下面的底座'])
def test_explicit_name_overrides_selected_poster(service,text):
    pid=setup_scene(service);m=service.memory(pid,'poster',text)
    assert m['edit_intent']['required_remove_ids']==['base']
    assert m['edit_intent']['delete_only']
    assert {o['id'] for o in m['objects']}=={'poster','base','frame'}
    validate_edit_intent(Patch(base_version=1,operations=[Operation(type='remove',object_id='base')]),m)


@pytest.mark.parametrize('text',['不要删除底座','别删除底座','是否删除底座？','可以删除底座吗？','底座不删除'])
def test_negation_and_questions_never_authorize_remove(service,text):
    pid=setup_scene(service);m=service.memory(pid,query=text)
    with pytest.raises(AppError):validate_edit_intent(Patch(base_version=1,operations=[Operation(type='remove',object_id='base')]),m)


@pytest.mark.parametrize('text',['把背景设成黑色','把海报背面改为黑色'])
@pytest.mark.parametrize('target',['base','frame','poster'])
def test_region_color_cannot_be_substituted_by_another_object_or_whole_tint(service,text,target):
    pid=setup_scene(service);m=service.memory(pid,query=text)
    with pytest.raises(AppError):validate_edit_intent(Patch(base_version=1,operations=[Operation(type='tint',object_id=target,color='#000000')]),m)
    validate_edit_intent(Patch(base_version=1,explanation='暂不支持局部配色，当前场景未改动'),m)


@pytest.mark.parametrize('text',['删除它','删除不存在的椅子'])
def test_unknown_parts_and_pronouns_require_clarification(service,text):
    pid=setup_scene(service);m=service.memory(pid,query=text)
    assert m['edit_intent']['needs_clarification']
    validate_edit_intent(Patch(base_version=1,explanation='请明确要删除的独立物品'),m)
    with pytest.raises(AppError):validate_edit_intent(Patch(base_version=1,operations=[Operation(type='remove',object_id='poster')]),m)


@pytest.mark.parametrize('text',['删除海报上的文字','去掉人物的帽子','把球的凹凸不平去掉'])
def test_part_edits_do_not_authorize_whole_object_removal(service,text):
    pid=setup_scene(service);m=service.memory(pid,query=text)
    assert not m['edit_intent']['remove_authorized']
    with pytest.raises(AppError):validate_edit_intent(Patch(base_version=1,operations=[Operation(type='remove',object_id='poster')]),m)
    # Existing image-edit support/rejection remains handled by capabilities.
    validate_edit_intent(Patch(base_version=1,operations=[Operation(type='regenerate',object_id='poster',prompt=text)]),m)


def test_ambiguous_names_do_not_use_selection_to_guess(service):
    pid=setup_scene(service,extra_base=True);m=service.memory(pid,'base','删除底座')
    assert m['edit_intent']['needs_clarification'];assert m['edit_intent']['candidate_ids']==['base','base2']
    m=service.memory(pid,'base','删除这个')
    assert m['edit_intent']['required_remove_ids']==['base']


@pytest.mark.parametrize('ops',[
    [Operation(type='transform',object_id='poster',transform=Transform())],
    [Operation(type='tint',object_id='base',color='#000000')],
    [Operation(type='remove',object_id='poster')],
    [Operation(type='remove',object_id='base'),Operation(type='transform',object_id='poster',transform=Transform())],
    []])
def test_delete_is_not_substituted_or_accompanied_by_unrequested_changes(service,ops):
    pid=setup_scene(service);m=service.memory(pid,query='删除底座')
    with pytest.raises(AppError):validate_edit_intent(Patch(base_version=1,operations=ops),m)


def test_removal_preserves_remaining_objects_and_old_version(service):
    pid=setup_scene(service);before=service.scene(pid)['scene']
    result=service.apply_patch(pid,Patch(base_version=1,explanation='错误说法',operations=[Operation(type='remove',object_id='base')]))
    assert result['version']==2 and not result['job_id']
    assert result['scene']['objects']==[o for o in before['objects'] if o['id']!='base']
    assert result['scene']['relations']==[]
    assert service.scene(pid,1)['scene']==before
    restored=service.restore(pid,1,2);assert restored['version']==3;assert restored['scene']==before


def test_remove_lock_and_stale_version_guards(service):
    pid=setup_scene(service,locked=True)
    with pytest.raises(AppError,match='锁定'):service.apply_patch(pid,Patch(base_version=1,operations=[Operation(type='remove',object_id='base')]))
    assert service.project(pid)['head']==1
    with pytest.raises(AppError,match='旧版本'):service.apply_patch(pid,Patch(base_version=0,operations=[Operation(type='remove',object_id='poster')]))


def test_remove_dependency_cleanup_does_not_cascade_delete(service):
    pid=setup_scene(service);sc=Scene.model_validate(service.scene(pid)['scene']);sc.audio=[AudioTrack(id='audio',label='声音',anchor='poster')]
    service.publish(pid,sc,1,'绑定声音')
    result=service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='remove',object_id='poster')]))
    assert {o['id'] for o in result['scene']['objects']}=={'base','frame'}
    assert result['scene']['objects'][1]['generation']['frame_target'] is None
    assert result['scene']['audio'][0]['anchor'] is None
    assert result['scene']['objects'][1]['transform']==sc.objects[2].transform.model_dump()


def test_removing_target_cannot_mutate_locked_frame(service):
    pid=setup_scene(service);service.apply_patch(pid,Patch(base_version=1,operations=[Operation(type='lock',object_id='frame',locked=True)]))
    with pytest.raises(AppError,match='锁定'):service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='remove',object_id='poster')]))
    assert service.project(pid)['head']==2


def test_reused_target_requires_explicit_dependency_choice(service):
    pid=setup_scene(service);sc=Scene.model_validate(service.scene(pid)['scene'])
    sc.objects.append(SceneObject(id='copy',label='复制底座',generation=Generation(strategy='reuse',reuse_object='base')))
    service.publish(pid,sc,1,'复用')
    with pytest.raises(AppError,match='复用'):service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='remove',object_id='base')]))
    result=service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='remove',object_id='base'),Operation(type='remove',object_id='copy')]))
    assert {o['id'] for o in result['scene']['objects']}=={'poster','frame'}


@pytest.mark.parametrize('ops',[
    [Operation(type='remove',object_id='base'),Operation(type='remove',object_id='base')],
    [Operation(type='remove',object_id='base'),Operation(type='tint',object_id='base',color='#000000')]])
def test_contradictory_patch_is_atomic(service,ops):
    pid=setup_scene(service)
    with pytest.raises(AppError):service.apply_patch(pid,Patch(base_version=1,operations=ops))
    assert service.project(pid)['head']==1


def test_remove_has_no_ignored_operands():
    with pytest.raises(ValidationError):Operation(type='remove',object_id='base',transform=Transform())


def test_memory_recalls_older_related_request_beyond_twelve_and_separates_suggestions(service):
    pid=setup_scene(service)
    old=service.enqueue(pid,'edit',{'base_version':1,'prompt':'底座保留原木色','selected_object':'base'})
    for i in range(20):service.enqueue(pid,'edit',{'base_version':1,'prompt':f'无关的声音请求{i}'})
    m=service.memory(pid,query='底座现在怎么了')
    turn=next(e for e in m['episodic_history'] if e.get('job_id')==old['id'])
    assert turn['user_request']=='底座保留原木色' and turn['proposal_status']=='not_created'
    assert turn['historical_only'] and m['retrieval']['scanned_turns']==21


def test_memory_reports_actual_diff_not_false_delete_claim_and_tracks_restore(service):
    pid=setup_scene(service)
    wrong=service.apply_patch(pid,Patch(base_version=1,explanation='底座已删除',operations=[Operation(type='transform',object_id='poster',transform=Transform())]))
    m=service.memory(pid,query='删除底座')
    evidence=next(e for e in m['episodic_history'] if e.get('version')==wrong['version'])
    assert not any(e['action']=='removed' for e in evidence['verified_changes'])
    assert '底座已删除' not in json.dumps(m['episodic_history'],ensure_ascii=False)
    service.restore(pid,1,2);m=service.memory(pid,query='底座')
    evidence=next(e for e in m['episodic_history'] if e.get('version')==2)
    assert evidence['superseded_by_restore']
    assert 'base' in m['all_object_ids']


def test_real_pipeline_repairs_wrong_delete_with_current_intent_memory(service):
    pid=setup_scene(service)
    class Provider:
        calls=0
        def cards(self):return {}
        def chat(self,project,system,user,images):
            self.calls+=1;context=json.loads(user.split('\n上一轮')[0])
            assert 'recent_decisions' not in context['memory']
            assert context['memory']['edit_intent']['required_remove_ids']==['base']
            assert '不删除已有对象' not in system
            if self.calls==1:return {'base_version':1,'explanation':'删除了底座','operations':[{'type':'transform','object_id':'poster','transform':Transform().model_dump()}]}
            assert '不能以移动海报' in user
            return {'base_version':1,'explanation':'只删除底座','operations':[{'type':'remove','object_id':'base'}]}
    provider=Provider();worker=Worker(service,Pipeline(service,provider))
    job=service.enqueue(pid,'edit',{'prompt':'删除底座','base_version':1,'selected_object':'poster'})
    assert worker.run_once();result=service.job(job['id']);assert result['status']=='succeeded' and provider.calls==2
    assert [op['type'] for op in result['result']['patch']['operations']]==['remove']
    proposal_id=result['result']['proposal_id']
    service.apply_patch(pid,Patch.model_validate(result['result']['patch']),from_model=True,proposal_id=proposal_id)
    assert 'base' not in service.memory(pid)['all_object_ids']


def test_apply_old_pending_wrong_proposal_rechecks_intent(service):
    from memoryscape.db import dumps
    import time
    pid=setup_scene(service);job=service.enqueue(pid,'edit',{'prompt':'删除底座','base_version':1})
    patch=Patch(base_version=1,operations=[Operation(type='transform',object_id='poster',transform=Transform())])
    service.db.execute('INSERT INTO proposals VALUES(?,?,?,?,?)',('legacy',pid,dumps(patch.model_dump()),'pending',time.time()))
    service.db.execute('UPDATE jobs SET result=?,status="succeeded" WHERE id=?',(dumps({'proposal_id':'legacy','patch':patch.model_dump()}),job['id']))
    with pytest.raises(AppError):service.apply_patch(pid,patch,from_model=True,proposal_id='legacy')
    assert service.project(pid)['head']==1
