"""Workflow-first policy tests; doubles exercise control flow, not visual quality."""
import copy
import pytest
from pydantic import ValidationError
from memoryscape.schemas import ScenePlan, Scene, SceneObject, Transform
from memoryscape.pipeline import Pipeline
from memoryscape.errors import AppError, ProviderError
from memoryscape.layout import validate_plan
from memoryscape.config import Settings
from memoryscape.jobs import Worker
from tests.test_multiview_quality import Critic, TextureCritic, seed as build_seed
from tests.test_quality_repair import execute, seed as repair_seed, request, RepairDouble


def document():
    return {'summary':'四个人的生日', 'scene':{
        'reference_person_count':4,
        'objects':[SceneObject(id=f'p{i}',label=f'人物{i}',kind='person',
            transform=Transform(position=[i*2,0,0])).model_dump() for i in range(4)]}}


def test_misplaced_count_is_normalized_without_changing_document_or_dropping_people():
    raw=document();before=copy.deepcopy(raw)
    plan=ScenePlan.model_validate(raw)
    assert raw==before
    assert plan.reference_person_count==4
    assert 'reference_person_count' not in plan.scene.model_dump()
    project={'requirements':'保留原图人数','budget':{'max_objects':20,'max_generated_assets':8},'allow_synthetic_audio':False}
    assert len(validate_plan(plan,project,[],{}).scene.objects)==4


@pytest.mark.parametrize('top',[None,4])
def test_matching_or_empty_canonical_count_accepts_nested_alias(top):
    assert ScenePlan.model_validate({**document(),'reference_person_count':top}).reference_person_count==4


@pytest.mark.parametrize('count',[-1,21,True,'4',4.5])
def test_compatibility_does_not_turn_invalid_counts_into_valid_statistics(count):
    raw=document();raw['scene']['reference_person_count']=count
    with pytest.raises(ValidationError):ScenePlan.model_validate(raw)


def test_conflicting_counts_unknown_fields_and_missing_people_remain_rejected():
    with pytest.raises(ValidationError,match='冲突'):
        ScenePlan.model_validate({**document(),'reference_person_count':3})
    raw=document();raw['scene']['command']='execute something'
    with pytest.raises(ValidationError,match='Extra inputs'):ScenePlan.model_validate(raw)
    raw=document();raw['scene']['objects'].pop()
    plan=ScenePlan.model_validate(raw)
    with pytest.raises(AppError,match='人物数量不一致'):
        validate_plan(plan,{'requirements':'保留原图人数','budget':{},'allow_synthetic_audio':False},[],{})


def test_misplaced_count_needs_one_director_call_not_three(service):
    class Director:
        calls=0
        def chat(self,*args):self.calls+=1;return document()
    class Context:
        project='contract-test'
        def check(self):pass
        def emit(self,*args):raise AssertionError('No schema retry should occur')
    director=Director()
    plan=Pipeline(service,director).structured(Context(),'system','user',[],ScenePlan)
    assert plan.reference_person_count==4 and director.calls==1


def test_defaults_are_advisory_but_invalid_policy_still_fails(monkeypatch,tmp_path):
    monkeypatch.delenv('MS_ASSET_REVIEW_POLICY',raising=False)
    monkeypatch.delenv('MS_REFERENCE_REVIEW_POLICY',raising=False)
    settings=Settings(data_dir=tmp_path,token='test-only-token-that-is-long-enough')
    assert settings.asset_review_policy==settings.reference_review_policy=='warn'
    settings.asset_review_policy='ignore_everything'
    with pytest.raises(ValueError,match='strict or warn'):settings.initialize()


def test_warn_publishes_valid_rejected_mesh_without_reroll_and_records_all_views(service,settings,png):
    critic=Critic(bad=20)
    pid,job=build_seed(service,settings,png,critic,policy='warn')
    assert job['status']=='succeeded',job
    assert service.project(pid)['head']==1
    assert job['payload']['quality_profile']['repair_attempts']==0
    assert critic.remote_calls==[('geometry.generate',2026)]
    quality=job['result']['asset_quality']
    assert quality['status']=='warning' and not quality['objects']['target']['current']['accepted']
    assert len(quality['objects']['target']['current']['renders'])==6 and len(quality['scene']['renders'])==8
    assert job['result']['quality_warnings'][0]['quality_accepted'] is False


@pytest.mark.parametrize('unavailable',[False,True])
def test_warn_reference_review_is_advisory_not_a_generation_block(service,settings,png,unavailable):
    class ReferenceWarning(Critic):
        def chat(self,pid,system,user,images):
            if 'ReferenceReview' in system:
                if unavailable:raise ProviderError('HTTP503',code='provider_transient')
                report=super().chat(pid,system,user,images)
                report.update(verdict='reject',parts_complete=False)
                return report
            return super().chat(pid,system,user,images)
    critic=ReferenceWarning()
    pid,job=build_seed(service,settings,png,critic,policy='warn')
    assert job['status']=='succeeded' and service.project(pid)['head']==1,job
    assert critic.remote_calls==[('geometry.generate',2026)]
    quality=job['result']['asset_quality']
    assert quality['status']=='warning'
    ref=quality['objects']['target']['candidates'][0]
    assert ref['stage']=='reference' and ref['accepted'] is False


def test_warn_still_textures_rejected_geometry_and_never_rerolls(service,settings,png):
    critic=TextureCritic();critic.bad=20
    pid,job=build_seed(service,settings,png,critic,textured=True,policy='warn')
    assert job['status']=='succeeded',job
    assert critic.remote_calls==[('geometry.generate',2026),('geometry.texture',2026)]
    assert job['result']['asset_quality']['status']=='warning'
    assert service.assets.get(job['result']['scene']['objects'][0]['asset_id'],pid)['meta']['triangles']>0


@pytest.mark.parametrize('transport',[False,True])
def test_warn_does_not_accept_corrupt_glb_or_generation_transport_failure(service,settings,png,transport):
    class BrokenGeometry(Critic):
        def remote(self,*args,**kwargs):
            if transport:raise ProviderError('HTTP503',code='provider_transient')
            return {'data':b'not-a-glb','model':'explicit-corrupt-double'}
    pid,job=build_seed(service,settings,png,BrokenGeometry(),policy='warn')
    assert job['status']=='failed' and service.project(pid)['head']==0,job
    assert job['result']['failures'] and job['result']['candidate_only']


def test_warn_does_not_accept_texture_that_changes_shape(service,settings,png):
    pid,job=build_seed(service,settings,png,TextureCritic(changed=True),textured=True,policy='warn')
    assert job['status']=='failed' and service.project(pid)['head']==0,job
    assert '改变了' in str(job['result']['failures'])


@pytest.mark.parametrize('stage',['regenerate_geometry','relayout'])
def test_warn_repair_publishes_one_valid_candidate_and_truthful_warning(service,settings,png,stage):
    pid,before,job,critic=execute(service,settings,png,stage=stage,after='reject',policy='warn')
    assert job['status']=='succeeded' and service.project(pid)['head']==2,job
    record=job['result']['auto_repair']
    assert record['status']=='published_with_warnings' and record['quality_accepted'] is False
    assert record['rounds_executed']==1 and record['policy']=='warn'
    assert Scene.model_validate(service.scene(pid)['scene']).objects[1]==before.objects[1]
    assert service.scene(pid,1)['scene']==before.model_dump()
    assert len(critic.remote_calls)==(2 if stage=='regenerate_geometry' else 0)


def test_warn_repair_still_rejects_below_floor_change(service,settings,png):
    pid,before,_=repair_seed(service,settings,png,policy='warn')
    critic=RepairDouble(png,stage='relayout');original=critic.chat
    def below_floor(pid,system,user,images):
        value=original(pid,system,user,images)
        if 'RepairPlan' in system:value['actions'][0]['transform']=Transform(position=[0,-1,0]).model_dump()
        return value
    critic.chat=below_floor
    job=service.enqueue_repair(pid,request(service,pid))
    Worker(service,Pipeline(service,critic)).run_once()
    assert service.job(job['id'])['status']=='needs_review'
    assert service.scene(pid)['scene']==before.model_dump()
