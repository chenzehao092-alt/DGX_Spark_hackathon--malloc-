"""A connected borrowed model must never be provisioned or stopped."""
import io
import json
import sys
from pathlib import Path
import pytest
from memoryscape.config import Settings

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import desktop_node
import desktop_stop


def deployment(tmp_path,lifecycle='reuse'):
    path=tmp_path/'deployment.toml'
    path.write_text(f'''[remote]
lifecycle = "{lifecycle}"
ssh_target = "tester@spark"
project = "/srv/apps/memoryscape-test"
python = "/srv/env/bin/python"
node_port = 9103
local_port = 19103
''',encoding='utf-8')
    return path


@pytest.mark.parametrize('lifecycle',['reuse','managed'])
@pytest.mark.parametrize('capabilities',[['geometry.generate'],['geometry.generate','geometry.texture']])
def test_ready_node_is_reused_without_deploying_or_installing(tmp_path,monkeypatch,lifecycle,capabilities):
    path=deployment(tmp_path,lifecycle)
    settings=Settings(data_dir=tmp_path/'data',config_file=tmp_path/'models.toml').initialize()
    calls=[]
    def command(argv,**kwargs):
        calls.append(argv)
        if argv[0]=='ssh':return json.dumps({'ready':True,'port_in_use':True}).encode()
        assert argv[0]=='scp' and '-r' not in argv
        assert argv[-2].endswith('/node-data/geometry/token')
        Path(argv[-1]).write_text('test-only-node-token-123456789')
        return b''
    def urlopen(*args,**kwargs):
        return io.BytesIO(json.dumps({'fingerprint':{'runtime_revision':'memoryscape-1.5-desktop'},
            'execution_mode':'native','capabilities':capabilities}).encode())
    monkeypatch.setattr(desktop_node,'command',command)
    monkeypatch.setattr(desktop_node.urllib.request,'urlopen',urlopen)
    monkeypatch.delenv('GEOMETRY_NODE_TOKEN',raising=False)
    desktop_node.ensure_node(tmp_path,settings,path)
    assert len(calls)==2
    assert settings.models()['geometry']['capabilities']==capabilities
    assert settings.models()['geometry']['url']=='http://127.0.0.1:19103'
    record=json.loads((settings.data_dir/'node-connection.json').read_text())
    assert record['remote_started'] is False
    assert not desktop_stop.owns_remote(settings.data_dir,record)


@pytest.mark.parametrize('lifecycle,busy',[('reuse',False),('managed',True)])
def test_unavailable_borrowed_or_foreign_node_fails_without_sync(tmp_path,monkeypatch,lifecycle,busy):
    calls=[]
    def command(argv,**kwargs):
        calls.append(argv)
        return json.dumps({'ready':False,'port_in_use':busy}).encode()
    monkeypatch.setattr(desktop_node,'command',command)
    settings=Settings(data_dir=tmp_path/'data',config_file=tmp_path/'models.toml').initialize()
    with pytest.raises(RuntimeError):desktop_node.ensure_node(tmp_path,settings,deployment(tmp_path,lifecycle))
    assert len(calls)==1 and calls[0][0]=='ssh'
    assert not settings.config_file.exists()


def test_remote_stop_requires_matching_managed_launch_record(tmp_path):
    conf={'lifecycle':'managed','project':'/srv/apps/memoryscape-test','ssh_target':'tester@spark','node_port':9103}
    assert not desktop_stop.owns_remote(tmp_path,conf)
    (tmp_path/'node-connection.json').write_text(json.dumps({**conf,'remote_started':True}))
    assert desktop_stop.owns_remote(tmp_path,conf)
    assert not desktop_stop.owns_remote(tmp_path,{**conf,'lifecycle':'reuse'})
    assert not desktop_stop.owns_remote(tmp_path,{**conf,'project':'/srv/apps/memoryscape-other'})


@pytest.mark.parametrize('field,value',[('local_port',True),('node_port',0),('lifecycle','invalid'),('ssh_target','-oProxyCommand=bad')])
def test_invalid_deployment_never_reaches_ssh(field,value):
    conf={'project':'/srv/apps/memoryscape-test','ssh_target':'tester@spark','node_port':9103,'local_port':19103}
    with pytest.raises(ValueError):desktop_node.validate_remote({**conf,field:value})
def test_stop_record_handles_worker_exit_and_explicit_success(tmp_path, monkeypatch):
    import json
    from types import SimpleNamespace
    import desktop_stop
    (tmp_path/'host.process.json').write_text(json.dumps({'pid':123,'created':456}))
    captured=[]
    monkeypatch.setattr(desktop_stop.subprocess,'run',lambda argv,**kw:(captured.append(argv[-1]) or SimpleNamespace(returncode=0)))
    assert desktop_stop.stop_record(tmp_path,'host','memoryscape.api:create_app')
    assert "CommandLine -notlike" in captured[0]
    assert 'if(Get-Process -Id 123 -ErrorAction SilentlyContinue){Stop-Process' in captured[0]
    assert 'Wait-Process -Id 123 -Timeout 5' in captured[0]
    assert 'try{Stop-Process -Id $k.ProcessId -Force -ErrorAction Stop}' in captured[0]
    assert 'catch{if(Get-Process -Id $k.ProcessId -ErrorAction SilentlyContinue){throw}}' in captured[0]
    assert captured[0].strip().endswith('exit 0')


def test_stop_record_has_bounded_wait_on_windows(tmp_path,monkeypatch):
    (tmp_path/'tunnel.process.json').write_text(json.dumps({'pid':123,'created':456}))
    def slow_run(argv,**kwargs):
        assert kwargs['timeout']==30
        assert 'Wait-Process -Id 123 -Timeout 5' in argv[-1]
        raise desktop_stop.subprocess.TimeoutExpired(argv,30)
    monkeypatch.setattr(desktop_stop.subprocess,'run',slow_run)
    assert desktop_stop.stop_record(tmp_path,'tunnel','127.0.0.1:19103:127.0.0.1:9103') is False
