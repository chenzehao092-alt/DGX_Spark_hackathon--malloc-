"""Protocol/mechanism tests, not evidence of a real model's visual accuracy."""
import io,json,math
import numpy as np
import pytest
from PIL import Image
from pydantic import ValidationError
from memoryscape.asset_quality import AssetReview,SceneQualityReview
from memoryscape.geometry import procedural_glb
from memoryscape.quality_render import render_views,mesh_checks,surface_signature,VIEWS
from memoryscape.schemas import Scene,SceneObject,Generation,GeometryOptions,ProjectCreate,ScenePlan,SceneEvidenceManifest,ObjectEvidence,Crop
from memoryscape.scene_decomposition import validate_decomposition
from memoryscape.pipeline import Pipeline
from memoryscape.jobs import Worker
from memoryscape.errors import AppError,ProviderError
from memoryscape.view_bundle import ANGLES,validate_camera,validate_bundle
from memoryscape.db import dumps,uid


def asset_report(oid='target',bad=False):
    return {'object_id':oid,'verdict':'reject' if bad else 'accept','reviewed_views':list(VIEWS),
        'findings':[{'object_id':oid,'view':'back','severity':'major','category':'geometry',
            'evidence':'背部轮廓塌陷（测试桩判断）','repair':'regenerate_geometry'}] if bad else [],
        'summary':'测试桩报告，不证明真实质量'}


def test_six_actual_mesh_views_include_back_and_bottom():
    views=render_views(procedural_glb('table'),edge=128)
    assert [v['name'] for v in views]==list(VIEWS)
    assert all(v['camera']['coverage']>.001 for v in views)
    assert views[-1]['camera']['direction']==[0,-1,0]
    assert all(Image.open(io.BytesIO(v['data'])).size==(128,128) for v in views)
    assert all('asset_sha256' in v['camera'] for v in views)


def test_renderer_times_out_instead_of_certifying_partial_views():
    with pytest.raises(AppError,match='超时'):render_views(procedural_glb('box'),edge=128,seconds=0)


def test_requested_texture_cannot_pass_with_untextured_mesh():
    assert 'missing_embedded_texture_or_uv' in mesh_checks(procedural_glb('box'),textured=True)['issues']


def textured_box(changed=False):
    import trimesh
    mesh=trimesh.load(io.BytesIO(procedural_glb('box')),file_type='glb',force='mesh',process=False)
    if changed:mesh.vertices[0,0]+=.05
    mesh.unmerge_vertices()
    mesh.visual=trimesh.visual.texture.TextureVisuals(uv=np.zeros((len(mesh.vertices),2)),
        material=trimesh.visual.material.PBRMaterial(baseColorTexture=Image.new('RGB',(4,4),'red')))
    mesh.faces=mesh.faces[::-1,::-1]
    return mesh.export(file_type='glb')


def test_texture_signature_allows_uv_seams_order_material_but_not_new_shape():
    raw=procedural_glb('box')
    assert surface_signature(raw)==surface_signature(textured_box())
    assert surface_signature(raw)!=surface_signature(textured_box(changed=True))


@pytest.mark.parametrize('change',[{'reviewed_views':['front']},{'reviewed_views':['front']*6},
    {'verdict':'accept','findings':asset_report(bad=True)['findings']},
    {'findings':[{**asset_report(bad=True)['findings'][0],'object_id':'other'}]}])
def test_critic_cannot_hide_missing_coverage_or_major_failure(change):
    with pytest.raises(ValidationError):AssetReview.model_validate({**asset_report(),**change})


def test_decomposition_requires_one_entry_per_object_and_matching_crop():
    src={'id':'source','kind':'image'}
    obj=SceneObject(id='target',label='物品',generation=Generation(strategy='generate3d',primary_source='source'))
    plan=ScenePlan(summary='test',scene=Scene(objects=[obj]))
    with pytest.raises(AppError,match='decomposition'):validate_decomposition(plan,[src])
    plan.decomposition=SceneEvidenceManifest(objects=[ObjectEvidence(object_id='target',source_ids=['source'],
        required_parts=['完整桌子及桌腿'],inferred=['不可见背面'],crop=Crop(x=.1,y=.1,width=.8,height=.8))])
    validate_decomposition(plan,[src]);assert obj.generation.crop==plan.decomposition.objects[0].crop
    plan.decomposition.objects[0].source_ids=['invented']
    with pytest.raises(AppError,match='不存在'):validate_decomposition(plan,[src])


class Critic:
    def __init__(self,bad=0,error=None):self.bad=bad;self.error=error;self.calls=[];self.remote_calls=[]
    def cards(self):return {'geometry':{'capabilities':['geometry.generate']}}
    def chat(self,pid,system,user,images):
        self.calls.append((system,len(images)))
        if self.error:raise self.error
        if 'SceneQualityReview' in system:return {'verdict':'accept','reviewed_views':list(ANGLES),'findings':[],'summary':'合同测试全景'}
        if 'AssetReview' in system:
            bad=self.bad>0;self.bad-=int(bad);return asset_report(bad=bad)
        return {'object_id':'target','verdict':'accept','target_present':True,'target_count':1,
            'other_subjects':[],'appearance_preserved':True,'parts_complete':True,'background_clean':True,'reasons':['测试桩通过'],
            'view':'three_quarter','view_evidence':'正面及侧面可见（明确测试桩）'}
    def remote(self,ctx,name,capability,**kwargs):
        self.remote_calls.append((capability,kwargs['options']['seed']))
        return {'data':procedural_glb('box'),'model':'test-double-not-native'}


def seed(service,settings,png,critic,textured=False,policy='strict'):
    settings.asset_review_policy=policy
    settings.asset_review=True;settings.quality_render_edge=128
    pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    src=service.add_source(pid,png,'source.png','object',rights=True)
    obj=SceneObject(id='target',label='物品',generation=Generation(strategy='generate3d',
        primary_source=src['id'],geometry_model='geometry',options=GeometryOptions(textured=textured)))
    job=service.enqueue(pid,'build',{'scene':Scene(objects=[obj]).model_dump(),'base_version':0,
        'input_revision':service.project(pid)['input_revision']})
    Worker(service,Pipeline(service,critic)).run_once()
    return pid,service.job(job['id'])


def test_new_build_has_object_and_assembled_multiview_gates(service,settings,png):
    critic=Critic();pid,job=seed(service,settings,png,critic)
    assert job['status']=='succeeded',job
    q=job['result']['asset_quality'];assert q['status']=='accepted' and q['scene']['accepted']
    assert len(q['objects']['target']['current']['renders'])==6 and len(q['scene']['renders'])==8
    assert [n for _,n in critic.calls]==[2,8,9]
    assert len(critic.remote_calls)==1


def test_bad_object_retries_only_once_then_holds_candidate(service,settings,png):
    critic=Critic(bad=20);pid,job=seed(service,settings,png,critic)
    assert job['status']=='needs_review' and job['result']['candidate_only']
    assert service.project(pid)['head']==0
    assert critic.remote_calls==[('geometry.generate',2026),('geometry.generate',2027)]
    assert len(job['result']['asset_quality']['objects']['target']['candidates'])==2


def test_transport_failure_does_not_reroll_or_generate(service,settings,png):
    critic=Critic(error=ProviderError('503',code='provider_transient'))
    pid,job=seed(service,settings,png,critic)
    assert len(critic.calls)==1 and critic.remote_calls==[]
    assert service.project(pid)['head']==0 and job['status']=='needs_review'


def test_recovered_checkpoints_do_not_repeat_quality_calls(service,settings,png):
    critic=Critic(bad=20);pid,job=seed(service,settings,png,critic)
    counts=(len(critic.calls),len(critic.remote_calls))
    service.db.execute('UPDATE jobs SET status="queued",owner=NULL WHERE id=?',(job['id'],))
    Worker(service,Pipeline(service,critic)).run_once()
    assert (len(critic.calls),len(critic.remote_calls))==counts
    assert service.project(pid)['head']==0


class TextureCritic(Critic):
    def __init__(self,changed=False):super().__init__();self.changed=changed;self.texture_checks=0
    def cards(self):return {'geometry':{'capabilities':['geometry.generate','geometry.texture']}}
    def remote(self,ctx,name,capability,**kwargs):
        self.remote_calls.append((capability,kwargs['options']['seed']))
        return {'data':textured_box(self.changed) if capability=='geometry.texture' else procedural_glb('box'),'model':'test-double'}
    def chat(self,pid,system,user,images):
        if 'AssetReview' in system and json.loads(user)['stage']=='texture':
            self.calls.append((system,len(images)));self.texture_checks+=1
            report=asset_report(bad=self.texture_checks==1)
            if report['findings']:report['findings'][0].update(category='texture',repair='retexture')
            return report
        return super().chat(pid,system,user,images)


def test_bad_texture_retries_texture_only_without_repeating_accepted_geometry(service,settings,png):
    critic=TextureCritic();pid,job=seed(service,settings,png,critic,textured=True)
    assert job['status']=='succeeded',job
    assert critic.remote_calls==[('geometry.generate',2026),('geometry.texture',2026),('geometry.texture',2027)]
    assert len(job['result']['asset_quality']['objects']['target']['candidates'])==3


def test_texture_stage_cannot_change_accepted_shape(service,settings,png):
    critic=TextureCritic(changed=True);pid,job=seed(service,settings,png,critic,textured=True)
    assert service.project(pid)['head']==0 and job['status']=='needs_review'
    assert '改变了已验收几何' in str(job['result']['failures'])
    assert len(critic.remote_calls)==2


def test_render_failure_keeps_candidate_and_does_not_trigger_another_gpu_job(service,settings,png,monkeypatch):
    def unavailable(*args,**kwargs):raise AppError('inspection unavailable',code='quality_render_unavailable')
    monkeypatch.setattr('memoryscape.quality_render.render_views',unavailable)
    critic=Critic();pid,job=seed(service,settings,png,critic)
    q=job['result']['asset_quality']['objects']['target']['current']
    assert q['asset_id'] and q['verdict']=='uncertain' and q['renders']==[]
    assert service.project(pid)['head']==0 and len(critic.remote_calls)==1


def bundle(service,pid,scene,names,object_id=None):
    ids=[]
    raw=render_views(procedural_glb('box'),edge=128)[0]['data']
    for name in names:
        yaw,pitch=ANGLES[name]
        cam=validate_camera({'schema':'view-bundle-v1','name':name,'yaw':yaw,'pitch':pitch,'distance':4,
            'target':[0,1,0],'width':128,'height':128,'renderer':'webgl2','object_id':object_id,
            'hide_environment':True,'asset_ids':[scene['objects'][0]['asset_id']]},scene)
        a=service.assets.put(pid,raw,'view.png','rendered');rid=uid('v_')
        service.db.execute('INSERT INTO renders VALUES(?,?,?,?,?,0)',(rid,pid,1,a['id'],dumps(cam)));ids.append(rid)
    return ids


def test_view_bundle_binds_scope_version_and_back_coverage(service,project):
    pid=project['id'];asset=service.assets.put(pid,procedural_glb('box'),'shape.glb','generated')
    scene=Scene(objects=[SceneObject(id='target',label='物品',asset_id=asset['id'],status='ready')])
    service.publish(pid,scene,0,'test');body=scene.model_dump()
    ids=bundle(service,pid,body,list(VIEWS),object_id='target')
    req={'base_version':1,'render_ids':ids,'selected_object':'target'}
    assert validate_bundle(service,pid,req)['scope']=='object'
    with pytest.raises(AppError,match='覆盖不完整'):validate_bundle(service,pid,{**req,'render_ids':ids[:-1]})
    with pytest.raises(AppError,match='重复'):validate_bundle(service,pid,{**req,'render_ids':[ids[0]]*6})
    with pytest.raises(AppError,match='目标'):validate_bundle(service,pid,{**req,'selected_object':None})


def test_false_back_label_is_not_accepted():
    cam={'schema':'view-bundle-v1','name':'back','yaw':0,'pitch':0,'distance':4,'target':[0,1,0],
        'width':128,'height':128,'renderer':'webgl2','object_id':None,'hide_environment':True,'asset_ids':['a']}
    with pytest.raises(AppError,match='伪背面'):validate_camera(cam,{'objects':[{'id':'target','asset_id':'a'}]})
