import hashlib
import httpx
import pytest
from memoryscape.errors import ProviderError, Cancelled
from memoryscape.jobs import Worker, JobContext
from memoryscape.providers import Providers
from memoryscape.schemas import ProjectCreate


def context(service):
    p=service.create_project(ProjectCreate(mode='real',remote_consent=True))
    service.enqueue(p['id'],'edit',{'retry_generation':0})
    worker=Worker(service,lambda c:{})
    return JobContext(service,worker.claim(),worker.owner)


def configured(settings):
    settings.test_models={'geometry':{'enabled':True,'protocol':'node-v1','require_token':False,
        'url':'http://127.0.0.1:19103','capabilities':['geometry.generate']}}


def test_saved_remote_job_is_polled_after_disconnect_without_resubmission(service,settings):
    configured(settings);ctx=context(service);counts={'GET':0,'POST':0}
    def request(req):
        if req.method=='POST':counts['POST']+=1;pytest.fail('existing remote job must not be submitted again')
        counts['GET']+=1
        if counts['GET']==1:raise httpx.ConnectError('injected disconnect')
        return httpx.Response(200,json={'status':'succeeded','result':{'report':{'description':'protocol-only'}}})
    provider=Providers(service,httpx.MockTransport(request))
    # Establish a genuine durable step, then attach its authoritative remote ID.
    ctx.step('asset:object',{},lambda:{})
    service.db.execute('UPDATE steps SET status="failed" WHERE job=?',(ctx.id,))
    from memoryscape.db import digest
    fp=digest({'model':'geometry','revision':None,'capability':'geometry.generate','input':None,'prompt':'','options':{}})
    ctx.set_remote('asset:object',{'model':'geometry','job_id':'existing-job','fingerprint':fp})
    result=provider.remote(ctx,'asset:object','geometry.generate')
    assert result['remote_id']=='existing-job' and counts=={'GET':2,'POST':0}


def test_idempotent_submit_can_retry_without_changing_key_or_payload(service,settings):
    configured(settings);ctx=context(service);seen=[]
    def request(req):
        seen.append((req.headers.get('Idempotency-Key'),req.content))
        if len(seen)==1:raise httpx.ReadTimeout('response lost after server accepted request')
        return httpx.Response(200,json={'id':'one-authoritative-job'})
    provider=Providers(service,httpx.MockTransport(request))
    out=provider._node_request(ctx,'geometry','POST','v1/jobs',body={'capability':'geometry.generate'},headers={'Idempotency-Key':'fixed-key'})
    assert out['id']=='one-authoritative-job' and seen[0]==seen[1]


@pytest.mark.parametrize('method,path,headers',[
    ('POST','v1/assets',{}),('POST','v1/jobs',{}),
    ('POST','v1/jobs/id/retry',{}),('POST','v1/jobs/id/cancel',{}),
])
def test_non_idempotent_requests_are_not_blindly_replayed(service,settings,method,path,headers):
    configured(settings);ctx=context(service);calls=[]
    def request(req):calls.append(req);raise httpx.ReadTimeout('injected')
    provider=Providers(service,httpx.MockTransport(request))
    with pytest.raises(ProviderError):provider._node_request(ctx,'geometry',method,path,headers=headers)
    assert len(calls)==1


def test_auth_failure_is_not_retried(service,settings):
    configured(settings);ctx=context(service);calls=[]
    provider=Providers(service,httpx.MockTransport(lambda req:calls.append(req) or httpx.Response(401)))
    with pytest.raises(ProviderError) as caught:provider._node_request(ctx,'geometry','GET','v1/jobs/id')
    assert caught.value.code=='provider_http_error' and len(calls)==1


def test_asset_connect_failure_waits_without_replaying_an_uncertain_response(service,settings):
    configured(settings);ctx=context(service);calls=[]
    def request(req):
        calls.append(req)
        if len(calls)==1:raise httpx.ConnectError('request not sent')
        return httpx.Response(200,json={'id':'content-addressed-asset'})
    provider=Providers(service,httpx.MockTransport(request))
    assert provider._node_request(ctx,'geometry','POST','v1/assets')['id']=='content-addressed-asset'
    assert len(calls)==2


def test_recovery_has_a_finite_budget_and_keeps_checkpoint(service,settings):
    configured(settings);settings.connection_grace_seconds=0;ctx=context(service)
    def disconnected(req):raise httpx.ConnectError('private address must not appear in message')
    provider=Providers(service,httpx.MockTransport(disconnected))
    with pytest.raises(ProviderError) as caught:provider._node_request(ctx,'geometry','GET','v1/jobs/id')
    assert caught.value.code=='connection_recovery_timeout' and 'private address' not in str(caught.value)


def test_cancellation_interrupts_reconnection_wait(service,settings):
    configured(settings);ctx=context(service)
    def disconnected(req):
        service.db.execute('UPDATE jobs SET cancel=1 WHERE id=?',(ctx.id,))
        raise httpx.ConnectError('injected')
    provider=Providers(service,httpx.MockTransport(disconnected))
    with pytest.raises(Cancelled):provider._node_request(ctx,'geometry','GET','v1/jobs/id')
