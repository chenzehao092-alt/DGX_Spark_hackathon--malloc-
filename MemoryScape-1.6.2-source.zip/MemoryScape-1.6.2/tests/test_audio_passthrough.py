import json
import pytest
from memoryscape.jobs import Worker
from memoryscape.pipeline import Pipeline
from memoryscape.schemas import ProjectCreate, ScenePlan, Scene, SceneObject


class BrainOnly:
    def __init__(self):self.contexts=[]
    def cards(self):return {'brain':{'capabilities':['brain.plan']}}
    def chat(self,project,system,user,images):
        self.contexts.append(json.loads(user))
        return ScenePlan(summary='仅验证规划协议，不是模型质量验收',
            scene=Scene(objects=[SceneObject(id='box',label='协议测试物体')])).model_dump()
    def remote(self,*args,**kwargs):raise AssertionError('passthrough audio must stay local')


def test_music_needs_no_audio_model_and_original_track_cannot_be_silently_omitted(service,wav):
    project=service.create_project(ProjectCreate(mode='real',remote_consent=True))
    source=service.add_source(project['id'],wav,'user-music.wav','audio',rights=True)
    p=service.project(project['id']);provider=BrainOnly();worker=Worker(service,Pipeline(service,provider))
    job=service.enqueue(p['id'],'plan',{'base_version':p['head'],'input_revision':p['input_revision']})
    assert worker.run_once();result=service.job(job['id'])
    assert result['status']=='succeeded',result['error']
    track=result['result']['plan']['scene']['audio'][0]
    assert track['source_id']==source['id'] and track['strategy']=='original'
    assert track['duration']==2 and track['status']=='planned'
    report=provider.contexts[0]['audio_reports'][0]
    assert report['execution_mode']=='passthrough' and '没有分析' in report['description']
    build=service.confirm_plan(p['id'],result['result']['plan_id'],0,p['input_revision'])
    worker.run_once();assert service.job(build['id'])['status']=='succeeded'
    assert service.scene(p['id'])['scene']['audio'][0]['asset_id']==source['id']
    assert service.assets.read(source['id'])==wav


def test_explicit_audio_understanding_does_not_silently_fallback(service,wav):
    p=service.create_project(ProjectCreate(mode='real',remote_consent=True,audio_mode='describe'))
    service.add_source(p['id'],wav,'recording.wav','audio',rights=True)
    p=service.project(p['id']);provider=BrainOnly()
    job=service.enqueue(p['id'],'plan',{'base_version':0,'input_revision':p['input_revision']})
    Worker(service,Pipeline(service,provider)).run_once()
    result=service.job(job['id'])
    assert result['status']=='failed' and '音频理解服务' in result['error']
    assert not provider.contexts


def test_legacy_project_without_mode_defaults_to_local_passthrough(service,wav):
    p=service.create_project(ProjectCreate(mode='real',remote_consent=True))
    doc=json.loads(service.db.one('SELECT doc FROM projects WHERE id=?',(p['id'],))['doc'])
    doc.pop('audio_mode')
    service.db.execute('UPDATE projects SET doc=? WHERE id=?',(json.dumps(doc),p['id']))
    service.add_source(p['id'],wav,'legacy.wav','audio',rights=True);p=service.project(p['id'])
    job=service.enqueue(p['id'],'plan',{'base_version':0,'input_revision':p['input_revision']})
    Worker(service,Pipeline(service,BrainOnly())).run_once()
    assert service.job(job['id'])['status']=='succeeded'


def test_audio_mode_is_strict_and_requires_revision(client):
    p=client.post('/api/projects',json={'mode':'real'}).json()
    assert client.patch('/api/projects/'+p['id'],json={'audio_mode':'invented','expected_input_revision':0}).status_code==422
    updated=client.patch('/api/projects/'+p['id'],json={'audio_mode':'describe','expected_input_revision':0})
    assert updated.status_code==200 and updated.json()['audio_mode']=='describe'
    assert client.patch('/api/projects/'+p['id'],json={'audio_mode':'passthrough','expected_input_revision':0}).status_code==409
