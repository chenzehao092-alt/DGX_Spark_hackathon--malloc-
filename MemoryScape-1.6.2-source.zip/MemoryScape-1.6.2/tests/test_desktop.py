import sys
from pathlib import Path
from memoryscape.settings_api import StepFunUpdate, apply_stepfun
import pytest

def test_key_rejects_env_injection():
    with pytest.raises(ValueError): StepFunUpdate(api_key='abcdefg123\nMS_TOKEN=bad')

def test_one_key_keeps_nodes(tmp_path, monkeypatch):
    from memoryscape.config import Settings
    monkeypatch.delenv('DIRECTOR_TOKEN',raising=False)
    p=tmp_path/'models.toml'
    p.write_text('''[models.geometry]
enabled = true
url = "http://127.0.0.1:19103"
token_env = "GEOMETRY_NODE_TOKEN"
[models.director]
enabled = false
[models.image]
enabled = false
capabilities = ["image.edit"]
''')
    s=Settings(data_dir=tmp_path/'data',config_file=p).initialize()
    view=apply_stepfun(s,StepFunUpdate(api_key='unit-test-not-real-key'))
    assert view['geometry']['enabled'] and view['geometry']['base_url'].endswith('19103')
    assert view['image']['enabled'] and view['image']['token_configured']
    assert view['director']['token_configured']
    assert 'unit-test-not-real-key' not in str(view)

def test_invalid_key_not_echoed(tmp_path):
    from memoryscape.api import create_app
    from memoryscape.config import Settings
    from fastapi.testclient import TestClient
    s=Settings(data_dir=tmp_path/'data',start_worker=False).initialize()
    with TestClient(create_app(s),headers={'Authorization':'Bearer '+s.token}) as c:
        r=c.post('/api/settings/stepfun',json={'api_key':'secret-rejected-value\nwrong'})
        assert r.status_code==422
        assert 'secret-rejected-value' not in r.text

def test_refresh_stepfun_key_preserves_connected_local_image_and_selected_director(tmp_path):
    from memoryscape.config import Settings
    config=tmp_path/'models.toml'
    config.write_text('''[models.director]
url="https://api.stepfun.com/v1"
model="operator-selected-vision-model"
[models.image]
enabled=true
protocol="node-v1"
url="http://127.0.0.1:9102"
token_env="IMAGE_NODE_TOKEN"
model="local-step1x-edit"
''')
    settings=Settings(data_dir=tmp_path/'data',config_file=config).initialize()
    apply_stepfun(settings,StepFunUpdate(api_key='test-only-refresh-key'))
    models=settings.models()
    assert models['director']['model']=='operator-selected-vision-model'
    assert models['image']['protocol']=='node-v1'
    assert models['image']['model']=='local-step1x-edit'
    assert models['image']['token_env']=='IMAGE_NODE_TOKEN'

def test_cloud_image_uses_real_protocol(tmp_path,png,monkeypatch):
    import base64,httpx
    from memoryscape.config import Settings
    from memoryscape.service import Service
    from memoryscape.providers import Providers
    s=Settings(data_dir=tmp_path/'data',test_models={'image':{'enabled':True,
        'url':'https://api.stepfun.com/v1','protocol':'stepfun-images',
        'token_env':'DIRECTOR_TOKEN','model':'step-image-edit-2','capabilities':['image.edit']}}).initialize()
    monkeypatch.setenv('DIRECTOR_TOKEN','unit-test-key')
    service=Service(s);pid=service.create_project(__import__('memoryscape.schemas',fromlist=['ProjectCreate']).ProjectCreate(mode='real',remote_consent=True))['id']
    class Context:
        project=pid
        def check(self):pass
    def handler(request):
        assert request.url.path=='/v1/images/edits'
        assert b'steps' in request.content and b'b64_json' in request.content
        return httpx.Response(200,json={'data':[{'b64_json':base64.b64encode(png).decode()}]})
    provider=Providers(service,transport=httpx.MockTransport(handler))
    out=provider.stepfun_image('image',Context(),'image.edit',png,'white background',{})
    assert out['data'] and out['metrics']['execution_mode']=='native-cloud'
    assert out['metrics']['upstream_model']=='step-image-edit-2'

def test_explicit_move_updates_support_offset(service):
    from memoryscape.schemas import ProjectCreate,Scene,SceneObject,Transform,Relation,Patch,Operation
    project=service.create_project(ProjectCreate())['id']
    scene=Scene(objects=[SceneObject(id='base',label='底座',transform=Transform(position=[0,.4,0],size=[.2,.01,.2])),
        SceneObject(id='camera',label='相机',transform=Transform(position=[0,.51,0],size=[.15,.1,.08]))],
        relations=[Relation(type='on',subject='camera',target='base',offset=[0,.1,0])])
    service.publish(project,scene,0,'layout')
    service.apply_patch(project,Patch(base_version=1,operations=[
        Operation(type='transform',object_id='base',transform=Transform(position=[0,0,0],size=[.2,.01,.2])),
        Operation(type='transform',object_id='camera',transform=Transform(position=[0,.01,0],size=[.15,.1,.08]))]))
    updated=service.scene(project)['scene']
    assert abs(updated['relations'][0]['offset'][1])<1e-9

def test_overloaded_image_is_not_advertised_as_available(tmp_path,monkeypatch):
    from memoryscape.config import Settings
    from memoryscape.service import Service
    from memoryscape.providers import Providers
    s=Settings(data_dir=tmp_path/'data',test_models={'image':{'enabled':True,'url':'https://api.stepfun.com/v1',
       'protocol':'stepfun-images','capabilities':['image.edit']}}).initialize()
    provider=Providers(Service(s));provider.record_inference('image',503)
    assert provider.cards()['image']['available'] is False
    assert provider.cards()['image']['state']=='temporarily_unavailable'

@pytest.mark.parametrize('returncode,expected',[(0,True),(2,False)])
def test_stop_checks_pid_creation_time(tmp_path,monkeypatch,returncode,expected):
    import json,subprocess
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
    import desktop_stop
    monkeypatch.setattr(subprocess,'CREATE_NO_WINDOW',0,raising=False)
    (tmp_path/'host.process.json').write_text(json.dumps({'pid':1234,'created':6789}))
    def run(command,**kwargs):
        script=command[-1]
        assert 'StartTime.ToUniversalTime().Ticks -ne 6789' in script
        assert "-notlike '*memoryscape.api:create_app*'" in script
        return subprocess.CompletedProcess(command,returncode)
    monkeypatch.setattr(subprocess,'run',run)
    assert desktop_stop.stop_record(tmp_path,'host','memoryscape.api:create_app') is expected

def test_stop_without_record_does_not_claim_success(tmp_path):
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
    import desktop_stop
    assert desktop_stop.stop_record(tmp_path,'host','memoryscape.api:create_app') is False

def test_schema_retry_supplies_the_rejected_document(service):
    from memoryscape.pipeline import Pipeline
    from memoryscape.schemas import ScenePlan
    rejected={'summary':'原海报展示','scene':{'objects':[{'id':'poster','label':'海报',
        'generation':{'strategy':'text','steps':50}}]}}
    valid={'summary':'原海报展示','scene':{'objects':[{'id':'poster','label':'海报',
        'generation':{'strategy':'procedural','primitive':'text','options':{'steps':50}}}]}}
    class Provider:
        def __init__(self):self.calls=[]
        def chat(self,project,system,user,images):
            self.calls.append(user)
            return rejected if len(self.calls)==1 else valid
    class Context:
        project='unit-test'
        def check(self):pass
        def emit(self,*args):pass
    provider=Provider()
    plan=Pipeline(service,provider).structured(Context(),'system','user',[],ScenePlan)
    assert plan.scene.objects[0].generation.options.steps==50
    assert len(provider.calls)==2
    assert '原海报展示' in provider.calls[1] and '"strategy":"text"' in provider.calls[1]
    assert 'generation.options.steps' in provider.calls[1]

def test_schema_repair_is_bounded_and_never_accepts_invalid_strategy(service):
    from memoryscape.pipeline import Pipeline
    from memoryscape.schemas import ScenePlan
    from memoryscape.errors import ProviderError
    class Provider:
        calls=0
        def chat(self,*args):
            self.calls+=1
            return {'summary':'invalid','scene':{'objects':[{'id':'x','label':'test',
                'generation':{'strategy':'unknown'}}]}}
    class Context:
        project='unit-test'
        def check(self):pass
        def emit(self,*args):pass
    provider=Provider()
    with pytest.raises(ProviderError,match='三次'):
        Pipeline(service,provider).structured(Context(),'system','user',[],ScenePlan)
    assert provider.calls==3

@pytest.mark.parametrize('poster_y,fit',[(.6,'stretch'),(.1,'uniform')])
def test_contact_edit_rejects_false_success(poster_y,fit):
    from memoryscape.schemas import Scene,SceneObject,Transform,Relation,Patch,Operation
    from memoryscape.layout import validate_contact_edit
    from memoryscape.errors import AppError
    scene=Scene(objects=[SceneObject(id='base',label='底座',transform=Transform(size=[1.8,.1,.6])),
        SceneObject(id='poster',label='海报',transform=Transform(position=[0,.6,0]))],
        relations=[Relation(type='on',subject='poster',target='base')])
    patch=Patch(base_version=1,operations=[Operation(type='transform',object_id='base',
        transform=Transform(position=[0,0,0],size=[1.8,.1,.6],fit=fit)),
        Operation(type='transform',object_id='poster',transform=Transform(position=[0,poster_y,0]))])
    with pytest.raises(AppError):validate_contact_edit(patch,scene,'落在地面，海报紧贴底座；长宽高分别缩放')

def test_contact_edit_accepts_grounded_stretched_base():
    from memoryscape.schemas import Scene,SceneObject,Transform,Relation,Patch,Operation
    from memoryscape.layout import validate_contact_edit
    scene=Scene(objects=[SceneObject(id='base',label='底座',transform=Transform(size=[.1,.1,.1])),
        SceneObject(id='poster',label='海报')],relations=[Relation(type='on',subject='poster',target='base')])
    patch=Patch(base_version=1,operations=[Operation(type='transform',object_id='base',
        transform=Transform(position=[0,0,0],size=[1.8,.1,.6],fit='stretch')),
        Operation(type='transform',object_id='poster',transform=Transform(position=[0,.1,0]))])
    assert validate_contact_edit(patch,scene,'落在地面，海报紧贴底座；长宽高分别缩放') is patch
