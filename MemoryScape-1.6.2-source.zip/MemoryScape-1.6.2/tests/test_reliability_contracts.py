"""Reproductions of actual 503, colour overlay and stale support failures."""
import hashlib
import json
import time
from types import SimpleNamespace
import httpx
import pytest
from pydantic import ValidationError
from memoryscape.providers import Providers
from memoryscape.errors import AppError,ProviderError
from memoryscape.schemas import Scene,SceneObject,Transform,Generation,Relation,Operation,Patch,ProjectCreate,SizeEdit
from memoryscape.memory import validate_edit_intent
from memoryscape.pipeline import Pipeline
from memoryscape.layout import check_scene,solve_layout
from memoryscape.jobs import Worker
from memoryscape.geometry import procedural_glb


def image_provider(service):
    service.settings.test_models={'image':{'enabled':True,'url':'https://api.stepfun.com/v1',
        'protocol':'stepfun-images','model':'step-image-edit-2','require_token':False,'capabilities':['image.edit']}}
    return Providers(service)


@pytest.mark.parametrize('status',[503,500,429])
def test_cooldown_retains_configuration_but_blocks_inference(service,status):
    p=image_provider(service);p.record_inference('image',status)
    c=p.cards()['image']
    assert c['available'] is False and c['last_http_status']==status and 0<c['retry_after_seconds']<=60
    with pytest.raises(ProviderError) as exc:p.choose('image.edit','image')
    assert exc.value.code=='provider_unavailable' and f'HTTP {status}' in str(exc.value)
    assert '没有已配置' not in str(exc.value)


def test_cooldown_expiry_and_config_change(service,monkeypatch):
    p=image_provider(service);p.record_inference('image',503)
    now=time.time();monkeypatch.setattr('memoryscape.providers.time.time',lambda:now+61)
    assert p.choose('image.edit')=='image'
    p.record_inference('image',503)
    service.settings.test_models['image']['model']='replacement-model'
    assert p.cards()['image']['available'] and p.inference_status('image')=={}


@pytest.mark.parametrize('header,delay',[('120',120),('0',0),('bad',60),('-1',60),('999999999',60)])
def test_retry_after_header_controls_manual_cooldown(service,monkeypatch,header,delay):
    p=image_provider(service)
    now=time.time();monkeypatch.setattr('memoryscape.providers.time.time',lambda:now)
    p.record_inference('image',503,header)
    assert p.retry_after('image')==delay


def test_retry_after_http_date_is_respected(service,monkeypatch):
    from email.utils import formatdate
    now=1700000000
    monkeypatch.setattr('memoryscape.providers.time.time',lambda:now)
    p=image_provider(service);p.record_inference('image',503,formatdate(now+120,usegmt=True))
    assert p.retry_after('image')==120


def test_legacy_failure_does_not_lock_service_for_thirty_minutes(service,monkeypatch):
    p=image_provider(service);p.record_inference('image',503)
    path=service.settings.data_dir/'provider-status'/(hashlib.sha256(b'image').hexdigest()+'.json')
    saved=json.loads(path.read_text('utf-8'));saved.pop('retry_after_seconds')
    path.write_text(json.dumps(saved),'utf-8')
    monkeypatch.setattr('memoryscape.providers.time.time',lambda:saved['at']+61)
    assert p.choose('image.edit')=='image'


def test_real_http_failure_uses_header_and_does_not_auto_retry(service,png):
    p=image_provider(service)
    pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    calls=[]
    def respond(req):
        calls.append(req)
        return httpx.Response(503,headers={'Retry-After':'120'},json={'error':{'code':'service_unavailable'}})
    p.transport=httpx.MockTransport(respond)
    ctx=SimpleNamespace(project=pid,check=lambda:None)
    with pytest.raises(ProviderError,match='HTTP 503'):
        p.stepfun_image('image',ctx,'image.edit',png,'清理背景',{})
    assert len(calls)==1
    assert 119<=p.retry_after('image')<=120


@pytest.mark.parametrize('value',[[],None,{'http_status':'503','at':1},{'http_status':503,'at':'bad'},
    {'http_status':503,'at':float('nan')},{'http_status':503,'at':time.time()+3600},
    {'http_status':True,'at':1},{'http_status':999,'at':1}])
def test_corrupt_status_cannot_crash_model_listing(service,value):
    p=image_provider(service);p.record_inference('image',200)
    path=service.settings.data_dir/'provider-status'/(hashlib.sha256(b'image').hexdigest()+'.json')
    path.write_text(json.dumps(value),'utf-8')
    assert p.cards()['image']['available']


def test_telemetry_write_failure_does_not_mask_paid_result(service,monkeypatch):
    p=image_provider(service)
    def fail(*args):raise OSError('disk unavailable')
    monkeypatch.setattr('memoryscape.providers.os.replace',fail)
    p.record_inference('image',200)
    assert not list((service.settings.data_dir/'provider-status').glob('*.tmp'))


def test_atomic_status_temp_name_stays_short_for_nested_windows_installs(service,monkeypatch):
    import os
    p=image_provider(service);replace=os.replace;names=[]
    def checked(source,dest):names.append(source.name);return replace(source,dest)
    monkeypatch.setattr('memoryscape.providers.os.replace',checked)
    p.record_inference('image',503)
    assert len(names)==1 and len(names[0])<=44
    assert p.cards()['image']['available'] is False


@pytest.mark.parametrize('body',[b'null',b'[]',b'{"data":null}',b'{"data":[]}'])
def test_bad_image_responses_are_typed_errors_without_automatic_retries(service,png,body):
    p=image_provider(service);pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    calls=[]
    def reply(request):calls.append(request);return httpx.Response(200,content=body)
    p.transport=httpx.MockTransport(reply)
    ctx=SimpleNamespace(project=pid,check=lambda:None)
    with pytest.raises(ProviderError):p.stepfun_image('image',ctx,'image.edit',png,'用户授权测试',{})
    assert len(calls)==1 and p.inference_status('image').get('http_status')!=200


def colour_scene(service):
    pid=service.create_project(ProjectCreate(mode='real',remote_consent=True))['id']
    asset=service.assets.put(pid,procedural_glb('box'),'existing.glb','procedural')
    pet=SceneObject(id='pet_3d',label='黄色卡通宠物',status='ready',asset_id=asset['id'],tint='#ffd700',
        generation=Generation(strategy='generate3d'),transform=Transform(position=[1,1,0],size=[.3,.7,.8]))
    table=SceneObject(id='table',label='桌子',transform=Transform(position=[-2,.5,0],size=[1.75,.585,.96]))
    service.publish(pid,Scene(objects=[pet,table]),0,'用户已有模型')
    return pid


@pytest.mark.parametrize('prompt',['不是全部都黄色，而是参考最开始的图片中的颜色进行涂色',
    '恢复宠物原来的配色，桌子保持不变','还原宠物最初的颜色','取消宠物整体染色'])
def test_original_colour_intent_is_local_and_preserves_mesh_pose(service,prompt):
    pid=colour_scene(service);m=service.memory(pid,query=prompt)
    assert m['appearance_intent']['target_id']=='pet_3d' and not m['restore_intent']['authorized']
    patch=Patch(base_version=1,operations=[Operation(type='clear_tint',object_id='pet_3d')])
    validate_edit_intent(patch,m);before=service.scene(pid)['scene']
    result=service.apply_patch(pid,patch)
    expected=json.loads(json.dumps(before));expected['objects'][0]['tint']=None
    assert result['scene']==expected and result['job_id'] is None
    with pytest.raises(AppError,match='实际变化'):service.apply_patch(pid,patch.model_copy(update={'base_version':2}))


def test_original_colour_edit_proposal_needs_no_cloud_or_gpu(service):
    pid=colour_scene(service)
    class NoInference:
        def chat(self,*args,**kwargs):raise AssertionError('must not call cloud')
        def cards(self):return {}
    job=service.enqueue(pid,'edit',{'base_version':1,'prompt':'恢复宠物原来的配色'})
    Worker(service,Pipeline(service,NoInference())).run_once();out=service.job(job['id'])
    assert out['status']=='succeeded' and out['result']['patch']['operations']==[Operation(type='clear_tint',object_id='pet_3d').model_dump()]
    assert service.project(pid)['head']==1  # User still approves the proposal.


@pytest.mark.parametrize('type', ['regenerate','tint','transform','restore_object'])
def test_colour_recovery_rejects_wrong_tool_or_collateral_edit(service,type):
    pid=colour_scene(service);m=service.memory(pid,query='恢复宠物原来的配色')
    extra={'regenerate':{'prompt':'原图配色'},'tint':{'color':'#ffff00'},'transform':{'transform':Transform()},'restore_object':{'source_version':0}}[type]
    with pytest.raises(ProviderError):validate_edit_intent(Patch(base_version=1,operations=[Operation(type=type,object_id='pet_3d',**extra)]),m)


@pytest.mark.parametrize('data',[{'color':'#ffffff'},{'prompt':'重画'},{'transform':{}},{'source_version':1}])
def test_clear_tint_has_no_silently_ignored_operands(data):
    with pytest.raises(ValidationError):Operation(type='clear_tint',object_id='pet',**data)


def test_ambiguous_or_regional_colour_recovery_cannot_clear_everything(service):
    pid=colour_scene(service);scene=Scene.model_validate(service.scene(pid)['scene'])
    scene.objects[1].tint='#aa0000';service.publish(pid,scene,1,'另一个染色物品')
    for prompt in ('恢复原来的颜色','恢复宠物背面的原始颜色'):
        m=service.memory(pid,query=prompt)
        assert m['appearance_intent']['needs_clarification']
        with pytest.raises(ProviderError):validate_edit_intent(Patch(base_version=2,operations=[Operation(type='clear_tint',object_id='pet_3d')]),m)


@pytest.mark.parametrize('query',['恢复椅子原来的颜色','恢复不存在的物品原来的配色'])
def test_unknown_colour_target_never_becomes_stale_selected_pet(service,query):
    pid=colour_scene(service);m=service.memory(pid,'pet_3d',query)
    assert m['appearance_intent']['needs_clarification']
    with pytest.raises(ProviderError):validate_edit_intent(Patch(base_version=1,operations=[Operation(type='clear_tint',object_id='pet_3d')]),m)


def test_colour_reset_respects_lock_negation_and_new_colour_request(service):
    pid=colour_scene(service)
    for query in ('不要恢复宠物原来的配色','按照原图把宠物改成红色'):
        assert not service.memory(pid,query=query)['appearance_intent']['authorized']
    service.apply_patch(pid,Patch(base_version=1,operations=[Operation(type='lock',object_id='pet_3d',locked=True)]))
    with pytest.raises(AppError):service.apply_patch(pid,Patch(base_version=2,operations=[Operation(type='clear_tint',object_id='pet_3d')]))
    assert service.project(pid)['head']==2


def test_resize_support_preserves_placements_and_refreshes_offsets(service):
    pid=service.create_project(ProjectCreate())['id']
    table=SceneObject(id='table',label='桌子',transform=Transform(position=[-2,.5,0],size=[2,.9,1],fit='stretch'))
    mic=SceneObject(id='mic',label='麦克风',transform=Transform(position=[-2,1.7,0]))
    service.publish(pid,Scene(objects=[table,mic],relations=[Relation(type='on',subject='mic',target='table',offset=[0,.3,0])]),0,'已有场景')
    result=service.apply_patch(pid,Patch(base_version=1,operations=[Operation(type='resize',object_id='table',size_edit=SizeEdit(height=.585))]))
    scene=Scene.model_validate(result['scene'])
    assert scene.objects[1].transform.position==[-2,1.7,0]
    assert not any(f['type']=='support_mismatch' for f in check_scene(scene))
    assert any(f['type']=='support_gap' for f in check_scene(scene))  # Gap is not silently claimed as contact.
    assert solve_layout(scene).objects[1].transform.position==[-2,1.7,0]


def test_conflicting_or_cyclic_supports_fail_before_generation():
    a=SceneObject(id='a',label='A');b=SceneObject(id='b',label='B');c=SceneObject(id='c',label='C')
    for relations in ([Relation(type='on',subject='a',target='b'),Relation(type='on',subject='a',target='c')],
        [Relation(type='on',subject='a',target='b'),Relation(type='on',subject='b',target='a')]):
        with pytest.raises(AppError):solve_layout(Scene(objects=[a,b,c],relations=relations))


def test_unavailable_capability_explanation_is_not_missing_configuration(service):
    pid=colour_scene(service);p=image_provider(service);p.record_inference('image',503)
    patch=Patch(base_version=1,operations=[Operation(type='regenerate',object_id='pet_3d',prompt='添加局部细节')])
    out=Pipeline(service,p).adapt_patch_to_capabilities(patch,service.memory(pid))
    assert not out.operations and '已配置' in out.explanation and 'HTTP 503' in out.explanation
    assert '未接通' not in out.explanation


def test_other_available_provider_does_not_hide_explicit_unavailable_choice(service):
    pid=colour_scene(service);scene=Scene.model_validate(service.scene(pid)['scene'])
    scene.objects[0].generation.image_model='selected-image';service.publish(pid,scene,1,'指定图片服务')
    class Cards:
        def cards(self):return {'selected-image':{'available':False,'last_http_status':503,'capabilities':['image.edit']},
            'another-image':{'available':True,'capabilities':['image.edit']}}
    patch=Patch(base_version=2,operations=[Operation(type='regenerate',object_id='pet_3d',prompt='局部编辑')])
    out=Pipeline(service,Cards()).adapt_patch_to_capabilities(patch,service.memory(pid))
    assert not out.operations and '已配置' in out.explanation


def test_failed_spatial_postcondition_retains_candidate_not_false_success(service):
    pid=service.create_project(ProjectCreate())['id']
    asset=service.assets.put(pid,procedural_glb('box'),'existing.glb','procedural')
    base=SceneObject(id='base',label='底座',asset_id=asset['id'],status='ready')
    mic=SceneObject(id='mic',label='麦克风',asset_id=asset['id'],status='ready',locked=True,transform=Transform(position=[0,3,0]))
    scene=Scene(objects=[base,mic],relations=[Relation(type='on',subject='mic',target='base')])
    service.publish(pid,scene,0,'用户已有布局')
    job=service.enqueue(pid,'build',{'scene':scene.model_dump(),'base_version':1,'input_revision':0,'targets':None,
        'production':ProjectCreate().model_dump()})
    Worker(service,Pipeline(service)).run_once();out=service.job(job['id'])
    assert out['status']=='needs_review' and out['result']['candidate_only']
    assert any(c['type']=='support_mismatch' for c in out['result']['checks'])
    assert service.project(pid)['head']==1 and service.scene(pid)['scene']==scene.model_dump()
