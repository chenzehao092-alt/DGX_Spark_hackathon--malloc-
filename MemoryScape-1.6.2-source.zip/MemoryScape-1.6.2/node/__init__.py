"""Remote, authenticated, durable model node. One process per model environment."""
