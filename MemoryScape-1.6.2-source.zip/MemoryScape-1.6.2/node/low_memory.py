"""Bounded, staged Step1X runtime. Never evict or modify another GPU process."""
import os
import subprocess
import time

def select_gpu():
    threshold = int(os.getenv('MS_GPU_MIN_FREE_MIB', '0'))
    if not threshold: return
    deadline = time.monotonic() + 7200
    reported = False
    while time.monotonic() < deadline:
        text = subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free',
                         '--format=csv,noheader,nounits'], text=True)
        choices = [(int(free.strip()), index.strip()) for index, free in
                   (line.split(',') for line in text.strip().splitlines())]
        free, index = max(choices)
        if free >= threshold:
            os.environ['CUDA_VISIBLE_DEVICES'] = index
            import torch
            budget = min(int(os.getenv('MS_GPU_MEMORY_MIB','23000')), free-1000)
            if free>=22000:
                os.environ['GEOMETRY_CPU_OFFLOAD']='false'
                os.environ['STEP1X_TEXTURE_SAFE_OFFLOAD']='false'
            total = torch.cuda.get_device_properties(0).total_memory / 1024**2
            torch.cuda.set_per_process_memory_fraction(min(budget/total, .95), 0)
            print(f'[GPU] device={index}; free={free} MiB; own allocator cap={budget} MiB', flush=True)
            return
        if not reported:
            print(f'[GPU] waiting for {threshold} MiB free; not touching other jobs', flush=True)
            reported = True
        time.sleep(15)
    raise RuntimeError('没有足够空闲显存；请稍后重试，不会结束其他任务。')

def texture_pipeline(config):
    """Keep SDXL weights on CPU until needed; upstream .to(cuda) peaks too high."""
    from diffusers import AutoencoderKL, DDPMScheduler
    from step1x3d_texture.pipelines.ig2mv_sdxl_pipeline import IG2MVSDXLPipeline
    from step1x3d_texture.pipelines.step1x_3d_texture_synthesis_pipeline import Step1X3DTexturePipeline
    from step1x3d_texture.models.attention_processor import DecoupledMVRowColSelfAttnProcessor2_0
    from step1x3d_texture.schedulers.scheduling_shift_snr import ShiftSNRScheduler
    class OffloadedTexture(Step1X3DTexturePipeline):
        def prepare_ig2mv_pipeline(self, base_model, vae_model, unet_model, lora_model,
                                  adapter_path, scheduler, num_views, device, dtype):
            vae = AutoencoderKL.from_pretrained(vae_model, torch_dtype=dtype)
            pipe = IG2MVSDXLPipeline.from_pretrained(base_model, torch_dtype=dtype, variant='fp16', vae=vae)
            pipe.scheduler = ShiftSNRScheduler.from_scheduler(pipe.scheduler,
                shift_mode='interpolated', shift_scale=8., scheduler_class=DDPMScheduler)
            pipe.init_custom_adapter(num_views=num_views, self_attn_processor=DecoupledMVRowColSelfAttnProcessor2_0)
            pipe.load_custom_adapter(adapter_path, 'step1x-3d-ig2v.safetensors')
            pipe.cond_encoder.to(device=device, dtype=dtype)
            pipe.enable_vae_slicing(); pipe.enable_vae_tiling()
            # Sequential offload supports the customized six-view SDXL stack.
            pipe.enable_sequential_cpu_offload(gpu_id=0)
            return pipe
    return OffloadedTexture(config)
