"""Authenticated asynchronous model node: content-addressed inputs + durable jobs.

Start exactly one process per model environment/resource pool. GPU work runs outside
request handlers. A lost client connection does not restart model inference.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import secrets
import sqlite3
import threading
import time
import traceback
from contextlib import asynccontextmanager,contextmanager
from pathlib import Path
from fastapi import FastAPI,Depends,File,Header,UploadFile,HTTPException
from fastapi.responses import FileResponse,JSONResponse
from pydantic import BaseModel,ConfigDict,Field,ValidationError
from memoryscape.db import dumps,digest,uid
from memoryscape.errors import AppError
from memoryscape.media import inspect,image_copy,canonical_audio
from memoryscape.schemas import RemoteRequest,GeometryOptions
from memoryscape.security import BodyLimit,ProcessLock

CAPS={'geometry':['geometry.generate','geometry.texture'],'image':['image.edit'],
      'audio':['audio.describe','audio.tts'],'enhance':['audio.enhance'],
      'image-api':['image.edit','image.generate']}


def validate_options(kind,request):
    c=request.capability;opts=request.options
    if c not in CAPS[kind]:raise AppError(f'该节点不支持 {c}。')
    if c in ('geometry.generate','geometry.texture'):
        if request.prompt.strip():raise AppError('图像条件三维模型不接收自由文本 prompt；请先修改参考图。')
        return GeometryOptions.model_validate(opts).model_dump()
    if c.startswith('image.'):
        class ImageOptions(BaseModel):
            model_config=ConfigDict(extra='forbid',allow_inf_nan=False)
            seed:int=Field(2026,ge=0,lt=2**31)
            steps:int=Field(30,ge=4,le=80)
            guidance_scale:float=Field(6,ge=1,le=15)
        if not request.prompt.strip():raise AppError('图片任务需要提示词。')
        return ImageOptions.model_validate(opts).model_dump()
    if opts:raise AppError('该音频能力不接受额外模型参数。')
    if c=='audio.tts' and not 0<len(request.prompt)<=1500:raise AppError('语音生成文字需在 1–1500 字符之间。')
    return {}


class NodeStore:
    def __init__(self,root):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'jobs.sqlite3'
        with self.connect() as c:
            c.executescript('''CREATE TABLE IF NOT EXISTS blobs(id TEXT PRIMARY KEY,sha TEXT NOT NULL,filename TEXT NOT NULL,mime TEXT NOT NULL,kind TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,idem TEXT UNIQUE,fp TEXT NOT NULL,request TEXT NOT NULL,status TEXT NOT NULL,
            result TEXT,error TEXT,cancel INTEGER DEFAULT 0,metrics TEXT,created REAL,updated REAL);
            ''')
    @contextmanager
    def connect(self):
        c=sqlite3.connect(self.path,timeout=20);c.row_factory=sqlite3.Row;c.execute('PRAGMA journal_mode=WAL')
        try:
            with c:yield c
        finally:c.close()
    def put(self,raw,filename):
        if len(raw)>128*1024*1024:raise AppError('节点文件大小上限 128 MiB。',413)
        kind,mime,_=inspect(raw,filename);sha=hashlib.sha256(raw).hexdigest();id='b_'+sha
        with self.connect() as c:
            existing=c.execute('SELECT * FROM blobs WHERE id=?',(id,)).fetchone()
            if not existing:
                path=self.root/id;tmp=self.root/uid('pending_');tmp.write_bytes(raw);os.replace(tmp,path)
                c.execute('INSERT OR IGNORE INTO blobs VALUES(?,?,?,?,?)',(id,sha,Path(filename).name[:150],mime,kind))
        return {'id':id,'sha256':sha,'filename':Path(filename).name[:150],'mime':mime,'kind':kind}
    def blob(self,id):
        with self.connect() as c:row=c.execute('SELECT * FROM blobs WHERE id=?',(id,)).fetchone()
        if not row:raise AppError('节点素材不存在。',404)
        path=self.root/row['id']
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha']:raise AppError('节点素材校验失败。',409)
        return dict(row),path
    def job(self,id):
        with self.connect() as c:r=c.execute('SELECT * FROM jobs WHERE id=?',(id,)).fetchone()
        if not r:raise AppError('远端任务不存在。',404)
        r=dict(r)
        for k in ('request','result','metrics'):r[k]=json.loads(r[k]) if r[k] else None
        r.pop('fp');r.pop('idem');return r


def create_app(*,kind=None,root=None,token=None,backend=None,start_worker=True):
    kind=kind or os.getenv('MS_NODE_KIND','geometry')
    if kind not in CAPS:raise ValueError(f'Unknown node kind: {kind}')
    token=token or os.getenv('MS_NODE_TOKEN','')
    if len(token)<24:raise ValueError('MS_NODE_TOKEN 必须至少 24 字符。')
    store=NodeStore(root or os.getenv('MS_NODE_DATA',f'node-data/{kind}'))
    stop=threading.Event();box={'backend':backend,'last_success':None}
    mode='contract-test' if backend is not None else 'native'
    process_lock=ProcessLock(store.root/'process.lock')
    fingerprint={'kind':kind,'model':os.getenv('MODEL_PATH',os.getenv('IMAGE_UPSTREAM_MODEL','')),
                 'revision':os.getenv('MODEL_REVISION','UNRECORDED'),
                 'runtime_revision':os.getenv('MODEL_RUNTIME_REVISION','UNRECORDED'),
                 'driver_sha256':hashlib.sha256(Path(__file__).with_name('backends.py').read_bytes()).hexdigest(),
                 'profile':{k:os.getenv(k,'') for k in ['TEXTURE_STEPS','TEXTURE_SIZE','TEXTURE_RENDER_SIZE','TEXTURE_DIFFUSION_SIZE','GEOMETRY_DEVICE','TEXTURE_DEVICE','SINGLE_GPU_STAGED','IMAGE_CPU_OFFLOAD','IMAGE_OFFLOAD_MODE','IMAGE_SIZE_LEVEL','MS_IMAGE_GPU_MEMORY_MIB']}}
    if kind=='image':fingerprint['profile'].update({k:os.getenv(k,'false') for k in ('IMAGE_THINKING_MODE','IMAGE_REFLECTION_MODE')})
    def cancel_file(id):
        work=(store.root/id).resolve()
        if not work.is_relative_to(store.root.resolve()) or work.name!=id:raise AppError('任务目录不安全。',409)
        return work/'cancel.requested'
    def execute_one():
        with store.connect() as c:
            c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT * FROM jobs WHERE status="queued" AND cancel=0 ORDER BY created LIMIT 1').fetchone()
            if not row:return False
            c.execute('UPDATE jobs SET status="running",updated=? WHERE id=?',(time.time(),row['id']))
        request=json.loads(row['request']);work=store.root/row['id'];work.mkdir(exist_ok=True);path=None
        began=time.perf_counter()
        try:
            if request['input_asset']:
                blob,source=store.blob(request['input_asset'])
                if blob['kind']=='image':
                    path=work/'input.png';path.write_bytes(image_copy(source.read_bytes(),max_edge=2048,alpha=True))
                elif blob['kind']=='audio':
                    path=work/'input.wav';path.write_bytes(canonical_audio(source.read_bytes(),Path(blob['filename']).suffix))
                elif blob['kind']=='model' and request['capability']=='geometry.texture':
                    path=work/'input.glb';path.write_bytes(source.read_bytes())
                else:raise AppError('模型输入格式不正确。')
            if request.get('reference_asset'):
                blob,source=store.blob(request['reference_asset'])
                if blob['kind']!='image':raise AppError('贴图参考必须为图片。')
                (work/'reference.png').write_bytes(image_copy(source.read_bytes(),max_edge=2048,alpha=True))
            if box['backend'] is None:
                from .backends import load_driver
                box['backend']=load_driver(kind)
            output=box['backend'].run(request['capability'],path,work,request['prompt'],request['options'])
            if isinstance(output,dict):result={'report':output}
            else:
                outpath=Path(output)
                if not outpath.is_file() or not outpath.resolve().is_relative_to(work.resolve()):raise AppError('模型未在当前工作目录生成产物。')
                a=store.put(outpath.read_bytes(),outpath.name)
                expected='model' if kind=='geometry' else ('image' if kind in ('image','image-api') else 'audio')
                if a['kind']!=expected:raise AppError('模型输出类型不匹配。')
                result={'asset':a}
            metrics={'elapsed_seconds':round(time.perf_counter()-began,3),'execution_mode':mode,'model_fingerprint':fingerprint}
            with store.connect() as c:
                cancelled=c.execute('SELECT cancel FROM jobs WHERE id=?',(row['id'],)).fetchone()['cancel']
                c.execute('UPDATE jobs SET status=?,result=?,metrics=?,updated=? WHERE id=?',
                          ('cancelled' if cancelled else 'succeeded',dumps(result),dumps(metrics),time.time(),row['id']))
            box['last_success']=time.time()
        except Exception as e:
            traceback.print_exc()
            with store.connect() as c:
                cancelled=c.execute('SELECT cancel FROM jobs WHERE id=?',(row['id'],)).fetchone()['cancel']
                c.execute('UPDATE jobs SET status=?,error=?,updated=? WHERE id=?',
                          ('cancelled' if cancelled else 'failed',str(e)[:1000],time.time(),row['id']))
        return True
    def loop():
        if os.getenv('MS_NODE_PRELOAD','false').lower()=='true' and box['backend'] is None:
            try:
                from .backends import load_driver
                box['backend']=load_driver(kind)
            except Exception:
                traceback.print_exc()  # a request can explicitly retry loading
        while not stop.is_set():
            try:
                if not execute_one():stop.wait(.25)
            except Exception:traceback.print_exc();stop.wait(1)
    @asynccontextmanager
    async def lifespan(app):
        process_lock.acquire()
        with store.connect() as c:
            c.execute('UPDATE jobs SET status="cancelled",updated=? WHERE status IN ("running","cancelling") AND cancel=1',(time.time(),))
            c.execute('UPDATE jobs SET status="failed",error="Node process restarted during inference; explicit retry required",updated=? WHERE status IN ("running","cancelling") AND cancel=0',(time.time(),))
        thread=threading.Thread(target=loop,daemon=True) if start_worker else None
        if thread:thread.start()
        yield
        stop.set()
        if thread:thread.join(timeout=2)
        process_lock.release()
    app=FastAPI(title='MemoryScape Model Node',version='1.0.0-rc1',lifespan=lifespan,docs_url=None,redoc_url=None)
    app.add_middleware(BodyLimit,limit=130*1024*1024)
    app.state.store=store;app.state.run_one=execute_one
    def auth(authorization:str|None=Header(None)):
        if not secrets.compare_digest((authorization or '').removeprefix('Bearer '),token):raise HTTPException(401,'Unauthorized')
    @app.exception_handler(AppError)
    async def error(request,e):return JSONResponse({'error':e.code,'message':e.message},status_code=e.status)
    @app.get('/health')
    def health():return {'service':'memoryscape-model-node','kind':kind,'queue':'available','model_loaded':box['backend'] is not None,
                         'last_success':box['last_success'],'execution_mode':mode,'gpu_verified':False}
    @app.get('/v1/capabilities',dependencies=[Depends(auth)])
    def caps():return {'capabilities':CAPS[kind],'model_loaded':box['backend'] is not None,'execution_mode':mode,'fingerprint':fingerprint,
                       'concurrency':1,'requires_input':kind not in ('image-api',),
                       'cancellation':'queued-immediate; running-at-diffusion-step' if kind=='image' and mode=='native' else 'queued-immediate; running-discard-on-finish'}
    @app.post('/v1/assets',dependencies=[Depends(auth)])
    async def upload(file:UploadFile=File(...)):
        raw=await file.read(128*1024*1024+1)
        return store.put(raw,file.filename or 'input.bin')
    @app.get('/v1/assets/{id}',dependencies=[Depends(auth)])
    def blob(id:str):
        row,path=store.blob(id);return FileResponse(path,media_type=row['mime'],filename=row['filename'])
    @app.post('/v1/jobs',dependencies=[Depends(auth)])
    def create(req:RemoteRequest,idempotency_key:str|None=Header(None)):
        if not idempotency_key or len(idempotency_key)>120 or not idempotency_key.isascii():raise AppError('需要合法 Idempotency-Key。')
        try:options=validate_options(kind,req)
        except ValidationError as e:raise AppError('模型参数不合法：'+str(e)[:900]) from e
        needs_input=req.capability not in ('audio.tts','image.generate','music.generate')
        if needs_input and not req.input_asset:raise AppError('缺少输入素材。')
        input_sha=None
        if req.input_asset:
            blob,_=store.blob(req.input_asset);input_sha=blob['sha']
            expected='model' if req.capability=='geometry.texture' else 'image' if req.capability.startswith(('image.','geometry.')) else 'audio'
            if blob['kind']!=expected:raise AppError('输入素材类型不正确。')
        reference_sha=None
        if req.reference_asset:
            reference,_=store.blob(req.reference_asset)
            if reference['kind']!='image':raise AppError('贴图参考必须为图片。')
            reference_sha=reference['sha']
        body=req.model_dump(exclude_none=True);body['options']=options
        body.setdefault('input_asset',None)
        # Content-based fingerprint: repeated upload produces the same asset id.
        fp=digest({'request':body,'input_sha':input_sha,'reference_sha':reference_sha,'model':fingerprint})
        with store.connect() as c:
            c.execute('BEGIN IMMEDIATE')
            existing=c.execute('SELECT * FROM jobs WHERE idem=?',(idempotency_key,)).fetchone()
            if existing:
                if existing['fp']!=fp:raise AppError('幂等键的输入或模型指纹不同。',409)
                id=existing['id']
            else:
                id=uid('r_');now=time.time()
                c.execute('INSERT INTO jobs(id,idem,fp,request,status,created,updated) VALUES(?,?,?,?,"queued",?,?)',
                          (id,idempotency_key,fp,dumps(body),now,now))
        return {'id':id,'status':store.job(id)['status'],'execution_mode':mode}
    @app.get('/v1/jobs/{id}',dependencies=[Depends(auth)])
    def get(id:str):
        out=store.job(id);out['execution_mode']=mode;return out
    @app.post('/v1/jobs/{id}/cancel',dependencies=[Depends(auth)])
    def cancel(id:str):
        store.job(id)
        with store.connect() as c:
            c.execute('UPDATE jobs SET cancel=1,status=CASE WHEN status="queued" THEN "cancelled" WHEN status="running" THEN "cancelling" ELSE status END,updated=? WHERE id=?',(time.time(),id))
            flag=cancel_file(id);flag.parent.mkdir(exist_ok=True);flag.touch()
        return get(id)
    @app.post('/v1/jobs/{id}/retry',dependencies=[Depends(auth)])
    def retry(id:str):
        with store.connect() as c:
            c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT status FROM jobs WHERE id=?',(id,)).fetchone()
            if not row:raise AppError('任务不存在。',404)
            if row['status'] not in ('failed','cancelled'):raise AppError('只能重试终止任务，不能重复启动正在执行的 GPU 任务。',409)
            cancel_file(id).unlink(missing_ok=True)
            c.execute('UPDATE jobs SET status="queued",error=NULL,result=NULL,cancel=0,updated=? WHERE id=?',(time.time(),id))
        return get(id)
    return app


def main():
    import uvicorn
    p=argparse.ArgumentParser();p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=9103);args=p.parse_args()
    uvicorn.run(create_app(),host=args.host,port=args.port,workers=1)

if __name__=='__main__':main()
