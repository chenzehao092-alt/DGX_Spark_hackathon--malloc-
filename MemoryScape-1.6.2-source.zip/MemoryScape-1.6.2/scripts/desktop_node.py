"""Deploy only this app's node code; start/reuse node and a private SSH tunnel."""
import json
import os
import re
import shlex
import socket
import subprocess
import time
try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib
import urllib.request
from pathlib import Path, PurePosixPath

FLAGS = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0

def node_kind(conf):
    kind = conf.get('kind', 'geometry')
    if kind not in ('geometry', 'image'):
        raise ValueError('桌面部署仅支持 geometry 或 image 节点。')
    return kind

def runtime_revision(conf):
    return conf.get('runtime_revision', 'memoryscape-1.5-desktop' if node_kind(conf)=='geometry'
                    else 'memoryscape-step1xedit-v1p2')

def node_ready(conf, data):
    capability = 'geometry.generate' if node_kind(conf)=='geometry' else 'image.edit'
    return (data.get('execution_mode')=='native' and capability in data.get('capabilities',[])
            and data.get('fingerprint',{}).get('runtime_revision')==runtime_revision(conf))

def node_records(conf):
    if node_kind(conf)=='geometry':
        return ('node-connection.json', 'tunnel', 'ssh-tunnel')
    return ('image-node-connection.json', 'tunnel-image', 'ssh-tunnel-image')

def configured_remotes(path):
    values = tomllib.loads(path.read_text('utf-8'))
    return [(section, values[section]) for section in ('remote', 'image_remote') if section in values]

def record_process(data, name, proc):
    if os.name != 'nt':return
    result=command(['powershell','-NoProfile','-Command',
        f'(Get-Process -Id {proc.pid}).StartTime.ToUniversalTime().Ticks'])
    (data/(name+'.process.json')).write_text(json.dumps({'pid':proc.pid,'created':int(result.strip())}))

def command(argv, timeout=90, capture=True):
    r = subprocess.run(argv, stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
                       stderr=subprocess.PIPE, timeout=timeout, creationflags=FLAGS)
    if r.returncode:
        raise RuntimeError(f'{Path(argv[0]).stem} 失败（退出码 {r.returncode}）；检查 SSH 登录、网络和部署路径。')
    return r.stdout or b''

def validate_project_path(project):
    """Only accept an explicit, dedicated app directory on a Linux node.

    The operator selects the target in deployment.toml; it must never be a
    broad home/workspace/root directory. Do not pin portable deployments to
    one developer's account or mount point.
    """
    if (not isinstance(project, str) or len(project) > 240
        or not re.fullmatch(r'/[A-Za-z0-9_./-]+', project)
        or any(part in ('', '.', '..') for part in project.split('/')[1:])):
        raise ValueError('远端项目必须是无路径跳转的明确 Linux 绝对路径。')
    path = PurePosixPath(project)
    if len(path.parts) < 3 or not re.fullmatch(r'memoryscape-[A-Za-z0-9][A-Za-z0-9_.-]*', path.name):
        raise ValueError('请使用专用 memoryscape-版本名 目录，不能使用根目录、主目录或工作区根目录。')
    return project

def validate_remote(conf):
    node_kind(conf)
    validate_project_path(conf['project'])
    if not re.fullmatch(r'(?:[A-Za-z0-9_.-]+@)?[A-Za-z0-9_.-]+', conf['ssh_target']):
        raise ValueError('SSH 目标必须是主机别名或 user@host。')
    for key in ('node_port', 'local_port'):
        if type(conf[key]) is not int or not 1 <= conf[key] <= 65535:
            raise ValueError(f'{key} 必须是 1–65535 的端口。')
    if conf.get('lifecycle', 'managed') not in ('managed', 'reuse'):
        raise ValueError('lifecycle 只能为 managed 或 reuse。')
    for key in ('thinking_mode','reflection_mode'):
        if key in conf and type(conf[key]) is not bool:raise ValueError(key+' must be a TOML boolean')


def probe_existing(conf, ssh):
    """Use the token on the remote node; only capability metadata is returned."""
    capability = 'geometry.generate' if node_kind(conf)=='geometry' else 'image.edit'
    code = f'PROJECT={conf["project"]!r}\nPORT={conf["node_port"]}\nKIND={node_kind(conf)!r}\nCAP={capability!r}\nREV={runtime_revision(conf)!r}\n' + '''import json,pathlib,socket,urllib.request
p=pathlib.Path(PROJECT)/('node-data/'+KIND+'/token')
s=socket.socket(); busy=s.connect_ex(('127.0.0.1',PORT))==0; s.close()
out={'ready':False,'port_in_use':busy}
if busy and p.is_file():
 try:
  req=urllib.request.Request('http://127.0.0.1:%d/v1/capabilities'%PORT,headers={'Authorization':'Bearer '+p.read_text().strip()})
  with urllib.request.urlopen(req,timeout=8) as r: data=json.load(r)
  out['ready']=(CAP in data.get('capabilities',[]) and data.get('execution_mode')=='native' and data.get('fingerprint',{}).get('runtime_revision')==REV)
  out['capabilities']=data
 except Exception: pass
print(json.dumps(out))
'''
    return json.loads(command(ssh + [shlex.quote(conf['python']) + ' -c ' + shlex.quote(code)], timeout=30))


def ensure_tunnel(settings, conf, token, stop_event=None):
    """Repair only a dedicated, verified local forward; never deploy a model."""
    from memoryscape.security import ProcessLock
    validate_remote(conf)
    record_file, process_name, tunnel_name = node_records(conf)
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    lock=ProcessLock(settings.data_dir/(tunnel_name+'.lock'))
    lock.acquire()
    proc=None
    try:
        local,port=conf['local_port'],conf['node_port']
        def healthy():
            try:
                req=urllib.request.Request(f'http://127.0.0.1:{local}/v1/capabilities',
                    headers={'Authorization':'Bearer '+token})
                # SSH forwards are loopback, not a system HTTP proxy route.
                opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
                with opener.open(req,timeout=3) as r:data=json.load(r)
                return node_ready(conf,data)
            except Exception:return False
        if healthy():return {'reused':True}
        with socket.socket() as sock:
            sock.settimeout(1);busy=sock.connect_ex(('127.0.0.1',local))==0
        record_path=settings.data_dir/record_file
        try:record=json.loads(record_path.read_text('utf-8'))
        except (OSError,ValueError):record={}
        identity=('ssh_target','project','node_port','local_port')
        matching=all(record.get(k)==conf[k] for k in identity)
        if (settings.data_dir/(process_name+'.process.json')).is_file() and matching and os.name=='nt':
            from scripts.desktop_stop import stop_record
            stopped=stop_record(settings.data_dir,process_name,f'127.0.0.1:{local}:127.0.0.1:{port}')
            if busy and not stopped:raise RuntimeError('本机端口占用且隧道身份未通过校验；不会结束其他进程。')
            with socket.socket() as sock:
                sock.settimeout(1);busy=sock.connect_ex(('127.0.0.1',local))==0
        if busy:raise RuntimeError('本机转发端口已被其他进程占用；不会抢占端口。')
        if stop_event and stop_event.is_set():raise RuntimeError('连接守护正在停止。')
        with (settings.data_dir/(tunnel_name+'.log')).open('ab') as log:
            proc=subprocess.Popen(['ssh','-N','-T','-o','BatchMode=yes','-o','ConnectTimeout=10',
                '-o','ConnectionAttempts=1','-o','ExitOnForwardFailure=yes',
                '-o','ServerAliveInterval=10','-o','ServerAliveCountMax=3','-o','TCPKeepAlive=yes',
                '-L',f'127.0.0.1:{local}:127.0.0.1:{port}',conf['ssh_target']],
                stdin=subprocess.DEVNULL,stdout=log,stderr=log,creationflags=FLAGS)
        (settings.data_dir/(process_name+'.pid')).write_text(str(proc.pid))
        record_process(settings.data_dir,process_name,proc)
        deadline=time.monotonic()+20
        while time.monotonic()<deadline and proc.poll() is None:
            if stop_event and stop_event.is_set():break
            if healthy():return {'reused':False}
            if stop_event:stop_event.wait(.5)
            else:time.sleep(.5)
        raise RuntimeError('SSH 隧道暂未就绪；后台稍后继续重连。')
    except Exception:
        # This handle was created in this call; never terminate an arbitrary PID.
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:proc.wait(timeout=3)
            except subprocess.TimeoutExpired:pass
        raise
    finally:lock.release()


def ensure_node(root, settings, path, section='remote'):
    conf = tomllib.loads(path.read_text('utf-8'))[section]
    kind = node_kind(conf)
    record_file, _, _ = node_records(conf)
    target, project = conf['ssh_target'], conf['project']
    validate_remote(conf)
    ssh = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', target]
    port, local = conf['node_port'], conf['local_port']
    lifecycle = conf.get('lifecycle', 'managed')
    print('[模型] 检查已配置的 DGX Spark / server6 节点…', flush=True)
    probe = probe_existing(conf, ssh)
    if probe['ready']:
        result = {'status': 'ready', 'reused': True}
    else:
        if lifecycle == 'reuse':
            raise RuntimeError('复用模式下现有节点不可访问或协议不匹配；请检查部署路径、节点状态和 SSH 配置。')
        if probe.get('port_in_use'):
            raise RuntimeError('远端端口已有不匹配的服务；不会同步代码或重启该进程。')
        mkdir = 'mkdir -p ' + ' '.join(shlex.quote(project + '/' + p) for p in ['node','memoryscape','scripts','configs'])
        command(ssh + [mkdir])
        for name in ['node', 'memoryscape']:
            command(['scp', '-q', '-r', str(root / name), target + ':' + project + '/'])
        command(['scp', '-q', str(root / 'scripts' / 'remote_node.py'), target + ':' + project + '/scripts/'])
        command(['scp', '-q', str(path), target + ':' + project + '/configs/deployment.toml'])
        remote = 'cd ' + shlex.quote(project) + ' && ' + shlex.quote(conf['python']) + ' scripts/remote_node.py ensure '+kind
        command(ssh + [shlex.quote(conf['python']) + ' -m pip install tomli==2.2.1'], timeout=180)
        result = json.loads(command(ssh + [remote], timeout=180))
    if result.get('status') != 'ready':
        raise RuntimeError(f'远端节点未就绪；查看远端 node-data/{kind}/serve.log。')
    tokenfile = settings.data_dir / (kind+'-node-token')
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    pending = tokenfile.with_suffix('.pending')
    try:
        command(['scp', '-q', target + ':' + project + '/node-data/'+kind+'/token', str(pending)])
        if len(pending.read_text().strip()) < 24:
            raise RuntimeError('节点令牌格式不合法。')
        os.replace(pending, tokenfile)
    finally:
        pending.unlink(missing_ok=True)
    token = tokenfile.read_text().strip()
    url = f'http://127.0.0.1:{local}'
    advertised={}
    def healthy():
        nonlocal advertised
        try:
            req = urllib.request.Request(url + '/v1/capabilities', headers={'Authorization': 'Bearer ' + token})
            with urllib.request.urlopen(req, timeout=3) as r:
                data = json.load(r)
            if not node_ready(conf,data):return False
            advertised=data
            return True
        except Exception:
            return False
    if not healthy():
        ensure_tunnel(settings,conf,token)
        if not healthy():raise RuntimeError('节点能力未通过认证核对；未宣称支持新接口。')
    from memoryscape.settings_api import _save_secrets, _write_models_toml
    token_env = kind.upper()+'_NODE_TOKEN'
    _save_secrets(settings, {token_env: token})
    changes = {'url': url, 'enabled': 'true', 'protocol': 'node-v1', 'token_env': token_env}
    # Negotiate real capabilities, not the newest disabled example card.
    supported=['geometry.generate','geometry.texture'] if kind=='geometry' else ['image.edit']
    changes['capabilities']=[cap for cap in supported if cap in advertised.get('capabilities',[])]
    for key in ('model', 'revision'):
        if key in conf:changes[key]=conf[key]
    _write_models_toml(settings, {kind: changes})
    record = settings.data_dir / record_file
    identity = {'ssh_target': target, 'project': project, 'node_port': port, 'local_port': local}
    try: previous = json.loads(record.read_text('utf-8'))
    except (OSError, ValueError): previous = {}
    owns = lifecycle == 'managed' and (not result.get('reused') or
        (all(previous.get(k) == v for k, v in identity.items()) and previous.get('remote_started') is True))
    record.write_text(json.dumps({**identity, 'lifecycle': lifecycle, 'remote_started': owns}), 'utf-8')
    print('[模型] '+('Step1X-3D' if kind=='geometry' else 'Step1X-Edit v1p2')+' 原生节点已连接（' + ('复用现有服务' if result.get('reused') else '本次启动') + '）；生成请求由 UI 提交。', flush=True)
