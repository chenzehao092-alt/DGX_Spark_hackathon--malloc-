"""Create an isolated host environment once; then run the desktop launcher."""
import os
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class EnvironmentPreparationLock:
    """A standard-library-only lock usable before application dependencies exist."""

    def __init__(self, path):
        self.path = path
        self.file = None

    def acquire(self):
        self.file = open(self.path, 'a+b')
        try:
            if os.name == 'nt':
                import msvcrt
                if self.file.tell() == 0:
                    self.file.write(b'0')
                    self.file.flush()
                self.file.seek(0)
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            self.file.close()
            self.file = None
            raise RuntimeError('另一个启动窗口正在准备本机环境。') from error

    def release(self):
        if self.file:
            self.file.close()
            self.file = None


@contextmanager
def prepare_environment(timeout=600):
    """Serialize first-run setup; never hold this lock while invoking the venv."""
    data = ROOT / 'data'
    data.mkdir(exist_ok=True)
    lock = EnvironmentPreparationLock(data / 'environment-prepare.lock')
    deadline = time.monotonic() + timeout
    waiting = False
    while True:
        try:
            lock.acquire()
            break
        except RuntimeError:
            if time.monotonic() >= deadline:
                raise RuntimeError('等待本机环境准备超时，请查看另一个启动窗口。')
            if not waiting:
                print('[准备] 正在等待另一个启动窗口完成环境准备…', flush=True)
                waiting = True
            time.sleep(1)
    try:
        yield
    finally:
        lock.release()


def main():
    target = ROOT / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if Path(sys.prefix).resolve() != target.parents[1].resolve():
        with prepare_environment():
            if not target.is_file():
                print('[准备] 首次创建本机 Python 环境…', flush=True)
                subprocess.run([sys.executable, '-m', 'venv', str(ROOT / '.venv')], check=True)
        # The child also takes the preparation lock to install dependencies.
        return subprocess.call([str(target), str(Path(__file__)), *sys.argv[1:]], cwd=ROOT)
    marker = ROOT / '.venv' / 'memoryscape-installed'
    import hashlib
    with prepare_environment():
        stamp = hashlib.sha256((ROOT / 'pyproject.toml').read_bytes()).hexdigest()
        if not marker.is_file() or marker.read_text(encoding='utf-8') != stamp:
            print('[准备] 安装本机服务依赖（首次启动需要联网）…', flush=True)
            subprocess.run([sys.executable, '-m', 'pip', 'install', '-e', str(ROOT)], check=True, cwd=ROOT)
            marker.write_text(stamp, encoding='utf-8')
    sys.path.insert(0, str(ROOT / 'scripts'))
    sys.path.insert(0, str(ROOT))
    from memoryscape.security import ProcessLock
    (ROOT/'data').mkdir(exist_ok=True)
    lock=ProcessLock(ROOT/'data/desktop-start.lock')
    deadline=time.monotonic()+180
    while True:
        try:lock.acquire();break
        except RuntimeError:
            if time.monotonic()>deadline:
                print('另一个启动窗口仍在准备服务，请查看该窗口。');return 1
            time.sleep(1)
    try:
        import start_all
        return start_all.main(sys.argv[1:])
    finally:lock.release()

if __name__ == '__main__':
    raise SystemExit(main())
