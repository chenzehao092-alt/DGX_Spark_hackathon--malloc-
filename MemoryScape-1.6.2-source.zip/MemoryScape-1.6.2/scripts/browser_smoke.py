"""Browser smoke. Default uses normal localhost navigation. --bridge is for managed
containers where navigation is explicitly unavailable; records that narrower scope.
Requires the dev extra and a Chromium installation. Starts no model inference.
"""
import argparse,os,shutil,sys
from playwright.sync_api import sync_playwright
import httpx,base64,json,re,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
client=None

def bridge(req):
    url=req['url']
    if url.startswith('blob:'):raise RuntimeError('blob does not belong on bridge')
    path='/' + url.split('://',1)[-1].split('/',1)[1] if '://' in url else url
    if not path.startswith('/api/') and not path.startswith('/web/'):raise RuntimeError('Only local application requests')
    raw=base64.b64decode(req['body']) if req.get('body') else None
    r=client.request(req.get('method','GET'),path,headers=req.get('headers',{}),content=raw)
    return {'status':r.status_code,'headers':dict(r.headers),'data':base64.b64encode(r.content).decode()}

BOOT=r'''
const nativeFetch=window.fetch.bind(window);
window.fetch=async function(input,options={}){
 const url=typeof input==='string'?input:input.url;
 if(url.startsWith('blob:')||url.startsWith('data:'))return nativeFetch(input,options);
 const req=new Request(new URL(url,'http://memoryscape.test').href,options),raw=new Uint8Array(await req.arrayBuffer());let binary='';for(let i=0;i<raw.length;i+=65536)binary+=String.fromCharCode(...raw.subarray(i,i+65536));
 const r=await window.__http({url:req.url,method:req.method,headers:Object.fromEntries(req.headers),body:raw.length?btoa(binary):null});
 const bytes=Uint8Array.from(atob(r.data),c=>c.charCodeAt(0));return new Response(bytes,{status:r.status,headers:r.headers});
};
window.__mediaPromises=[];
new MutationObserver(()=>{for(const el of document.querySelectorAll('img[src^="/api/"],audio[src^="/api/"]')){const src=el.getAttribute('src');el.removeAttribute('src');const p=fetch(src).then(r=>r.blob()).then(b=>{el.src=URL.createObjectURL(b);});window.__mediaPromises.push(p);}}).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src']});
'''

def setup(page):
    page.expose_function('__http',bridge)
    html=(ROOT/'web/index.html').read_text()
    html=re.sub(r'<script type="module".*?</script>','',html)
    html=html.replace('<link rel="stylesheet" href="/web/style.css">','<style>'+(ROOT/'web/style.css').read_text()+'</style>')
    page.set_content(html)
    page.evaluate(BOOT)
    urls={}
    for name in ['math.js','glb.js','viewer.js','audio.js','simple.js','app.js']:
        source=(ROOT/'web'/name).read_text()
        for dep,url in urls.items():source=source.replace("'./"+dep+"'",json.dumps(url))
        urls[name]=page.evaluate('(source)=>URL.createObjectURL(new Blob([source],{type:"text/javascript"}))',source)
    page.evaluate('(url)=>import(url)',urls['app.js'])

def main():
 global client
 parser=argparse.ArgumentParser()
 parser.add_argument('--url',default='http://127.0.0.1:8000')
 parser.add_argument('--bridge',action='store_true')
 parser.add_argument('--output',type=Path,default=ROOT/'docs/reports/simple-browser.json')
 parser.add_argument('--screenshot',type=Path,default=ROOT/'docs/simple-preview.png')
 args=parser.parse_args()
 token=os.getenv('MS_TOKEN','') or (Path(os.getenv('MS_DATA_DIR',str(ROOT/'data')))/'access-token').read_text().strip()
 client=httpx.Client(base_url=args.url,trust_env=False,timeout=40)
 checks=[];errors=[]
 def check(name,condition=True):
  assert condition,name;checks.append({'name':name,'passed':True});print('PASS:',name,flush=True)
 def wait_state(page,expression,timeout=30000):
  # Playwright's string-based wait_for_function uses eval, blocked by the app CSP.
  deadline=time.monotonic()+timeout/1000
  while time.monotonic()<deadline:
   if page.evaluate(expression):return
   page.wait_for_timeout(200)
  raise AssertionError('Timed out waiting for browser state: '+expression)
 with sync_playwright() as p:
  exe=os.getenv('CHROMIUM_PATH') or shutil.which('chromium')
  opts={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
  if exe:opts['executable_path']=exe
  browser=p.chromium.launch(**opts);context=browser.new_context(viewport={'width':1440,'height':980},device_scale_factor=1)
  page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
  if args.bridge:setup(page)
  else:page.goto(args.url,wait_until='networkidle')
  page.locator('#token').fill(token);page.locator('#loginForm button').click();page.wait_for_selector('#studio:visible')
  if not args.bridge:client.post('/api/session',headers={'Authorization':'Bearer '+token})
  check('authenticated simple screen')
  check('old property, model and parameter panels are not in the document',page.locator('#objectTab, #objectInspector, #nodeButton, #sourceRole, #reviewButton').count()==0)
  check('one prompt input for generation and modification',page.locator('#chatInput').count()==1)
  # Sample is explicitly requested, has no real inference, and proceeds without a hidden second confirmation.
  page.locator('#menuButton').click();page.locator('#demoButton').click();page.wait_for_timeout(750)
  wait_state(page,'memoryscapeStatus().project && memoryscapeStatus().objects===13 && memoryscapeStatus().loaded===13 && memoryscapeStatus().version>=1',timeout=60000)
  check('single sample action reaches all 13 parsed GLBs without searching task records')
  check('demo remains visibly labelled', '非模型生成' in page.locator('#modeBadge').inner_text())
  pid=page.evaluate('memoryscapeStatus().project');base='/api/projects/'+pid
  n=len(client.get('/api/projects').json());page.locator('#menuButton').click();page.locator('#demoButton').click();page.wait_for_timeout(700)
  check('opening the sample again does not create duplicate projects',len(client.get('/api/projects').json())==n)
  before=client.get(base+'/scene').json();version=before['version']
  page.locator('#chatInput').fill('只把气球改成金色，人物保持不变');page.locator('#sendButton').click()
  page.locator('#applyPatch').wait_for(state='visible',timeout=30000)
  check('modification is a readable confirmation card, without JSON',page.locator('.edit-card pre').count()==0 and page.locator('#applyPatch').is_enabled())
  page.locator('#applyPatch').click();wait_state(page,f'memoryscapeStatus().version>{version}',timeout=30000)
  after=client.get(base+'/scene').json()
  check('colour edit applied to balloons only',all(o['tint']=='#d3b56b' for o in after['scene']['objects'] if o['id'].startswith('balloon_')))
  check('unrelated people remain exactly unchanged',[o for o in before['scene']['objects'] if o['id'].startswith('person_')]==[o for o in after['scene']['objects'] if o['id'].startswith('person_')])
  page.wait_for_timeout(300);page.locator('#undoButton').click();wait_state(page,f'memoryscapeStatus().version>{after["version"]}',timeout=15000)
  undone=client.get(base+'/scene').json()
  check('one-click undo restores prior scene without deleting history',undone['scene']==before['scene'] and len(client.get(base+'/versions').json())>=4)
  # Decline another proposal; the state is on the server and must survive a screen reload.
  page.locator('#chatInput').fill('把气球改成蓝色');page.locator('#sendButton').click();page.locator('#applyPatch').wait_for(state='visible',timeout=30000)
  page.locator('.edit-card').get_by_role('button',name='保持原样',exact=True).click()
  wait_state(page,'!document.getElementById("applyPatch")',timeout=10000)
  check('declined edit is persisted',client.get(base+'/proposals').json()[0]['status']=='dismissed')
  # Reload actual front-end modules in bridge mode; normal mode uses an ordinary refresh.
  if args.bridge:
   page.close();page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));setup(page)
  else:page.reload(wait_until='networkidle')
  wait_state(page,f'memoryscapeStatus().project==="{pid}" && memoryscapeStatus().loaded===13',timeout=30000)
  check('reopening retains conversation and does not re-offer a declined edit',page.locator('#applyPatch').count()==0 and '保持原样' in page.locator('#chatMessages').inner_text())
  page.locator('#playButton').click();page.wait_for_timeout(1400)
  check('original test sound playback advances',page.locator('#timeCurrent').inner_text()!='0:00')
  page.locator('#playButton').click()
  page.locator('#historyButton').click();page.locator('.history-row').last.get_by_role('button',name='查看',exact=True).click()
  wait_state(page,'memoryscapeStatus().history===true')
  check('old versions are read-only',page.locator('#sendButton').is_disabled())
  page.locator('#chatMessages').get_by_role('button',name='回到当前版本',exact=True).click();wait_state(page,'memoryscapeStatus().history===false')
  check('return to current version enables normal editing',page.locator('#sendButton').is_enabled())
  args.screenshot.parent.mkdir(parents=True,exist_ok=True);page.wait_for_timeout(800);page.screenshot(path=str(args.screenshot),full_page=True)
  page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(500)
  check('390px mobile layout has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
  mobile=args.screenshot.with_name(args.screenshot.stem+'-mobile.png');page.screenshot(path=str(mobile),full_page=True);page.set_viewport_size({'width':1440,'height':980})
  page.locator('#exportButton').click()
  with page.expect_download() as dl:page.locator('#dialogYes').click()
  file=args.output.parent/'browser-saved.memory.zip';file.parent.mkdir(parents=True,exist_ok=True);dl.value.save_as(str(file))
  import zipfile
  check('single save choice downloads a valid complete project',zipfile.is_zipfile(file) and dl.value.suggested_filename.endswith('.memory.zip'))
  page.locator('#menuButton').click();page.locator('#importButton').click();page.locator('#importInput').set_input_files(str(file))
  wait_state(page,f'memoryscapeStatus().project!=="{pid}" && memoryscapeStatus().loaded===13',timeout=40000)
  check('saved project reopens without inference')
  # Create real project: no user-facing mode/model selector. File metadata is automatic.
  page.locator('#menuButton').click();page.locator('#newButton').click();page.locator('#newTitle').fill('自动化测试：简易上传');page.locator('#createProject').click()
  wait_state(page,'memoryscapeStatus().objects===0',timeout=10000)
  real=page.evaluate('memoryscapeStatus().project');check('new personal project defaults to real, never silent demo fallback',client.get('/api/projects/'+real).json()['mode']=='real')
  import io,numpy as np
  from PIL import Image
  from memoryscape.media import encode_wav
  png=io.BytesIO();Image.new('RGB',(64,64),(140,110,80)).save(png,format='PNG')
  wav=encode_wav(np.zeros(16000,dtype=np.int16))
  page.locator('#fileInput').set_input_files([{'name':'合影.png','mimeType':'image/png','buffer':png.getvalue()},{'name':'声音.wav','mimeType':'audio/wav','buffer':wav},{'name':'日记.txt','mimeType':'text/plain','buffer':'今天很开心'.encode()}])
  page.locator('#dialogConsent').check();page.locator('#dialogYes').click();wait_state(page,'document.querySelectorAll(".source-card").length===3',timeout=20000)
  sources=client.get('/api/projects/'+real+'/sources').json()
  check('mixed photo, audio and diary upload requires no role selector',{s['kind']:s['role'] for s in sources}=={'image':'scene','audio':'audio','text':'diary'})
  page.locator('#chatInput').fill('请保留大家的原声，生成回忆');page.locator('#sendButton').click();page.wait_for_timeout(1000)
  check('unconfigured model produces friendly explanation, not fabricated scene','创作服务尚未接通' in page.locator('#chatMessages').inner_text() and page.evaluate('memoryscapeStatus().objects')==0)
  page.locator('.source-card').first.click();page.locator('#sourceNote').fill('戴帽子的是我；这张与合影是同一天。');page.locator('#saveSource').click()
  page.wait_for_timeout(500)
  check('source explanation uses one plain-language field', '戴帽子' in client.get('/api/projects/'+real+'/sources').json()[0]['note'])
  page.locator('.source-card').last.click();page.locator('#removeSource').click();page.locator('#dialogYes').click()
  wait_state(page,'document.querySelectorAll(".source-card").length===2',timeout=10000)
  check('unused upload can be removed without professional settings')
  # Reproduce the user's RC1 v0 state: a completed plan, but no scene yet.
  pending=client.post('/api/demo').json();pending_base='/api/projects/'+pending['id']
  pending=client.patch(pending_base,json={'expected_input_revision':pending['input_revision'],'title':'恢复测试：不用再找生成按钮'}).json()
  job=client.post(pending_base+'/plan').json()
  for _ in range(100):
   item=client.get('/api/jobs/'+job['id']).json()
   if item['status'] not in ('queued','running'):break
   time.sleep(.1)
  assert item['status']=='succeeded'
  page.locator('#menuButton').click();page.locator('#openButton').click()
  page.locator('.project-row').filter(has_text='恢复测试：不用再找生成按钮').get_by_role('button',name='打开',exact=True).click()
  page.locator('#confirmPlan').wait_for(state='visible',timeout=15000)
  check('old ungenerated project exposes pending plan directly inside conversation',page.locator('#confirmPlan').is_enabled())
  page.locator('#confirmPlan').click();wait_state(page,'memoryscapeStatus().loaded===13',timeout=40000)
  check('recovered RC1 project can complete without developer or task panels')
  check('no uncaught JavaScript errors',not errors)
  status=page.evaluate('memoryscapeStatus()')
  report={'transport':'in-memory DOM/ES-module + real local HTTP API bridge' if args.bridge else 'ordinary HTTP browser navigation','renderer':status['renderer'],'passed':len(checks),'checks':checks,'page_errors':errors,'real_gpu_model_inference':False,'not_covered':['real model generation','GPU WebGL rendering when renderer=cpu','ordinary navigation, native cookie transport and CSP when bridge=true']}
  args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2));browser.close()
 client.close()
if __name__=='__main__':main()
