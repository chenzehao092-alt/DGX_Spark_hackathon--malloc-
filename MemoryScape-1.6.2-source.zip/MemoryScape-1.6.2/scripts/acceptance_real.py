"""Operator acceptance: real photo -> StepFun plan -> native textured GLB.

Only use an authorized photograph; never executed by the normal launcher.
Reads a key file locally without printing it. Run against a disposable data dir.
"""
import argparse
import io
import json
import struct
import time
import zipfile
from pathlib import Path
import httpx

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--data',type=Path,required=True)
    p.add_argument('--photo',type=Path,required=True)
    p.add_argument('--key-file',type=Path,required=True)
    p.add_argument('--url',default='http://127.0.0.1:8002')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--resume',action='store_true')
    p.add_argument('--source-note',default='',help='Verified provenance/license for the supplied photo; do not infer it from a filename')
    args=p.parse_args(); args.output.mkdir(parents=True,exist_ok=True)
    key=''
    for line in args.key_file.read_text('utf-8').splitlines():
        if line.startswith(('DIRECTOR_TOKEN=','STEPFUN_API_KEY=')):
            key=line.split('=',1)[1].strip().strip('"').strip("'")
            if key: break
    if not key:raise RuntimeError('配置中未找到 StepFun Key。')
    token=(args.data/'access-token').read_text().strip()
    with httpx.Client(base_url=args.url,headers={'Authorization':'Bearer '+token},timeout=120,trust_env=False) as c:
        def req(method,path,**kw):
            r=c.request(method,path,**kw);r.raise_for_status();return r.json()
        req('POST','/api/settings/stepfun',json={'api_key':key});key=''
        print('StepFun Key saved through UI settings API (not displayed)',flush=True)
        if args.resume:
            state=json.loads((args.output/'state.json').read_text('utf-8'))
            project=req('GET','/api/projects/'+state['project_id'])
        else:
            project=req('POST','/api/projects',json={'title':'实物相机 · 真实模型验收',
            'mode':'real','remote_consent':True,
            'requirements':'根据上传的实物相机照片，使用 geometry 模型生成一个带纹理的相机三维物体；必须 generate3d，不使用程序化相机、气球或 billboard。保留机身、镜头盖与黑色材质。只放一个相机物体，放在简单中性底座上，不使用图片编辑，不生成声音。',
            'style':'忠于实物照片的静态带纹理三维展品，不加入虚构故事。',
            'budget':{'max_objects':2,'max_generated_assets':1,'max_parallel':1,'max_review_rounds':0}})
        b='/api/projects/'+project['id']
        source={'id':state['source_id']} if args.resume else req('POST',b+'/sources',files={'file':('real-camera.jpg',args.photo.read_bytes(),'image/jpeg')},
                   data={'role':'object','label':'已授权实物相机照片','subject':'相机机身','rights_confirmed':'true',
                         'note':args.source_note})
        state={'project_id':project['id'],'source_id':source['id']}
        (args.output/'state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),'utf-8')
        def wait(job):
            last=None;deadline=time.monotonic()+7200
            while time.monotonic()<deadline:
                data=req('GET','/api/jobs/'+job['id']);status=data['status']
                if status!=last:print(f"job {job['id']} {status}",flush=True);last=status
                if status in ('succeeded','partial','failed','cancelled','needs_review'):
                    (args.output/(job['id']+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2),'utf-8')
                    if status!='succeeded':raise RuntimeError(f"Real job ended {status}: {data.get('error')}")
                    return data
                time.sleep(3)
            raise RuntimeError('Real inference timeout; not replacing with fake output.')
        if args.resume:
            plan=next(x for x in req('GET',b+'/jobs') if x['kind']=='plan' and x['status']=='succeeded')
        else:plan=wait(req('POST',b+'/plan',json={}))
        pending=req('GET',b+'/plans'); record=next(x for x in pending if x['id']==plan['result']['plan_id'])
        scene=record['body']['scene'] if 'body' in record else record['scene']
        generated=[x for x in scene['objects'] if x.get('generation',{}).get('strategy')=='generate3d']
        if not generated:raise RuntimeError('Planner did not choose native 3D; reject procedural fallback.')
        current=req('GET',b)
        build=req('POST',b+'/plans/'+plan['result']['plan_id']+'/confirm',json={
            'expected_version':current['head'],'expected_input_revision':current['input_revision']})
        if build['status'] in ('partial','failed','cancelled'):
            build=req('POST','/api/jobs/'+build['id']+'/retry',json={})
        done=wait(build)
        r=c.get(b+'/scene.glb');r.raise_for_status();raw=r.content
        magic,ver,size=struct.unpack_from('<4sII',raw)
        assert magic==b'glTF' and ver==2 and size==len(raw)
        length,kind=struct.unpack_from('<II',raw,12);gltf=json.loads(raw[20:20+length])
        assert gltf.get('meshes') and gltf.get('textures') and gltf.get('images') and gltf.get('materials')
        assert all('bufferView' in image for image in gltf['images'])
        (args.output/'real-camera.glb').write_bytes(raw)
        r=c.get(b+'/export');r.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:assert z.testzip() is None
        (args.output/'real-camera.memory.zip').write_bytes(r.content)
        result={'project_id':project['id'],'build_job':done['id'],'scene_bytes':len(raw),
            'meshes':len(gltf['meshes']),'materials':len(gltf['materials']),
            'textures':len(gltf['textures']),'embedded_images':len(gltf['images']),
            'real_geometry_assets':len(generated),'export_zip_valid':True}
        (args.output/'result.json').write_text(json.dumps(result,indent=2),'utf-8')
        print(json.dumps(result),flush=True)

if __name__=='__main__':main()
