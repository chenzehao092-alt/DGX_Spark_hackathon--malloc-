"""Stop only the verified node and launcher-owned local processes."""
import json
import os
import subprocess
import sys
import tomllib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
FLAGS=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0

def stop_record(data,name,needle):
    path=data/(name+'.process.json')
    if not path.is_file():return False
    record=json.loads(path.read_text()); pid=int(record['pid']); created=int(record['created'])
    # Start-time comparison protects against PID reuse. The command line is
    # inspected inside PowerShell, never returned or logged.
    code=f'''$ErrorActionPreference='Stop';
$p=Get-CimInstance Win32_Process -Filter "ProcessId={pid}";
if(-not $p){{exit 0}};
if((Get-Process -Id {pid}).StartTime.ToUniversalTime().Ticks -ne {created} -or $p.CommandLine -notlike '*{needle}*'){{exit 2}};
function StopOwnedChildren([int]$parent){{
 $kids=Get-CimInstance Win32_Process -Filter "ParentProcessId=$parent";
 foreach($k in $kids){{if($k.CommandLine -like '*{needle}*'){{
  StopOwnedChildren $k.ProcessId;
  # A venv child can disappear when its own worker exits. Ignore only that
  # disappearance; a surviving process/access error still fails safely.
  try{{Stop-Process -Id $k.ProcessId -Force -ErrorAction Stop}}
  catch{{if(Get-Process -Id $k.ProcessId -ErrorAction SilentlyContinue){{throw}}}}
 }}}}
}};
StopOwnedChildren {pid};
# A venv launcher may exit as soon as its worker is stopped.
if(Get-Process -Id {pid} -ErrorAction SilentlyContinue){{Stop-Process -Id {pid} -Force}};
# Windows can retain a terminating process briefly after Stop-Process returns.
# Wait for exit before declaring failure; never widen the verified target.
Wait-Process -Id {pid} -Timeout 5 -ErrorAction SilentlyContinue;
if(Get-Process -Id {pid} -ErrorAction SilentlyContinue){{exit 3}};
# The final missing-process probe sets PowerShell's $? to false. Explicit
# success avoids reporting failure after the verified process is gone.
exit 0
'''
    try:
        result=subprocess.run(['powershell','-NoProfile','-Command',code],creationflags=FLAGS,timeout=30)
    except subprocess.TimeoutExpired:
        return False
    return result.returncode == 0

def owns_remote(data,conf):
    from scripts.desktop_node import node_records
    try:record=json.loads((data/node_records(conf)[0]).read_text('utf-8'))
    except (OSError,ValueError):return False
    return (conf.get('lifecycle','managed')=='managed' and record.get('remote_started') is True
        and all(record.get(k)==conf.get(k) for k in ('ssh_target','project','node_port')))

def main():
    sys.path.insert(0,str(ROOT))
    from memoryscape.config import Settings,load_env
    load_env(ROOT/'.env');settings=Settings().initialize();data=settings.data_dir
    path=ROOT/'configs/deployment.toml'
    from desktop_node import configured_remotes, node_records, node_kind, validate_remote
    remotes=configured_remotes(path) if path.is_file() else []
    import shlex
    errors=[]
    for _, conf in remotes:
        validate_remote(conf)
        if owns_remote(data,conf):
            try:
                r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',conf['ssh_target'],
                    'cd '+shlex.quote(conf['project'])+' && '+shlex.quote(conf['python'])+' scripts/remote_node.py stop '+node_kind(conf)],
                    capture_output=True,creationflags=FLAGS,timeout=30)
                if r.returncode:errors.append('远端模型未确认停止，请检查 SSH 网络。')
            except subprocess.TimeoutExpired:errors.append('等待远端停止超时。')
        else:print(node_kind(conf)+' 远端节点为复用服务或无本次启动记录，将继续运行。')
    if (data/'host.process.json').is_file() and not stop_record(data,'host','memoryscape.api:create_app'):
        errors.append('本机服务进程未通过记录校验或未成功停止。')
    for _, conf in remotes:
        record_file, process_name, _ = node_records(conf)
        try:connection=json.loads((data/record_file).read_text('utf-8'))
        except (OSError,ValueError):connection=conf
        if (data/(process_name+'.process.json')).is_file():
            needle=f"127.0.0.1:{connection['local_port']}:127.0.0.1:{connection['node_port']}"
            if not stop_record(data,process_name,needle):errors.append('本次 '+node_kind(conf)+' SSH 隧道未成功停止。')
    for message in errors:print(message)
    if not errors:print('本次记录的本机服务与隧道已停止；资料保留。')
    return 1 if errors else 0

if __name__=='__main__':raise SystemExit(main())
