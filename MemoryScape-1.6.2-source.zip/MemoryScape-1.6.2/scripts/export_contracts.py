"""Refresh machine-readable contracts from the running code (does not use a GPU)."""
import json,sys,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from memoryscape import schemas
from memoryscape.quality_repair import RepairRequest,RepairAction,RepairPlan
from memoryscape.config import ROOT,Settings
from memoryscape.api import create_app
for name in ['ProjectCreate','SourceUpdate','Scene','ScenePlan','Patch','EditRequest','RemoteRequest']:
    (ROOT/'contracts'/f'{name}.schema.json').write_text(json.dumps(getattr(schemas,name).model_json_schema(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for model in (RepairRequest,RepairAction,RepairPlan):
    (ROOT/'contracts'/f'{model.__name__}.schema.json').write_text(json.dumps(model.model_json_schema(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with tempfile.TemporaryDirectory() as t:
    app=create_app(Settings(data_dir=Path(t),token='contract-export-only-'+'x'*24,start_worker=False,test_models={}))
    (ROOT/'contracts/openapi.json').write_text(json.dumps(app.openapi(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Exported 10 schemas and application OpenAPI')
