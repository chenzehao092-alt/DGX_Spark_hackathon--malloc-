"""Make the pinned Step1X-3D DINOv2 config/processor use a local mirror."""
from __future__ import annotations

import os
from pathlib import Path


repo = Path(os.environ["MODEL_REPO"])
files = [
    repo / "step1x3d_geometry/models/conditional_encoders/dinov2_encoder.py",
    repo / "step1x3d_geometry/models/conditional_encoders/dinov2_clip_encoder.py",
]
marker = """        offline_dino = os.environ.get(\"DINOV2_MODEL_PATH\")
        if offline_dino and self.cfg.dino_type == \"facebook/dinov2-with-registers-large\":
            self.cfg.dino_type = offline_dino
"""
for path in files:
    text = path.read_text("utf-8")
    changed = False
    if "import os\n" not in text:
        text = "import os\n" + text
        changed = True
    if marker not in text:
        anchor = "        super().configure()\n"
        if anchor not in text:
            raise SystemExit("configure anchor not found in " + str(path))
        text = text.replace(anchor, anchor + "\n" + marker, 1)
        changed = True
    if changed:
        temporary = path.with_suffix(".tmp")
        temporary.write_text(text, "utf-8")
        temporary.replace(path)
    print("DINO_OFFLINE_PATCH_OK", path.name, "changed=" + str(changed).lower())
