"""Lifecycle for this deployment only. No arbitrary PID/process termination."""
import json
import os
import secrets
import signal
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def config(kind='geometry'):
    try:
        import tomllib
        return tomllib.loads((ROOT / 'configs/deployment.toml').read_text())['remote' if kind=='geometry' else 'image_remote']
    except ModuleNotFoundError:
        import tomli
        return tomli.loads((ROOT / 'configs/deployment.toml').read_text())['remote' if kind=='geometry' else 'image_remote']

def health(port, token, conf=None):
    try:
        req = urllib.request.Request(f'http://127.0.0.1:{port}/v1/capabilities',
                                     headers={'Authorization':'Bearer ' + token})
        with urllib.request.urlopen(req, timeout=2) as r:
            data = json.load(r)
        from scripts.desktop_node import node_ready
        return node_ready(conf or {},data)
    except Exception:
        return False

def owned_pid(path):
    try:
        pid = int(path.read_text())
        return pid if (Path(f'/proc/{pid}/cwd').resolve() == ROOT
                       and Path(f'/proc/{pid}/exe').resolve() == Path(sys.executable).resolve()) else None
    except (OSError, ValueError):
        return None

def main():
    action=sys.argv[1] if len(sys.argv)>1 else 'ensure'
    kind=sys.argv[2] if len(sys.argv)>2 else 'geometry'
    if action not in ('ensure','stop') or kind not in ('geometry','image'):raise ValueError('Invalid lifecycle command')
    conf = config(kind)
    from scripts.desktop_node import validate_remote
    validate_remote(conf)
    if conf.get('kind','geometry')!=kind:raise ValueError('Node kind does not match deployment section')
    data = ROOT / ('node-data/'+kind); data.mkdir(parents=True, exist_ok=True)
    tokenfile, pidfile = data / 'token', data / 'serve.pid'
    if not tokenfile.exists():
        fd = os.open(tokenfile, os.O_WRONLY|os.O_CREAT|os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as f: f.write(secrets.token_urlsafe(36))
    token = tokenfile.read_text().strip(); port = int(conf['node_port'])
    if action == 'stop':
        pid = owned_pid(pidfile)
        if pid:
            os.kill(pid, signal.SIGTERM)
            for _ in range(40):
                if not owned_pid(pidfile): break
                time.sleep(.25)
            if owned_pid(pidfile): raise RuntimeError('节点仍在退出中；不强制杀死进程。')
        print(json.dumps({'status':'stopped','owned_process_only':True})); return
    if health(port, token, conf):
        print(json.dumps({'status':'ready','reused':True})); return
    with socket.socket() as s:
        if s.connect_ex(('127.0.0.1',port)) == 0:
            raise RuntimeError('节点端口被另一部署占用；不会结束该进程。')
    env = dict(os.environ, PYTHONPATH=str(ROOT), MS_NODE_KIND=kind, MS_NODE_DATA=str(data),
        MS_NODE_TOKEN=token,MS_NODE_PRELOAD='true')
    if kind=='image':
        proof=json.loads((ROOT/'model-verification.json').read_text('utf-8'))
        if proof['model_revision'] not in conf['revision'] or proof['diffusers_revision'] not in conf['revision']:
            raise RuntimeError('Verified model and fork revisions do not match deployment')
        env.update(MODEL_PATH=conf['model_path'],MODEL_REVISION=conf['revision'],
            MODEL_RUNTIME_REVISION=conf.get('runtime_revision','memoryscape-step1xedit-v1p2'),
            IMAGE_DEVICE='cuda:0',IMAGE_OFFLOAD_MODE=conf.get('offload_mode','sequential'),
            IMAGE_SIZE_LEVEL=str(conf.get('size_level',512)),MS_IMAGE_GPU_INDEX=str(conf['gpu_index']),
            IMAGE_THINKING_MODE=str(conf.get('thinking_mode',False)).lower(),
            IMAGE_REFLECTION_MODE=str(conf.get('reflection_mode',False)).lower(),
            MS_IMAGE_MIN_FREE_MIB=str(conf.get('min_free_mib',22000)),
            MS_IMAGE_GPU_MEMORY_MIB=str(conf.get('gpu_memory_mib',22000)),
            HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',OMP_NUM_THREADS='8')
    else:
        env.update(
        MS_NODE_TOKEN=token, MODEL_REPO=conf['model_repo'], MODEL_PATH=conf['model_path'],
        DINOV2_MODEL_PATH=conf['dinov2'], MODEL_REVISION='server6-existing-step1x3d-weights',
        MODEL_RUNTIME_REVISION='memoryscape-1.5-desktop',
        GEOMETRY_DEVICE='cuda:0', TEXTURE_DEVICE='cuda:0', SINGLE_GPU_STAGED='true',
        PATCHED_STEP1X_RUNTIME='true', GEOMETRY_CPU_OFFLOAD='true',
        STEP1X_TEXTURE_SAFE_OFFLOAD='true', MS_GPU_MIN_FREE_MIB=str(conf['min_free_mib']),
        MS_GPU_MEMORY_MIB=str(conf['gpu_memory_mib']), MS_NODE_PRELOAD='true',
        TEXTURE_BASE_MODEL=conf['texture_base'], TEXTURE_VAE_MODEL=conf['texture_vae'],
        TEXTURE_STEPS='12', TEXTURE_RENDER_SIZE='512', TEXTURE_SIZE='512', TEXTURE_DIFFUSION_SIZE='512',
        U2NET_HOME=str(Path(conf['model_repo']).parent / 'background-removal'))
    with (data / 'serve.log').open('ab') as log:
        proc = subprocess.Popen([sys.executable,'-m','uvicorn','node.gateway:create_app',
            '--factory','--host','127.0.0.1','--port',str(port),'--no-access-log'],
            cwd=ROOT, env=env, stdout=log, stderr=log, stdin=subprocess.DEVNULL, start_new_session=True)
    pidfile.write_text(str(proc.pid))
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline and proc.poll() is None:
        if health(port, token, conf):
            print(json.dumps({'status':'ready','reused':False})); return
        time.sleep(.5)
    raise RuntimeError(f'节点启动失败；查看本部署 node-data/{kind}/serve.log。')

if __name__ == '__main__': main()
