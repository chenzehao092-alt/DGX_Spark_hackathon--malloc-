"""One real, authorized image edit; key stays in local secret storage."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from memoryscape.config import Settings
from memoryscape.settings_api import load_local_secrets
from memoryscape.service import Service
from memoryscape.providers import Providers
from memoryscape.errors import ProviderError

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--project',required=True);p.add_argument('--photo',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    settings=Settings(data_dir=args.root/'data',config_file=args.root/'configs/models.toml').initialize()
    load_local_secrets(settings);providers=Providers(Service(settings))
    class Context:
        project=args.project
        def check(self):pass
    try:
        out=providers.stepfun_image('image',Context(),'image.edit',args.photo.read_bytes(),
            'Keep the camera unchanged. Remove the background and place the camera on a plain white background.',{'seed':2026})
        (args.output/'cloud-camera.png').write_bytes(out['data'])
        result={'image_edit':'succeeded','model':out['metrics']['upstream_model'],'bytes':len(out['data'])}
    except ProviderError as e:
        result={'image_edit':'failed','detail':str(e),'no_demo_fallback':True}
    (args.output/'cloud-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
