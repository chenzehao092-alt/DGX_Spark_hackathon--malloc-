"""Restore a private application backup into a NEW directory after SHA and SQLite checks."""
from __future__ import annotations
import argparse,contextlib,hashlib,json,re,shutil,sqlite3,tempfile,zipfile
from pathlib import Path


def restore(archive:Path,target:Path):
    target=target.resolve()
    if target.exists():raise ValueError('Target must not exist; stop the app and choose a new directory')
    target.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.memoryscape-restore-',dir=target.parent) as temp:
        work=Path(temp)/'data';work.mkdir()
        with zipfile.ZipFile(archive) as z:
            names=z.namelist()
            if len(names)!=len(set(names)) or len(names)>200000:raise ValueError('Duplicate or excessive entries')
            if any(n not in ('manifest.json','README.txt','memoryscape.sqlite3') and not re.fullmatch(r'blobs/[a-f0-9]{2}/[a-f0-9]{64}',n) for n in names):raise ValueError('Unexpected backup entry')
            if sum(i.file_size for i in z.infolist())>10*1024**3:raise ValueError('Backup exceeds 10 GiB restore budget')
            if z.getinfo('manifest.json').file_size>32*1024**2:raise ValueError('Manifest exceeds budget')
            manifest=json.loads(z.read('manifest.json'))
            if not isinstance(manifest,dict) or set(manifest)!=(set(names)-{'manifest.json','README.txt'}):raise ValueError('Manifest mismatch')
            for name,sha in manifest.items():
                out=work/name;out.parent.mkdir(parents=True,exist_ok=True);digest=hashlib.sha256()
                with z.open(name) as src,out.open('xb') as dst:
                    while chunk:=src.read(1024*1024):digest.update(chunk);dst.write(chunk)
                if digest.hexdigest()!=sha:raise ValueError('Hash mismatch: '+name)
        db=work/'memoryscape.sqlite3'
        with contextlib.closing(sqlite3.connect(db)) as c:
            if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('SQLite integrity check failed')
            for (sha,) in c.execute('SELECT DISTINCT sha FROM assets'):
                if manifest.get('blobs/'+sha[:2]+'/'+sha)!=sha:raise ValueError('Database references missing blob')
            # Never auto-resubmit old running tasks. An operator may explicitly retry.
            c.execute("UPDATE jobs SET status='cancelled',cancel=1,owner=NULL,lease=NULL,error='Restored from backup; explicit retry required' WHERE status IN ('running','queued')")
            c.commit()
        work.rename(target)
    return target

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('archive',type=Path);p.add_argument('target',type=Path);a=p.parse_args()
    try:print(restore(a.archive,a.target))
    except (ValueError,OSError,KeyError,zipfile.BadZipFile,sqlite3.Error) as e:p.exit(1,str(e)+'\n')
