"""Read-only verification after a user has generated and saved through the UI.

Only GET requests: this script cannot submit planning, generation or edits.
It keeps a private copy of the resulting export under this app's data folder.
"""
import argparse
import json
import urllib.request
import zipfile
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from memoryscape.media import parse_glb,glb_info


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('project')
    parser.add_argument('--port',type=int,default=8002)
    args=parser.parse_args()
    if not args.project.startswith('p_') or not args.project.replace('_','').isalnum():
        parser.error('Invalid project ID')
    token=(ROOT/'data/access-token').read_text().strip()
    def get(path):
        req=urllib.request.Request(f'http://127.0.0.1:{args.port}'+path,
            headers={'Authorization':'Bearer '+token})
        with urllib.request.urlopen(req,timeout=60) as response:return response.read()
    base='/api/projects/'+args.project
    scene=json.loads(get(base+'/scene'))
    jobs=json.loads(get(base+'/jobs'))
    assets=json.loads(get(base+'/assets'))
    # Preserve prior acceptance evidence rather than overwrite an older version.
    destination=ROOT/'data/ui-verification'/args.project/('v'+str(scene['version']))
    destination.mkdir(parents=True,exist_ok=True)
    raw=get(base+'/scene.glb?version='+str(scene['version']))
    doc=parse_glb(raw);info=glb_info(raw)
    (destination/'scene.glb').write_bytes(raw)
    pack=get(base+'/export?version='+str(scene['version'])+'&originals=false')
    packfile=destination/'memory.memory.zip';packfile.write_bytes(pack)
    with zipfile.ZipFile(packfile) as archive:
        if archive.testzip() is not None:raise RuntimeError('Corrupted export ZIP')
        entries=archive.namelist()
    renders=[a for a in assets if a['provenance']=='rendered' and a['meta'].get('version')==scene['version']]
    if renders:
        render=renders[-1]
        (destination/'preview.png').write_bytes(get(base+'/assets/'+render['id']))
    native=[]
    for job in jobs:
        if job['kind']!='build' or job['status']!='succeeded':continue
        for step in job.get('steps',[]):
            metrics=(step.get('result') or {}).get('meta',{}).get('metrics',{})
            if metrics.get('execution_mode')=='native':native.append(metrics)
    report={'project':args.project,'version':scene['version'],'ui_preview_saved':bool(renders),
        'zip_valid':True,'zip_entries':len(entries),'glb_bytes':len(raw),
        'meshes':len(doc.get('meshes',[])),'materials':len(doc.get('materials',[])),
        'textures':len(doc.get('textures',[])),'embedded_images':sum('bufferView' in x for x in doc.get('images',[])),
        'triangles':info['triangles'],'native_inference':bool(native),'native_metrics':native,
        'objects':[{'id':o['id'],'label':o['label'],'provenance':o['provenance'],
                    'position':o['transform']['position'],'size':o['transform']['size'],
                    'fit':o['transform']['fit']} for o in scene['scene']['objects']],
        'private_proof_directory':str(destination)}
    (destination/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
