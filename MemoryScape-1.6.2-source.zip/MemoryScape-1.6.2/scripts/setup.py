#!/usr/bin/env python3
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from memoryscape.cli import main
if __name__=='__main__':
    sys.argv=[sys.argv[0],'setup',*sys.argv[1:]];main()
