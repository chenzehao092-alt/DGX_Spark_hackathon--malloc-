"""Patch the pinned Step1X-3D source to load SDXL's fp16 Diffusers variant."""
from __future__ import annotations

import os
from pathlib import Path


target = Path(os.environ["MODEL_REPO"]) / (
    "step1x3d_texture/pipelines/step1x_3d_texture_synthesis_pipeline.py"
)
text = target.read_text("utf-8")
replacements = {
    "AutoencoderKL.from_pretrained(vae_model)": "AutoencoderKL.from_pretrained(vae_model, torch_dtype=dtype)",
    "IG2MVSDXLPipeline.from_pretrained(base_model, **pipe_kwargs)": (
        "IG2MVSDXLPipeline.from_pretrained(base_model, torch_dtype=dtype, variant=\"fp16\", **pipe_kwargs)"
    ),
}
changed = False
for old, new in replacements.items():
    if new in text:
        continue
    if old not in text:
        raise SystemExit("Expected pinned-source line not found: " + old)
    text = text.replace(old, new, 1)
    changed = True
if changed:
    temporary = target.with_suffix(".tmp")
    temporary.write_text(text, "utf-8")
    temporary.replace(target)
print("STEP1X_FP16_PATCH_OK", "changed=" + str(changed).lower())
