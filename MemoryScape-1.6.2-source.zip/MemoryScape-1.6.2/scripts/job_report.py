"""Read-only per-project runtime report. Counts come from actual stored jobs/steps."""
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from memoryscape.client import Client,ident
p=argparse.ArgumentParser();p.add_argument('project');p.add_argument('output',type=Path);a=p.parse_args();c=Client();base='/api/projects/'+ident(a.project)
project=c.json('GET',base);jobs=c.json('GET',base+'/jobs');scene=c.json('GET',base+'/scene')
rows=[]
for j in jobs:
    rows.append({k:j.get(k) for k in ['id','kind','status','created','updated']})
    rows[-1]['elapsed_wall_seconds']=round(max(0,j['updated']-j['created']),3)
    rows[-1]['steps']=[{k:s.get(k) for k in ['name','status','updated']} for s in j.get('steps',[])]
out={'mode':project['mode'],'project_id':project['id'],'scene_version':scene['version'],'objects':len(scene['scene']['objects']),'audio_tracks':len(scene['scene']['audio']),'jobs':rows,'scope':'Wall-clock includes queueing and user wait; not GPU kernel time or a model quality score. Node environment/run artifacts are required to claim GPU/DGX execution.'}
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(a.output)
