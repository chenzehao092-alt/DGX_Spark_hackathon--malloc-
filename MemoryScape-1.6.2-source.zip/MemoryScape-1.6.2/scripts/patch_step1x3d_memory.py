"""Make the pinned Step1X texture pipeline configurable on 24 GB GPUs.

This is deliberately an idempotent source patch. It retains upstream defaults
and activates memory-saving options only when the launcher enables them.
"""
from __future__ import annotations

import os
from pathlib import Path


target = Path(os.environ["MODEL_REPO"]) / (
    "step1x3d_texture/pipelines/step1x_3d_texture_synthesis_pipeline.py"
)
text = target.read_text("utf-8")

old = "import argparse\n"
new = old + "import os\n"
if new not in text:
    if old not in text:
        raise SystemExit("Expected pinned-source import line not found")
    text = text.replace(old, new, 1)

old = "        self.dtype = torch.float16\n"
new = old + "        self.diffusion_size = 768\n"
if new not in text:
    if old not in text:
        raise SystemExit("Expected pinned-source config line not found")
    text = text.replace(old, new, 1)

old = "        pipe.cond_encoder.to(device=device, dtype=dtype)\n"
new = old + '''\
        # Stock Diffusers options, kept opt-in for full-quality deployments.
        if os.getenv("STEP1X_TEXTURE_ATTENTION_SLICING", "false").lower() == "true":
            pipe.enable_attention_slicing()
        if os.getenv("STEP1X_TEXTURE_VAE_SLICING", "false").lower() == "true":
            pipe.enable_vae_slicing()
        if os.getenv("STEP1X_TEXTURE_VAE_TILING", "false").lower() == "true":
            pipe.enable_vae_tiling()
        if os.getenv("STEP1X_TEXTURE_CPU_OFFLOAD", "false").lower() == "true":
            pipe.enable_model_cpu_offload(device=device)
'''
if new not in text:
    if old not in text:
        raise SystemExit("Expected pinned-source pipeline line not found")
    text = text.replace(old, new, 1)

old = "                height=768,\n                width=768,\n"
new = "                height=self.config.diffusion_size,\n                width=self.config.diffusion_size,\n"
if new not in text:
    if old not in text:
        raise SystemExit("Expected pinned-source resolution lines not found")
    text = text.replace(old, new, 1)

temporary = target.with_suffix(".tmp")
temporary.write_text(text, "utf-8")
temporary.replace(target)
print("STEP1X_MEMORY_PATCH_OK")
