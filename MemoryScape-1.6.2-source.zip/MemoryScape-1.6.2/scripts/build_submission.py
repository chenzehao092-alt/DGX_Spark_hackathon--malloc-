"""Build a clean source deliverable from the verified allowlist, never data/."""
import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if __package__:
    from .release_paths import MANIFEST_NAME, load_manifest, release_paths
else:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from release_paths import MANIFEST_NAME, load_manifest, release_paths


def build(root,output):
    root=Path(root).resolve();output=Path(output)
    if output.exists():raise ValueError('Output already exists; choose a new path.')
    manifest=load_manifest(root)
    payload=[]
    for name,canonical,path in release_paths(root,manifest):
        raw=path.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=manifest[name]:raise ValueError('Manifest mismatch: '+name)
        payload.append((canonical,raw))
    payload.append((MANIFEST_NAME,(root/MANIFEST_NAME).read_bytes()))
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,raw in sorted(payload):
            info=zipfile.ZipInfo('MemoryScape-1.6.2/'+name,date_time=(2026,9,29,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
            z.writestr(info,raw)
    with zipfile.ZipFile(output) as z:
        if z.testzip():raise ValueError('Invalid ZIP')
    return {'files':len(payload),'bytes':output.stat().st_size,
            'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'output':str(output.resolve()),
            'contains_runtime_data':False,'contains_weights':False}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();print(json.dumps(build(ROOT,args.output),indent=2))


if __name__=='__main__':main()
