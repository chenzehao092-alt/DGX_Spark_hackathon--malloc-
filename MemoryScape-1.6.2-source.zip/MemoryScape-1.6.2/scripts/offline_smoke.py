"""Test an exported project's actual offline player using an explicit in-memory bridge.
This does not replace normal browser navigation testing on the user's machine.
Only run against a package you produced; it executes the package's player JS.
"""
from pathlib import Path
import argparse,base64,json,re,zipfile
from playwright.sync_api import sync_playwright


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('package',type=Path);p.add_argument('--output',type=Path,default=Path('docs/reports/offline-smoke.json'));a=p.parse_args()
    with zipfile.ZipFile(a.package) as z:files={n:z.read(n) for n in z.namelist()}
    def get(req):
        # No filesystem/URL fetch; only explicit already-loaded package entries.
        path=req['path'].lstrip('/')
        if path not in files:raise ValueError('Package path missing')
        return base64.b64encode(files[path]).decode()
    with sync_playwright() as pw:
        import shutil,os
        kwargs={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
        exe=os.getenv('CHROMIUM_PATH') or shutil.which('chromium')
        if exe:kwargs['executable_path']=exe
        browser=pw.chromium.launch(**kwargs);page=browser.new_page(viewport={'width':1300,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.expose_function('__file',get)
        html=files['player/player.html'].decode();html=re.sub(r'<script type="module".*?</script>','',html);html=re.sub(r'<link rel="stylesheet"[^>]+>',lambda m:'<style>'+files['player/player.css'].decode()+'</style>',html)
        # Test-only bridge requires blob imports. Normal exported CSP remains unchanged.
        html=re.sub(r'<meta[^>]*http-equiv="Content-Security-Policy"[^>]*>','',html,flags=re.I)
        page.set_content(html)
        page.evaluate("""()=>{const f=window.fetch.bind(window);window.fetch=async (url)=>{if(url.startsWith('blob:')||url.startsWith('data:'))return f(url);const path=new URL(url,'http://package.test/player/player.html').pathname;const b=await __file({path});return new Response(Uint8Array.from(atob(b),c=>c.charCodeAt(0)));};}""")
        urls={}
        for name in ['math.js','glb.js','quality.js','viewer.js','audio.js','player.js']:
            source=files['player/'+name].decode()
            for dep,url in urls.items():source=source.replace("'./"+dep+"'",json.dumps(url))
            urls[name]=page.evaluate('(s)=>URL.createObjectURL(new Blob([s],{type:"text/javascript"}))',source)
        page.evaluate('(url)=>import(url)',urls['player.js'])
        page.wait_for_function("document.querySelector('canvas[data-loaded-assets]')?.dataset.loadedAssets==='13'",timeout=30000)
        assert page.locator('#title').inner_text()=='十八岁的夏天'
        page.locator('#play').click();page.wait_for_timeout(1300);assert '0:01' in page.locator('#time').inner_text()
        report={'scope':'offline project player ES modules; package bytes only, no model/API calls','passed':4,'checks':['project and diary read','13 exported GLB assets parsed/rendered','exported audio decoded and clock advanced','no page exceptions'],'renderer':page.locator('canvas[data-renderer]').get_attribute('data-renderer'),'page_errors':errors,'normal_browser_navigation_tested':False}
        assert not errors
        a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2));browser.close()
if __name__=='__main__':main()
