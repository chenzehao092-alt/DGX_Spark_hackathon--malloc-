"""Capture reproducibility metadata, never environment variables/secrets/user filenames."""
import argparse,importlib.metadata,json,platform,shutil,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args()
out={'python':sys.version,'platform':platform.platform(),'machine':platform.machine(),'gpu_inference_verified':False,'packages':{}}
for name in ['fastapi','pydantic','httpx','trimesh','numpy','torch','transformers','diffusers','mcp']:
    try:out['packages'][name]=importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:pass
for command in [['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],['git','rev-parse','HEAD']]:
    if shutil.which(command[0]):
        try:
            r=subprocess.run(command,capture_output=True,text=True,timeout=15,check=False)
            out[command[0]]=r.stdout.strip() if r.returncode==0 else 'unavailable'
        except (OSError,subprocess.TimeoutExpired):out[command[0]]='unavailable'
a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(a.output)
