"""Shared, platform-independent source-release allowlist validation.

Release archives can be extracted on Windows even when built on another OS.
Check both the listed and resolved paths before any payload file is read.
"""
import json
import re
from pathlib import Path, PureWindowsPath


MANIFEST_NAME = 'MANIFEST.sha256.json'
FORBIDDEN_COMPONENTS = {
    'data', 'node-data', 'acceptance', 'backups', 'weights', 'models',
    '.git', '.hg', '.svn', '.venv', 'venv', '.virtualenv', 'virtualenv',
    '.image-venv', 'upstream-diffusers', 'site-packages', 'node_modules',
    '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.cache',
    'cache', 'caches', '.tmp', '.temp', 'tmp', 'temp',
    '.tox', '.nox', 'htmlcov', 'coverage', 'build', 'dist', 'logs',
    '.simple-ui-backups', '.tmp-tests', 'test-data', 'test_data', 'testdata',
    'test-results', 'test_results', 'playwright-report',
}
FORBIDDEN_NAMES = {
    'python-path.txt', 'access-token', 'geometry-node-token', 'image-node-token',
    'audio-node-token', 'enhance-node-token', 'director-token',
    'image-api-node-token', 'pyvenv.cfg', 'thumbs.db', '.ds_store',
}
FORBIDDEN_SUFFIXES = {
    '.safetensors', '.ckpt', '.pth', '.pt', '.gguf', '.onnx', '.bin',
    '.pyc', '.pyo', '.log', '.bak', '.backup', '.tmp', '.pending',
    '.pem', '.key', '.ppk', '.p12', '.pfx',
}
WINDOWS_DEVICES = {'con', 'prn', 'aux', 'nul'} | {
    f'{prefix}{number}' for prefix in ('com', 'lpt') for number in range(1, 10)
}


def _private_parts(parts):
    if not parts:
        return True
    folded = [part.casefold() for part in parts]
    if any(part in FORBIDDEN_COMPONENTS or
           part.endswith(('.egg-info', '.dist-info', '-venv')) or
           part.startswith(('.venv-', 'venv-', '.tmp-')) for part in folded):
        return True
    name = folded[-1]
    private_config = (name.endswith('.toml') and
                      name.startswith(('models.', 'deployment.')) and
                      not name.endswith('.example.toml'))
    private_env = (name.endswith('.env') or
                   name.startswith('.env') and name != '.env.example')
    return (name in FORBIDDEN_NAMES or private_config or private_env or
            name.startswith('.coverage') or name.endswith('.memory.zip') or
            '.memory.zip.' in name or
            bool(set(Path(name).suffixes) & FORBIDDEN_SUFFIXES))


def release_path(root, name):
    """Return a portable archive name and its verified, existing source file."""
    root = Path(root).resolve()
    if not isinstance(name, str) or not name or '\x00' in name:
        raise ValueError('Forbidden release path: invalid name')
    normalized = name.replace('\\', '/')
    parts = normalized.split('/')
    windows = PureWindowsPath(name)
    if (windows.drive or windows.root or
        any(not part or part in ('.', '..') or part.endswith((' ', '.')) or
            re.search(r'[<>:"|?*\x00-\x1f]', part) or
            part.split('.', 1)[0].casefold() in WINDOWS_DEVICES for part in parts) or
        normalized.casefold() == MANIFEST_NAME.casefold() or _private_parts(parts)):
        raise ValueError('Forbidden release path: ' + name)
    target = root.joinpath(*parts).resolve()
    if not target.is_relative_to(root) or _private_parts(target.relative_to(root).parts):
        raise ValueError('Forbidden release path: ' + name)
    if not target.is_file():
        raise ValueError('Missing or invalid release path: ' + name)
    return '/'.join(parts), target


def release_paths(root, names):
    """Validate every path, including aliases, before reading any payload."""
    entries, seen = [], set()
    for name in names:
        canonical, target = release_path(root, name)
        folded = canonical.casefold()
        if folded in seen:
            raise ValueError('Duplicate release path: ' + name)
        seen.add(folded)
        entries.append((name, canonical, target))
    return entries


def _unique_object(pairs):
    result = {}
    for name, value in pairs:
        if name in result:
            raise ValueError('Duplicate manifest entry: ' + name)
        result[name] = value
    return result


def load_manifest(root):
    """Read only valid manifest metadata; never follow it outside the root."""
    root = Path(root).resolve()
    path = (root / MANIFEST_NAME).resolve()
    if (not path.is_relative_to(root) or
        _private_parts(path.relative_to(root).parts)):
        raise ValueError('Forbidden release manifest path')
    manifest = json.loads(path.read_text('utf-8'), object_pairs_hook=_unique_object)
    if not isinstance(manifest, dict):
        raise ValueError('Release manifest must be a JSON object')
    for name, expected in manifest.items():
        if not isinstance(expected, str) or not re.fullmatch(r'[0-9a-f]{64}', expected):
            raise ValueError('Invalid manifest SHA-256: ' + name)
    return manifest
