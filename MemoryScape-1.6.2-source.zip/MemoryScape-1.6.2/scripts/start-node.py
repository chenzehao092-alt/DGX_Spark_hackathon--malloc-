#!/usr/bin/env python3
"""Run from a model-specific environment, not the user's UI environment."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from node.gateway import main
if __name__=='__main__':main()
