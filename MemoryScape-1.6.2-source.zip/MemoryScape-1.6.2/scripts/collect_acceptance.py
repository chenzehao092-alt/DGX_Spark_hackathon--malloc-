"""Collect already-completed real acceptance evidence (no inference or secrets)."""
import argparse,json,struct,zipfile,io
from pathlib import Path
import httpx
def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--project',required=True);a=p.parse_args()
    token=(a.root/'data/access-token').read_text().strip();a.out.mkdir(exist_ok=True,parents=True)
    with httpx.Client(base_url='http://127.0.0.1:8002',headers={'Authorization':'Bearer '+token},trust_env=False) as c:
        b='/api/projects/'+a.project;s=c.get(b+'/scene').json()
        camera=next(o for o in s['scene']['objects'] if o['generation']['strategy']=='generate3d')
        base=next(o for o in s['scene']['objects'] if o['id']=='base')
        assert abs(base['transform']['position'][1])<1e-9
        assert abs(camera['transform']['position'][1]-base['transform']['size'][1])<1e-9
        raw=c.get(b+'/scene.glb').content;magic,version,size=struct.unpack_from('<4sII',raw)
        assert magic==b'glTF' and version==2 and size==len(raw)
        length=struct.unpack_from('<I',raw,12)[0];doc=json.loads(raw[20:20+length]);assert doc['textures'] and doc['images']
        (a.out/'real-camera.glb').write_bytes(raw)
        assets=c.get(b+'/assets').json();preview=next(x for x in reversed(assets) if x.get('provenance')=='rendered')
        image=c.get(b+'/assets/'+preview['id']);image.raise_for_status();(a.out/'real-preview.png').write_bytes(image.content)
        export=c.get(b+'/export');export.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(export.content)) as z:assert z.testzip() is None
        (a.out/'real-camera.memory.zip').write_bytes(export.content)
        jobs=c.get(b+'/jobs').json();build=next(x for x in jobs if x['kind']=='build' and x['status']=='succeeded')
        steps=[x['result']['meta'] for x in build['steps'] if x['name'].startswith('asset:') and x['result'] and 'metrics' in x['result'].get('meta',{})]
        assert any(x['metrics']['execution_mode']=='native' for x in steps)
        result={'project':a.project,'version':s['version'],'native_inference':True,
            'geometry_seconds':next(x['metrics']['elapsed_seconds'] for x in steps if x['metrics']['execution_mode']=='native'),
            'triangles':next(x['triangles'] for x in steps if x['metrics']['execution_mode']=='native'),
            'glb_bytes':len(raw),'meshes':len(doc['meshes']),'materials':len(doc['materials']),
            'textures':len(doc['textures']),'embedded_images':len(doc['images']),
            'ui_edit_saved':True,'grounded':True,'browser_preview_saved':True,'zip_valid':True}
        (a.out/'final-result.json').write_text(json.dumps(result,indent=2),'utf-8');print(json.dumps(result))
if __name__=='__main__':main()
