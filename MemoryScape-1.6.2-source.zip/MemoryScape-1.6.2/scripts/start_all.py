#!/usr/bin/env python3
"""Start/reuse the configured remote Step1X node, SSH tunnel and local host.

Model capability probes are not inference acceptance tests. Startup never
submits a generation request. Local browser login is automatic on loopback;
secrets and HTTP access logs are not printed or written by this launcher.
"""
from __future__ import annotations
import argparse
import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
DEFAULT_PORT = 8002
HEALTH_TIMEOUT = 60
PROBE_REMOTE = os.getenv('MS_PROBE_REMOTE', '0').lower() in ('1', 'true', 'yes')
_ACCESS_TOKEN_RE = re.compile(r'(Access token \(keep private\):\s*)\S+')


def python_ok(version_info=None) -> tuple[bool, str]:
    v = version_info or sys.version_info
    ver = (v.major, v.minor)
    if ver < (3, 11):
        return False, f'需要 Python 3.11–3.13，当前 {v.major}.{v.minor}.{v.micro}'
    if ver >= (3, 14):
        return False, f'项目要求 Python 3.11–3.13，当前 {v.major}.{v.minor} 可能不兼容'
    return True, f'Python {v.major}.{v.minor}.{v.micro} ({sys.executable})'


def check_layout() -> list[str]:
    missing = []
    for name in ('configs', 'data', 'web', 'scripts', 'memoryscape'):
        if not (ROOT / name).is_dir():
            missing.append(name)
    return missing


def fetch_health(host: str, port: int, timeout: float = 1.5):
    url = f'http://{host}:{port}/health'
    try:
        req = urllib.request.Request(url, headers={'Accept': 'application/json'})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            if r.status != 200:
                return None
            return json.loads(r.read().decode('utf-8'))
    except Exception:
        return None


def port_in_use(host: str, port: int) -> bool:
    with socket.socket() as s:
        s.settimeout(1)
        try:
            s.connect((host, port))
            return True
        except OSError:
            return False


class _RedactingLog:
    """Append-only log writer that redacts the access-token line so secrets
    never reach disk (nor the console)."""

    def __init__(self, path: Path):
        self._fh = open(path, 'a', encoding='utf-8')

    def write(self, data: str) -> int:
        line = _ACCESS_TOKEN_RE.sub(r'\1***', data)
        self._fh.write(line)
        self._fh.flush()
        return len(data)

    def flush(self):
        self._fh.flush()

    def close(self):
        self._fh.close()


def node_report(settings, probe_remote: bool = False) -> dict:
    """Summarise configured nodes. Reuses Providers.preflight() for probes."""
    from urllib.parse import urlsplit
    from memoryscape.config import endpoint
    from memoryscape.service import Service
    from memoryscape.providers import Providers
    try:
        models = settings.models()
    except Exception as e:
        return {'config': {'status': 'invalid_config',
                           'detail': f'模型配置文件解析失败：{str(e)[:200]}'}}
    out = {}
    probe_names = []
    for name, conf in models.items():
        if not conf.get('enabled'):
            continue
        try:
            base = endpoint(conf)
        except ValueError as e:
            out[name] = {'status': 'invalid_config', 'detail': str(e)[:200]}
            continue
        host = urlsplit(base).hostname or ''
        if host in ('localhost', '127.0.0.1', '::1'):
            probe_names.append(name)
        elif probe_remote:
            probe_names.append(name)
        else:
            out[name] = {'status': 'configured_remote',
                         'detail': '远端节点：一键启动不主动探测（设置 MS_PROBE_REMOTE=1 可开启探测）。'}
    if probe_names:
        svc = Service(settings)
        providers = Providers(svc)
        for check in providers.preflight()['checks']:
            if check['connection'] == 'ok':
                out[check['model']] = {'status': 'connected', 'detail': '网络与能力检查通过（未验证推理）'}
            else:
                out[check['model']] = {'status': 'failed', 'detail': (check.get('error') or '')[:200]}
    return out


def main(argv: list[str] | None = None) -> int:
    from memoryscape.config import load_env
    load_env(ROOT / '.env')
    parser = argparse.ArgumentParser(prog='start_all', description='启动模型连接、SSH 隧道与本机 MemoryScape UI')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=int(os.getenv('MS_PORT', DEFAULT_PORT)))
    parser.add_argument('--no-browser', action='store_true', help='不自动打开浏览器')
    parser.add_argument('--no-auth', action='store_true', help='不做本机自动登录（仍打开普通地址）')
    parser.add_argument('--probe-remote', action='store_true', help='也探测远端模型节点（默认只探测本机回环节点）')
    parser.add_argument('--deployment', type=Path, help='指定部署配置文件')
    parser.add_argument('--skip-node', action='store_true', help='仅启动主机；不连接或启动远端节点')
    args = parser.parse_args(argv)

    ok, py_text = python_ok()
    if not ok:
        print(f'[错误] {py_text}', file=sys.stderr)
        return 2
    print(f'[环境] {py_text}')

    missing = check_layout()
    if missing:
        print(f'[警告] 缺少目录：{", ".join(missing)}（继续尝试启动）', file=sys.stderr)

    # load .env so MS_MODELS_FILE / MS_DATA_DIR take effect
    from memoryscape.config import Settings
    from memoryscape.settings_api import load_local_secrets
    load_env(ROOT / '.env')
    settings = Settings().initialize()
    load_local_secrets(settings)  # persisted local tokens for node probing
    url = f'http://{args.host}:{args.port}'
    health = fetch_health(args.host, args.port)
    if health and health.get('app') == 'MemoryScape':
        identity = health.get('workspace_id')
        expected = __import__('hashlib').sha256(str(settings.data_dir).encode()).hexdigest()[:16]
        if identity and identity != expected:
            print('[错误] 端口属于另一份 MemoryScape，请关闭旧版本或换端口。', file=sys.stderr)
            return 1
    elif port_in_use(args.host, args.port):
        print(f'[错误] 端口 {args.port} 已被其他程序占用，请换用 --port 指定其他端口。', file=sys.stderr)
        return 1
    deployment = args.deployment or ROOT / 'configs' / 'deployment.toml'
    if args.deployment and not deployment.is_file():
        print('[错误] 指定的部署配置不存在。', file=sys.stderr)
        return 1
    if deployment.is_file() and not args.skip_node:
        from desktop_node import ensure_node, configured_remotes
        for section, conf in configured_remotes(deployment):
            try:
                ensure_node(ROOT, settings, deployment, section)
            except Exception as e:
                print(f'[警告] {conf.get("kind", "geometry")} 连接暂未就绪：{e}；继续启动本机，后台仅重连已有服务，不自动部署或重启模型。', file=sys.stderr)
    elif not args.skip_node:
        print('[提示] 尚未配置远端 3D 节点。填写 configs/deployment.toml 后重新启动；当前仅启用本机工作台。')
    if settings.config_file.is_file():
        print(f'[配置] {settings.config_file}')
    else:
        print(f'[提示] 未找到模型配置文件 {settings.config_file}；将按未配置模型启动。')

    health = fetch_health(args.host, args.port)
    if health and health.get('app') == 'MemoryScape':
        identity = health.get('workspace_id')
        expected = __import__('hashlib').sha256(str(settings.data_dir).encode()).hexdigest()[:16]
        if identity and identity != expected:
            print('[错误] 端口属于另一份 MemoryScape，请关闭旧版本或换端口。', file=sys.stderr)
            return 1
        print(f'[就绪] MemoryScape 已在运行：{url}（不重复启动）')
    elif port_in_use(args.host, args.port):
        print(f'[错误] 端口 {args.port} 已被其他程序占用，且不是 MemoryScape 服务。请先释放端口或换用 --port 指定其他端口。', file=sys.stderr)
        return 1
    else:
        print(f'[启动] 正在启动 MemoryScape host at {url} ...')
        log_path = settings.data_dir / 'start-all.log'
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
        try:
            # A real file handle survives the launcher exiting. Disable HTTP
            # access logs so the local auto-login URL never logs its token.
            env = dict(os.environ, MS_DATA_DIR=str(settings.data_dir),
                       MS_MODELS_FILE=str(settings.config_file), PYTHONPATH=str(ROOT),
                       MS_DEPLOYMENT_FILE=str(deployment.resolve()),
                       MS_AUTORECONNECT='0' if args.skip_node else '1',
                       MS_LOCAL_AUTO_LOGIN='0' if args.no_auth else '1')
            with log_path.open('ab') as log:
                proc = subprocess.Popen(
                    [sys.executable, '-m', 'uvicorn', 'memoryscape.api:create_app',
                     '--factory', '--host', args.host, '--port', str(args.port),
                     '--no-access-log'], cwd=ROOT, stdout=log, stderr=log,
                    stdin=subprocess.DEVNULL, env=env, creationflags=flags)
            (settings.data_dir / 'host.pid').write_text(str(proc.pid))
            from desktop_node import record_process
            record_process(settings.data_dir,'host',proc)
        except Exception as e:
            print(f'[错误] 无法启动 MemoryScape host：{e}', file=sys.stderr)
            return 1
        deadline = time.monotonic() + HEALTH_TIMEOUT
        ready = None
        while time.monotonic() < deadline:
            time.sleep(0.5)
            if proc.poll() is not None:
                print(f'[错误] 启动进程提前退出（退出码 {proc.returncode}）。请查看日志：{log_path}', file=sys.stderr)
                return 1
            h = fetch_health(args.host, args.port)
            if h and h.get('app') == 'MemoryScape':
                ready = h
                break
        if ready is None:
            print(f'[错误] {HEALTH_TIMEOUT} 秒内未等到健康检查通过。请查看日志：{log_path}', file=sys.stderr)
            return 1
        print(f'[就绪] {url} · MemoryScape {ready.get("version", "?")}（日志：{log_path}）')

    print('[节点] 模型节点状态（仅配置层检查，未验证推理）：')
    report = node_report(settings, probe_remote=args.probe_remote or PROBE_REMOTE)
    if not report:
        print('        未启用任何模型节点（configs/models.toml 全部 disabled 或缺失）。')
    for name, info in report.items():
        if name in ('director', 'image') and info['detail'] == '缺少节点密钥环境变量':
            print(f'        {name}: 等待你在 UI 的 StepFun 设置中输入 API Key')
        else:
            print(f'        {name}: {info["status"]} — {info["detail"]}')

    # Root navigation creates a loopback-only session. Keep credentials out
    # of the browser URL/history and avoid any manual token-copying step.
    loopback = args.host in ('127.0.0.1', 'localhost', '::1')
    if loopback and not args.no_auth:
        browser_url = url  # root creates the local session; no secret in URL/history
        print('[认证] 正在建立本地会话')
    else:
        browser_url = url
        if not loopback:
            print('[提示] 非本机地址：不做自动登录，请在登录页输入访问口令。')

    if not args.no_browser:
        try:
            webbrowser.open(browser_url)
            print('[浏览器] 已打开 MemoryScape')
        except Exception as e:
            print(f'[提示] 无法自动打开浏览器：{e}；请手动访问 {url}' +
                  ('（本机可重新运行本脚本自动登录）' if loopback else ''))
    else:
        print(f'[提示] 未自动打开浏览器；请手动访问 {url}')
    print('[完成] MemoryScape host 保持运行；重新运行本脚本可复用现有实例。')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
