"""Exercise a real running HTTP server. Creates an explicitly fictional demo project."""
from __future__ import annotations
import argparse,hashlib,io,json,sys,time,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from memoryscape.client import Client


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--url',default='http://127.0.0.1:8000');parser.add_argument('--output',type=Path,default=Path('docs/reports/http-smoke.json'));parser.add_argument('--example',type=Path);a=parser.parse_args()
    c=Client(a.url);checks=[]
    def checked(name,fn):fn();checks.append({'name':name,'passed':True})
    def truth(v):assert v
    r=c.call('GET','/api/config');checked('authenticated HTTP and CSP',lambda:truth(r.headers.get('content-security-policy')))
    p=c.json('POST','/api/demo');base='/api/projects/'+p['id'];checked('fictional demo registered',lambda:truth(p['mode']=='demo'))
    j=c.json('POST',base+'/plan')
    def wait(id):
        end=time.monotonic()+90
        while time.monotonic()<end:
            j=c.json('GET','/api/jobs/'+id)
            if j['status'] not in ('queued','running'):
                assert j['status']=='succeeded',j
                return j
            time.sleep(.2)
        raise AssertionError('Job timed out')
    j=wait(j['id']);checked('planning queue completed',lambda:truth(j['result']['plan_id']))
    p=c.json('GET',base)
    j=wait(c.json('POST',base+'/plans/'+j['result']['plan_id']+'/confirm',json={'expected_version':p['head'],'expected_input_revision':p['input_revision']})['id'])
    current=c.json('GET',base+'/scene');scene=current['scene'];checked('13 ready independent objects',lambda:truth(len(scene['objects'])==13 and all(o['status']=='ready' for o in scene['objects'])))
    for o in scene['objects']:
        raw=c.call('GET',base+'/assets/'+o['asset_id']).content;assert raw[:4]==b'glTF'
    checked('actual GLB binary responses',lambda:truth(True))
    checked('original track retained',lambda:truth(scene['audio'][0]['asset_id']==scene['audio'][0]['source_id']))
    raw=c.call('GET',base+'/export').content
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        manifest=json.loads(z.read('manifest.json'))
        for name,sha in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha
        assert 'player/player.html' in z.namelist() and 'START_VIEWER.py' in z.namelist()
    checked('offline package and all hashes',lambda:truth(True))
    imported=c.json('POST','/api/import',files={'file':('test.memory.zip',raw,'application/zip')})
    restored=c.json('GET','/api/projects/'+imported['id']+'/scene');checked('project imported without model calls',lambda:truth(len(restored['scene']['objects'])==13))
    glb=c.call('GET',base+'/scene.glb').content;checked('combined scene GLB',lambda:truth(glb[:4]==b'glTF'))
    if a.example:a.example.parent.mkdir(parents=True,exist_ok=True);a.example.write_bytes(raw)
    report={'transport':'real HTTP to running Uvicorn','mode':'procedural-demo','checks':checks,'passed':len(checks),'failed':0,'gpu_model_inference':False}
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
