"""Verify a source distribution's manifest. Run from its extracted root."""
from pathlib import Path
import hashlib
import sys

ROOT=Path(__file__).resolve().parents[1]
if __package__:
    from .release_paths import load_manifest, release_paths
else:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from release_paths import load_manifest, release_paths


def verify(root):
    manifest=load_manifest(root)
    for name,canonical,path in release_paths(root,manifest):
        if hashlib.sha256(path.read_bytes()).hexdigest()!=manifest[name]:
            raise ValueError('SHA mismatch: '+name)
    return len(manifest)


def main():
    try:
        count=verify(ROOT)
    except (ValueError,OSError) as error:
        raise SystemExit(str(error)) from None
    print(f'Verified {count} source/document files. Runtime data and test caches are not part of the release manifest.')


if __name__=='__main__':main()
