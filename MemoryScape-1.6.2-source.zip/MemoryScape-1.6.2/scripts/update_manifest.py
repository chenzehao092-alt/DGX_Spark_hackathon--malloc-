"""Refresh hashes for existing release files plus explicitly supplied additions."""
import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if __package__:
    from .release_paths import MANIFEST_NAME, load_manifest, release_paths
else:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from release_paths import MANIFEST_NAME, load_manifest, release_paths


def refresh(root,add=()):
    root=Path(root).resolve();path=root/MANIFEST_NAME
    names=set(load_manifest(root))|set(add)
    result={}
    for name,canonical,target in release_paths(root,sorted(names)):
        result[canonical]=hashlib.sha256(target.read_bytes()).hexdigest()
    pending=path.with_suffix('.json.pending')
    # Exclusive creation also refuses a stale or redirected pending path.
    with pending.open('x',encoding='utf-8') as stream:
        stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    os.replace(pending,path)
    return len(result)


def main():
    p=argparse.ArgumentParser();p.add_argument('--add',action='append',default=[])
    args=p.parse_args();print(f'Updated manifest: {refresh(ROOT,args.add)} files')

if __name__=='__main__':main()
