"""Offline loading checks for the operator-pinned Step1X-3D runtime."""
from __future__ import annotations

import os
from pathlib import Path


def main() -> None:
    vae_path = Path(os.environ["TEXTURE_VAE_MODEL"])
    model_path = Path(os.environ["MODEL_PATH"])
    base_path = Path(os.environ["TEXTURE_BASE_MODEL"])

    from diffusers import AutoencoderKL

    vae = AutoencoderKL.from_pretrained(vae_path, local_files_only=True)
    print("VAE_OK", vae.__class__.__name__, next(vae.parameters()).dtype)
    del vae

    required = {
        "geometry": model_path / "Step1X-3D-Geometry-1300m",
        "texture": model_path / "Step1X-3D-Texture",
        "sdxl": base_path,
    }
    missing = [name for name, path in required.items() if not path.is_dir()]
    if missing:
        raise SystemExit("MISSING_DIRECTORIES " + ",".join(missing))
    print("MODEL_DIRECTORIES_OK", ",".join(required))


if __name__ == "__main__":
    main()
