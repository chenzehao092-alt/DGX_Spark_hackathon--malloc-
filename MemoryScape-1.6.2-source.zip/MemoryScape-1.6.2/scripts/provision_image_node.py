"""Explicit operator-run provisioning; never called by UI or connection checks.

Run on the Linux model host. A separate venv shares the read-only CUDA torch
installation, while all new Python packages and the pinned fork stay isolated.
Public model downloads are resumable; every LFS shard is checksum-verified.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.request

MODEL_ID = 'stepfun-ai/Step1X-Edit-v1p2'
MODEL_REVISION = 'ca85b97fd19f2235dc0d6fd3633d1319f169e149'
FORK_REVISION = 'f5f1c98fa00cb4d0479af1b1b1c17d724345963a'


def run(args):
    subprocess.run(args, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--model-path', type=Path, required=True)
    parser.add_argument('--endpoint', default='https://huggingface.co')
    parser.add_argument('--download-only', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--download-workers', type=int, choices=range(1,9), default=2)
    args = parser.parse_args()
    from desktop_node import validate_project_path
    project = Path(validate_project_path(str(args.project)))
    model = args.model_path.resolve()
    if not model.is_absolute() or model.name != 'Step1X-Edit-v1p2':
        raise ValueError('Use a dedicated absolute Step1X-Edit-v1p2 model directory.')
    if args.endpoint not in ('https://huggingface.co', 'https://hf-mirror.com'):
        raise ValueError('Only the public official host or explicitly selected mirror is supported.')
    project.mkdir(parents=True, exist_ok=True)
    env = project / '.image-venv'
    python = env / 'bin/python'
    if not python.is_file():
        run([sys.executable, '-m', 'venv', '--system-site-packages', str(env)])
    # Never replace the existing 3D environment's torch or packages.
    if not args.download_only:
        run([str(python), '-m', 'pip', 'install', 'transformers==4.55.0',
         'accelerate==1.10.1', 'huggingface-hub==0.34.4', 'safetensors==0.6.2',
         'peft==0.17.0', 'einops==0.8.1', 'qwen-vl-utils==0.0.10',
             'numpy==1.26.4', 'Pillow==11.1.0', 'megfile==5.0.17',
             '-r', str(project/'requirements-node.txt')])
    fork = project / 'upstream-diffusers'
    if not args.download_only and not (fork / '.git').is_dir():
        run(['git', 'clone', '--depth', '1', '--branch', 'step1xedit_v1p2',
             'https://github.com/Peyton-Chen/diffusers.git', str(fork)])
    if not args.download_only:
        run(['git', '-C', str(fork), 'fetch', '--depth', '1', 'origin', FORK_REVISION])
        run(['git', '-C', str(fork), 'checkout', '--detach', FORK_REVISION])
        run([str(python), '-m', 'pip', 'install', '--no-deps', '-e', str(fork)])
    os.environ.update(HF_ENDPOINT=args.endpoint, HF_HUB_DISABLE_XET='1',
                      HF_HUB_DOWNLOAD_TIMEOUT='90', HF_HUB_ETAG_TIMEOUT='30')
    # Invoke downloads in the new environment, not in the old environment.
    if not args.download_only:
        run([str(python), str(Path(__file__).resolve()), '--project', str(project),
             '--model-path', str(model), '--endpoint', args.endpoint, '--download-only',
             '--download-workers',str(args.download_workers)])
        return
    def metadata_at(path):
        request=urllib.request.Request(args.endpoint+path, headers={'User-Agent':'Mozilla/5.0 MemoryScape-model-provisioner'})
        with urllib.request.urlopen(request, timeout=30) as r:
            return json.load(r)
    metadata = metadata_at('/api/models/'+MODEL_ID+'?blobs=true')
    if metadata['sha'] != MODEL_REVISION:
        # Main may advance; fetch the pinned revision's metadata instead.
        metadata = metadata_at('/api/models/'+MODEL_ID+'/revision/'+MODEL_REVISION+'?blobs=true')
    if metadata['sha'] != MODEL_REVISION:
        raise RuntimeError('Model revision metadata mismatch; no unpinned weights accepted.')
    from huggingface_hub import snapshot_download
    print(f'Downloading pinned public weights; resumable; {args.download_workers} download workers.', flush=True)
    snapshot_download(MODEL_ID, revision=MODEL_REVISION, local_dir=model,
                      ignore_patterns=['assets/*', 'examples/*', '.gitattributes'], max_workers=args.download_workers,
                      user_agent='Mozilla/5.0 MemoryScape-model-provisioner')
    verified = []
    for item in metadata['siblings']:
        name = item['rfilename']
        if name.startswith(('assets/', 'examples/')) or name == '.gitattributes':
            continue
        file = model / name
        if not file.resolve().is_relative_to(model) or not file.is_file():
            raise RuntimeError('Missing or invalid model file: '+name)
        if file.stat().st_size != item['size']:
            raise RuntimeError('Model size mismatch: '+name)
        sha = hashlib.sha256()
        with file.open('rb') as stream:
            for chunk in iter(lambda: stream.read(8*1024*1024), b''):
                sha.update(chunk)
        checksum = sha.hexdigest()
        if item.get('lfs') and checksum != item['lfs']['sha256']:
            raise RuntimeError('Model checksum mismatch: '+name)
        verified.append({'file': name, 'size': file.stat().st_size, 'sha256': checksum})
        print('Verified', name, flush=True)
    proof = {'model':MODEL_ID, 'model_revision':MODEL_REVISION,
             'diffusers_revision':FORK_REVISION, 'download_endpoint':args.endpoint,
             'files':verified}
    (project/'model-verification.json').write_text(json.dumps(proof, indent=2), 'utf-8')
    print('PROVISIONING_COMPLETE (inference not yet verified)', flush=True)


if __name__ == '__main__':
    main()
