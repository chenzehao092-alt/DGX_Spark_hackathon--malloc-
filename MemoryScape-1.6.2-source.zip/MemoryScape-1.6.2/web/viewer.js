/** MemoryScape offline renderer. Real static GLB geometry; no CDN or remote textures.
 * Deliberately not a full PBR, skeletal-animation or measurement engine.
 */
import {identity,multiply,trs,transform,perspective,lookAt,inverse,normalize,sub,rayBox,hexRgb,eulerQuaternion,objectMatrix,sceneFrame} from './math.js';
import {parseGlb} from './glb.js';
import {canonicalViews} from './quality.js';
const VS=`#version 300 es
precision highp float;
in vec3 position;in vec3 normal;in vec2 uv;in vec4 vertexColor;
uniform mat4 world;uniform mat4 viewProjection;
out vec3 N;out vec3 P;out vec2 U;out vec4 V;
void main(){vec4 p=world*vec4(position,1.);P=p.xyz;N=normalize(transpose(inverse(mat3(world)))*normal);U=uv;V=vertexColor;gl_Position=viewProjection*p;}`;
const FS=`#version 300 es
precision highp float;
in vec3 N;in vec3 P;in vec2 U;in vec4 V;
uniform vec4 baseColor;uniform sampler2D colorTexture;uniform bool hasTexture;uniform bool unlit;uniform bool shadow;uniform bool recolor;
out vec4 outColor;
void main(){vec4 c=baseColor*V;if(hasTexture)c*=texture(colorTexture,U);if(c.a<.02)discard;if(recolor)c.rgb=baseColor.rgb;
vec3 n=gl_FrontFacing?normalize(N):-normalize(N);
float key=max(dot(n,normalize(vec3(-.5,.95,.55))),0.);float fill=max(dot(n,normalize(vec3(.7,.3,-.2))),0.);
float hemi=.66+.12*n.y;vec3 light=vec3(hemi)+vec3(1.,.97,.91)*key*.38+vec3(.83,.9,1.)*fill*.10;
vec3 col=unlit?c.rgb:c.rgb*light;
if(!unlit)col=mix(col,vec3(.94,.91,.86),smoothstep(12.,45.,length(P))*.3);
outColor=vec4(col,c.a);}`;
function cubeData(){
 const points=[[-.5,-.5,-.5],[.5,-.5,-.5],[.5,.5,-.5],[-.5,.5,-.5],[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]];
 const faces=[[[4,5,6,7],[0,0,1]],[[1,0,3,2],[0,0,-1]],[[3,7,6,2],[0,1,0]],[[0,1,5,4],[0,-1,0]],[[0,4,7,3],[-1,0,0]],[[5,1,2,6],[1,0,0]]];
 const data=[];for(const [ids,n] of faces)for(const j of [0,1,2,0,2,3])data.push(...points[ids[j]],...n,...[[0,0],[1,0],[1,1],[0,1]][j],1,1,1,1);
 return new Float32Array(data);
}
function planeData(){return new Float32Array([-1,0,-1,0,1,0,0,0,1,1,1,1, 1,0,1,0,1,0,1,1,1,1,1,1, 1,0,-1,0,1,0,1,0,1,1,1,1, -1,0,-1,0,1,0,0,0,1,1,1,1,-1,0,1,0,1,0,0,1,1,1,1,1,1,0,1,0,1,0,1,1,1,1,1,1]);}
function linesData(){const c=[[-.5,-.5,-.5],[.5,-.5,-.5],[.5,.5,-.5],[-.5,.5,-.5],[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]],out=[];for(const [a,b] of [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]])for(const p of [c[a],c[b]])out.push(...p,0,1,0,0,0,1,1,1,1);return new Float32Array(out);}
export class MemoryViewer {
 constructor(container,assetURLOrOptions={},options={}){
  const {assetURL,onSelect=()=>{},onWarning=()=>{},onCamera=()=>{}}=typeof assetURLOrOptions==='function'?{assetURL:assetURLOrOptions,...options,onWarning:options.onWarning||options.onError||(()=>{})}:assetURLOrOptions;this.onCamera=onCamera;
  this.container=container;this.assetURL=assetURL;this.onSelect=onSelect;this.onWarning=onWarning;
  this.canvas=document.createElement('canvas');this.canvas.tabIndex=0;this.canvas.setAttribute('aria-label','交互式三维回忆场景：拖动旋转，滚轮缩放，点击选物。');
  this.labels=document.createElement('div');this.labels.className='scene-labels';container.append(this.canvas,this.labels);
  this.scene={objects:[],audio:[]};this.cache=new Map();this.pending=new Map();this.failed=new Map();this.selected=null;this.mode='memory';this.showLabels=true;
  this.yaw=.32;this.pitch=.48;this.distance=9.6;this.target=[0,.95,-.1];this.dirty=true;
  this.gl=this.canvas.getContext('webgl2',{alpha:false,antialias:true,preserveDrawingBuffer:true});
  if(!this.gl){this.canvas.remove();this.canvas=document.createElement('canvas');container.prepend(this.canvas);this.ctx=this.canvas.getContext('2d');this.fallback=true;onWarning('当前使用 CPU 三维兼容预览，不支持贴图效果；正式演示请启用浏览器 WebGL2。');}
  else this.init();
  this.canvas.dataset.renderer=this.fallback?'cpu-triangles':'webgl2';this.canvas.dataset.loadedAssets='0';
  this.bind();this.observer=new ResizeObserver(()=>this.resize());this.observer.observe(container);
  const loop=()=>{if(this.disposed)return;if(this.dirty){this.draw();this.dirty=false;}this.frame=requestAnimationFrame(loop);};loop();
 }
 init(){
  const gl=this.gl,shader=(type,text)=>{const s=gl.createShader(type);gl.shaderSource(s,text);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};
  const v=shader(gl.VERTEX_SHADER,VS),f=shader(gl.FRAGMENT_SHADER,FS);this.program=gl.createProgram();gl.attachShader(this.program,v);gl.attachShader(this.program,f);gl.linkProgram(this.program);gl.deleteShader(v);gl.deleteShader(f);
  if(!gl.getProgramParameter(this.program,gl.LINK_STATUS))throw Error('WebGL shader link failed');
  this.loc={};for(const n of ['world','viewProjection','baseColor','colorTexture','hasTexture','unlit','recolor'])this.loc[n]=gl.getUniformLocation(this.program,n);
  this.cube=this.mesh(cubeData());this.plane=this.mesh(planeData());this.lines=this.mesh(linesData());
  gl.enable(gl.DEPTH_TEST);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
  this.white=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,this.white);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,255,255,255]));
  const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d'),g=x.createRadialGradient(64,64,3,64,64,64);g.addColorStop(0,'rgba(49,39,30,0.23)');g.addColorStop(.45,'rgba(49,39,30,0.10)');g.addColorStop(1,'rgba(49,39,30,0)');x.fillStyle=g;x.fillRect(0,0,128,128);
  this.shadowTexture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,this.shadowTexture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,c);gl.generateMipmap(gl.TEXTURE_2D);
 }
 mesh(data){
  const gl=this.gl,vao=gl.createVertexArray(),buffer=gl.createBuffer();gl.bindVertexArray(vao);gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);
  for(const [name,size,offset] of [['position',3,0],['normal',3,12],['uv',2,24],['vertexColor',4,32]]){const at=gl.getAttribLocation(this.program,name);if(at>=0){gl.enableVertexAttribArray(at);gl.vertexAttribPointer(at,size,gl.FLOAT,false,48,offset);}}
  return {vao,buffer,count:data.length/12,data};
 }
 bind(){
  let drag=null;
  this.canvas.addEventListener('contextmenu',e=>e.preventDefault());
  this.canvas.addEventListener('pointerdown',e=>{if(this.capturing)return;drag={x:e.clientX,y:e.clientY,moved:0,pan:e.button===2||e.shiftKey};this.canvas.setPointerCapture(e.pointerId);});
  this.canvas.addEventListener('pointermove',e=>{if(this.capturing){drag=null;return;}if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.moved+=Math.abs(dx)+Math.abs(dy);drag.x=e.clientX;drag.y=e.clientY;if(drag.pan){const s=this.distance*.0015;this.target[0]-=dx*s*Math.cos(this.yaw);this.target[2]+=dx*s*Math.sin(this.yaw);this.target[1]+=dy*s;}else{this.yaw-=dx*.006;this.pitch=Math.max(.08,Math.min(1.52,this.pitch+dy*.006));}this.dirty=true;});
  this.canvas.addEventListener('pointerup',e=>{if(!this.capturing&&drag&&drag.moved<5)this.pick(e);drag=null;});this.canvas.addEventListener('pointercancel',()=>drag=null);
  this.canvas.addEventListener('wheel',e=>{e.preventDefault();if(this.capturing)return;this.distance=Math.max(.08,Math.min(200,this.distance*Math.exp(e.deltaY*.0009)));this.dirty=true;},{passive:false});
  this.canvas.addEventListener('keydown',e=>{if(this.capturing)return;if(e.key==='ArrowLeft')this.yaw-=.12;else if(e.key==='ArrowRight')this.yaw+=.12;else if(e.key==='ArrowUp')this.pitch=Math.min(1.52,this.pitch+.1);else if(e.key==='ArrowDown')this.pitch=Math.max(.08,this.pitch-.1);else return;e.preventDefault();this.dirty=true;});
  this.canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.onWarning('浏览器丢失图形上下文，请刷新。项目已保存在本机。');});
 }
 resize(){const dpr=Math.min(window.devicePixelRatio||1,1.75);this.canvas.width=Math.max(1,Math.floor(this.container.clientWidth*dpr));this.canvas.height=Math.max(1,Math.floor(this.container.clientHeight*dpr));this.dirty=true;}
 setScene(scene,{selected=this.selected,mode=this.mode,reset=false}={}){
  this.sceneEpoch=(this.sceneEpoch||0)+1;
  this.failed=new Map([...this.failed].filter(([id])=>scene.objects.some(o=>o.asset_id===id)));this.scene=scene;this.selected=selected;this.mode=mode;this.dirty=true;
  if(reset)this.reset();
  const wanted=new Set(scene.objects.map(o=>o.asset_id).filter(Boolean));
  for(const [id,model] of this.cache)if(!wanted.has(id)){this.releaseModel(model);this.cache.delete(id);}
  this.canvas.dataset.loadedAssets=String(this.cache.size);
  this.labels.replaceChildren();
  for(const o of scene.objects){const b=document.createElement('button');b.className='object-label';b.dataset.id=o.id;b.textContent=o.label;b.title=o.status==='ready'?'点击选择此物品':'此对象尚未生成，当前为占位';b.addEventListener('click',()=>this.select(o.id));this.labels.append(b);if(o.asset_id)this.load(o.asset_id);}
 }
 releaseModel(model){if(this.gl)for(const part of model.parts||[]){if(part.buffer)this.gl.deleteBuffer(part.buffer);if(part.vao)this.gl.deleteVertexArray(part.vao);if(part.texture)this.gl.deleteTexture(part.texture);}}
 select(id){if(this.capturing)return;this.selected=id;this.dirty=true;this.onSelect(id);}
 setMode(mode){if(this.capturing)return;this.mode=mode;this.dirty=true;}
 async load(id){
  if(this.cache.has(id))return this.cache.get(id);if(this.pending.has(id))return this.pending.get(id);if(this.failed.has(id))return null;
  const promise=(async()=>{try{
   const response=await fetch(this.assetURL(id));if(!response.ok)throw Error(`素材 HTTP ${response.status}`);const model=parseGlb(await response.arrayBuffer());
   const parts=[];
   for(const part of model.parts){
    const mesh=this.fallback?{data:part.data,count:part.data.length/12}:this.mesh(part.data);let texture=null;
    if(part.image&&!this.fallback){const bitmap=await createImageBitmap(new Blob([part.image.bytes],{type:part.image.mime}));if(bitmap.width*bitmap.height>32000000){bitmap.close();throw Error('贴图尺寸超限');}const gl=this.gl;texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,bitmap);gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);bitmap.close();}
    parts.push({...part,...mesh,texture});
   }
   if(!this.disposed&&this.scene.objects.some(o=>o.asset_id===id)){this.cache.set(id,{...model,parts});this.canvas.dataset.loadedAssets=String(this.cache.size);this.dirty=true;}else this.releaseModel({parts});return model;
  }catch(e){this.failed.set(id,e.message);this.onWarning(`三维素材加载失败：${e.message}。失败对象保留为可见占位。`);return null;}finally{this.pending.delete(id);}})();
  this.pending.set(id,promise);return promise;
 }
 async ready(){await Promise.allSettled([...this.pending.values()]);this.dirty=true;this.draw();}
 camera(){return {yaw:this.yaw,pitch:this.pitch,distance:this.distance,target:[...this.target],width:this.canvas.width,height:this.canvas.height,renderer:this.canvas.dataset.renderer};}
 setupCamera(){const [x,y,z]=this.target,d=this.distance;this.eye=[x+Math.sin(this.yaw)*Math.cos(this.pitch)*d,y+Math.sin(this.pitch)*d,z+Math.cos(this.yaw)*Math.cos(this.pitch)*d];this.vp=multiply(perspective(.72,this.canvas.width/this.canvas.height,Math.min(.05,d/100),Math.max(180,d*4)),lookAt(this.eye,this.target,this.captureUp||[0,1,0]));if(!this.capturing)this.onCamera({eye:[...this.eye],target:[...this.target]});}
 render(mesh,world,color,texture=null,unlit=false,wire=false,recolor=false){const gl=this.gl;gl.uniform1i(this.loc.recolor,recolor);gl.uniformMatrix4fv(this.loc.world,false,world);gl.uniform4fv(this.loc.baseColor,color);gl.uniform1i(this.loc.unlit,unlit);gl.uniform1i(this.loc.hasTexture,!!texture);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture||this.white);gl.uniform1i(this.loc.colorTexture,0);gl.bindVertexArray(mesh.vao);gl.drawArrays(wire?gl.LINES:gl.TRIANGLES,0,mesh.count);}
 draw(){
  if(!this.canvas.width||!this.canvas.height)return;this.setupCamera();if(this.fallback){this.drawCPU();this.updateLabels();return;}
  const gl=this.gl,bg=hexRgb(this.scene.background||'#eee4d9');gl.viewport(0,0,this.canvas.width,this.canvas.height);gl.clearColor(...bg,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(this.program);gl.uniformMatrix4fv(this.loc.viewProjection,false,this.vp);
  if(!this.inspection){
  this.render(this.plane,trs([0,-.07,0],undefined,[50,1,50]),[...bg,1]);
  this.render(this.cube,trs([0,-.16,0],undefined,[7.6,.17,5.8]),[.82,.75,.66,1]);
  this.render(this.cube,trs([0,-.055,0],undefined,[7.7,.05,5.9]),[.94,.88,.79,1]);
  gl.depthMask(false);
  for(const o of this.scene.objects){const p=o.transform.position,s=o.transform.size;
    this.render(this.plane,trs([p[0],.001,p[2]],undefined,[Math.max(.3,s[0]*.8),1,Math.max(.3,s[2]*.8)]),[1,1,1,1],this.shadowTexture,true);}
  gl.depthMask(true);
  }
  for(const o of this.scene.objects){
   const model=o.asset_id?this.cache.get(o.asset_id):null,t=o.transform;
   if(model&&this.mode!=='layout'){
    const matrix=objectMatrix(o,model.bounds),tint=o.tint?hexRgb(o.tint):[1,1,1];
    for(const part of model.parts){let col=o.tint?[...tint,part.color[3]]:part.color;if(this.mode==='origin'&&o.provenance==='generated')col=[.72,.77,.74,.8];this.render(part,matrix,col,part.texture,part.unlit,false,!!o.tint&&this.mode!=='origin');}
   }else{
    const pos=[t.position[0],t.position[1]+t.size[1]/2,t.position[2]],matrix=trs(pos,eulerQuaternion(t.rotation),t.size);
    const c=o.status==='failed'?[.72,.37,.33]:hexRgb(o.color);this.render(this.cube,matrix,[...c,.52]);this.render(this.lines,matrix,[.40,.39,.36,.8],null,true,true);
   }
   if(o.id===this.selected){const pos=[t.position[0],t.position[1]+t.size[1]/2,t.position[2]];this.render(this.lines,trs(pos,eulerQuaternion(t.rotation),t.size.map(v=>v+0.04)),[.52,.39,.21,1],null,true,true);}
  }
  this.updateLabels();
 }
 updateLabels(){
  const rect=this.canvas.getBoundingClientRect();
  for(const label of this.labels.children){const o=this.scene.objects.find(x=>x.id===label.dataset.id);if(!o)continue;const p=transform(this.vp,[o.transform.position[0],o.transform.position[1]+o.transform.size[1]+.10,o.transform.position[2]]);
   const x=(p[0]/p[3]*.5+.5)*rect.width,y=(.5-p[1]/p[3]*.5)*rect.height;label.style.transform=`translate(${x}px,${y}px) translate(-50%,-100%)`;label.hidden=!this.showLabels||p[3]<=0||x<0||y<0||x>rect.width||y>rect.height;label.classList.toggle('selected',o.id===this.selected);}
 }
 drawCPU(){
  const ctx=this.ctx,w=this.canvas.width,h=this.canvas.height;ctx.fillStyle=this.scene.background||'#eee4d9';ctx.fillRect(0,0,w,h);const triangles=[];
  const project=(m,p)=>{const r=transform(m,p);return [(.5+r[0]/r[3]*.5)*w,(.5-r[1]/r[3]*.5)*h,r[2]/r[3],r[3]];};
  for(const o of this.scene.objects){const model=this.cache.get(o.asset_id),bounds=model?.bounds||{min:[-.5,-.5,-.5],max:[.5,.5,.5]},world=objectMatrix(o,bounds),vp=multiply(this.vp,world),parts=model?.parts||[{data:cubeData(),color:[...hexRgb(o.color),1]}];
   for(const part of parts){const d=part.data,step=Math.max(1,Math.ceil(d.length/36/15000));for(let i=0;i<d.length;i+=36*step){const p=[0,1,2].map(k=>project(vp,d.slice(i+k*12,i+k*12+3)));if(p.some(a=>a[3]<.1))continue;const shade=.68+.3*Math.max(0,(d[i+4]+d[i+5])*.7);const tint=o.tint?hexRgb(o.tint):[1,1,1];const c=part.color.slice(0,3).map((v,k)=>Math.min(255,Math.round((o.tint?tint[k]:v*d[i+8+k])*shade*255)));triangles.push({p,z:p.reduce((s,a)=>s+a[2],0)/3,c});}}
  }
  triangles.sort((a,b)=>b.z-a.z);for(const t of triangles){ctx.beginPath();ctx.moveTo(t.p[0][0],t.p[0][1]);ctx.lineTo(t.p[1][0],t.p[1][1]);ctx.lineTo(t.p[2][0],t.p[2][1]);ctx.closePath();ctx.fillStyle=`rgb(${t.c.join(',')})`;ctx.fill();}
 }
 pick(e){
  this.setupCamera();const r=this.canvas.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*2-1,y=1-(e.clientY-r.top)/r.height*2,iv=inverse(this.vp);
  const a=transform(iv,[x,y,-1]),b=transform(iv,[x,y,1]),origin=a.slice(0,3).map(v=>v/a[3]),far=b.slice(0,3).map(v=>v/b[3]);let nearest=Infinity,best=null;
  for(const o of this.scene.objects){const model=this.cache.get(o.asset_id),bounds=model?.bounds||{min:[-.5,-.5,-.5],max:[.5,.5,.5]},world=objectMatrix(o,bounds),iw=inverse(world),o1=transform(iw,origin).slice(0,3),o2=transform(iw,far).slice(0,3),direction=sub(o2,o1),distance=rayBox(o1,direction,bounds.min,bounds.max);if(distance!==null&&distance<nearest){best=o.id;nearest=distance;}}
  if(best)this.select(best);
 }
 reset(){
  if(this.capturing)return;
  const pos=this.scene.camera_position||[7,5.5,8],target=this.scene.camera_target||[0,1,0],d=sub(pos,target),length=Math.max(.001,Math.hypot(...d));
  const fit=sceneFrame(this.scene,this.container.clientWidth/Math.max(1,this.container.clientHeight));
  this.target=fit.target;this.distance=fit.distance;this.yaw=Math.atan2(d[0],d[2]);this.pitch=Math.max(.08,Math.min(1.52,Math.asin(d[1]/length)));this.dirty=true;
 }
 focus(id){if(this.capturing)return;const o=this.scene.objects.find(x=>x.id===id);if(!o)return;const fit=sceneFrame({objects:[o]},this.container.clientWidth/Math.max(1,this.container.clientHeight));this.target=fit.target;this.distance=fit.distance;this.dirty=true;}
 async captureViews({objectId=null}={}){
  if(this.capturing)throw Error('多视角截图正在进行。');
  if(this.fallback)throw Error('多视角贴图验收需要 WebGL2，兼容预览不能冒充。');
  const scale=Math.min(1,768/Math.max(this.canvas.width,this.canvas.height));
  if(Math.min(this.canvas.width,this.canvas.height)*scale<128)throw Error('画面过小，请展开窗口再检查。');
  await this.ready();const saved={camera:this.camera(),scene:this.scene,selected:this.selected,mode:this.mode,epoch:this.sceneEpoch},out=[];
  if(this.capturing)throw Error('多视角截图正在进行。');
  const objects=objectId?this.scene.objects.filter(o=>o.id===objectId):this.scene.objects;
  if(!objects.length||objects.some(o=>!o.asset_id||!this.cache.has(o.asset_id)))throw Error('存在未加载的真实网格；未用占位物检查质量。');
  this.capturing=true;this.inspection=true;this.selected=null;this.mode='memory';
  try{
   this.scene={...saved.scene,objects};const frame=sceneFrame(this.scene,this.canvas.width/this.canvas.height);this.target=frame.target;this.distance=frame.distance;
   for(const {name,yaw,pitch,up} of canonicalViews.slice(0,objectId?6:8)){
    if(this.sceneEpoch!==saved.epoch)throw Error('截图期间场景发生变化。');
    this.yaw=yaw;this.pitch=pitch;this.captureUp=up;this.draw();const c=document.createElement('canvas');c.width=Math.round(this.canvas.width*scale);c.height=Math.round(this.canvas.height*scale);c.getContext('2d').drawImage(this.canvas,0,0,c.width,c.height);
    const blob=await new Promise(resolve=>c.toBlob(resolve,'image/png'));if(!blob)throw Error('多视角截图编码失败。');
    out.push({name,blob,camera:{...this.camera(),width:c.width,height:c.height,name,schema:'view-bundle-v1',object_id:objectId,hide_environment:true,failed_assets:[],asset_ids:objects.map(o=>o.asset_id)}});
   }
   return out;
  }finally{
   this.capturing=false;this.inspection=false;this.captureUp=undefined;
   if(this.sceneEpoch===saved.epoch){this.scene=saved.scene;this.selected=saved.selected;this.mode=saved.mode;Object.assign(this,{yaw:saved.camera.yaw,pitch:saved.camera.pitch,distance:saved.camera.distance,target:saved.camera.target});}
   this.dirty=true;this.draw();
  }
 }
 screenshot(){this.draw();return new Promise(resolve=>this.canvas.toBlob(resolve,'image/png'));}
 dispose(){this.disposed=true;cancelAnimationFrame(this.frame);this.observer.disconnect();if(this.gl){for(const model of this.cache.values())for(const p of model.parts){this.gl.deleteBuffer(p.buffer);this.gl.deleteVertexArray(p.vao);if(p.texture)this.gl.deleteTexture(p.texture);}this.gl.getExtension('WEBGL_lose_context')?.loseContext();}this.container.replaceChildren();}
}
