/** Self-contained static GLB loader, derived from the supplied MIT application.
 * Supports embedded base-color textures, vertex colors, indexed/interleaved geometry,
 * smooth normals, material factors and glTF node transforms. No network lookups.
 * Skinning/animation/mesh compression/sparse accessors are explicitly rejected.
 */
import {identity,multiply,trs,transform,cross,sub,normalize,inverse} from './math.js';
export function parseGlb(buffer) {
  const view=new DataView(buffer);
  if(buffer.byteLength<20||view.getUint32(0,true)!==0x46546c67||view.getUint32(4,true)!==2||view.getUint32(8,true)!==buffer.byteLength)throw Error('GLB 文件头或长度错误');
  let offset=12,doc,bin;
  while(offset<buffer.byteLength){
    if(offset+8>buffer.byteLength)throw Error('块头越界');
    const size=view.getUint32(offset,true),type=view.getUint32(offset+4,true);offset+=8;
    if(size%4||offset+size>buffer.byteLength)throw Error('块边界错误');
    if(type===0x4e4f534a){if(doc)throw Error('重复 JSON 块');doc=JSON.parse(new TextDecoder().decode(buffer.slice(offset,offset+size)));}
    if(type===0x004e4942){if(bin)throw Error('重复 BIN 块');bin=buffer.slice(offset,offset+size);}
    offset+=size;
  }
  if(!doc||!bin||!doc.meshes?.length)throw Error('没有内嵌静态网格');
  if((doc.extensionsUsed||[]).some(e=>['KHR_draco_mesh_compression','EXT_meshopt_compression','KHR_texture_basisu'].includes(e)))throw Error('不支持压缩网格或 KTX2 贴图');
  if(doc.skins?.length||doc.animations?.length)throw Error('请导出静态无骨骼 GLB');
  if((doc.extensionsRequired||[]).some(e=>e!=='KHR_materials_unlit'))throw Error('不支持该必需扩展/压缩格式');
  if([...(doc.buffers||[]),...(doc.images||[])].some(a=>a.uri!==undefined))throw Error('禁止外部 GLB 资源');
  const arities={SCALAR:1,VEC2:2,VEC3:3,VEC4:4},sizes={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4};
  const getters={5120:'getInt8',5121:'getUint8',5122:'getInt16',5123:'getUint16',5125:'getUint32',5126:'getFloat32'};
  const bv=new DataView(bin),accessors=new Map();
  function accessor(index){
    if(accessors.has(index))return accessors.get(index);
    const a=doc.accessors?.[index];if(!a||a.sparse)throw Error('缺失或 sparse accessor');
    const v=doc.bufferViews?.[a.bufferView],arity=arities[a.type],size=sizes[a.componentType];
    if(!v||v.buffer!==0||!arity||!size||!Number.isInteger(a.count)||a.count<0||a.count>6000000)throw Error('accessor 无效');
    const stride=v.byteStride||arity*size,base=v.byteOffset||0,start=a.byteOffset||0,offset=base+start;
    const needed=a.count?((a.count-1)*stride+arity*size):0;
    if(stride<arity*size||offset<0||base+v.byteLength>bin.byteLength||start+needed>v.byteLength)throw Error('accessor 超过 bufferView');
    const out=new Float32Array(a.count*arity);
    for(let i=0;i<a.count;i++)for(let k=0;k<arity;k++){
      let x=bv[getters[a.componentType]](offset+i*stride+k*size,true);
      if(a.normalized&&a.componentType!==5126)x=Math.max(-1,x/({5120:127,5121:255,5122:32767,5123:65535,5125:4294967295}[a.componentType]));
      if(!Number.isFinite(x))throw Error('非有限数据');out[i*arity+k]=x;
    }
    const result={values:out,arity,count:a.count};accessors.set(index,result);return result;
  }
  const parts=[],seen=new Set();let triangles=0;
  function node(index,parent,depth=0){
    if(depth>80||seen.has(index))throw Error('节点循环或多父节点');
    const n=doc.nodes?.[index];if(!n)throw Error('节点索引不存在');seen.add(index);
    const matrix=multiply(parent,n.matrix||trs(n.translation,n.rotation,n.scale));
    if(matrix.some(v=>!Number.isFinite(v)))throw Error('节点矩阵非法');
    if(n.mesh!==undefined){
      const mesh=doc.meshes[n.mesh];if(!mesh)throw Error('网格不存在');
      for(const p of mesh.primitives){
        if((p.mode??4)!==4||p.targets||p.extensions)throw Error('仅支持未压缩三角网格');
        const pos=accessor(p.attributes.POSITION);if(pos.arity!==3)throw Error('POSITION 必须 VEC3');
        const normal=p.attributes.NORMAL!==undefined?accessor(p.attributes.NORMAL):null;
        const uv=p.attributes.TEXCOORD_0!==undefined?accessor(p.attributes.TEXCOORD_0):null;
        const colors=p.attributes.COLOR_0!==undefined?accessor(p.attributes.COLOR_0):null;
        const idx=p.indices!==undefined?accessor(p.indices).values:Array.from({length:pos.count},(_,i)=>i);
        if(idx.length%3)throw Error('三角面索引无效');triangles+=idx.length/3;if(triangles>600000)throw Error('单资产超过 60 万面，请减面');
        const data=new Float32Array(idx.length*12),ni=inverse(matrix);
        for(let i=0;i<idx.length;i+=3){
          const pts=[];
          for(let k=0;k<3;k++){
            const j=idx[i+k];if(!Number.isInteger(j)||j<0||j>=pos.count)throw Error('顶点索引越界');
            pts.push(transform(matrix,pos.values.slice(j*3,j*3+3)).slice(0,3));
          }
          const face=normalize(cross(sub(pts[1],pts[0]),sub(pts[2],pts[0])));
          for(let k=0;k<3;k++){
            const j=idx[i+k];let nn=face;
            if(normal){if(normal.arity!==3||normal.count!==pos.count)throw Error('法线数量错误');const a=normal.values.slice(j*3,j*3+3);nn=normalize([0,1,2].map(r=>ni[r*4]*a[0]+ni[r*4+1]*a[1]+ni[r*4+2]*a[2]));}
            const tuv=uv?uv.values.slice(j*2,j*2+2):[0,0];if(tuv.length!==2)throw Error('UV 数量错误');
            let c=[1,1,1,1];if(colors){if(![3,4].includes(colors.arity)||colors.count!==pos.count)throw Error('颜色数量错误');c=Array.from(colors.values.slice(j*colors.arity,(j+1)*colors.arity));if(c.length===3)c.push(1);}
            data.set([...pts[k],...nn,...tuv,...c],(i+k)*12);
          }
        }
        const material=doc.materials?.[p.material]||{},pbr=material.pbrMetallicRoughness||{};let image=null;
        if(pbr.baseColorTexture){
          if((pbr.baseColorTexture.texCoord||0)!==0)throw Error('仅支持基础色 UV0');
          const tex=doc.textures?.[pbr.baseColorTexture.index],im=doc.images?.[tex?.source],v=doc.bufferViews?.[im?.bufferView];
          if(!v||v.buffer!==0||(v.byteOffset||0)+v.byteLength>bin.byteLength||!['image/png','image/jpeg','image/webp'].includes(im?.mimeType))throw Error('内嵌纹理无效');
          image={bytes:bin.slice(v.byteOffset||0,(v.byteOffset||0)+v.byteLength),mime:im.mimeType};
        }
        parts.push({data,color:pbr.baseColorFactor||[1,1,1,1],image,unlit:!!material.extensions?.KHR_materials_unlit,alphaMode:material.alphaMode||'OPAQUE'});
      }
    }
    for(const child of n.children||[])node(child,matrix,depth+1);
  }
  const scene=doc.scenes?.[doc.scene??0];if(!scene)throw Error('缺少场景根节点');
  for(const root of scene.nodes||[])node(root,identity());
  if(!parts.length)throw Error('场景为空');
  const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
  for(const p of parts)for(let i=0;i<p.data.length;i+=12)for(let k=0;k<3;k++){min[k]=Math.min(min[k],p.data[i+k]);max[k]=Math.max(max[k],p.data[i+k]);}
  if(max.every((v,i)=>v-min[i]<1e-7))throw Error('网格尺寸为零');
  return {parts,triangles,bounds:{min,max}};
}
