import {MemoryViewer} from './viewer.js';
import {MemoryAudio} from './audio.js';
const $=id=>document.getElementById(id),clock=s=>`${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,'0')}`;
try{
 const response=await fetch('../project.json');if(!response.ok)throw Error('找不到项目数据。请解压完整项目包并运行 START_VIEWER.py。');const doc=await response.json();
 const assets=Object.fromEntries(doc.assets.map(a=>[a.id,a]));const assetURL=id=>{const a=assets[id];if(!a)throw Error('素材缺失：'+id);return '../'+a.path;};
 const scene=doc.scene;
 $('title').textContent=doc.title;$('diary').textContent=doc.diary||scene.story;$('caption').textContent=scene.story;
 const audio=new MemoryAudio(assetURL,({time,duration,playing})=>{$('seek').max=Math.max(1,duration);$('seek').value=time;$('time').textContent=clock(time)+' / '+clock(duration);$('play').textContent=playing?'Ⅱ 暂停':'▶ 播放声音';});
 const viewer=new MemoryViewer($('viewport'),assetURL,{onSelect:id=>{const o=scene.objects.find(x=>x.id===id);$('objectTitle').textContent=o.label;$('caption').textContent=(o.caption||o.description)+'\n\n来源类型：'+o.provenance+(o.uncertainty.length?'\n'+o.uncertainty:'');$('references').replaceChildren();for(const ref of new Set([o.reference_asset_id,...o.reference_ids].filter(Boolean))){if(assets[ref]?.kind==='image'){const img=document.createElement('img');img.src=assetURL(ref);img.alt='保存的参考图片';$('references').append(img);}}},onCamera:c=>audio.listener(c),onError:text=>$('mode').textContent=text});
 viewer.setScene(scene,{reset:true});audio.setScene(scene);$('labels').onclick=()=>{viewer.showLabels=!viewer.showLabels;viewer.dirty=true;};$('reset').onclick=()=>viewer.reset();
 $('shot').onclick=async()=>{const blob=await viewer.screenshot(),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='MemoryScape.png';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000);};
 $('play').onclick=async()=>{try{if(audio.playing)audio.stop(false);else await audio.play();}catch(e){$('mode').textContent=e.message;}};$('seek').onchange=()=>audio.seek(Number($('seek').value));
 $('mode').textContent=viewer.fallback?'离线 · CPU 纹理近似预览':'离线 · WebGL2';
}catch(e){$('notice').textContent=e.message;}
