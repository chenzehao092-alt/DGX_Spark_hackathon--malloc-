// Model configuration panel (configuration layer only).
// Tokens are entered as password fields, never echoed back into the page,
// never stored in localStorage, and never returned by the backend.
export const STATUS_TEXT = {
  connected: ['✅', 'Connected', '已连接'],
  not_configured: ['⚪', 'Not configured', '未配置'],
  unreachable: ['❌', 'Unreachable', '无法访问'],
  unauthorized: ['❌', 'Unauthorized', '未授权'],
  invalid_response: ['⚠️', 'Invalid response', '响应异常'],
  configured_remote: ['🔗', 'Configured (remote)', '已配置（远端，未探测）'],
  failed: ['❌', 'Failed', '检查失败'],
  unavailable: ['⚠️', 'Unavailable', '云端推理暂不可用'],
};

export function statusMeta(status) {
  return STATUS_TEXT[status] || ['❔', status, status];
}

const TOKEN_FIELDS = [
  ['director', 'Director（旗舰多模态导演）', 'Base URL', 'Model', 'API Key'],
  ['geometry', 'Geometry（Step1X-3D 节点）', 'Node URL', '', 'Token'],
  ['image', 'Image（Step1X-Edit 节点）', 'Node URL', '', 'Token'],
  ['audio', 'Audio（Step-Audio2 节点）', 'Node URL', '', 'Token'],
];

function fieldGroupHtml(helpers, kind, title, urlLabel, modelLabel, tokenLabel) {
  const esc = helpers.esc;
  return `<fieldset><legend>${esc(title)}</legend>
  <label>${esc(urlLabel)}<input id="ms_${kind}_url" type="text" autocomplete="off" spellcheck="false" placeholder="http://127.0.0.1:9102"></label>
  ${modelLabel ? `<label>${esc(modelLabel)}<input id="ms_${kind}_model" type="text" autocomplete="off" spellcheck="false" placeholder="模型名称"></label>` : ''}
  <label>${esc(tokenLabel)}<input id="ms_${kind}_token" type="password" autocomplete="new-password" placeholder="不显示已保存的密钥"></label>
  <p class="small muted" id="ms_${kind}_tokenstate"></p></fieldset>`;
}

function preflightRowsHtml(helpers, checks) {
  const rows = Object.entries(checks || {}).map(([kind, c]) => {
    const [icon, en, zh] = statusMeta(c.status);
    const cls = c.status === 'connected' ? 'status-ok' : c.status === 'not_configured' ? 'status-muted' : 'status-bad';
    return `<div class="settings-status-row ${cls}"><span>${icon}</span><b>${helpers.esc(kind)}</b><span>${helpers.esc(zh)}</span><span class="small muted">${helpers.esc(c.status==='unavailable'?c.detail:c.status)}</span></div>`;
  });
  return rows.join('');
}

export function mountSettings(helpers) {
  const { api, dialog, closeDialog, btn, toast, friendlyError } = helpers;
  return async function settingsDialog() {
    let view;
    try {
      view = await api('/api/settings/models');
    } catch (e) {
      toast(friendlyError ? friendlyError(e) : e.message, true);
      return;
    }
    const html = `<form id="sf_form"><fieldset><legend>StepFun API Key</legend>
      <p>填入阶跃星辰 API Key，连接照片理解、场景规划和云端图片编辑。</p>
      <p>${view.geometry?.enabled && view.geometry?.token_configured ? '3D 服务已配置，可用“测试连接”确认节点状态。' : '3D 服务尚未配置。需先接通 DGX Spark / server6 节点，再使用照片生成立体模型。文字规划和已有回忆的本地编辑仍可使用。'}</p>
      <label>StepFun API Key<input id="sf_key" type="password" autocomplete="new-password" placeholder="${view.director?.token_configured ? '已配置；留空保留已有密钥' : '粘贴你的 API Key（不会回显）'}" ${view.director?.token_configured ? '' : 'required'}></label>
      <label>图片接口计费方式<select id="sf_image_mode" ${view.image?.enabled && view.image?.api_mode == null ? 'disabled' : ''}>
        <option value="standard" ${view.image?.api_mode !== 'step_plan' ? 'selected' : ''}>普通 API（按量余额）</option>
        <option value="step_plan" ${view.image?.api_mode === 'step_plan' ? 'selected' : ''}>Step Plan（开放平台订阅额度）</option>
      </select></label>
      <label>图片 API 区域<select id="sf_image_region" ${view.image?.enabled && view.image?.api_mode == null ? 'disabled' : ''}>
        <option value="cn">中国区（api.stepfun.com）</option>
        <option value="international">国际区（api.stepfun.ai）</option>
      </select></label>
      <p class="small muted">Step Plan 需具备开放平台订阅权限，不等同于聊天 App 的会员。此选项只调整云端图片入口，不切换照片理解模型，也不自动回退到按量计费。已连接的本地图片节点保持不变。</p>
      <p id="sf_state" class="small muted">${view.director?.token_configured ? '密钥：已配置' : '密钥：未配置'}</p>
      <button id="sf_save" type="submit" class="primary full">保存并连接 StepFun</button>
      <p class="small muted">密钥只存本机 data/local-secrets.env；调用云端时才发送给 StepFun。连通检查不等于推理成功，过载会如实报错，不用假结果替代。</p>
      <p id="sf_feedback" role="status" aria-live="polite"></p><div id="sf_checks"></div>
      </fieldset></form><details><summary>高级节点配置（通常无需修改）</summary><form id="ms_form" novalidate>
      ${TOKEN_FIELDS.map(([kind, title, urlLabel, modelLabel, tokenLabel]) => fieldGroupHtml(helpers, kind, title, urlLabel, modelLabel, tokenLabel)).join('')}
      <p class="small muted">密钥只保存在本机（data/local-secrets.env），不会显示、不会进入浏览器存储，也不会提交到代码仓库。留空表示不修改已有密钥。</p>
      <div class="modal-actions"><button type="button" id="ms_test" class="secondary">测试连接</button><button type="submit" id="ms_save" class="primary">保存配置</button></div>
      <div id="ms_status"></div>
    </form></details>`;
    dialog('模型配置', html, (root) => {
      root.querySelector('#sf_image_mode').value = view.image?.api_mode || 'standard';
      root.querySelector('#sf_image_region').value = view.image?.api_region || 'cn';
      root.querySelector('#sf_form').addEventListener('submit', async e => {
        e.preventDefault(); const input = root.querySelector('#sf_key');
        const key = input.value.trim(); input.value = ''; // never leave plaintext in the DOM
        const button = root.querySelector('#sf_save'); button.disabled = true;
        const feedback = root.querySelector('#sf_feedback');
        const checks = root.querySelector('#sf_checks');
        let saved = false;
        feedback.className = 'small muted';
        feedback.textContent = '正在保存并检查 StepFun 连接…';
        checks.innerHTML = '';
        try {
          const mode = root.querySelector('#sf_image_mode');
          const region = root.querySelector('#sf_image_region');
          const result = await api('/api/settings/stepfun', {method:'POST', body:{api_key:key, ...(mode.disabled ? {} : {image_api_mode:mode.value,image_api_region:region.value})}});
          saved = true;
          root.querySelector('#sf_state').textContent = result.director.token_configured ? '密钥：已配置' : '密钥：未配置';
          const check = await api('/api/settings/preflight', {method:'POST',body:{}});
          checks.innerHTML = preflightRowsHtml(helpers, check.checks);
          if (check.checks?.director?.status === 'connected' && (!result.image?.enabled || check.checks?.image?.status === 'connected')) {
            closeDialog();
            toast('StepFun 接口检查通过；实际生成结果以任务记录为准。');
          } else {
            feedback.className = 'error-text';
            feedback.textContent = `配置已保存，但连接未通过（director: ${check.checks?.director?.status || 'invalid_response'}，image: ${check.checks?.image?.status || 'not_configured'}）。请查看下方检查结果后重试。`;
          }
        } catch(err) {
          feedback.className = 'error-text';
          feedback.textContent = `${saved ? '配置已保存，但连接检查未通过' : '配置保存失败'}：${friendlyError ? friendlyError(err) : err.message}`;
        }
        finally {button.disabled = false;}
        // Refresh generation controls even when the saved configuration fails preflight.
        // A refresh error must not be mistaken for a failed save or connection probe.
        if (saved) {
          try { await helpers.onSaved?.(); }
          catch { toast('配置已保存，但主界面状态刷新失败，请刷新页面。', true); }
        }
      });
      for (const [kind, , , , ] of TOKEN_FIELDS) {
        const conf = (view && view[kind]) || {};
        const urlInput = root.querySelector(`#ms_${kind}_url`);
        const modelInput = root.querySelector(`#ms_${kind}_model`);
        const stateEl = root.querySelector(`#ms_${kind}_tokenstate`);
        if (urlInput) urlInput.value = conf.base_url || '';
        if (modelInput) modelInput.value = conf.model || '';
        if (stateEl) stateEl.textContent = conf.token_configured ? '密钥：已配置' : '密钥：未配置';
      }
      const testBtn = root.querySelector('#ms_test');
      const statusBox = root.querySelector('#ms_status');
      testBtn.addEventListener('click', async () => {
        testBtn.disabled = true;
        statusBox.innerHTML = '<p class="small muted">正在检查模型节点连通性…</p>';
        try {
          const result = await api('/api/settings/preflight', { method: 'POST', body: {} });
          statusBox.innerHTML = preflightRowsHtml(helpers, result.checks);
        } catch (e) {
          statusBox.innerHTML = `<p class="error-text">${helpers.esc(friendlyError ? friendlyError(e) : e.message)}</p>`;
        } finally {
          testBtn.disabled = false;
        }
      });
      root.querySelector('#ms_form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const body = {};
        for (const [kind, , , , ] of TOKEN_FIELDS) {
          const url = root.querySelector(`#ms_${kind}_url`).value.trim();
          const model = root.querySelector(`#ms_${kind}_model`)?.value.trim() || '';
          const token = root.querySelector(`#ms_${kind}_token`).value;
          if (kind === 'director') {
            body.director_base_url = url;
            body.director_model = model;
            body.director_token = token;
          } else {
            body[`${kind}_url`] = url;
            body[`${kind}_token`] = token;
          }
          root.querySelector(`#ms_${kind}_token`).value = ''; // never leave plaintext in the DOM
        }
        const saveBtn = root.querySelector('#ms_save');
        saveBtn.disabled = true;
        try {
          const result = await api('/api/settings/models', { method: 'POST', body });
          for (const [kind, , , , ] of TOKEN_FIELDS) {
            const stateEl = root.querySelector(`#ms_${kind}_tokenstate`);
            if (stateEl) stateEl.textContent = result[kind]?.token_configured ? '密钥：已配置' : '密钥：未配置';
          }
          toast('配置已保存到本机。');
        } catch (err) {
          toast(friendlyError ? friendlyError(err) : err.message, true);
        } finally {
          saveBtn.disabled = false;
        }
      });
      const cancelBtn = root.querySelector('#dialogNo');
      if (cancelBtn) cancelBtn.addEventListener('click', closeDialog);
    });
  };
}
