import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

test('UI export uses authenticated native HTTP download instead of an unsupported blob URL',()=>{
  const app=readFileSync(new URL('../app.js',import.meta.url),'utf8');
  const save=app.slice(app.indexOf('async function saveMemory()'),app.indexOf('function qualityEvidenceDialog()'));
  assert.ok(save.includes('/renders'));
  assert.ok(save.includes('a.href=`${base()}/export?version='));
  assert.ok(save.includes('a.download='));
  assert.ok(!save.includes('response.blob()'));
  assert.ok(!save.includes('createObjectURL'));
  assert.ok(!save.includes('token='));
});
