import test from 'node:test';
import assert from 'node:assert/strict';
import {sceneFrame} from '../math.js';

test('photo poster marked as background is included in framing',()=>{
  const frame=sceneFrame({objects:[
    {kind:'background',generation:{strategy:'photo'},transform:{position:[0,.1,0],rotation:[0,0,0],size:[1.5,2.25,.01]}},
    {kind:'prop',transform:{position:[0,0,0],rotation:[0,0,0],size:[.1,.1,.1]}},
    {kind:'background',generation:{strategy:'procedural'},transform:{position:[0,0,0],rotation:[0,0,0],size:[100,1,100]}}
  ]},.8);
  assert.ok(frame.target[1]>1);
  assert.ok(frame.distance>4 && frame.distance<20);
});
const object=(position,size)=>({kind:'prop',transform:{position,size,rotation:[0,0,0]}});
test('tiny real camera fills view instead of using a 10 metre camera distance',()=>{
  const fit=sceneFrame({objects:[object([0,.01,0],[.15,.1,.08])]},.85);
  assert.ok(fit.distance<.5 && fit.distance>.15);
  assert.ok(Math.abs(fit.target[1]-.06)<1e-8);
});
test('portrait viewport increases framing distance; large scenes still fit',()=>{
  const scene={objects:[object([-3,0,0],[2,2,2]),object([3,0,0],[2,2,2])]};
  assert.ok(sceneFrame(scene,.5).distance>sceneFrame(scene,2).distance);
});
