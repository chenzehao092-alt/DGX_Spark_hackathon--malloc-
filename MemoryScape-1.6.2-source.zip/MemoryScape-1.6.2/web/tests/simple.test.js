import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {inferRole,currentPlan,readyVersions,undoTarget,patchLines,friendlyError,jobFailureDetail,progressText,versionNote,retryBlockReason,acceptedPatchMessage,patchIsCurrent,connectionText} from '../simple.js';

test('local connection is not mistaken for cloud or 3D readiness',()=>{
  const state={monitor_running:true,models:[{model:'director',state:'connected'},{model:'geometry',state:'reconnecting'}]};
  assert.match(connectionText(state),/3D 正在自动重连/);
  state.models[1].state='connected';assert.match(connectionText(state),/StepFun \/ 3D 已连接/);
  state.models[0].state='offline';assert.match(connectionText(state),/StepFun 尚未接通/);
  state.monitor_running=false;assert.match(connectionText(state),/检查未运行/);
});

test('image connection failures are not concealed by a healthy 3D node',()=>{
  const state={monitor_running:true,models:[{model:'director',state:'connected'},
    {model:'geometry',state:'connected'},{model:'image',state:'offline'}]};
  assert.match(connectionText(state),/图片服务尚未接通/);
  state.models[2].state='reconnecting';assert.match(connectionText(state),/图片服务正在自动重连/);
  state.models[2].state='connected';assert.match(connectionText(state),/图片 \/ 3D 已连接/);
});

test('audio model absence suggests background playback instead of generic configuration blame',()=>{
  assert.match(friendlyError('没有已配置的 audio.describe 模型'),/背景音/);
  assert.match(friendlyError({code:'audio_model_unavailable',message:'missing'}),/仅作背景声音/);
  const app=fs.readFileSync(new URL('../app.js',import.meta.url),'utf8');
  assert.match(app,/sourceAudioMode/);assert.match(app,/api\('\/api\/connectivity'\)/);
});

test('missing FFmpeg is not falsely reported as a large file or cloud outage',()=>{
  for(const text of ['该音频需要 FFmpeg。安装后重试','需要 ffmpeg','需要 FFMPEG']) {
    const message=friendlyError(text);
    assert.match(message,/本机音频解码工具/);
    assert.match(message,/不是文件过大/);
    assert.doesNotMatch(message,/创作服务|录音暂时无法/);
  }
  assert.match(friendlyError({message:'dependency missing',code:'audio_decoder_unavailable'}),/一键启动/);
  const failure=friendlyError('音频解码失败/超时，或超过 30 分钟。');
  assert.match(failure,/音频解码失败/);
  assert.doesNotMatch(failure,/与创作服务/);
});

test('null job error still exposes the real image step 503',()=>{
  const detail=jobFailureDetail({status:'failed',error:null,steps:[{status:'failed',error:'StepFun 图片编辑返回 HTTP 503'}],result:{failures:{'asset:pet':'依赖失败'}}});
  assert.match(detail,/HTTP 503/);assert.doesNotMatch(detail,/没有接通/);
});

test('held repair reference is not falsely explained as changed inputs or disconnected services',()=>{
  const detail=jobFailureDetail({status:'needs_review',result:{auto_repair:{status:'held'},
    asset_quality:{objects:{table:{candidates:[{stage:'reference',accepted:false}]}}}}});
  assert.match(detail,/建模参考图未通过验收/);
  assert.doesNotMatch(detail,/素材发生变化|连接|重试/);
});

test('held geometry quality is reported without claiming concurrent edits',()=>{
  const detail=jobFailureDetail({status:'needs_review',result:{asset_quality:{objects:{
    table:{candidates:[{stage:'reference',accepted:false},{stage:'geometry',accepted:false}]}}}}});
  assert.match(detail,/没有通过验收/);assert.doesNotMatch(detail,/素材发生变化|建模参考图未通过/);
});

test('an actual repair version conflict is not concealed as visual rejection',()=>{
  const detail=jobFailureDetail({status:'needs_review',result:{auto_repair:{status:'held',code:'version_conflict'},
    asset_quality:{objects:{}}}});
  assert.match(detail,/素材发生变化/);assert.doesNotMatch(detail,/没有通过验收/);
});

test('spatial review is not falsely explained as concurrent user changes',()=>{
  const text=jobFailureDetail({status:'needs_review',result:{checks:[{type:'support_mismatch'}]}});
  assert.match(text,/摆放检查未通过/);assert.doesNotMatch(text,/发生变化/);
});

test('untrusted failure labels are escaped at the chat rendering boundary',()=>{
  const src=fs.readFileSync(new URL('../app.js',import.meta.url),'utf8');
  assert.match(src,/failDetail=esc\(jobFailureDetail\(j\)\)/);
  assert.doesNotMatch(src,/failedObjects\.map\(o=>o.label\)/);
});

test('503 configuration remains known; rate limits are not falsely 503',()=>{
  const message=friendlyError('image 已配置，但最近真实推理返回 HTTP 503；服务暂时不可用');
  assert.match(message,/HTTP 503/);assert.doesNotMatch(message,/没有接通|部署的队友/);
  assert.match(friendlyError('HTTP 429；服务暂时不可用'),/HTTP 429/);
  assert.doesNotMatch(friendlyError('HTTP 429；服务暂时不可用'),/503/);
  assert.match(friendlyError('模型未启用'),/没有接通/);
});

test('structured cloud errors preserve engine code and request ID',()=>{
  const detail='StepFun step-image-edit-2（Step Plan 订阅入口）返回 HTTP 503；上游错误码：engine_overloaded；请求编号：rid-safe；未使用演示替代。';
  assert.equal(friendlyError(detail),detail);
});

test('unavailable configured image retry is distinguished from missing service',()=>{
  const job={kind:'build',status:'failed',payload:{base_version:7,input_revision:1,targets:['pet'],scene:{objects:[
    {id:'pet',generation:{strategy:'generate3d',image_mode:'edit',image_model:'image'}}]}}};
  const project={head:7,input_revision:1};
  const text=retryBlockReason(job,project,null,[{id:'image',available:false,last_http_status:503,retry_after_seconds:90,capabilities:['image.edit']}]);
  assert.match(text,/已配置/);assert.match(text,/2 分钟/);assert.doesNotMatch(text,/尚未接通/);
  assert.equal(retryBlockReason(job,project,null,[{id:'image',available:true,capabilities:['image.edit']}]),'');
});

test('clearing an overlay never claims regenerated or exact original-photo colours',()=>{
  const patch={operations:[{type:'clear_tint',object_id:'pet'}]};
  const text=acceptedPatchMessage(patch,'id',[],{objects:[{id:'pet',label:'宠物'}]});
  assert.match(text,/取消整体染色/);assert.match(text,/保留网格/);
  assert.doesNotMatch(text,/重新制作|正在|原图完全/);
});

test('historical restore and precise resize are local edits, not a GPU build',()=>{
  const scene={objects:[{id:'base',label:'底座'}]};
  const patch={operations:[{type:'restore_object',object_id:'base',source_version:13}]};
  assert.match(patchLines(patch,scene)[0],/第 13 版/);
  assert.match(acceptedPatchMessage(patch,'p',[],scene),/已保存/);
  assert.doesNotMatch(acceptedPatchMessage(patch,'p',[],scene),/正在|重新制作/);
  assert.match(patchLines({operations:[{type:'resize',object_id:'base',size_edit:{width:2}}]},scene)[0],/保留位置/);
});

test('old accepted patches and restored versions are not presented as current state',()=>{
  const patch={base_version:11,explanation:'删除底座'};
  assert.equal(patchIsCurrent(patch,'p',[],{version:12,note:'删除底座'}),true);
  assert.equal(patchIsCurrent(patch,'p',[],{version:14,note:'删除底座'}),false);
  assert.equal(patchIsCurrent(patch,'p',[],{version:12,note:'从版本 9 恢复'}),false);
  assert.equal(patchIsCurrent(patch,'p',[{kind:'build',payload:{proposal_id:'p'},result:{version:13},status:'succeeded'}],{version:13,note:'组件装配完成'}),true);
});

test('removal is described as reversible removal, not a transform or model build',()=>{
  const patch={operations:[{type:'remove',object_id:'base'}]};
  const scene={objects:[{id:'base',label:'底座'}]};
  assert.deepEqual(patchLines(patch,scene),['底座：从场景移除（可从历史恢复）']);
  assert.match(acceptedPatchMessage(patch,'p',[],scene),/已保存为新的版本/);
  assert.doesNotMatch(acceptedPatchMessage(patch,'p',[],scene),/重新制作|调整位置/);
  assert.match(acceptedPatchMessage({...patch,explanation:'从场景移除底座，其他物品不变'},'p',[],{objects:[]}),/移除底座/);
});

test('added geometry waits for its own build and never claims premature success',()=>{
  const patch={operations:[{type:'add',object_id:'frame',new_object:{label:'海报框'}}]};
  assert.deepEqual(patchLines(patch,{objects:[]}),['海报框：新增程序几何']);
  assert.deepEqual(patchLines({operations:[{type:'bind_frame',object_id:'frame',target_id:'poster'}]},{objects:[{id:'frame',label:'海报框'}]}),['海报框：自动贴合海报']);
  assert.match(acceptedPatchMessage(patch,'p',[{kind:'build',payload:{proposal_id:'p'},status:'running'}],null),/完成前保留当前版本/);
  assert.match(acceptedPatchMessage(patch,'p',[{kind:'build',payload:{proposal_id:'p'},status:'failed'}],null),/没有应用/);
  assert.match(acceptedPatchMessage(patch,'p',[{kind:'build',payload:{proposal_id:'p'},status:'succeeded'}],null),/已完成并保存/);
});
test('checkpoint conflicts are explained without blaming changed materials',()=>{
  assert.match(friendlyError('检查点 director.edit 输入已变化，需新建任务。'),/旧检查点/);
  assert.doesNotMatch(friendlyError('检查点 director.edit 输入已变化，需新建任务。'),/director\.edit/);
});
test('historical procedural text regeneration does not falsely claim shape changes',()=>{
  const patch={operations:[{type:'regenerate',object_id:'base',prompt:'round corners'}]};
  const job={kind:'build',payload:{proposal_id:'p'},status:'succeeded',steps:[{name:'asset:base',result:{meta:{operation:'deterministic-procedural'}}}]};
  const text=acceptedPatchMessage(patch,'p',[job],null);
  assert.match(text,/形状修改并未执行/);
  assert.doesNotMatch(text,/外观修改已完成/);
});
test('plan retry with changed sources is blocked before a misleading repeated request',()=>{
  assert.match(retryBlockReason({kind:'plan',payload:{base_version:1,input_revision:2}},{head:1,input_revision:3},null),/旧素材/);
});

test('successful tint is independent of historical geometry failure',()=>{
  const patch={operations:[{type:'tint',object_id:'ball',color:'#d3b56b'}]};
  assert.equal(acceptedPatchMessage(patch,'p',[],{objects:[{id:'ball',label:'球',status:'failed'}]}),'已保存为新的版本。球：调整配色。');
});
test('regeneration feedback uses its own job, not later object state',()=>{
  const patch={operations:[{type:'regenerate',object_id:'ball'}]};
  const jobs=[{kind:'build',payload:{proposal_id:'other'},status:'failed'},{kind:'build',payload:{proposal_id:'p'},status:'succeeded'}];
  assert.match(acceptedPatchMessage(patch,'p',jobs,{objects:[{id:'ball',status:'failed'}]}),/已完成并保存/);
});
test('missing image edit and stale build suppress ineffective retry',()=>{
 const project={head:3,input_revision:1};
 const j={kind:'build',status:'failed',payload:{base_version:3,input_revision:1,scene:{objects:[{id:'ball',generation:{strategy:'generate3d',image_mode:'edit'}}]}}};
 assert.match(retryBlockReason(j,project,null,[]),/尚未接通/);
 assert.equal(retryBlockReason(j,project,null,[{id:'image',capabilities:['image.edit']}]),'');
 assert.match(retryBlockReason(j,{...project,head:4},null,[]),/已变化/);
});

test('mixed uploads use file types without manual technical classification',()=>{
  assert.equal(inferRole({name:'first.png',type:'image/png'}),'scene');
  assert.equal(inferRole({name:'closeup.jpg',type:'image/jpeg'},[{kind:'image'}]),'object');
  assert.equal(inferRole({name:'recording.wav',type:''}),'audio');
  assert.equal(inferRole({name:'diary.md',type:'text/plain'}),'diary');
});
test('a photo filename never identifies a real person',()=>{
  assert.equal(inferRole({name:'my_face.jpg',type:'image/jpeg'},[{kind:'image'}]),'object');
});
test('pending plans only recover when both scene and inputs still match',()=>{
  const p={head:2,input_revision:4}, plan={id:'x',status:'pending',base_version:2,input_revision:4};
  assert.equal(currentPlan([plan],p),plan);
  assert.equal(currentPlan([{...plan,input_revision:3}],p),null);
  assert.equal(currentPlan([{...plan,status:'accepted'}],p),null);
  assert.equal(currentPlan([{...plan,base_version:0}],p),null);
});
test('undo excludes layout drafts and empty scenes',()=>{
  assert.deepEqual(readyVersions([{version:2,note:'组件装配完成'},{version:1,note:'确认方案，建立布局草稿'},{version:0,note:'创建项目'}]).map(v=>v.version),[2]);
});
test('repeated undo follows the restored content instead of toggling redo',()=>{
  const versions=[{version:6,note:'从版本 4 恢复（新建版本，保留历史）'},{version:5,note:'局部编辑'},{version:4,note:'从版本 2 恢复（新建版本，保留历史）'},{version:3,note:'局部编辑'},{version:2,note:'组件装配完成'}];
  assert.equal(undoTarget(versions,5).version,4);
  assert.equal(undoTarget(versions,4),null);
  assert.equal(undoTarget(versions,6),null);
  assert.equal(undoTarget(versions,3).version,2);
});
test('edit summary hides coordinates and shader parameters',()=>{
  const lines=patchLines({operations:[{type:'transform',object_id:'x',transform:{position:[1,2,3]}},{type:'tint',object_id:'x',color:'#ffffff'},{type:'audio',audio_id:'a'}]},{objects:[{id:'x',label:'蛋糕'}]});
  assert.deepEqual(lines,['蛋糕：调整位置或大小','蛋糕：调整配色','调整声音的播放效果']);
});
test('progress describes real completed steps, not made-up percentages',()=>{
  const p=progressText([{id:'j',kind:'build',status:'running',steps:[{name:'asset:x',status:'succeeded'},{name:'asset:y',status:'running'}]}]);
  assert.match(p.note,/已做好 1 件/);assert.doesNotMatch(p.note,/%/);
  assert.equal(progressText([{id:'x',status:'failed'}]),null);
});

test('long image jobs show preparation or queueing instead of claiming 3D success',()=>{
  const p=progressText([{id:'j',kind:'build',status:'running',payload:{scene:{objects:[{id:'table',label:'生日桌'}]}},steps:[
    {name:'reference:table',status:'running'}]}]);
  assert.match(p.note,/准备参考图：生日桌/);
  assert.match(p.note,/排队或图片编辑/);
  assert.match(p.note,/保持本机应用运行/);
  assert.doesNotMatch(p.note,/已做好|已准备|%/);
});

test('reference completion and geometry execution are reported independently',()=>{
  const p=progressText([{id:'j',kind:'build',status:'running',steps:[
    {name:'reference:person',status:'succeeded'},
    {name:'asset:person',status:'running'},
    {name:'asset:gift',status:'succeeded'}]}]);
  assert.match(p.note,/已准备 1 张参考图/);
  assert.match(p.note,/已做好 1 件物品/);
  assert.match(p.note,/正在制作三维物品：person/);
  assert.doesNotMatch(p.note,/已做好 2|%/);
});

test('unknown or incomplete steps do not break the progress display',()=>{
  assert.doesNotThrow(()=>progressText([{id:'j',kind:'build',status:'running',steps:[{}, {status:'running'}]}]));
  const p=progressText([{id:'j',kind:'plan',status:'running',steps:[{name:'reference:x',status:'succeeded'}]}]);
  assert.doesNotMatch(p.note,/已准备|已做好/);
});

test('confirmed plan clears the obsolete re-reading notice only after successful submission',()=>{
  const src=fs.readFileSync(new URL('../app.js',import.meta.url),'utf8');
  const fn=src.slice(src.indexOf('async function confirmPlan(plan)'),src.indexOf('function appendMessage('));
  assert.match(fn,/await post[\s\S]*state\.notice=''/);
  assert.match(fn,/Idempotency-Key/);
});

test('adjusting an unconfirmed plan opens re-planning instead of editing the existing scene',()=>{
  const src=fs.readFileSync(new URL('../app.js',import.meta.url),'utf8');
  assert.match(src,/btn\('我想调整一下',\(\)=>replanDialog\(\)\)/);
  const fn=src.slice(src.indexOf('function replanDialog()'),src.indexOf('async function upload'));
  assert.match(fn,/state\.project\.requirements/);
  assert.match(fn,/expected_input_revision/);
  assert.match(fn,/await post\(`\$\{base\(\)\}\/plan`/);
  assert.doesNotMatch(fn,/\/edit`/);
});

test('semantic reference rejection is not a connection outage or optimistic geometry success',()=>{
  const p=friendlyError({status:409,code:'reference_quality_failed',message:'桌子的建模参考图未通过内容校验'});
  assert.match(p,/停止对应的三维生成/);
  assert.match(p,/不是连接断开/);
  assert.doesNotMatch(p,/刚刚有了变化|尚未接通|已做好/);
  assert.match(jobFailureDetail({status:'failed',steps:[{status:'failed',error:'桌子的建模参考图未通过内容校验：含瓶子'}]}),/参考图的内容/);
});

test('invalid critic reports do not masquerade as validated reference images',()=>{
  assert.match(friendlyError('旗舰输出三次未通过结构校验：3 validation errors for ReferenceReview'),/没有返回可验证的报告/);
});

test('reference verification is its own stage before geometry',()=>{
  const p=progressText([{id:'j',kind:'build',status:'running',steps:[
    {name:'reference:table',status:'succeeded'}, {name:'quality:table',status:'running'}]}]);
  assert.match(p.note,/正在检查参考图内容：table/);
  assert.doesNotMatch(p.note,/正在制作三维|已做好/);
});
test('error text does not expose node paths or secret-like technical details',()=>{
  assert.doesNotMatch(friendlyError(Error('Traceback /home/user/.env token:some-secret')),/some-secret|\/home/);
  assert.match(friendlyError({message:'没有已配置的 brain.plan 模型',status:502}),/负责部署的队友/);
  assert.match(friendlyError({message:'版本过期',status:409}),/已有|变化/);
});
test('truncated director JSON is not mislabeled as lost connection or bad upload',()=>{
  const message=friendlyError('旗舰 JSON 因 token 上限被截断（max_tokens=12000），请调整模型配置。');
  assert.match(message,/回复过长|被截断/);
  assert.doesNotMatch(message,/没有接通|文件过大|max_tokens/);
  assert.match(friendlyError({code:'provider_output_truncated',message:'length'}),/尚未应用/);
});
test('invalid planning coordinates are not mislabeled as missing configuration',()=>{
  const message=friendlyError('旗舰输出三次未通过结构校验：规划布局未通过，需要修正 relation 配置。');
  assert.match(message,/修正方案|未通过校验/);
  assert.doesNotMatch(message,/没有接通|文件过大/);
});
test('novice document entirely removes old inspector and developer panels',()=>{
  const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
  for(const forbidden of ['objectInspector','objectTab','data-right','sourceRole','nodeButton','activityToggle','autoReview','reviewButton','memoryButton','objectPosition'])assert.equal(html.includes(forbidden),false,forbidden);
  assert.equal((html.match(/id="chatInput"/g)||[]).length,1);
  assert.match(html,/id="undoButton"/);assert.match(html,/id="historyButton"/);assert.match(html,/id="exportButton"/);
});
test('Chinese input method Enter is not sent while composing',()=>{
  const script=fs.readFileSync(new URL('../app.js',import.meta.url),'utf8');
  assert.match(script,/!e\.isComposing/);assert.match(script,/e\.keyCode!==229/);
  assert.doesNotMatch(script,/JSON\.stringify\(.*patch\.operations/);
});
test('saved version labels use human language',()=>{
  assert.equal(versionNote('组件装配完成'),'回忆制作完成');
  assert.equal(versionNote('从版本 2 恢复（新建版本，保留历史）'),'恢复了以前保存的内容');
});
