import test from 'node:test';
import assert from 'node:assert/strict';
import {parseGlb} from '../glb.js';
function glb(extra={},binary=new Float32Array([0,0,0,1,0,0,0,1,0])){
 const doc={asset:{version:'2.0'},buffers:[{byteLength:binary.byteLength}],bufferViews:[{buffer:0,byteOffset:0,byteLength:binary.byteLength}],accessors:[{bufferView:0,componentType:5126,count:3,type:'VEC3'}],meshes:[{primitives:[{attributes:{POSITION:0}}]}],nodes:[{mesh:0,translation:[1,2,3]}],scenes:[{nodes:[0]}],scene:0,...extra};let text=JSON.stringify(doc);text+=' '.repeat((4-new TextEncoder().encode(text).length%4)%4);const j=new TextEncoder().encode(text),b=new Uint8Array(binary.buffer,binary.byteOffset,binary.byteLength),out=new Uint8Array(28+j.length+b.length),v=new DataView(out.buffer);v.setUint32(0,0x46546c67,true);v.setUint32(4,2,true);v.setUint32(8,out.length,true);v.setUint32(12,j.length,true);v.setUint32(16,0x4e4f534a,true);out.set(j,20);v.setUint32(20+j.length,b.length,true);v.setUint32(24+j.length,0x004e4942,true);out.set(b,28+j.length);return out.buffer;
}
test('parse a real triangle and node translation',()=>{const p=parseGlb(glb());assert.equal(p.parts.length,1);assert.equal(p.parts[0].data.length,36);assert.deepEqual(p.bounds,{min:[1,2,3],max:[2,3,3]});});
test('reject external URIs before texture fetch',()=>{assert.throws(()=>parseGlb(glb({images:[{uri:'https://evil.example/texture.png'}]})));});
test('reject broken length and magic',()=>{const raw=glb();assert.throws(()=>parseGlb(raw.slice(0,-1)));new Uint8Array(raw)[0]=0;assert.throws(()=>parseGlb(raw));});
test('reject unsupported compression and skins',()=>{assert.throws(()=>parseGlb(glb({skins:[{}]})));assert.throws(()=>parseGlb(glb({extensionsUsed:['KHR_draco_mesh_compression']})));});
test('interleaved positions are read without ignoring byteStride',()=>{const vals=new Float32Array([0,0,0,99,1,0,0,99,0,1,0,99]);const p=parseGlb(glb({bufferViews:[{buffer:0,byteOffset:0,byteLength:48,byteStride:16}]},vals));assert.equal(p.bounds.max[0],2);assert.equal(p.bounds.max[1],3);});
test('unsafe accessor range does not allocate uncontrolled buffers',()=>{assert.throws(()=>parseGlb(glb({accessors:[{bufferView:0,componentType:5126,count:99999999,type:'VEC3'}]})));});
