import test from 'node:test';
import assert from 'node:assert/strict';
import {canonicalViews,qualityLines,qualityEvidence,reviewHeading,repairLines,jobQualityResult} from '../quality.js';
import {MemoryViewer} from '../viewer.js';
import {lookAt} from '../math.js';
import {retryBlockReason,progressText} from '../simple.js';

test('canonical coverage has a real negative-pitch bottom, back and both sides',()=>{
 assert.equal(canonicalViews.length,8);assert.equal(new Set(canonicalViews.map(v=>v.name)).size,8);
 assert.equal(canonicalViews.find(v=>v.name==='bottom').pitch,-Math.PI/2);
 assert.equal(canonicalViews.find(v=>v.name==='back').yaw,Math.PI);
 for(const v of canonicalViews.filter(v=>v.up))assert.ok(lookAt([0,Math.sin(v.pitch)*5,Math.cos(v.pitch)*5],[0,0,0],v.up).every(Number.isFinite));
});
test('historical single-view reviews are not relabeled as canonical coverage',()=>{
 assert.match(reviewHeading({payload:{coverage_mode:'canonical'}}),/^多视角复核/);
 for(const job of [{},{payload:{}},{payload:{coverage_mode:'legacy'}}])assert.match(reviewHeading(job),/^画面复核/);
});

function fakeViewer(fail=false){
 const scene={objects:[{id:'table',asset_id:'a',transform:{size:[2,1,2],rotation:[0,0,0],position:[0,0,0]}}]};
 globalThis.document={createElement:()=>({width:0,height:0,getContext:()=>({drawImage(){}}),toBlob:fn=>fn(fail?null:{type:'image/png'})})};
 return {scene,sceneEpoch:1,selected:'table',mode:'origin',yaw:.4,pitch:.5,distance:8,target:[1,2,3],
  canvas:{width:400,height:300},cache:new Map([['a',{}]]),fallback:false,
  camera(){return {yaw:this.yaw,pitch:this.pitch,distance:this.distance,target:[...this.target],renderer:'webgl2'};},
  async ready(){},draw(){},seen:[]};
}
test('isolated six-view capture restores camera and scene even after encoding fails',async()=>{
 for(const fail of [false,true]){
  const v=fakeViewer(fail),scene=v.scene;
  if(fail)await assert.rejects(()=>MemoryViewer.prototype.captureViews.call(v,{objectId:'table'}),/编码失败/);
  else{const views=await MemoryViewer.prototype.captureViews.call(v,{objectId:'table'});assert.equal(views.length,6);assert.equal(views[5].camera.pitch,-Math.PI/2);}
  assert.equal(v.scene,scene);assert.equal(v.mode,'origin');assert.equal(v.selected,'table');assert.deepEqual(v.target,[1,2,3]);assert.equal(v.pitch,.5);assert.equal(v.capturing,false);
 }
});
test('UI does not call uninspected output quality-accepted',()=>{
 assert.match(qualityLines({asset_quality:{status:'needs_review',objects:{}}})[0],/未通过或不可用/);
 assert.match(qualityLines({asset_quality:{status:'accepted',objects:{}}})[0],/不是精确真实还原保证/);
});
test('advisory publication is not described as quality acceptance or held output',()=>{
 const build=qualityLines({asset_quality:{status:'warning',objects:{}}})[0];
 assert.match(build,/模型已采用/);assert.match(build,/不代表质量通过/);
 const repair=repairLines({auto_repair:{status:'published_with_warnings'}})[0];
 assert.match(repair,/已采用/);assert.match(repair,/历史版本可恢复/);
 assert.doesNotMatch(repair,/已执行并通过|未发布/);
});
test('quality evidence retains rejected candidates and separates full-scene views',()=>{
 const report={renders:[{view:'back',asset_id:'a'}],accepted:false};
 const sections=qualityEvidence({asset_quality:{objects:{table:{current:report,candidates:[{stage:'geometry',attempt:0,evidence:report}]}},scene:report}});
 assert.equal(sections.length,2);assert.equal(sections[0].report.accepted,false);assert.match(sections[1].title,/八向/);
 assert.deepEqual(qualityEvidence({}),[]);
});
test('too-small viewport never submits falsely valid multiview evidence',async()=>{
 const v=fakeViewer();v.canvas.height=50;
 await assert.rejects(()=>MemoryViewer.prototype.captureViews.call(v),/画面过小/);assert.ok(!v.capturing);
});
test('quality-held candidate does not offer an ineffective restore/retry loop',()=>{
 assert.match(retryBlockReason({status:'needs_review',result:{asset_quality:{status:'needs_review'}}},{},{}),/不会重置预算/);
});
test('repair evidence includes actual before and after even without a generated asset',()=>{
 const before={renders:[{view:'back',asset_id:'a'}]},after={renders:[{view:'bottom',asset_id:'b'}]};
 const sections=qualityEvidence({auto_repair:{before,after}});
 assert.equal(sections.length,2);assert.equal(sections[0].report,before);assert.equal(sections[1].report,after);
 assert.equal(qualityEvidence({auto_repair:{before,after},asset_quality:{scene:after}}).length,2);
});
test('repair success is distinct from held candidate or no-change inspection',()=>{
 assert.match(repairLines({auto_repair:{status:'accepted'}})[0],/已执行并通过/);
 assert.match(repairLines({auto_repair:{status:'held'}})[0],/未发布/);
 assert.match(repairLines({auto_repair:{status:'no_repair_needed'}})[0],/未创建重复版本/);
 assert.deepEqual(repairLines({}),[]);
});
test('running repair evidence reads only succeeded checkpoints, not unfinished output',()=>{
 const report={renders:[{view:'back',asset_id:'real'}]};
 const job={kind:'repair',status:'running',steps:[{name:'repair:inspect:before',status:'running',result:report}]};
 assert.equal(jobQualityResult(job),null);job.steps[0].status='succeeded';
 assert.equal(jobQualityResult(job).auto_repair.before,report);
 assert.equal(qualityEvidence(jobQualityResult(job)).length,1);
 assert.equal(jobQualityResult({kind:'review'}),null);
});
test('a terminal repair result supersedes checkpoint-only previews',()=>{
 const result={auto_repair:{status:'held'}};
 assert.equal(jobQualityResult({kind:'repair',status:'needs_review',result,steps:[]}),result);
});
test('repair progress distinguishes judging from execution and final reinspection',()=>{
 const job={kind:'repair',status:'running',steps:[{name:'repair:inspect:before',status:'running'}]};
 assert.match(progressText([job]).note,/还未执行修复/);
 job.steps[0].name='geometry:target:0';assert.match(progressText([job]).note,/3D节点/);
 job.steps[0].name='inspect:assembled-scene';assert.match(progressText([job]).note,/八向全景复检/);
});
test('a rejected image reference is visible but never claimed to be a 3D render',()=>{
 const r={reference_asset_id:'ref',accepted:false,summary:'含错误的椅子'};
 const result={auto_repair:{status:'held'},asset_quality:{objects:{table:{current:r,candidates:[{stage:'reference',attempt:0,evidence:r}]}}}};
 const sections=qualityEvidence(result);
 assert.equal(sections.length,1);assert.match(sections[0].title,/不是3D/);
 assert.equal(sections[0].report.renders[0].asset_id,'ref');assert.equal(sections[0].report.scope,'reference-image-not-3d-render');
 assert.match(repairLines(result).join('\n'),/错误的椅子/);
});
