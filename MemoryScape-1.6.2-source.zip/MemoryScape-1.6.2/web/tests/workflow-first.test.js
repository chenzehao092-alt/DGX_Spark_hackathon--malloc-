import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const app=readFileSync(new URL('../app.js',import.meta.url),'utf8');
const index=readFileSync(new URL('../index.html',import.meta.url),'utf8');
test('visual warnings remain visible without claiming quality acceptance',()=>{
  assert.match(app,/j\.result\?\.quality_warnings\?\.length/);
  assert.match(app,/质量提示未阻断制作/);
  assert.match(app,/esc\(cleanTech/);
});
test('initial local screen avoids flashing a manual token form',()=>{
  assert.match(index,/<section id="login" class="login-screen" hidden>/);
  assert.match(index,/本机启动会自动连接，无需输入口令/);
});
