import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {observationRequest,geometryEvidenceLines} from '../agent.js';
import {friendlyError,retryBlockReason} from '../simple.js';
for(const text of ['你看看尺寸不对','你自己看看你做的东西','帮我看看','看一下','检查当前画面的布局','底座大小不对','位置不对','review scene']) {
  test(`inspection routes to a real screenshot: ${text}`,()=>assert.equal(observationRequest(text),true));
}
for(const text of ['删除底座','你看看然后放大20%','帮我看看并加回底座','大小不对，修改尺寸','恢复底座','移动到左边','生成生日回忆','给海报加框','', '把桌子加宽']) {
  test(`edits never become an automatic review loop: ${text}`,()=>assert.equal(observationRequest(text),false));
}
test('budget errors have an actionable message and stop repeated retry buttons',()=>{
  assert.match(friendlyError({status:409,code:'agent_budget_exhausted',message:'预算用完'}),/停止追加调用/);
  assert.match(retryBlockReason({kind:'edit',error:'本轮请求的模型调用预算已用完',payload:{}},{head:1},null),/重复恢复不会增加/);
});
test('scope guard errors are not mislabeled as stale-version conflicts',()=>assert.match(friendlyError({status:409,code:'task_scope_violation'}),/目标或执行结果/));
test('screenshot review never auto-applies proposals or autogenerates again',()=>{
  const app=readFileSync(new URL('../app.js',import.meta.url),'utf8');
  const capture=app.slice(app.indexOf('async function queueVisualReview'),app.indexOf('async function confirmPlan'));
  assert.match(capture,/viewer\.captureViews\(/);assert.match(capture,/coverage_mode:'canonical'/);assert.match(capture,/\/renders/);assert.match(capture,/\/review/);
  assert.doesNotMatch(capture,/\/apply|\/retry|\/plan|setInterval/);
  assert.match(app,/检查当前画面（只给建议）/);
  assert.match(app,/state\.notice\.startsWith\('正在复核真实画面'\).*isActive\(j\)/);
});

test('grounded geometry UI only claims actual upright asset bounds, not inferred physical contact',()=>{
  const evidence={schema:'display-geometry-v1',objects:[
    {object_id:'table',label:'桌子',source:'validated_asset_bounds',upright:true,floor_status:'at_floor'},
    {object_id:'cake',label:'蛋糕',source:'validated_asset_bounds',upright:true,floor_status:'above_floor'},
    {object_id:'requested',label:'未生成',source:'requested_dimensions_not_actual_mesh',upright:true,floor_status:'at_floor'},
    {object_id:'tilted',label:'倾斜模型',source:'validated_asset_bounds',upright:false,floor_status:'at_floor'}],
    supports:[{subject:'cake',target:'table',source:'validated_asset_bounds',exact_for_upright_bounds:true,status:'box_contact'}]};
  assert.deepEqual(geometryEvidenceLines(evidence),['桌子：当前模型包围盒已落地','蛋糕与桌子：包围盒支撑高度一致']);
  evidence.supports[0].source='requested_dimensions_not_actual_mesh';
  assert.deepEqual(geometryEvidenceLines(evidence),['桌子：当前模型包围盒已落地']);
  assert.deepEqual(geometryEvidenceLines(null),[]);
});

test('geometry-only menu is read-only, version-bound and uses no model jobs',()=>{
  const app=readFileSync(new URL('../app.js',import.meta.url),'utf8');
  const facts=app.slice(app.indexOf('async function geometryFactsDialog'),app.indexOf('function menu()'));
  assert.match(facts,/\/memory/);assert.match(facts,/memory\.version!==version/);
  assert.match(facts,/esc\(line\)/);assert.doesNotMatch(facts,/post\(|method:|\/review|\/apply|\/retry/);
});

test('geometry conflict is reported as a numeric consistency guard, not service unavailable',()=>{
  assert.match(friendlyError({status:409,code:'review_geometry_conflict',message:'复核建议破坏已有落地约束'}),/落地或支撑关系冲突.*当前版本不变/);
});
