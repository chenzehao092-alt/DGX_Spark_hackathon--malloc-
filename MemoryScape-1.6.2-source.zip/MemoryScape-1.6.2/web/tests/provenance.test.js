import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  cleanTech, provenanceLabel, objectKindLabel, sourceKindLabel,
  decisionLines, whyLines, memoryCardHTML, memoryDetailsHTML, objectDetailsHTML,
} from '../provenance.js';

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

test('removal memory never calls it a position adjustment',()=>{
  const lines=decisionLines('patch',{operations:[{type:'remove',object_id:'base'}]},{objects:[{id:'base',label:'底座'}]});
  assert.deepEqual(lines,['底座：从场景移除，历史和素材仍保留']);
});

test('cleanTech removes the leaked scheduling parameters', () => {
  const input = '仅一个主体：对唯一上传的透明背景红色球参考图使用 strategy="generate3d"、primary_source=img_001、image_mode="original"、geometry_model="geometry"、textured=true、steps=4、max_faces=10000。';
  const out = cleanTech(input);
  for (const bad of ['strategy', 'generate3d', 'primary_source', 'image_mode', 'geometry_model', 'textured', 'steps=4', 'max_faces']) {
    assert.ok(!out.includes(bad), `should not contain ${bad}: ${out}`);
  }
  assert.ok(out.includes('红色球'), 'keeps the user-readable meaning');
});

test('cleanTech maps known phrases to natural language', () => {
  const out = cleanTech('使用 strategy="generate3d" 重建');
  assert.ok(!out.includes('strategy'));
  assert.equal(cleanTech('strategy="photo" 完成').replace(/\s+/g, ''), '完成');
});

test('cleanTech drops embedded JSON blocks with internal fields', () => {
  const out = cleanTech('说明：{"strategy":"generate3d","steps":4,"max_faces":10000} 其余正常。');
  assert.ok(!out.includes('strategy') && !out.includes('max_faces'));
});

test('real planner summaries hide source IDs and empty repair backticks', () => {
  const out = cleanTech('使用照片 `a_2b09788a06834e54b2bd153b` 制作相机。底座为 `fit=stretch`。');
  assert.ok(out.includes('相机') && out.includes('所选素材') && out.includes('按指定宽高'));
  assert.ok(!out.includes('a_2b09788') && !out.includes('fit=') && !out.includes('`'));
  assert.ok(!cleanTech('中性底座 `steps=50`。').includes('`'));
  assert.equal(cleanTech('必须使用 generate3d，不用平面代替。'), '必须使用 真实三维模型，不用平面代替。');
});

test('provenance labels map every schema enum to Chinese', () => {
  assert.equal(provenanceLabel('procedural'), '程序搭建');
  assert.equal(provenanceLabel('generated'), '模型生成');
  assert.equal(provenanceLabel('photo'), '来自照片');
  assert.equal(provenanceLabel('imported'), '用户导入');
  assert.equal(provenanceLabel('weird'), 'weird');
});

test('decision lines translate patch operations without raw fields', () => {
  const scene = {objects: [{id: 'ball', label: '红色玩具球'}]};
  const lines = decisionLines('patch', {operations: [{type: 'tint', object_id: 'ball'}, {type: 'regenerate', object_id: 'ball'}]}, scene);
  assert.deepEqual(lines, ['红色玩具球：调整了配色', '红色玩具球：重新制作了外观']);
  assert.equal(decisionLines('restore', {}, scene)[0], '恢复了以前保存的内容');
  assert.equal(decisionLines('asset_adopted', {}, scene)[0], '采用了已有资产');
});

test('why lines come only from real trace data, and admit thin data', () => {
  const ctx = {sources: [{id: 's1', kind: 'image', label: '照片'}, {id: 's2', kind: 'audio', label: '录音'}], scene: {objects: []}, decisions: []};
  const lines = whyLines({id: 'o', provenance: 'photo', reference_ids: ['s1', 's2'], uncertainty: '背面为生成补全。'}, ctx);
  assert.ok(lines.some(l => l.includes('1 份照片、1 份录音')));
  assert.ok(lines.some(l => l.includes('直接来自上传的照片')));
  assert.ok(lines.some(l => l.includes('背面为生成补全')));
  const thin = whyLines({id: 'o', provenance: 'unknown-x', reference_ids: []}, {sources: [], scene: {objects: []}, decisions: []});
  assert.equal(thin[0], '当前材料无法确定。');
});

test('memory card shows real counts and never renders JSON', () => {
  const html = memoryCardHTML({sources: [{kind: 'image'}, {kind: 'image'}, {kind: 'audio'}, {kind: 'text'}], scene: {objects: [{}, {}], locked_facts: ['a'], assumptions: ['b']}, project: {head: 3, requirements: '我的生日'}, version: 3}, {esc});
  assert.ok(html.includes('2 张照片') && html.includes('1 段录音') && html.includes('2 个对象') && html.includes('3 版'));
  assert.ok(html.includes('我的生日'));
  assert.ok(html.includes('查看追迹'));
  assert.ok(!html.includes('已确认') && !html.includes('仍需留意'));
  assert.ok(!html.includes('{' ) || !html.includes('JSON'));
});

test('memory details drawer cleans locked facts and assumptions', () => {
  const html = memoryDetailsHTML({
    sources: [{id: 's1', kind: 'image', label: '照片'}],
    scene: {objects: [], locked_facts: ['球是红色', 'strategy="generate3d" primary_source=img_001'], assumptions: ['背面需要推断', 'planning requirements: max_faces=10000']},
    project: {requirements: '生日照片 strategy="photo"'},
  }, {esc, assetURL: id => `/assets/${id}`, decisions: []});
  assert.ok(html.includes('球是红色') && html.includes('背面需要推断'));
  for (const bad of ['strategy', 'primary_source', 'planning requirements', 'max_faces']) assert.ok(!html.includes(bad), bad);
});

test('object details show source / basis / uncertainty / recent edits / why', () => {
  const o = {
    id: 'ball', label: '红色玩具球', provenance: 'photo', description: '按参考照片重建。',
    uncertainty: '照片没有覆盖背面。', reference_ids: ['s1'], reference_asset_id: null,
  };
  const ctx = {esc, assetURL: id => `/assets/${id}`, sources: [{id: 's1', kind: 'image', label: '球照片'}], scene: {objects: [], locked_facts: ['球是红色'], assumptions: []}, decisions: [{kind: 'patch', body: {operations: [{type: 'tint', object_id: 'ball'}]}}]};
  const html = objectDetailsHTML(o, ctx);
  for (const key of ['红色玩具球', '来源', '依据', '不确定', '最近修改', '为什么这样？', '球照片', '照片没有覆盖背面', '已确认', '组件参考'.replace('组件参考', '')]) {
    assert.ok(html.includes(key), `missing ${key}`);
  }
  assert.ok(html.includes('来自照片'));
  assert.ok(!html.includes('strategy') && !html.includes('JSON') && !html.includes('primary_source'));
});

test('app.js imports provenance and never renders raw generation params in chat copy', () => {
  const src = fs.readFileSync(new URL('../app.js', import.meta.url), 'utf8');
  assert.match(src, /import .*provenance\.js/);
  assert.match(src, /cleanTech\(b\.summary\)/);
  assert.match(src, /cleanTech\(patch\.explanation\)/);
  assert.match(src, /acceptedPatchMessage\(patch,proposal.id,state.jobs,state.scene\)/);
  assert.match(src, /renderTracePanels\(\)/);
});

test('index.html hosts the trace panels', () => {
  const src = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
  assert.match(src, /id="memoryCard"/);
  assert.match(src, /id="objectDetails"/);
  assert.match(src, /id="tracePanels"/);
});
