import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {STATUS_TEXT, statusMeta, mountSettings} from '../settings.js';

test('settings token inputs are password type', () => {
  const src = fs.readFileSync(new URL('../settings.js', import.meta.url), 'utf8');
  assert.match(src, /type="password"/);
  assert.match(src, /autocomplete="new-password"/);
});

test('settings page never echoes stored tokens', () => {
  const src = fs.readFileSync(new URL('../settings.js', import.meta.url), 'utf8');
  // token inputs are never assigned a value from the saved view
  assert.doesNotMatch(src, /_token"\)\.value\s*=\s*conf/);
  // the page only shows configured/unconfigured state, never the plaintext
  assert.match(src, /密钥：已配置/);
  assert.match(src, /密钥：未配置/);
});

test('settings code never writes tokens to localStorage', () => {
  const src = fs.readFileSync(new URL('../settings.js', import.meta.url), 'utf8');
  // no actual storage API call anywhere in the settings module
  assert.doesNotMatch(src, /(localStorage|sessionStorage)\./);
  // the module explicitly states the security contract
  assert.match(src, /never stored in localStorage/);
});

test('plaintext token is cleared from the DOM after save', () => {
  const src = fs.readFileSync(new URL('../settings.js', import.meta.url), 'utf8');
  assert.match(src, /\.value = ''/); // clears token input after submit
  assert.match(src, /never leave plaintext in the DOM/);
});

test('status text maps all preflight statuses', () => {
  assert.equal(statusMeta('connected')[0], '✅');
  assert.equal(statusMeta('connected')[2], '已连接');
  assert.equal(statusMeta('not_configured')[2], '未配置');
  assert.equal(statusMeta('unreachable')[2], '无法访问');
  assert.equal(statusMeta('unauthorized')[2], '未授权');
  assert.equal(statusMeta('invalid_response')[2], '响应异常');
  assert.equal(statusMeta('unknown-thing')[2], 'unknown-thing');
  assert.equal(Object.keys(STATUS_TEXT).length >= 6, true);
});

test('app menu exposes the model configuration entry', () => {
  const src = fs.readFileSync(new URL('../app.js', import.meta.url), 'utf8');
  assert.match(src, /import \{mountSettings\} from '\.\/settings\.js'/);
  assert.match(src, /settingsButton/);
  assert.match(src, /settingsDialog/);
});

async function saveStepFun({status = 'connected', imageStatus = 'connected', mode = 'standard', region = 'cn', saveError, probeError} = {}) {
  const elements = new Map();
  const root = {querySelector(selector) {
    if (!elements.has(selector)) elements.set(selector, {
      value: '', disabled: false, textContent: '', innerHTML: '',
      addEventListener(event, listener) { this[event] = listener; },
    });
    return elements.get(selector);
  }};
  const calls = [], events = [];
  const open = mountSettings({
    esc: value => String(value),
    dialog: (_, html, setup) => { assert.match(html, /id="sf_feedback" role="status"/); setup(root); },
    closeDialog: () => events.push('close'),
    toast: (message, bad) => events.push({message, bad}),
    onSaved: () => events.push('refresh'),
    api: async (path, options) => {
      calls.push(path);
      if (path === '/api/settings/models') return {director: {token_configured: false}, image: {enabled:true, api_mode:mode, api_region:region}};
      if (path === '/api/settings/stepfun') {
        assert.equal(options.body.api_key, 'test-only-key');
        assert.equal(options.body.image_api_mode, mode);
        assert.equal(options.body.image_api_region, region);
        assert.equal(root.querySelector('#sf_key').value, '');
        if (saveError) throw Error(saveError);
        return {director: {token_configured: true}, image: {enabled:true, api_mode:mode, api_region:region}};
      }
      if (probeError) throw Error(probeError);
      return {checks: {director: {status}, image: {status:imageStatus}, geometry: {status: 'unreachable'}}};
    },
  });
  await open();
  root.querySelector('#sf_key').value = ' test-only-key ';
  await root.querySelector('#sf_form').submit({preventDefault() {}});
  assert.equal(root.querySelector('#sf_save').disabled, false);
  assert.equal(root.querySelector('#sf_key').value, '');
  assert.doesNotMatch(root.querySelector('#sf_feedback').textContent, /test-only-key/);
  return {root, calls, events};
}

test('saved and connected closes settings before showing the main toast', async () => {
  const {events, calls} = await saveStepFun();
  assert.deepEqual(events, ['close', {message: 'StepFun 接口检查通过；实际生成结果以任务记录为准。', bad: undefined}, 'refresh']);
  assert.equal(calls.filter(path => path.endsWith('/preflight')).length, 1);
});

test('image subscription selection survives settings save', async () => {
  const {events} = await saveStepFun({mode:'step_plan',region:'international'});
  assert.equal(events[0], 'close');
});

test('director metadata success never hides an image connection failure', async () => {
  const {root,events} = await saveStepFun({imageStatus:'unavailable'});
  assert.deepEqual(events,['refresh']);
  assert.match(root.querySelector('#sf_feedback').textContent,/image: unavailable/);
});

for (const status of ['unauthorized', 'unreachable', 'invalid_response', 'not_configured', 'failed', undefined]) {
  test(`saved with ${status} keeps settings open and reports the real result`, async () => {
    const {root, events} = await saveStepFun({status: status ?? null});
    assert.deepEqual(events, ['refresh']);
    assert.match(root.querySelector('#sf_feedback').textContent, /配置已保存，但连接未通过/);
    assert.ok(root.querySelector('#sf_feedback').textContent.includes(status || 'invalid_response'));
  });
}

test('preflight request failure distinguishes saved configuration from connection', async () => {
  const {root, events} = await saveStepFun({probeError: '网络连接中断'});
  assert.deepEqual(events, ['refresh']);
  assert.match(root.querySelector('#sf_feedback').textContent, /配置已保存，但连接检查未通过：网络连接中断/);
});

test('save failure stays visible in settings without preflight or success toast', async () => {
  const {root, calls, events} = await saveStepFun({saveError: '保存请求失败'});
  assert.deepEqual(events, []);
  assert.ok(!calls.includes('/api/settings/preflight'));
  assert.match(root.querySelector('#sf_feedback').textContent, /配置保存失败：保存请求失败/);
});
