import test from 'node:test';
import assert from 'node:assert/strict';
import {MemoryAudio} from '../audio.js';
function context(){const starts=[];return {currentTime:10,state:'running',starts,destination:{},createBufferSource:()=>({connect(){},disconnect(){},stop(){},start(...args){starts.push(args);}}),createGain:()=>({gain:{value:1},connect(){}}),close(){}};}
function track(id){return {asset_id:id,status:'ready',start:0,trim_start:0,gain:1,loop:false,anchor:null};}
test('tracks decode before a shared clock is scheduled',async()=>{const a=new MemoryAudio(()=>''),c=context();a.context=c;a.scene={objects:[],audio:[track('a'),track('b')]};a.buffer=async id=>{await new Promise(r=>setTimeout(r,id==='a'?3:12));c.currentTime+=1;return {duration:5};};try{await a.play();assert.equal(c.starts.length,2);assert.equal(c.starts[0][0],c.starts[1][0]);assert.equal(a.startedAt,c.starts[0][0]);}finally{a.dispose();}});
test('stopping while decoding cancels delayed playback',async()=>{const a=new MemoryAudio(()=>''),c=context();a.context=c;a.scene={objects:[],audio:[track('a')]};let resolve;a.buffer=()=>new Promise(r=>resolve=r);try{const p=a.play();await new Promise(r=>setTimeout(r,1));a.stop();resolve({duration:3});await p;assert.equal(c.starts.length,0);assert.equal(a.playing,false);}finally{a.dispose();}});
