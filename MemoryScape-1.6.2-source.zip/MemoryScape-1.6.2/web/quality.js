/** Fixed inspection angles, independent of user camera and UI orbit limits. */
export const canonicalViews=[
 {name:'front',yaw:0,pitch:0}, {name:'back',yaw:Math.PI,pitch:0},
 {name:'left',yaw:-Math.PI/2,pitch:0}, {name:'right',yaw:Math.PI/2,pitch:0},
 {name:'top',yaw:0,pitch:Math.PI/2,up:[0,0,1]},
 {name:'bottom',yaw:0,pitch:-Math.PI/2,up:[0,0,1]},
 {name:'oblique_front',yaw:Math.PI/4,pitch:.48},
 {name:'oblique_back',yaw:-3*Math.PI/4,pitch:.48}
];
/** Legacy screenshots must not inherit the new canonical coverage claim. */
export function reviewHeading(job){
 return job?.payload?.coverage_mode==='canonical'?'多视角复核（建议，未自动修改）：':'画面复核（历史截图，建议未自动修改）：';
}
/** Read completed checkpoints while the outer repair job is still running. */
export function jobQualityResult(job){
 if(job?.result)return job.result;
 if(job?.kind!=='repair')return null;
 const done=(job.steps||[]).filter(s=>s.status==='succeeded'&&s.result);
 const before=done.find(s=>s.name==='repair:inspect:before')?.result;
 if(!before)return null;
 const objects={};
 for(const s of done.filter(s=>s.name.startsWith('asset:')&&s.result.quality))objects[s.name.slice(6)]={current:s.result.quality,candidates:s.result.quality_candidates||[]};
 const after=done.find(s=>['repair:inspect:after','inspect:assembled-scene'].includes(s.name))?.result;
 return {auto_repair:{status:job.status,before,after,plan:done.find(s=>s.name==='repair:commands')?.result},
   asset_quality:{objects,scene:after}};
}
export function qualityLines(result){
 const q=result?.asset_quality;if(!q)return [];
 const lines=[q.status==='accepted'?'散件与全景多视角自动验收通过（不是精确真实还原保证）':q.status==='warning'?'模型已采用；视觉检查仅作建议，仍有待优化项（不代表质量通过）':'产物已保留；多视角质量验收未通过或不可用'];
 for(const [id,record] of Object.entries(q.objects||{})){
  const r=record.current;lines.push(`${id}：${r?.accepted?'通过':r?.verdict==='uncertain'?'无法判断':'待修复'} · ${r?.summary||'详见参考图检查'}`);
 }
 if(q.scene?.summary)lines.push(`全景：${q.scene.summary}`);
 return lines;
}
export function qualityEvidence(result){
 const q=result?.asset_quality;
 const sections=[];
 if(result?.auto_repair?.before?.renders?.length)sections.push({title:'修复前 · 实际网格检查',report:result.auto_repair.before});
 for(const [id,record] of Object.entries(q?.objects||{})){
  for(const candidate of record.candidates||[]){
   const r=candidate.evidence;
   if(r?.renders?.length)sections.push({title:`${id} · ${candidate.stage} · 候选 ${candidate.attempt+1}`,report:r});
   else if(candidate.stage==='reference'&&r?.reference_asset_id)sections.push({title:`${id} · 建模参考图验收（不是3D截图）`,
    report:{...r,summary:r.summary||r.report?.reasons?.join('；'),scope:'reference-image-not-3d-render',
      renders:[{view:r.accepted?'建模参考图（通过内容检查）':'建模参考图（未通过内容检查）',asset_id:r.reference_asset_id}]}});
  }
  if(!record.candidates?.length&&record.current?.renders?.length)sections.push({title:id,report:record.current});
 }
 if(q?.scene?.renders?.length)sections.push({title:'装配全景 · 八向',report:q.scene});
 else if(result?.auto_repair?.after?.renders?.length)sections.push({title:'修复后 · 八向复检',report:result.auto_repair.after});
 return sections;
}
export function repairLines(result){
 const r=result?.auto_repair;if(!r)return [];
 const labels={prepare_reference:'重新准备参考并生成',regenerate_geometry:'修复参考后重建形状',retexture:'保留形状重新贴图',relayout:'调整摆放或比例'};
 const lines=[r.status==='accepted'?'本轮修复已执行并通过多视角复检；历史版本仍保留。':r.status==='published_with_warnings'?'本轮修复已采用；多视角复检仍有待优化项，历史版本可恢复。':r.status==='no_repair_needed'?'本轮检查没有发现需自动修复的严重缺陷，未创建重复版本。':'本轮未发布修复结果；原版本保持不变。'];
 for(const a of r.executed||[])lines.push(`${a.object_id}：${labels[a.stage]||a.stage} · ${a.explanation}`);
 for(const [id,object] of Object.entries(result?.asset_quality?.objects||{}))if(!object.current?.accepted&&object.current?.summary)lines.push(`${id}：${object.current.summary}`);
 if(r.plan?.summary)lines.push(r.plan.summary);
 return lines;
}
