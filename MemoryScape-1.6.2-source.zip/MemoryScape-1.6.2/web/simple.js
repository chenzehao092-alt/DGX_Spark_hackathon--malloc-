/** Pure presentation rules. Never interpret filenames as identities or scene facts. */
export const isActive = job => ['queued', 'running'].includes(job.status);
export function patchIsCurrent(patch, proposalId, jobs, latestVersion) {
  if (!latestVersion) return false;
  if (patch.base_version + 1 === latestVersion.version && patch.explanation === latestVersion.note) return true;
  return jobs.some(j => j.kind === 'build' && j.payload.proposal_id === proposalId && j.result?.version === latestVersion.version && j.status === 'succeeded');
}
export function retryBlockReason(job, project, scene, models = []) {
  if(job.status==='needs_review'&&job.result?.asset_quality)return '候选已保留，但本次质量验收未通过或不可用。请查看多视角证据并提出新的修改；恢复不会重置预算或追加候选。';
  if(/(?:调用|执行时间|复核)预算.*用完/.test(job.error||''))return '本次任务预算已用完，重复恢复不会增加额度。已有内容保留；请检查预算或明确发起新的请求。';
  if (job.kind !== 'build') return (job.payload.base_version != null && job.payload.base_version !== project.head) || (job.payload.input_revision != null && job.payload.input_revision !== project.input_revision) ? '这是旧版本或旧素材的请求，请重新描述修改。' : '';
  if (job.status !== 'partial' && (job.payload.base_version !== project.head || job.payload.input_revision !== project.input_revision)) return '场景或素材已变化，请重新描述修改。';
  const objects = job.status === 'partial' ? scene?.objects || [] : job.payload.scene?.objects || [];
  for (const o of objects) {
    if (o.locked && o.asset_id) continue;
    if (job.status === 'partial' ? o.status !== 'failed' : job.payload.targets && !job.payload.targets.includes(o.id)) continue;
    const g = o.generation;
    if (!g || !['generate3d','photo'].includes(g.strategy)) continue;
    const needs = g.image_mode === 'edit' ? 'image.edit' : g.image_mode === 'text2image' ? 'image.generate' : null;
    if (needs && !models.some(m => (!g.image_model || m.id === g.image_model) && m.capabilities?.includes(needs))) return '这次外观修改需要的图片创作服务尚未接通，重复尝试不会改变结果。';
    const matches = models.filter(m => (!g.image_model || m.id === g.image_model) && m.capabilities?.includes(needs));
    if (needs && matches.length && !matches.some(m => m.available !== false)) return `图片编辑服务已配置，但暂时不可用（HTTP ${matches[0].last_http_status || 503}）。请约 ${Math.max(1, Math.ceil((matches[0].retry_after_seconds || 60) / 60))} 分钟后重试，已有内容已保留。`;
  }
  return '';
}
export function acceptedPatchMessage(patch, proposalId, jobs, scene) {
  const details = patchLines(patch, scene).join('；') + '。';
  if (patch.operations.length && patch.operations.every(op => op.type === 'remove') && patch.explanation) return '已保存为新的版本。' + patch.explanation;
  if (!patch.operations.some(op => ['regenerate','add'].includes(op.type))) return '已保存为新的版本。' + details;
  const build = jobs.find(j => j.kind === 'build' && j.payload.proposal_id === proposalId);
  if (!build) return '已提交外观修改。' + details + '请查看对应制作记录确认结果。';
  if (isActive(build)) return '正在重新制作外观，完成前保留当前版本。';
  if (build.status === 'succeeded') {
    const unchanged = patch.operations.filter(op => op.type === 'regenerate' && op.prompt &&
      build.steps?.some(s => s.name === `asset:${op.object_id}` && s.result?.meta?.operation === 'deterministic-procedural'));
    if (unchanged.length) return '这条历史记录只重新生成了程序几何，自由文字要求的形状修改并未执行。不能据此认定已经变成圆角等新形状。';
    return '这次外观修改已完成并保存。' + details;
  }
  if (build.status === 'partial') return '这次外观修改有一部分完成，请查看对应制作记录。';
  return '这次外观修改没有应用，当前保留原来的版本。';
}
export function inferRole(file, previousSources = []) {
  const type = file.type || '', ext = file.name.split('.').pop().toLowerCase();
  if (type.startsWith('audio/') || ['wav','mp3','m4a','ogg','flac','aac'].includes(ext)) return 'audio';
  if (['txt','md'].includes(ext)) return 'diary';
  // This is an upload hint only. The director still receives every picture.
  return previousSources.some(s => s.kind === 'image') ? 'object' : 'scene';
}
export function currentPlan(plans, project) {
  return plans.find(p => p.status === 'pending' && p.base_version === project.head && p.input_revision === project.input_revision) || null;
}
export function readyVersions(versions) {
  // Do not offer an empty project or a half-built layout as a normal undo target.
  return versions.filter(v => v.version > 0 && v.note !== '确认方案，建立布局草稿');
}
export function undoTarget(versions, head) {
  const list = readyVersions(versions), by = new Map(list.map(v => [v.version, v]));
  let origin = head;const visited = new Set();
  while (by.has(origin) && !visited.has(origin)) {
    visited.add(origin);
    const restored = /^从版本 (\d+) 恢复/.exec(by.get(origin).note || '');
    if (!restored) break;
    origin = Number(restored[1]);
  }
  return list.find(v => v.version < origin) || null;
}
export function versionNote(note = '') {
  if (note === '组件装配完成') return '回忆制作完成';
  if (note.startsWith('从版本 ')) return '恢复了以前保存的内容';
  if (/配色|颜色/.test(note)) return '调整了物品的颜色';
  if (/部分组件失败/.test(note)) return '部分内容已完成，其余可以继续制作';
  if (/局部编辑|修改/.test(note)) return '保存了一次修改';
  return note.slice(0, 55);
}
export function patchLines(patch, scene) {
  const by = new Map((scene?.objects || []).map(o => [o.id, o.label]));
  return (patch.operations || []).map(op => {
    const name = by.get(op.object_id) || '这件物品';
    if (op.type === 'add') return `${op.new_object?.label || '新物品'}：新增程序几何`;
    if (op.type === 'bind_frame') return `${name}：自动贴合海报`;
    if (op.type === 'restore_object') return `${name}：复用第 ${op.source_version} 版的原物品与尺寸`;
    if (op.type === 'resize') return op.size_edit?.scale != null ? `${name}：等比例缩放，保留位置和角度` : `${name}：调整指定尺寸，保留位置和未指定尺寸`;
    if (op.type === 'remove') return `${name}：从场景移除（可从历史恢复）`;
    if (op.type === 'audio') return '调整声音的播放效果';
    if (op.type === 'tint') return `${name}：调整配色`;
    if (op.type === 'clear_tint') return `${name}：取消整体染色，保留网格和摆放`;
    if (op.type === 'transform') return `${name}：调整位置或大小`;
    if (op.type === 'caption') return `${name}：更新文字说明`;
    if (op.type === 'regenerate') return `${name}：重新制作外观`;
    return `${name}：更新设置`;
  });
}
export function friendlyError(error) {
  const text = String(error?.message || error || ''), status = error?.status;
  if (status === 401) return '连接已过期，请重新输入访问口令。你的回忆还在。';
  if(error?.code==='agent_budget_exhausted'||/(?:调用|执行时间|复核)预算.*用完/.test(text))return '本次任务预算已用完，已停止追加调用。已有内容保留；请检查预算或明确发起新的请求，不要反复重试。';
  if(error?.code==='review_geometry_conflict'||/复核建议.*(?:落地|支撑|穿入)/.test(text))return '复核建议与实际落地或支撑关系冲突，未采用，当前版本不变。可以明确描述修改目标，不必重新生成整个场景。';
  if(['task_scope_ambiguous','task_scope_violation','task_postcondition_failed'].includes(error?.code))return '本次修改的目标或执行结果与要求不一致，已保留当前版本。请明确要改的物品和范围。';
  if (error?.code==='audio_model_unavailable' || /audio\.describe|需要音频理解服务/.test(text)) return '声音理解服务未启用。音乐可以直接作背景音：点音乐素材，将本项目音频用途设为“仅作背景声音”，再试一次。';
  if (/检查点.*输入已变化/.test(text)) return '这次修改任务的输入与旧检查点不一致，尚未应用。请重新发送修改要求；不要继续重试这条旧记录。';
  if (/锁定|object_locked/.test(text)) return '这件物品之前设为了保持不变。点选它后，可以选择“允许修改”。';
  if (error?.code === 'reference_quality_failed' || /建模参考图未通过内容校验/.test(text)) return '建模参考图的内容未通过校验，已停止对应的三维生成。原素材与参考图已保留，不是连接断开；请修正单主体参考图后重新制作。';
  if (/validation errors for ReferenceReview/.test(text)) return '参考图视觉校验没有返回可验证的报告，未继续三维生成。原素材已保存，请检查视觉校验服务后再试。';
  if (status === 409 || /过期|冲突|已经变化|资料已/.test(text)) return '回忆或素材刚刚有了变化。已保留原来的内容，请刷新后再试。';
  // This is already bounded/redacted by the provider. Preserve actionable
  // quota/permission details and the support request ID instead of hiding
  // every upstream failure behind a generic "try later" message.
  if (/StepFun/.test(text) && /上游错误码|请求编号/.test(text)) return text;
  if (/HTTP\s*429/i.test(text)) return '创作服务暂时限流（HTTP 429）。已有回忆已保留，请稍后重试，不要反复提交。';
  if (/HTTP\s*503/i.test(text)) return '创作服务暂时不可用（最近返回 HTTP 503），不是缺少配置。已有回忆已保留，请稍后重试；取消整体染色等本地修改仍可使用。';
  if (/HTTP\s*5\d\d/i.test(text)) return '创作服务暂时出错。已有回忆已保留，请稍后重试。';
  if (/provider_unavailable|服务暂时不可用|服务已配置.*暂时不可用/i.test(text)) return '创作服务已配置，但暂时不可用。已有回忆已保留，请稍后重试。';
  if (error?.code === 'provider_output_truncated' || /(?:JSON|token)[^。\n]{0,45}(?:被截断|上限.*截断)/i.test(text)) return '创作方案的回复过长，被截断了，尚未应用。不是素材丢失或连接断开；请调整导演输出预算后再试。';
  if (/旗舰输出.*未通过结构校验|模型未返回合法.*JSON|规划(?:布局|执行意图)未通过|validation errors for ScenePlan/i.test(text)) return '创作方案未通过校验，尚未应用到你的回忆。素材已保存；需要修正方案，不是创作服务未连接。';
  if (error?.code === 'audio_decoder_unavailable' || /ffmpeg/i.test(text)) return '本机音频解码工具尚未就绪，不是文件过大。请重新运行一键启动完成依赖安装，或先转换为 WAV。';
  if (/音频解码/.test(text)) return '这段音频解码失败或超时，请检查文件是否损坏、时长是否超过 30 分钟；已有素材不会丢失。';
  if (/没有已配置|模型未启用|缺少环境变量|model 名称|端点|配置/.test(text)) return '创作服务还没有接通。素材已经保存在本机，请负责部署的队友连接服务后再生成。';
  if (/超时|连接|网络|HTTP 50|Network|fetch/i.test(text)) return '与创作服务的连接暂时中断。已保存的内容不会丢失，稍后可点“再试一次”。';
  if (/格式|文件|音频|图片|过大|上限|413|UTF-8/.test(text)) return '这份文件暂时无法读取，或文件过大。请使用常见的照片、录音或文字文件。';
  if (/已被.*回忆|已经用于|素材.*制作/.test(text)) return text;
  if (/未通过|JSON|校验|schema/i.test(text)) return '创作方案的格式校验未通过，尚未应用到你的回忆。素材已保存，可以再试一次。';
  // Do not leak node paths, internal IDs or traces into the novice screen.
  if (/Traceback|\/|\\|cuda|GPU|\.py|token|模型|推理/i.test(text)) return '这次创作没有完成，原来的回忆已保留。请稍后再试，或联系负责部署的队友。';
  return text.slice(0, 220) || '操作暂时没有完成，请稍后再试。';
}
export function connectionText(snapshot) {
  const by=new Map((snapshot?.models||[]).map(m=>[m.model,m]));
  const director=by.get('director'),geometry=by.get('geometry'),image=by.get('image');
  if(!snapshot?.monitor_running)return '● 本机已连接 · 模型连接检查未运行';
  if([director,geometry,image].some(m=>m?.state==='checking'))return '● 本机已连接 · 正在检查模型连接';
  if(geometry?.state==='reconnecting')return '● 本机已连接 · 3D 正在自动重连';
  if(geometry&&geometry.state!=='connected')return '● 本机已连接 · 3D 尚未接通';
  if(director&&director.state!=='connected')return '● 本机已连接 · StepFun 尚未接通';
  if(image?.state==='reconnecting')return '● 本机已连接 · 图片服务正在自动重连';
  if(image&&image.state!=='connected')return '● 本机已连接 · 图片服务尚未接通';
  if(!director||!geometry)return '● 本机已连接 · 创作服务尚未配齐';
  return image?'● 本机 / StepFun / 图片 / 3D 已连接':'● 本机 / StepFun / 3D 已连接';
}
export function jobFailureDetail(job) {
  if (job.status === 'needs_review') {
    const result=job.result||{},code=result.auto_repair?.code||result.code;
    if(code!=='version_conflict'&&(result.asset_quality||result.auto_repair)){
      const referenceRejected=Object.values(result.asset_quality?.objects||{}).some(record=>{
        const last=record.candidates?.[record.candidates.length-1];return last?.stage==='reference'&&!last.accepted;
      });
      return referenceRejected?'建模参考图未通过验收，已停止继续制作此候选。原回忆不变；可查看参考图和多视角证据。':
        '本轮检查或修复没有通过验收，候选和证据已保留，原回忆不变。不会自动追加一轮修复。';
    }
    if (job.result?.checks?.some(c => ['support_mismatch','below_floor'].includes(c.type))) return '模型产物已保留，但摆放检查未通过，需要确认布局。当前回忆没有被覆盖。';
    return '制作期间回忆或素材发生变化，旧结果没有覆盖当前内容。请重新描述想法。';
  }
  if (job.status === 'cancelled') return '已保存的内容不会丢失，需要时可以继续。';
  const failure = job.error || job.steps?.find(s => s.status === 'failed' && s.error)?.error ||
    Object.values(job.result?.failures || {}).find(v => typeof v === 'string');
  const detail = friendlyError(failure || '可以稍后再试一次，已有内容不会丢失。');
  const labels = (job.result?.scene?.objects || []).filter(o => o.status === 'failed').map(o => o.label);
  return job.status === 'partial' && labels.length ? `${labels.join('、')}没有制作成功，其余内容已保留。${detail}` : detail;
}
export function progressText(jobs) {
  const active = jobs.find(isActive);
  if (!active) return null;
  const names = {plan:'正在理解照片、整理素材…', build:'正在把回忆变成立体画面…', edit:'正在理解你的修改…', review:'正在看看哪里还能更好…',repair:'正在多视角检查、针对性修复与复检（最多一轮）…'};
  const steps = active.steps || [];
  const ready = steps.filter(s => s.name?.startsWith('asset:') && s.status === 'succeeded').length;
  let note = active.kind === 'build' && ready ? `已做好 ${ready} 件物品，其余还在制作。` : '可以继续观看，请保持本机应用运行。';
  if (active.kind === 'build') {
    const labels = new Map((active.payload?.scene?.objects || []).map(o => [o.id, o.label || o.id]));
    const refs = steps.filter(s => s.name?.startsWith('reference:'));
    const pendingRefs = refs.filter(s => s.status === 'running');
    const geometry = steps.filter(s => s.name?.startsWith('asset:') && s.status === 'running');
    const reviews = steps.filter(s => s.name?.startsWith('quality:') && s.status === 'running');
    const items = list => list.slice(0, 3).map(s => labels.get(s.name.split(':')[1]) || s.name.split(':')[1]).join('、');
    const stages = [];
    if (pendingRefs.length) stages.push(`正在准备参考图：${items(pendingRefs)}（排队或图片编辑）`);
    if (reviews.length) stages.push(`正在检查参考图内容：${items(reviews)}`);
    if (geometry.length) stages.push(`正在制作三维物品：${items(geometry)}`);
    if (stages.length) {
      const prepared = refs.filter(s => s.status === 'succeeded').length;
      note = `${prepared ? `已准备 ${prepared} 张参考图；` : ''}${ready ? `已做好 ${ready} 件物品；` : ''}${stages.join('；')}。模型推理可能较久，请保持本机应用运行。`;
    }
  }
  if(active.kind==='repair'){
    const running=steps.filter(s=>s.status==='running').map(s=>s.name||'');
    if(running.includes('repair:inspect:before'))note='正在渲染实际模型并让大模型检查各方向；还未执行修复。';
    else if(running.includes('repair:commands'))note='正在将明确缺陷转换成对象绑定的可执行修复方案。';
    else if(running.some(n=>n.startsWith('reference:')))note='正在从原始素材准备修复参考图；当前已保存版本不变。';
    else if(running.includes('inspect:assembled-scene')||running.includes('repair:inspect:after'))note='正在对修复候选进行八向全景复检；通过后才保存。';
    else if(running.some(n=>n.startsWith('inspect:')||n.startsWith('reference-accept:')))note='正在检查修复参考或真实候选六向画面；不通过就停止本轮。';
    else if(running.some(n=>n.startsWith('geometry:')||n.startsWith('texture:')||n.startsWith('asset:')))note='正在调用3D节点制作指定修复候选；不会无限追加生成。';
  }
  return {id:active.id, title:names[active.kind] || '正在处理…', note};
}
