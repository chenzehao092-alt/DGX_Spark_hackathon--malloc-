import {MemoryViewer} from './viewer.js';
import {MemoryAudio} from './audio.js';
import {inferRole, isActive, currentPlan, readyVersions, undoTarget, versionNote, patchLines, friendlyError, jobFailureDetail, progressText, retryBlockReason, acceptedPatchMessage, patchIsCurrent, connectionText} from './simple.js';
import {mountSettings} from './settings.js';
import {cleanTech, memoryCardHTML, memoryDetailsHTML, objectDetailsHTML, decisionLines} from './provenance.js';
import {observationRequest,geometryEvidenceLines} from './agent.js';
import {qualityLines,qualityEvidence,reviewHeading,repairLines,jobQualityResult} from './quality.js';

const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// settingsDialog is initialised after esc is defined so its deps are usable
const settingsDialog = mountSettings({api, dialog, closeDialog, btn, toast, friendlyError, esc,
  onSaved:async()=>{state.config=await api('/api/config');controls();}});
const clock = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const date = t => new Date(t * 1000).toLocaleString('zh-CN', {month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});
const key = () => crypto.randomUUID?.() || Array.from(crypto.getRandomValues(new Uint8Array(16)), b=>b.toString(16).padStart(2,'0')).join('');
const state = {project:null, projects:[], scene:null, version:0, history:false, sources:[], jobs:[], plans:[], proposals:[], versions:[], selected:null, traceOpen:false, busy:false, config:null, autoDemo:null, generation:0, chatSignature:'', sourceSignature:'', notice:'', memory:null, memoryAt:0};
let viewer, audio, timer, polling = false, modalResolve = null, dialogCleanup=null;
const rights = new Set();
const base = (id = state.project?.id) => `/api/projects/${encodeURIComponent(id)}`;
const assetURL = id => `${base()}/assets/${encodeURIComponent(id)}`;
const draftKey = () => `ms-simple-draft:${state.project?.id || 'new'}`;
function getLocal(k){try{return localStorage.getItem(k);}catch{return null;}}
function putLocal(k,v){try{if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v);}catch{/* local persistence may be disabled */}}
function draftSave(){try{sessionStorage.setItem(draftKey(), $('chatInput').value);}catch{}}
function draftRead(){try{return sessionStorage.getItem(draftKey()) || '';}catch{return '';}}
function toast(text, bad = false) {const e = document.createElement('div');e.className = 'toast' + (bad ? ' bad' : '');e.textContent = text;$('toasts').append(e);setTimeout(()=>e.remove(), 7000);}
async function api(path, options = {}) {
  const headers = {...options.headers};let body = options.body;
  if (body !== undefined && !(body instanceof FormData) && typeof body !== 'string') {headers['Content-Type']='application/json';body=JSON.stringify(body);}
  let r;
  try {r=await fetch(path, {...options, headers, body});} catch {throw Error('网络连接中断');}
  if (!r.ok) {let err={};try{err=await r.json();}catch{}const e=Error(err.message || (typeof err.detail==='string' ? err.detail : '这次操作没有完成'));e.status=r.status;e.code=err.error;
    if (r.status===401) {clearInterval(timer);audio?.stop();$('studio').hidden=true;$('login').hidden=false;}
    throw e;
  }
  return options.raw ? r : r.status===204 ? null : r.json();
}
const post = (url, body={}, options={}) => api(url, {method:'POST',body,...options});
async function safe(fn) {try{return await fn();}catch(e){toast(friendlyError(e),true);}}
function on(id, fn) {$(id)?.addEventListener('click', ()=>safe(fn));}
function btn(text, fn, cls='secondary') {const b=document.createElement('button');b.type='button';b.className=cls;b.textContent=text;b.onclick=()=>safe(async()=>{if(b.disabled)return;b.disabled=true;try{await fn();}finally{if(b.isConnected)b.disabled=false;}});return b;}
function closeDialog() {$('modal').querySelectorAll('audio,video').forEach(a=>a.pause());dialogCleanup?.();dialogCleanup=null;$('modal').close();const done=modalResolve;modalResolve=null;if(done)done(false);}
function dialog(title, html, setup=()=>{}) {closeDialog();$('modalTitle').textContent=title;$('modalContent').innerHTML=html;$('modal').showModal();setup($('modalContent'));}
function ask(title, text, yes='继续', consent='') {
  return new Promise(resolve=>{dialog(title, `<p>${esc(text)}</p>${consent?`<label class="checkline"><input type="checkbox" id="dialogConsent">${esc(consent)}</label>`:''}<div class="modal-actions"><button id="dialogNo" class="secondary">暂时不要</button><button id="dialogYes" class="primary" ${consent?'disabled':''}>${esc(yes)}</button></div>`,()=>{
    modalResolve=resolve;on('dialogNo',closeDialog);on('dialogYes',()=>{const done=modalResolve;modalResolve=null;closeDialog();done?.(true);});
    if(consent)$('dialogConsent').onchange=()=>{$('dialogYes').disabled=!$('dialogConsent').checked;};
  });});
}
function showNotice(text){state.notice=text;renderChat(true);}
async function work(fn) {if(state.busy)return;state.busy=true;controls();try{return await fn();}finally{state.busy=false;controls();renderChat(true);}}
function hasScene(){return !!state.scene?.objects.length;}
function activeJob(){return state.jobs.find(isActive);}
function hasDirector(){return (state.config?.models || []).some(m=>m.capabilities?.includes('brain.plan'));}
function hasReadyModel(){return state.scene?.objects.some(o=>o.asset_id && o.status==='ready');}
function controls() {
  const active=activeJob(), disabled=state.busy || !!active || state.history;
  $('sendButton').disabled=disabled;
  $('sendLabel').textContent=active ? '正在制作，请稍候…' : hasScene() ? '发送修改' : '生成回忆';
  $('promptLabel').textContent=state.history ? '你正在看以前的版本' : hasScene() ? '还想改哪里？' : '你想怎样记住这一刻？';
  $('chatInput').placeholder=hasScene() ? '例如：调整物品摆放，其他地方保持不变。' : '例如：把这张照片里的实物变成立体展品，保留原本的外观。';
  $('uploadButton').disabled=state.busy || !!active || state.history;
  $('dropzone').setAttribute('aria-disabled', String(state.busy || !!active || state.history));
  $('exportButton').disabled=state.busy || !hasReadyModel() || !!active;
  $('historyButton').disabled=!state.project;
  const target=undoTarget(state.versions,state.project?.head);
  $('undoButton').disabled=disabled || !target;
  $('titleButton').disabled=state.busy || !!active;
  $('resetCamera').disabled=!hasScene();
  $('sourceHint').hidden=!state.sources.length;
  $('sourceHint').textContent=`${state.sources.length} 份素材 · 点击可查看或补充一句说明`;
  $('dropzone').hidden=!!state.sources.length;
  const selected=state.scene?.objects.find(o=>o.id===state.selected);
  $('selectedChip').hidden=!selected;$('selectedText').textContent=selected ? `这次只改：${selected.label}` : '';
  $('lockedHint').hidden=!selected?.locked;$('unlockButton').disabled=disabled;
  $('canvasHint').hidden=!hasScene();
  const progress=progressText(state.jobs);$('progressStrip').hidden=!progress;
  if(progress){$('progressTitle').textContent=progress.title;$('progressNote').textContent=progress.note;$('cancelTask').disabled=state.busy || active?.cancel===1;}
  $('sceneStatus').textContent=state.history ? '正在看以前的版本' : active ? '正在制作你的回忆' : hasReadyModel() ? '这一刻，已经留下了' : hasScene() ? '正在准备回忆画面' : '你的回忆，会在这里展开';
  $('saveStatus').textContent=state.history ? '旧版本只用于查看；回到当前版本才能继续修改。' : state.project ? '进度自动保存在本机 · 右上角可下载保存' : '照片与回忆保存在你的工作台';
  $('composerHint').textContent=state.project?.mode==='demo' ? '当前是虚构示例。可试改气球颜色；没有调用真实模型。' : state.history ? '在历史版本中点“回到当前版本”，即可继续创作。' : '生成后继续用一句话修改。不满意可以撤销。';
}
async function initialize() {
  state.config=await api('/api/config');$('login').hidden=true;$('studio').hidden=false;
  if(!viewer){
    viewer=new MemoryViewer($('viewport'),assetURL,{onSelect:selectObject,onError:()=>{$('renderNotice').hidden=false;},onCamera:c=>audio?.listener(c)});
    viewer.showLabels=false;
    audio=new MemoryAudio(assetURL,({time,duration,playing})=>{const known=duration||Math.max(0,...(state.scene?.audio||[]).map(t=>(t.duration||0)+t.start));$('timeCurrent').textContent=clock(time);$('timeDuration').textContent=known?clock(known):'—';$('timeSeek').max=Math.max(1,known);$('timeSeek').value=time;$('playButton').textContent=playing?'Ⅱ':'▶';$('playButton').setAttribute('aria-label',playing?'暂停声音':'播放回忆的声音');});
    $('renderNotice').hidden=!viewer.fallback;
  }
  await refreshProjects();const last=getLocal('ms-simple-project');
  const first=state.projects.find(p=>p.id===last) || state.projects[0];
  if(first)await openProject(first.id);else{controls();renderChat(true);quickPrompts();}
  clearInterval(timer);timer=setInterval(()=>poll(),1600);
  const models=await api('/api/settings/models');
  if(!models.director?.token_configured)await settingsDialog();
}
async function refreshProjects(){state.projects=await api('/api/projects');}
async function openProject(id) {
  draftSave();state.generation++;const epoch=state.generation;audio?.stop();state.project=null;state.selected=null;state.traceOpen=false;
  const [p,sources]=await Promise.all([api(base(id)),api(`${base(id)}/sources`)]);if(epoch!==state.generation)return;
  state.project=p;state.sources=sources;state.jobs=[];state.plans=[];state.proposals=[];state.versions=[];state.history=false;state.scene=null;state.notice='';state.chatSignature='';state.sourceSignature='';
  putLocal('ms-simple-project',id);$('chatInput').value=draftRead();setProjectHeading();renderSources();
  await refreshScene(true);await poll(true);quickPrompts();controls();
}
function setProjectHeading(){$('projectTitle').textContent=state.project?.title || '新的回忆';$('modeBadge').hidden=state.project?.mode!=='demo';$('modeBadge').textContent='虚构示例 · 非模型生成';}
async function refreshScene(reset=false, version) {
  if(!state.project)return;const id=state.project.id,epoch=state.generation;
  const [record,p]=await Promise.all([api(`${base(id)}/scene${version===undefined?'':`?version=${version}`}`),api(base(id))]);
  if(epoch!==state.generation || state.project?.id!==id)return;
  state.project=p;state.scene=record.scene;state.version=record.version;state.history=record.version!==p.head;
  if(!state.scene.objects.some(o=>o.id===state.selected))state.selected=null;
  viewer.setScene(state.scene,{selected:state.selected,mode:'memory',reset});audio.setScene(state.scene);
  $('emptyState').hidden=hasScene();const tracks=state.scene.audio.filter(a=>a.status==='ready'&&a.asset_id);
  $('audioBar').hidden=!tracks.length;$('audioHint').textContent=p.mode==='demo'?'测试声音，非真实生日录音':'原声与合成声音分别保留';
  renderTracePanels();controls();
}
function quickPrompts(){
  $('quickPrompts').replaceChildren();
  const selected=state.scene?.objects.find(o=>o.id===state.selected);
  const texts=hasScene()?[selected?`把${selected.label}稍微放大`:'保持外观，调整摆放位置','其他地方保持不变']:['生日聚会','旅行的一天'];
  for(const text of texts)$('quickPrompts').append(btn(text,()=>{$('chatInput').value=hasScene()?text:`请把这些${text==='生日聚会'?'生日聚会':'旅行'}的照片变成可观看的立体回忆，保留原来的声音。`;$('chatInput').focus();draftSave();},''));
}
async function createProject(title='我的回忆') {const p=await post('/api/projects',{title,mode:'real'});await refreshProjects();await openProject(p.id);return p;}
function newProjectDialog(){dialog('开始一段新的回忆','<label for="newTitle">给回忆起个名字</label><input id="newTitle" maxlength="100" placeholder="例如：我的十八岁生日"><p class="small muted">现在的回忆会保留，随时可以再打开。</p><div class="modal-actions"><button id="createProject" class="primary">开始</button></div>',()=>on('createProject',()=>work(async()=>{const title=$('newTitle').value.trim()||'我的回忆';closeDialog();await createProject(title);$('chatInput').focus();})));}
function replanDialog(){
  if(!state.project||state.busy||activeJob()||state.history)return;
  dialog('重新构思这段回忆',`<p class="notice">会重新阅读原始素材并提出完整方案。确认前不改变画面；原素材、声音和历史版本都保留。</p><label for="replanText">这次想保留什么？</label><textarea id="replanText" rows="5" maxlength="8000">${esc(state.project.requirements||'')}</textarea><div class="modal-actions"><button id="planAgain" class="primary">先制定新方案</button></div>`,()=>on('planAgain',async()=>{
    const text=$('replanText').value.trim();if(!text)return;
    if(state.project.mode==='real'&&!hasDirector()){toast('创作服务尚未接通。',true);return;}
    if(state.project.mode==='real'&&!state.project.remote_consent){
      if(!await ask('允许重新理解素材？','会将本项目照片与描述发送给已配置的创作服务。','允许并继续'))return;
      state.project=await api(base(),{method:'PATCH',body:{expected_input_revision:state.project.input_revision,remote_consent:true}});
    }
    await work(async()=>{
      if(text!==state.project.requirements)state.project=await api(base(),{method:'PATCH',body:{expected_input_revision:state.project.input_revision,requirements:text}});
      await post(`${base()}/plan`,{}, {headers:{'Idempotency-Key':key()}});
      closeDialog();state.notice='正在重新理解原始素材；确认新方案前保留当前画面。';await poll(true);
    });
  }));
}
async function demo() {
  if(state.busy || activeJob())return;
  await work(async()=>{
    await refreshProjects();let p=state.project?.mode==='demo' ? state.project : state.projects.find(x=>x.mode==='demo'&&x.title==='十八岁的夏天');
    if(!p)p=await post('/api/demo');await openProject(p.id);
    if(hasReadyModel()){toast('已打开生日示例。可以拖动观看，或试着修改气球颜色。');return;}
    state.autoDemo=p.id;
    const pending=currentPlan(state.plans,state.project);
    if(pending)await confirmPlan(pending);else if(!activeJob())await post(`${base()}/plan`,{}, {headers:{'Idempotency-Key':key()}});
    await poll(true);
  });
}
async function chooseFiles(){if(state.busy || activeJob() || state.history)return;$('fileInput').click();}
async function upload(files) {
  if(!files.length || state.busy || activeJob())return;
  const supported=files.filter(f=>/\.(png|jpe?g|webp|wav|mp3|m4a|aac|ogg|flac|mp4|txt|md)$/i.test(f.name));
  if(supported.length!==files.length)toast('有文件未加入。这里接收照片、录音和文字日记；保存过的回忆请从“打开回忆”导入。',true);
  if(!supported.length)return;
  if(state.project?.mode==='demo'){
    if(!await ask('用自己的素材开始','你正在观看虚构示例。我们会为这些素材新建一段回忆，不改动示例。','新建我的回忆'))return;
    await createProject('我的回忆');
  }
  if(!rights.has(state.project?.id || 'new')){
    if(!await ask('把素材加入你的回忆','上传后先保存在这台电脑。开始生成前，会另行确认是否允许发送给创作服务。','添加素材','我有权使用这些照片、录音和文字。'))return;
    rights.add(state.project?.id || 'new');
  }
  await work(async()=>{
    if(!state.project)await createProject();rights.add(state.project.id);
    const id=state.project.id,known=[...state.sources];let count=0;
    try{
      for(const file of supported){
        if(file.size>(state.config.max_upload_mb||128)*1024*1024){toast(`“${file.name}”太大，没有上传。`,true);continue;}
        const fd=new FormData();fd.set('file',file);fd.set('role',inferRole(file,known));fd.set('label',file.name);fd.set('rights_confirmed','true');
        const src=await post(`${base(id)}/sources`,fd);known.push(src);count++;
      }
    }finally{state.sources=await api(`${base(id)}/sources`);state.project=await api(base(id));renderSources();await poll(true);}
    if(count)toast(`已添加 ${count} 份素材。${hasScene()?'在下面说说要怎么修改；原场景不会自动改变。':'说一句你想怎样记住它们吧。'}`);
  });
}
function renderSources(){
  const sig=JSON.stringify(state.sources.map(s=>[s.id,s.label,s.note,s.crop]));if(sig===state.sourceSignature)return;state.sourceSignature=sig;
  $('sourceList').replaceChildren();for(const source of state.sources){const e=document.createElement('button');e.className='source-card';e.dataset.source=source.id;e.title=`查看：${source.label}`;e.innerHTML=(source.kind==='image'?`<img src="${assetURL(source.id)}" alt="${esc(source.label)}" loading="lazy">`:`<span class="source-icon" aria-hidden="true">${source.kind==='audio'?'♫':'≡'}</span>`)+`<span class="source-name">${esc(source.label)}</span>`;e.onclick=()=>safe(()=>sourceDialog(source));$('sourceList').append(e);}
  controls();
}
function sourceDialog(s){
  const visual=s.kind==='image'?`<img class="source-preview" src="${assetURL(s.id)}" alt="${esc(s.label)}">`:s.kind==='audio'?`<audio controls src="${assetURL(s.id)}"></audio>`:'<p class="notice">文字会在生成时和照片一起阅读。</p>';
  const audioOptions=s.kind==='audio'?`<label for="sourceAudioMode">本项目音频用途</label><select id="sourceAudioMode"><option value="passthrough" ${(state.project.audio_mode||'passthrough')==='passthrough'?'selected':''}>仅作背景声音（不分析内容）</option><option value="describe" ${state.project.audio_mode==='describe'?'selected':''}>理解录音内容（需音频模型）</option></select><p class="small muted">背景音乐直接保留和播放，不调用音频理解服务，也不猜歌词或声音内容。</p>`:'';
  dialog('关于这份素材',`${visual}${audioOptions}<label for="sourceNote">补充一句说明（可不填）</label><textarea id="sourceNote" rows="3" maxlength="1000" placeholder="例如：戴帽子的是我，这张和合影里的是同一个蛋糕。">${esc(s.note)}</textarea><p class="small muted">不需要分类或设置参数。可以说明人物关系、物品细节或你想保留的内容。</p><div class="modal-actions"><button id="removeSource" class="quiet danger">移除素材</button><button id="saveSource" class="primary">保存说明</button></div>`,()=>{
    $('saveSource').disabled=state.busy||!!activeJob()||state.history;$('removeSource').disabled=state.busy||!!activeJob()||state.history;
    on('saveSource',()=>work(async()=>{const note=$('sourceNote').value,audioMode=$('sourceAudioMode')?.value;await api(`${base()}/sources/${s.id}`,{method:'PATCH',body:{note}});state.project=await api(base());if(audioMode&&audioMode!==(state.project.audio_mode||'passthrough'))state.project=await api(base(),{method:'PATCH',body:{expected_input_revision:state.project.input_revision,audio_mode:audioMode}});closeDialog();state.sources=await api(`${base()}/sources`);renderSources();await poll(true);toast('说明已保存。原来的回忆不会被自动修改。');}));
    on('removeSource',async()=>{if(!await ask('移除这份素材？','移除后不再用于新创作。已被回忆使用的素材会受到保护；不会删除原文件。','移除'))return;await work(async()=>{await api(`${base()}/sources/${s.id}`,{method:'DELETE'});state.sources=await api(`${base()}/sources`);state.project=await api(base());renderSources();await poll(true);toast('已移除这份素材。');});});
  });
}
async function send() {
  if(state.busy || activeJob())return;
  const text=$('chatInput').value.trim();if(!text)return;
  if(state.history){toast('先回到当前版本，再继续修改。',true);return;}
  if(!state.project){await createProject();$('chatInput').value=text;draftSave();}
  if(state.project.mode==='real'&&!hasDirector()){showNotice('素材和文字可以先保存在本机。创作服务尚未接通，请负责部署的队友连接服务后再生成。');draftSave();return;}
  if(state.project.mode==='real'&&!state.project.remote_consent){
    if(!await ask('开始制作这段回忆？','需要把这段回忆的照片、录音和描述发送给已配置的创作服务。原始资料仍会保存在本机。','允许并继续'))return;
    state.project=await api(base(),{method:'PATCH',body:{expected_input_revision:state.project.input_revision,remote_consent:true}});
  }
  await work(async()=>{
    if(!hasScene()){
      state.project=await api(base(),{method:'PATCH',body:{expected_input_revision:state.project.input_revision,requirements:text}});
      await post(`${base()}/plan`,{}, {headers:{'Idempotency-Key':key()}});
    }else if(observationRequest(text)){
      await queueVisualReview(text);
    }else{
      // The explicitly named target may differ from the old selection.
      // The server checks locks on actual operations, not stale UI focus.
      await post(`${base()}/edit`,{prompt:text,selected_object:state.selected,base_version:state.version},{headers:{'Idempotency-Key':key()}});
    }
    $('chatInput').value='';draftSave();state.notice='';await poll(true);
  });
}
async function queueVisualReview(prompt='检查当前画面的布局、尺寸和明显错误；只给出建议，不自动修改。') {
  if(!hasScene()||state.history)throw Error('请先打开当前已完成的回忆。');
  if(viewer.fallback)throw Error('当前浏览器无法提供真实三维截图，请启用 WebGL 后复核；未用空白图替代。');
  const id=state.project.id,version=state.version;
  const selected=state.selected,views=await viewer.captureViews({objectId:selected}),render_ids=[];
  for(const view of views){
    if(state.project?.id!==id||state.version!==version)throw Error('截图期间场景变化，请重新复核。');
    const fd=new FormData();fd.set('version',String(version));fd.set('camera',JSON.stringify(view.camera));fd.set('file',view.blob,`review-${view.name}.png`);
    const render=await post(`${base(id)}/renders`,fd);render_ids.push(render.id);
  }
  await post(`${base(id)}/review`,{base_version:version,render_ids,coverage_mode:'canonical',prompt:prompt.slice(0,2000),round:0,selected_object:selected},{headers:{'Idempotency-Key':key()}});
}
async function reviewCurrentView(){
  if(state.busy||activeJob())return;
  if(state.project?.mode==='real'&&!hasDirector()){toast('创作服务未连接，无法进行截图复核。',true);return;}
  if(state.project?.mode==='real'&&!state.project.remote_consent){
    if(!await ask('多视角复核？','会检查选中物品的六个方向，未选中则检查全景八个方向，发送真实模型截图和相关素材。只给建议，不自动修改。','允许并复核'))return;
    state.project=await api(base(),{method:'PATCH',body:{expected_input_revision:state.project.input_revision,remote_consent:true}});
  }
  await work(async()=>{await queueVisualReview();state.notice='正在复核真实画面；建议需要确认后才会应用。';await poll(true);});
}
async function repairCurrentView(){
  if(state.busy||activeJob()||state.history||!hasScene())return;
  const selected=state.selected;
  if(!await ask('检查并执行一轮修复？',`会发送${selected?'选中物品六向':'场景八向'}真实模型截图和相关原素材给已配置模型。最多修复${selected?'一件':'三件'}物品，每件一轮，可能调用图片和3D模型。通过复检才保存新版本，不通过保留候选；不会删除物品或解锁。`,'允许检查并修复'))return;
  await work(async()=>{
    if(!state.project.remote_consent)state.project=await api(base(),{method:'PATCH',body:{expected_input_revision:state.project.input_revision,remote_consent:true}});
    await post(`${base()}/quality-repair`,{base_version:state.version,input_revision:state.project.input_revision,
      user_approved:true,selected_object:selected,max_objects:selected?1:3,
      prompt:'检查真实模型的多角度画面，修复有明确证据的严重缺陷，其他内容保持不变。'}, {headers:{'Idempotency-Key':key()}});
    state.notice='正在多视角检查并修复；最多一轮，通过复检才保存。';await poll(true);
  });
}
async function confirmPlan(plan) {
  const id=state.project.id;
  await post(`${base(id)}/plans/${plan.id}/confirm`,{expected_version:plan.base_version,expected_input_revision:plan.input_revision},{headers:{'Idempotency-Key':`simple-confirm-${plan.id}`}});
  state.autoDemo=null;state.notice='';await refreshScene(true);await poll(true);
}
function appendMessage(parent, text, user=false){const e=document.createElement('div');e.className='message '+(user?'user':'assistant');e.textContent=text;parent.append(e);}
function renderChat(force=false) {
  const sig=JSON.stringify([state.project?.id,state.project?.head,state.project?.input_revision,state.history,state.jobs.map(j=>[j.id,j.status,j.updated]),state.plans.map(p=>[p.id,p.status]),state.proposals.map(p=>[p.id,p.status]),state.notice]);
  if(!force&&sig===state.chatSignature)return;state.chatSignature=sig;
  const log=$('chatMessages'),nearBottom=log.scrollHeight-log.scrollTop-log.clientHeight<80,oldTop=log.scrollTop;log.replaceChildren();
  const welcome=document.createElement('div');welcome.className='welcome-note';welcome.innerHTML=`<span class="assistant-avatar" aria-hidden="true">✧</span><div><strong>${hasScene()?'回忆在这里，想怎么改都可以说。':'你好，一起留住这一刻吧。'}</strong>${state.project?.mode==='demo'?'这是一个虚构生日示例。可以体验观看、改色、撤销和保存；没有使用真实模型。':'放进照片或声音，然后告诉我那天发生了什么。你也可以直接在下方写一段日记。'}</div>`;log.append(welcome);
  if(state.history){const card=document.createElement('div');card.className='chat-card';card.innerHTML='<p>你正在看以前的版本，当前版本没有被改变。</p>';card.append(btn('回到当前版本',()=>work(async()=>{await refreshScene();renderChat(true);}),'primary'));log.append(card);}
  const plan=currentPlan(state.plans,state.project || {}),proposals=new Map(state.proposals.map(p=>[p.id,p]));
  for(const j of [...state.jobs].reverse().slice(-14)){
    if(j.kind==='plan' && (j.payload.ui_prompt||j.payload.requirements))appendMessage(log,j.payload.ui_prompt||j.payload.requirements,true);
    if(['edit','review','repair'].includes(j.kind))appendMessage(log,j.payload.prompt,true);
    if(isActive(j))continue;
    if(j.kind==='repair'&&j.result?.auto_repair)appendMessage(log,repairLines(j.result).map(cleanTech).join('\n'));
    if(j.kind==='build'&&j.result?.asset_quality)appendMessage(log,'历史制作验收（只对应该次产物，不代表后续修改后的版本）：\n'+qualityLines(j.result).map(cleanTech).join('\n'));
    if(j.kind==='build'&&j.status==='succeeded'&&j.result?.quality_warnings?.length){
      appendMessage(log,'制作流程已完成，以下质量提示未阻断制作：\n'+j.result.quality_warnings.map(w=>cleanTech(w.message)).join('\n'));
    }
    if(['failed','partial','cancelled','needs_review'].includes(j.status)){
      const card=document.createElement('div');card.className='chat-card error-card';
      const title=j.status==='partial'?'这次制作有一部分没完成':j.status==='cancelled'?'已经停止这次制作':j.status==='needs_review'?'保留了原来的回忆':'这次还没做好';
      let failDetail=esc(jobFailureDetail(j));
      const retryBlocked=retryBlockReason(j,state.project,state.scene,state.config?.models||[]);
      if(retryBlocked)failDetail=failDetail.replace('可以稍后再试一次。','');
      card.innerHTML=`<h3>${title}</h3><p>${failDetail}</p>`;
      if(retryBlocked){const note=document.createElement('p');note.textContent=retryBlocked;card.append(note);}
      if(!retryBlocked&&!activeJob()&&!state.history&&['failed','partial','cancelled'].includes(j.status)){
        card.append(btn('再试一次',()=>work(async()=>{await post(`/api/jobs/${j.id}/retry`);state.notice='';await poll(true);}), 'secondary'));
      }
      log.append(card);continue;
    }
    if(j.kind==='plan'&&j.result?.plan_id){
      const p=state.plans.find(p=>p.id===j.result.plan_id);
      if(p?.id===plan?.id&&!state.history){
        const card=document.createElement('div');card.className='chat-card plan-card';card.dataset.plan=p.id;
        const b=p.body;card.innerHTML=`<h3>这样留下这段回忆，好吗？</h3><p>${esc(cleanTech(b.summary))}</p><p class="small muted">画面里会有：${b.scene.objects.map(o=>esc(o.label)).join('、')}。</p>`;
        const notes=[...(b.confirmations||[]),...(b.warnings||[]),...(b.scene.assumptions||[])].map(cleanTech);
        if(notes.length){const n=document.createElement('p');n.className='warning';n.textContent=notes.join('\n');card.append(n);}
        const actions=document.createElement('div');actions.className='card-buttons';actions.append(btn('我想调整一下',()=>replanDialog()));
        const btt=btn('就按这个生成',()=>work(()=>confirmPlan(p)),'primary');btt.id='confirmPlan';btt.disabled=state.busy||!!activeJob();actions.append(btt);card.append(actions);log.append(card);
      }else if(p?.status==='accepted'){appendMessage(log,'已按确认的想法开始制作。');}
      else if(p&&p.status==='pending'&&p.id===state.plans[0]?.id){appendMessage(log,'素材或回忆已有变化，之前的想法暂未执行。在下方重新描述，就能制定新的方案。');}
    }
    if(j.kind==='build'&&j.status==='succeeded')appendMessage(log,'做好了。拖动画面就能换个角度看；还想改哪里，直接告诉我。每次修改都可以回到以前的版本。');
    if(['edit','review'].includes(j.kind)&&j.result?.proposal_id){
      if(j.kind==='review'){
        const facts=geometryEvidenceLines(j.result.observation?.display_geometry);
        if(facts.length)appendMessage(log,'程序核对（不是视觉推测）：\n'+facts.join('\n')+'\n包围盒接触不证明精确的网格物理接触。');
      }
      if(j.kind==='review'&&j.result.review)appendMessage(log,reviewHeading(j)+cleanTech(j.result.review.summary)+(j.result.review.findings?.length?'\n'+j.result.review.findings.map(cleanTech).join('\n'):'')+(j.result.review.view_findings?.length?'\n'+j.result.review.view_findings.map(f=>cleanTech(`${f.view} · ${f.evidence}`)).join('\n'):''));
      const proposal=proposals.get(j.result.proposal_id),patch=j.result.patch || proposal?.body;
      if(!patch)continue;
      if(!patch.operations.length){appendMessage(log,'当时的模型答复（未修改场景）：'+cleanTech(patch.explanation));continue;}
      if(proposal?.status==='accepted'){
        const prefix=patchIsCurrent(patch,proposal.id,state.jobs,state.versions[0])?'':'历史记录（当前状态以最新版本为准）：';
        appendMessage(log,prefix+acceptedPatchMessage(patch,proposal.id,state.jobs,state.scene));continue;}
      if(proposal?.status==='dismissed'){appendMessage(log,'这次保持原样，没有修改你的回忆。');continue;}
      if(patch.base_version!==state.project.head){appendMessage(log,'这条修改建议对应以前的版本，未覆盖你后来的修改。');continue;}
      const card=document.createElement('div');card.className='chat-card edit-card';card.innerHTML=`<h3>准备这样修改</h3><p>${esc(cleanTech(patch.explanation))}</p><p class="small muted">${patchLines(patch,state.scene).map(esc).join('<br>')}</p>`;
      if(patch.operations.some(o=>['regenerate','add'].includes(o.type))){const n=document.createElement('p');n.className='warning';n.textContent='这次需要制作新增物品或部分外观。确认后才开始，完成前保留当前版本。';card.append(n);}
      if(patch.operations.some(o=>o.type==='remove')){const n=document.createElement('p');n.className='warning';n.textContent='确认后只移除指定物品，不删除原始素材和历史版本。不会自动移动其他物品。';card.append(n);}
      const actions=document.createElement('div');actions.className='card-buttons';
      actions.append(btn('保持原样',()=>work(async()=>{await post(`${base()}/proposals/${j.result.proposal_id}/dismiss`);await poll(true);})));const accept=btn('采用这次修改',()=>work(async()=>{const applied=await post(`${base()}/proposals/${j.result.proposal_id}/apply`);await refreshScene();await poll(true);toast(applied.job_id?'正在制作，完成后才会保存新版本。':'已保存这次修改，不满意可以撤销。');}),'primary');accept.id='applyPatch';accept.disabled=state.busy||!!activeJob()||state.history;actions.append(accept);card.append(actions);log.append(card);
    }
  }
  const latest=state.versions[0];if(latest?.note.startsWith('从版本 '))appendMessage(log,'已恢复到以前的内容。刚才的其他版本仍然可以在历史里找到。');
  if(state.notice)appendMessage(log,state.notice);
  if(nearBottom||force)log.scrollTop=log.scrollHeight;else log.scrollTop=oldTop;
}
async function poll(force=false) {
  if((polling&&!force)||!state.project)return;const id=state.project.id,epoch=state.generation;polling=true;
  try{
    const [p,jobs,plans,proposals,versions,connection]=await Promise.all([api(base(id)),api(`${base(id)}/jobs`),api(`${base(id)}/plans`),api(`${base(id)}/proposals`),api(`${base(id)}/versions`),api('/api/connectivity')]);
    if(state.project?.id!==id||epoch!==state.generation)return;
    const changed=p.head!==state.project.head;state.project=p;state.jobs=jobs;state.plans=plans;state.proposals=proposals;state.versions=versions;
    if(state.notice.startsWith('正在复核真实画面')&&!jobs.some(j=>j.kind==='review'&&isActive(j)))state.notice='';
    if(state.notice.startsWith('正在多视角检查并修复')&&!jobs.some(j=>j.kind==='repair'&&isActive(j)))state.notice='';
    // Cooldown expiry/configuration changes are facts independent of job
    // progress. Refresh metadata without another external inference request.
    if(Date.now()-(state.configAt||0)>30000){
      try{state.config=await api('/api/config');state.configAt=Date.now();state.chatSignature='';}catch{/* keep last known metadata */}
    }
    if(state.project?.id!==id||epoch!==state.generation)return;
    $('networkStatus').textContent=connectionText(connection);$('networkStatus').title=connection.note||'';
    if(changed&&!state.history){state.memory=null;await refreshScene();quickPrompts();}
    const running=jobs.find(j=>j.kind==='build'&&j.status==='running'&&j.payload.base_version===state.version);
    if(running&&!state.history){const preview=await api(`/api/jobs/${running.id}/preview`);if(state.project?.id===id&&preview?.base_version===state.version){viewer.setScene(preview.scene,{selected:state.selected,mode:'memory'});$('emptyState').hidden=!!preview.scene.objects.length;}}
    controls();renderChat();
    const pending=currentPlan(plans,p);
    if(state.autoDemo===id&&p.mode==='demo'&&pending&&!jobs.some(isActive)){state.autoDemo=null;await confirmPlan(pending);}
  }catch(e){if(e.status!==401){$('networkStatus').textContent='● 连接暂时中断';}}finally{polling=false;}
}
function loadMemory(force=false){
  if(!state.project)return Promise.resolve(null);
  if(!force&&state.memory&&Date.now()-state.memoryAt<30000)return Promise.resolve(state.memory);
  return api(`${base()}/memory`).then(m=>{state.memory=m;state.memoryAt=Date.now();return m;}).catch(()=>{state.memory=null;return null;});
}
function renderMemoryCard(){
  const card=$('memoryCard');
  card.hidden=false;
  card.innerHTML=memoryCardHTML(state,{esc,assetURL});
}
function closeTraceDrawer(clearSelection=false){
  if(clearSelection)state.selected=null;
  state.traceOpen=false;
  $('traceDrawer').classList.remove('open');
  $('traceDrawer').setAttribute('aria-hidden','true');
  $('traceBackdrop').hidden=true;
  if(viewer){viewer.selected=state.selected;viewer.dirty=true;}
  controls();
}
function openTraceDrawer(){
  state.traceOpen=true;
  $('traceDrawer').classList.add('open');
  $('traceDrawer').setAttribute('aria-hidden','false');
  $('traceBackdrop').hidden=false;
}
async function renderTraceDrawer(){
  const obj=$('objectDetails');
  if(!state.traceOpen){closeTraceDrawer();return;}
  const o=state.scene?.objects.find(x=>x.id===state.selected);
  const mem=await loadMemory();
  if(o){
    const decisions=(mem?.recent_decisions||[]).filter(d=>d.object_id===o.id);
    obj.innerHTML=objectDetailsHTML(o,{esc,assetURL,scene:state.scene,decisions,sources:state.sources});
  }else{
    obj.innerHTML=memoryDetailsHTML(state,{esc,assetURL,decisions:mem?.recent_decisions||[]});
  }
  openTraceDrawer();
}
function renderTracePanels(){renderMemoryCard();if(state.traceOpen)renderTraceDrawer().catch(()=>closeTraceDrawer());}
function bindTracePanels(){
  $('tracePanels').addEventListener('click',e=>{
    const t=e.target.closest('[data-action],[data-source]');if(!t)return;
    if(t.dataset.action==='add-material'){chooseFiles();return;}
    if(t.dataset.action==='open-memory'){state.selected=null;state.traceOpen=true;renderTraceDrawer().catch(()=>toast('暂时无法打开追迹详情。',true));return;}
  });
  $('traceDrawer').addEventListener('click',e=>{
    const t=e.target.closest('[data-action],[data-source]');if(!t)return;
    if(t.dataset.action==='close-drawer'){closeTraceDrawer(true);return;}
    if(t.dataset.action==='sources'){const o=state.scene?.objects.find(x=>x.id===state.selected);const ref=(o?.reference_ids||[]).map(id=>state.sources.find(s=>s.id===id)).filter(Boolean)[0];if(ref)sourceDialog(ref);else toast('这件物品没有直接关联的上传素材。');return;}
    if(t.dataset.action==='history'){historyDialog();return;}
    if(t.dataset.action==='edit'){$('chatInput').focus();$('chatInput').placeholder='告诉我你想怎样修改这个物品…';return;}
    if(t.dataset.source){const s=state.sources.find(x=>x.id===t.dataset.source);if(s)sourceDialog(s);}
  });
  $('traceBackdrop').addEventListener('click',()=>closeTraceDrawer(true));
}
function selectObject(id){state.selected=state.scene?.objects.some(o=>o.id===id)?id:null;state.traceOpen=!!state.selected;viewer.selected=state.selected;viewer.dirty=true;controls();renderTracePanels();if(id){$('chatInput').placeholder='告诉我你想怎样修改这个物品…';}}
async function undo(){
  const target=undoTarget(state.versions,state.project.head);if(!target||activeJob())return;
  await work(async()=>{await post(`${base()}/restore`,{version:target.version,expected_version:state.project.head});await refreshScene();await poll(true);toast('已撤销上次修改。撤销前的内容也保留在历史里。');});
}
async function historyDialog(){
  if(!state.project)return;
  state.versions=await api(`${base()}/versions`);const versions=readyVersions(state.versions);
  dialog('以前的回忆都在这里',`<p class="small muted">每次修改都会自动留一份。查看不会改变当前内容；恢复后，也不会删除其他版本。</p>${state.history?'<button id="backCurrent" class="secondary">回到当前版本</button>':''}<div id="historyList"></div>`,()=>{
    on('backCurrent',async()=>{closeDialog();await refreshScene();renderChat(true);});const list=$('historyList');
    if(!versions.length){list.innerHTML='<p class="notice">第一次制作完成后，这里就会出现保存记录。</p>';return;}
    for(const v of versions){const row=document.createElement('div');row.className='history-row';const label=v.version===state.project.head?'当前版本':'以前保存的版本';row.innerHTML=`<div><b>${label}</b><p>${esc(cleanTech(versionNote(v.note)))}</p><p>${date(v.created)} · 第 ${v.version} 次保存</p></div><div class="history-actions"></div>`;const actions=row.lastElementChild;
      actions.append(btn('查看',async()=>{closeDialog();await refreshScene(false,v.version);renderChat(true);}));
      if(v.version!==state.project.head){const restore=btn('恢复',async()=>{closeDialog();if(!await ask('恢复到这次保存？','现在的内容仍会保留在历史里，之后也能找回来。','恢复这个版本'))return;await work(async()=>{await post(`${base()}/restore`,{version:v.version,expected_version:state.project.head});await refreshScene();await poll(true);toast('已恢复。其他版本也都保留着。');});});restore.disabled=!!activeJob();actions.append(restore);}
      list.append(row);
    }
  });
}
async function saveMemory(){
  if(!state.project||!hasReadyModel())return;
  if(!await ask('把这段回忆保存下来','会下载一个回忆文件，包含画面、声音、日记和所用参考照片。再次打开拾光就能导入。分享给别人前，请确认里面没有不想公开的内容。','下载保存'))return;
  await work(async()=>{
    // Preserve a real browser-rendered preview with the current saved scene.
    if(!state.history && !viewer.fallback){
      await viewer.ready(); const preview=await viewer.screenshot(),fd=new FormData();
      fd.set('version',String(state.version));fd.set('camera',JSON.stringify(viewer.camera()));
      fd.set('file',preview,'preview.png');await post(`${base()}/renders`,fd);
    }
    // Use an authenticated same-origin HTTP attachment rather than a blob URL.
    // Embedded browsers can handle network downloads even when blob downloads
    // are not exposed by their download manager. No credential goes in the URL.
    const a=document.createElement('a');a.href=`${base()}/export?version=${state.version}&originals=false`;a.download=`${state.project.title.replace(/[\\/:*?"<>|]/g,'_')}.memory.zip`;document.body.append(a);a.click();a.remove();toast('已请求下载回忆文件，请查看浏览器下载列表。以后从“打开回忆”导入即可。');
  });
}
async function geometryFactsDialog(){
  if(!hasScene()||state.history)throw Error('请打开当前版本后再核对。');
  const id=state.project.id,version=state.version;
  const memory=await api(`${base(id)}/memory`);
  if(state.project?.id!==id||state.version!==version||memory.version!==version)throw Error('核对期间场景已变化，请重新打开。');
  const lines=geometryEvidenceLines(memory.display_geometry);
  dialog('程序核对 · 当前第 '+version+' 版',`<p>这一步只读取已生成模型的包围盒和摆放数据，不调用 AI、不修改相册。</p><p>坐标原点在物体底部中心，Y=0 是地面；不是几何中心，不能通过减去半个高度判定悬空。</p>${lines.length?'<ul>'+lines.map(line=>`<li>${esc(line)}</li>`).join('')+'</ul>':'<p>当前没有可确定的直立模型落地/支撑证据，未用请求尺寸冒充实际模型。</p>'}<p class="small muted">这里只核对包围盒高度，不证明完整网格的精确接触、碰撞或外观质量。倾斜物体需要结合实际画面查看。</p>`);
}
function qualityEvidenceDialog(){
 const job=state.jobs.find(j=>{const r=jobQualityResult(j);return r?.asset_quality||r?.auto_repair;});
 const sections=qualityEvidence(jobQualityResult(job));
 dialog('多视角验收证据',`<p class="notice">历史检查只对应原候选，不证明现在的版本或不可见背面真实还原。模型视图由实际 GLB 渲染；标注为“建模参考图”的图片是图片编辑结果，不是3D截图。</p>${job?`<p class="small muted">检查记录 ${esc(job.id)} · ${date(job.created)}</p>`:'<p>旧版本没有六向验收记录。可直接查看当前网格，或在下一次制作后查看自动检查证据。</p>'}<div id="qualityEvidence"></div><div class="modal-actions"><button id="captureEvidence" class="secondary">查看当前${state.selected?'选中物体六向':'场景八向'}截图（不调用 AI）</button></div>`,()=>{
  const gallery=$('qualityEvidence'),urls=[];dialogCleanup=()=>urls.forEach(url=>URL.revokeObjectURL(url));
  function append(title,report){
   const section=document.createElement('section'),heading=document.createElement('h3');heading.textContent=title;section.append(heading);
   const text=document.createElement('p');text.textContent=report.summary||'只提供截图证据，未由 AI 评价，不代表质量通过。';section.append(text);
   if(report.asset_sha256){const hash=document.createElement('p');hash.className='small muted';hash.textContent=`GLB SHA256: ${report.asset_sha256}`;section.append(hash);}
   const grid=document.createElement('div');grid.className='quality-grid';
   for(const r of report.renders||[]){const item=document.createElement('a');item.href=r.url||assetURL(r.asset_id);item.target='_blank';item.rel='noopener';const img=document.createElement('img');img.src=item.href;img.alt=r.view;img.loading='lazy';const label=document.createElement('span');label.textContent=r.view;item.append(img,label);grid.append(item);}section.append(grid);gallery.append(section);
  }
  sections.forEach(s=>append(s.title,s.report));
  $('captureEvidence').disabled=!hasReadyModel()||state.history;
  on('captureEvidence',async()=>{
   const button=$('captureEvidence');if(button.disabled)return;button.disabled=true;const generation=state.generation,objectId=state.selected;
   try{const views=await viewer.captureViews({objectId});if(state.generation!==generation||!gallery.isConnected||!$('modal').open)return;
    const renders=views.map(v=>{const url=URL.createObjectURL(v.blob);urls.push(url);return {view:v.name,url};});append('当前网格 · 仅截图', {renders});
   }finally{if(button.isConnected)button.disabled=false;}
  });
 });
}
function menu(){dialog('我的回忆','<div class="menu-grid"><button id="newButton">＋ 开始新的回忆</button><button id="openButton">打开以前的回忆</button><button id="importButton">导入已保存的回忆文件</button><button id="replanButton">重新构思当前回忆</button><button id="reviewButton">检查当前画面（只给建议）</button><button id="repairButton">检查并修复（最多一轮）</button><button id="qualityEvidenceButton">查看多视角验收证据</button><button id="geometryFactsButton">查看程序核对（不调用 AI）</button><button id="settingsButton">StepFun 设置</button><button id="logoutButton">退出</button></div>',()=>{
  $('reviewButton').disabled=!hasScene()||state.history||state.busy||!!activeJob();on('reviewButton',()=>{closeDialog();return reviewCurrentView();});
  $('repairButton').disabled=!hasScene()||state.history||state.busy||!!activeJob()||state.project?.mode!=='real';on('repairButton',()=>{closeDialog();return repairCurrentView();});
  $('geometryFactsButton').disabled=!hasScene()||state.history;on('geometryFactsButton',geometryFactsDialog);
  $('qualityEvidenceButton').disabled=!state.project;on('qualityEvidenceButton',qualityEvidenceDialog);
  $('replanButton').disabled=!state.project||state.busy||!!activeJob()||!!state.history;on('replanButton',()=>{closeDialog();replanDialog();});
  on('newButton',()=>{closeDialog();newProjectDialog();});on('openButton',openDialog);on('importButton',()=>{closeDialog();$('importInput').click();});on('demoButton',()=>{closeDialog();return demo();});on('settingsButton',()=>{closeDialog();settingsDialog();});on('logoutButton',async()=>{await api('/api/session',{method:'DELETE'});closeDialog();clearInterval(timer);audio.stop();state.generation++;$('studio').hidden=true;$('login').hidden=false;});
});}
async function openDialog(){await refreshProjects();dialog('打开以前的回忆','<div id="projectList"></div><div class="modal-actions"><button id="openSavedFile" class="secondary">从文件导入</button></div>',()=>{const list=$('projectList');if(!state.projects.length)list.innerHTML='<p class="muted">还没有保存的回忆。</p>';for(const p of state.projects){const row=document.createElement('div');row.className='project-row';const name=document.createElement('div');name.innerHTML=`<b>${esc(p.title)}</b><p class="small muted">${p.mode==='demo'?'虚构示例 · ':''}${date(p.updated)}</p>`;row.append(name,btn('打开',async()=>{closeDialog();await openProject(p.id);}));list.append(row);}on('openSavedFile',()=>{closeDialog();$('importInput').click();});});}
function renameDialog(){if(!state.project){newProjectDialog();return;}dialog('给这段回忆改个名字',`<input id="renameInput" aria-label="回忆名称" maxlength="100" value="${esc(state.project.title)}"><div class="modal-actions"><button id="renameSave" class="primary">保存名字</button></div>`,()=>on('renameSave',()=>work(async()=>{const title=$('renameInput').value.trim();if(!title)return;state.project=await api(base(),{method:'PATCH',body:{expected_input_revision:state.project.input_revision,title}});closeDialog();setProjectHeading();await refreshProjects();await poll(true);})));}
function help(){dialog('三步就会用','<p><b>1. 连接与添加素材</b><br>在顶部 StepFun 设置中输入 API Key，再上传你有权使用的真实照片。</p><p><b>2. 说说你的想法</b><br>例如“按这张照片生成物品，放在一个简单底座上”。确认我们理解的内容后，就会请求远端 3D 模型制作。</p><p><b>3. 接着修改，再保存</b><br>继续说“把物品移动到底座中央”。想只改一件物品，可以先点它。右上角能保存，历史里能找回以前的版本。</p><p class="notice">3D 模型运行在 server6 / DGX Spark，本机展示结果。云端服务不可用时会报告错误，不会用示例偷偷替代你的照片。</p>');}

bindTracePanels();
$('loginForm').onsubmit=e=>{e.preventDefault();safe(async()=>{try{await post('/api/session',{}, {headers:{Authorization:'Bearer '+$('token').value.trim()}});$('token').value='';$('loginError').textContent='';await initialize();}catch(err){$('loginError').textContent=friendlyError(err);}});};
$('modal').addEventListener('cancel',e=>{e.preventDefault();closeDialog();});on('closeModal',closeDialog);
$('modal').addEventListener('click',e=>{const rect=$('modal').getBoundingClientRect();if(e.target===$('modal')&&(e.clientX<rect.left||e.clientX>rect.right||e.clientY<rect.top||e.clientY>rect.bottom))closeDialog();});
on('titleButton',renameDialog);on('menuButton',menu);on('modelSettingsButton',settingsDialog);on('historyButton',historyDialog);on('exportButton',saveMemory);on('undoButton',undo);on('emptyDemo',demo);on('resetCamera',()=>viewer.reset());on('helpButton',help);
on('uploadButton',chooseFiles);on('dropzone',chooseFiles);$('dropzone').onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();safe(chooseFiles);}};
$('fileInput').onchange=()=>safe(async()=>{const files=[...$('fileInput').files];$('fileInput').value='';await upload(files);});
for(const event of ['dragenter','dragover'])$('dropzone').addEventListener(event,e=>{e.preventDefault();$('dropzone').classList.add('drag');});
$('dropzone').addEventListener('dragleave',()=>$('dropzone').classList.remove('drag'));
$('dropzone').addEventListener('drop',e=>{e.preventDefault();$('dropzone').classList.remove('drag');safe(()=>upload([...e.dataTransfer.files]));});
$('chatForm').onsubmit=e=>{e.preventDefault();safe(send);};$('chatInput').addEventListener('input',draftSave);
$('chatInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.keyCode!==229){e.preventDefault();safe(send);}});
on('clearSelection',()=>closeTraceDrawer(true));on('unlockButton',async()=>{const o=state.scene.objects.find(o=>o.id===state.selected);if(!o)return;if(!await ask('允许修改这个物品？',`“${o.label}”之前设为了保持不变。解锁后，你的下一条要求才能修改它。`,'允许修改'))return;await work(async()=>{await post(`${base()}/patch`,{base_version:state.version,explanation:'用户允许修改此物品',operations:[{type:'lock',object_id:o.id,locked:false}]});await refreshScene();await poll(true);});});
on('cancelTask',()=>work(async()=>{const j=activeJob();if(!j)return;await post(`/api/jobs/${j.id}/cancel`);await poll(true);toast('已请求停止。正在运行的制作可能需要一点时间才能结束。');}));
on('playButton',async()=>{if(audio.playing)audio.stop(false);else await audio.play();});$('timeSeek').onchange=()=>safe(()=>audio.seek(Number($('timeSeek').value)));
$('importInput').onchange=()=>safe(async()=>{const file=$('importInput').files[0];$('importInput').value='';if(!file)return;await work(async()=>{const fd=new FormData();fd.set('file',file);const p=await post('/api/import',fd);await refreshProjects();await openProject(p.id);toast('已打开保存的回忆，不需要重新生成。');});});
window.addEventListener('beforeunload',draftSave);
// Test/debug observation only. Contains no tokens, source contents or node addresses.
window.memoryscapeStatus=()=>({project:state.project?.id,version:state.version,objects:state.scene?.objects.length||0,selected:state.selected,renderer:viewer?.fallback?'cpu':'webgl2',loaded:(state.scene?.objects||[]).filter(o=>o.asset_id&&viewer?.cache.has(o.asset_id)).length,history:state.history,ui:'simple'});
api('/api/config').then(initialize).catch(()=>{});
