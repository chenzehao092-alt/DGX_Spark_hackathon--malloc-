/**
 * Traceable-memory presentation rules for the simple UI.
 * Pure, deterministic, testable. Never invents facts and never renders
 * internal scheduling parameters (strategy / primary_source / geometry_model /
 * steps / max_faces / image_mode ...) into the novice surface.
 */

export const PROVENANCE = {
  procedural: '程序搭建',
  generated: '模型生成',
  photo: '来自照片',
  imported: '用户导入',
};
export const OBJECT_KIND = {
  person: '人物', furniture: '家具', food: '食物', decoration: '装饰',
  background: '背景', prop: '物品', text: '文字卡片',
};
export const SOURCE_KIND = { image: '照片', audio: '录音', text: '文字', model: '模型' };

const TECH = [
  'strategy', 'primary_source', 'image_mode', 'geometry_model', 'image_model',
  'reuse_object', 'primitive', 'textured', 'guidance_scale', 'max_faces',
  'steps', 'seed', 'fit', 'crop', 'options', 'generation', 'provenance',
  'planning requirements', 'locked_facts',
];

// Ordered natural-language substitutions, applied before the fallback removal.
const TECH_PHRASES = [
  ['image.edit', '图片编辑'],
  ['geometry.generate', '三维生成'],
  ['`regenerate`', '重新制作外观'],
  ['`tint`', '调整配色'],
  ['strategy="generate3d"', '按参考图重建'],
  ['strategy="photo"', '按照片重建'],
  ['strategy="procedural"', '按描述搭建'],
  ['strategy="reuse"', '复用已有对象'],
  ['image_mode="original"', '保留原图'],
  ['image_mode="crop"', '使用裁剪区域'],
  ['image_mode="edit"', '参考原图编辑'],
  ['image_mode="text2image"', '按文字生成'],
  ['textured=true', '带纹理'],
  ['textured=false', '不带纹理'],
];

/** Remove internal scheduling/model parameters from user-facing text. */
export function cleanTech(text = '') {
  let out = String(text);
  // A model may repeat database IDs or repair parameters in its summary.
  // Keep these out of the novice chat without rewriting the stored evidence.
  out = out.replace(/`?\b(?:a|p|j|r|plan)_[a-f0-9]{12,64}\b`?/gi, '所选素材');
  out = out.replace(/`?fit\s*=\s*["']?stretch["']?`?/gi, '按指定宽高');
  out = out.replace(/`?fit\s*=\s*["']?uniform["']?`?/gi, '保持原比例');
  // Embedded JSON-ish object with internal fields -> drop it entirely first.
  out = out.replace(/\{[^{}]*?(?:strategy|primary_source|image_mode|geometry_model|max_faces|steps|locked_facts)[^{}]*?\}/g, '');
  // Fallback: field="value" or field=value or field:"value" (no Chinese values).
  const field = TECH.join('|');
  out = out.replace(new RegExp(`(?:${field})\\s*[:=]\\s*["']?[A-Za-z0-9_./:-]+["']?`, 'gi'), '');
  // Whole-line planner/debug records should disappear, while mixed Chinese
  // descriptions keep their user-readable lead-in.
  out = out.replace(/[^。！？；;\n]*?(?:planning requirements|locked_facts)[^。！？；;\n]*/gi, '');
  for (const [from, to] of TECH_PHRASES) out = out.split(from).join(to);
  // Leftover bare tokens from the parameter family.
  out = out.replace(/\bgenerate3d\b/gi, '真实三维模型').replace(/\btext2image\b/gi, '图片生成');
  out = out.replace(/\b(?:primary_source|image_mode|geometry_model|max_faces)\b/gi, '');
  out = out.replace(/`+/g, '');
  // Collapse duplicated punctuation / whitespace left behind.
  out = out.replace(/使用\s*(?:[，、]\s*)+/g, '');
  out = out.replace(/[，、]{2,}/g, '，').replace(/[。]{2,}/g, '。').replace(/\s{2,}/g, ' ');
  out = out.replace(/[，、]+(?=\s*。|$)/g, '').replace(/^[，、\s]+|[，、\s]+$/g, '');
  out = out.replace(/[，、]\s*([，、]+)/g, '，');
  return out.trim();
}

function cleanLines(items = []) {
  return items.map(cleanTech).map(t => t.replace(/^[:：,，、\s]+|[:：,，、\s]+$/g, '')).filter(Boolean);
}

export function provenanceLabel(value) {
  return PROVENANCE[value] || (value ? String(value) : '未知来源');
}

export function objectKindLabel(value) {
  return OBJECT_KIND[value] || String(value || '物品');
}

export function sourceKindLabel(value) {
  return SOURCE_KIND[value] || String(value || '素材');
}

/** User-language line for one memory/recent-decision record. */
export function decisionLines(kind, body, scene) {
  const b = body || {};
  if (kind === 'patch' && Array.isArray(b.operations)) {
    const lines = (b.operations || []).map(op => {
      const by = new Map((scene?.objects || []).map(o => [o.id, o.label]));
      const name = by.get(op.object_id) || '这件物品';
      if (op.type === 'audio') return '调整了声音的播放效果';
      if (op.type === 'remove') return `${name}：从场景移除，历史和素材仍保留`;
      if (op.type === 'add') return `${op.new_object?.label || '新物品'}：新增程序几何`;
        if (op.type === 'bind_frame') return `${name}：自动贴合海报`;
        if (op.type === 'restore_object') return `${name}：复用历史物品、恢复原尺寸与外观`;
        if (op.type === 'resize') return `${name}：调整指定尺寸，位置与未指定尺寸不变`;
      if (op.type === 'tint') return `${name}：调整了配色`;
      if (op.type === 'clear_tint') return `${name}：取消了整体染色，保留原网格和摆放`;
      if (op.type === 'transform') return `${name}：调整了位置或大小`;
      if (op.type === 'caption') return `${name}：更新了文字说明`;
      if (op.type === 'regenerate') return `${name}：重新制作了外观`;
      return `${name}：更新了设置`;
    });
    return lines.length ? lines : ['保存了一次修改'];
  }
  if (kind === 'restore') return ['恢复了以前保存的内容'];
  if (kind === 'asset_adopted') return ['采用了已有资产'];
  if (kind === 'plan_confirmed') return ['确认了场景规划'];
  if (kind === 'source.added') return ['添加了素材'];
  if (kind === 'scene.version') return ['保存了新版本'];
  return ['记录了这次修改'];
}

/** Evidence-based "why" lines. Never calls an LLM; says so when data is thin. */
export function whyLines(o, ctx) {
  const lines = [];
  const refs = (o.reference_ids || []).filter(id => ctx.sources?.some(s => s.id === id));
  if (refs.length) {
    const byKind = {};
    for (const id of refs) {
      const s = ctx.sources.find(x => x.id === id);
      byKind[s.kind] = (byKind[s.kind] || 0) + 1;
    }
    const parts = Object.entries(byKind).map(([k, n]) => `${n} 份${sourceKindLabel(k)}`);
    lines.push(`外观依据你上传的${parts.join('、')}。`);
  }
  if (o.reference_asset_id) lines.push('还关联了一张系统使用的组件参考图。');
  if (o.provenance === 'photo') lines.push('外观直接来自上传的照片。');
  else if (o.provenance === 'generated') lines.push('由系统根据素材和你的描述生成。');
  else if (o.provenance === 'procedural') lines.push('由系统按描述搭建，没有调用外部模型。');
  else if (o.provenance === 'imported') lines.push('来自你导入的已有模型。');
  if (o.uncertainty) lines.push(`不确定之处：${cleanTech(o.uncertainty)}`);
  const latest = (ctx.decisions || [])[0];
  if (latest) lines.push(`最近一次调整：${decisionLines(latest.kind, latest.body, ctx.scene).join('；')}`);
  if (!lines.length) lines.push('当前材料无法确定。');
  return lines;
}

/** HTML for the "这段回忆" summary card. Rendered above the chat. */
export function memoryCardHTML(state, ctx) {
  const sources = state.sources || [];
  const photos = sources.filter(s => s.kind === 'image').length;
  const audios = sources.filter(s => s.kind === 'audio').length;
  const texts = sources.filter(s => s.kind === 'text').length;
  const objects = state.scene?.objects?.length || 0;
  const head = state.project?.head || state.version || 0;
  const desc = state.project?.requirements || state.project?.diary || '';
  const parts = [];
  if (photos) parts.push(`${photos} 张照片`);
  if (audios) parts.push(`${audios} 段录音`);
  if (texts) parts.push(`${texts} 份文字`);
  if (objects) parts.push(`场景里 ${objects} 个对象`);
  if (head) parts.push(`已保存 ${head} 版`);
  return `<div class="memory-card"><div class="detail-head"><h3>这段回忆</h3><button data-action="open-memory" class="text-button">查看追迹</button></div>` +
    `<p class="memory-desc">${ctx.esc(desc ? '最初描述：'+cleanTech(desc) : '还没有写下描述，把想法写进下方输入框即可。')}</p>` +
    `<p class="memory-meta small muted">${parts.join(' · ') || '还没有素材'}</p>` +
    `<div class="summary-actions"><button data-action="add-material" class="secondary">继续添加材料</button></div></div>`;
}

/** HTML for the whole-memory trace drawer. */
export function memoryDetailsHTML(state, ctx) {
  const esc = ctx.esc;
  const sources = state.sources || [];
  const locked = cleanLines((state.scene?.locked_facts || []).slice(0, 8));
  const assumed = cleanLines((state.scene?.assumptions || []).slice(0, 8));
  const decisions = (ctx.decisions || []).slice(0, 5);
  return `<div class="drawer-head"><div><span class="eyebrow">TRACE</span><h3>这段回忆</h3></div><button data-action="close-drawer" class="icon-button" aria-label="关闭">×</button></div>` +
    `<p class="object-note">${esc(cleanTech(state.project?.requirements || state.project?.diary || '还没有写下描述。'))}</p>` +
    `<h4>素材来源</h4><div class="ref-grid">` +
    (sources.length ? sources.slice(0, 12).map(s => `<button class="ref-item" data-source="${esc(s.id)}" title="${esc(s.label)}">${s.kind === 'image' ? `<img src="${esc(ctx.assetURL(s.id))}" alt="${esc(s.label)}" loading="lazy">` : `<span class="ref-icon">${esc(sourceKindLabel(s.kind))}</span>`}<span>${esc(sourceKindLabel(s.kind))}</span></button>`).join('') : '<span class="muted small">还没有添加素材。</span>') +
    `</div>` +
    `<h4>已确认</h4><ul class="fact-list">${locked.length ? locked.map(t => `<li>${esc(t)}</li>`).join('') : '<li class="muted">还没有单独确认的事实。</li>'}</ul>` +
    `<h4>仍需留意</h4><ul class="fact-list">${assumed.length ? assumed.map(t => `<li>${esc(t)}</li>`).join('') : '<li class="muted">目前没有额外的不确定记录。</li>'}</ul>` +
    `<h4>最近修改</h4><div class="decision-list">${decisions.length ? decisions.map(d => `<p>${esc(decisionLines(d.kind, d.body, state.scene).join('；'))}</p>`).join('') : '<p class="muted">还没有修改记录。</p>'}</div>`;
}

/** HTML for the object detail drawer. */
export function objectDetailsHTML(o, ctx) {
  const esc = ctx.esc;
  const refs = (o.reference_ids || []).map(id => ctx.sources?.find(s => s.id === id)).filter(Boolean);
  const decisions = (ctx.decisions || []).slice(0, 3);
  const why = whyLines(o, ctx);
  const locked = cleanLines((ctx.scene?.locked_facts || []).slice(0, 2));
  const assumed = cleanLines((ctx.scene?.assumptions || []).slice(0, 2));
  return `<div class="drawer-head"><div><span class="eyebrow">TRACE</span><h3>${esc(o.label)}</h3></div><button data-action="close-drawer" class="icon-button" aria-label="关闭">×</button></div>` +
    `<div class="detail-head"><span class="provenance-badge">${esc(provenanceLabel(o.provenance))}</span></div>` +
    (o.description ? `<p class="object-note">${esc(cleanTech(o.description))}</p>` : '') +
    `<h4>来源</h4><div class="ref-grid">` +
    (refs.length ? refs.map(s => `<button class="ref-item" data-source="${esc(s.id)}" title="${esc(s.label)}"><img src="${esc(ctx.assetURL(s.id))}" alt="${esc(s.label)}" loading="lazy"><span>${esc(sourceKindLabel(s.kind))}</span></button>`).join('') : '') +
    (o.reference_asset_id ? `<a class="ref-item" href="${esc(ctx.assetURL(o.reference_asset_id))}" target="_blank" rel="noopener" title="组件参考图"><img src="${esc(ctx.assetURL(o.reference_asset_id))}" alt="组件参考图" loading="lazy"><span>组件参考</span></a>` : '') +
    (refs.length || o.reference_asset_id ? '' : '<span class="muted small">没有直接关联的上传素材，来源见“为什么这样”。</span>') +
    `</div>` +
    `<h4>依据</h4><ul class="fact-list">` +
    `<li><b>${esc(provenanceLabel(o.provenance))}</b>${o.provenance === 'photo' ? '，外观可直接对照上传照片。' : o.provenance === 'generated' ? '，由系统根据素材生成。' : o.provenance === 'procedural' ? '，按描述搭建，未调用外部模型。' : o.provenance === 'imported' ? '，来自导入的已有模型。' : ''}</li>` +
    (locked.length ? locked.map(t => `<li><b>已确认</b>：${esc(cleanTech(t))}</li>`).join('') : '') +
    (assumed.length ? assumed.map(t => `<li><b>推断</b>：${esc(cleanTech(t))}</li>`).join('') : '') +
    (assumed.length || locked.length ? '' : '<li class="muted">没有单独的推断记录；其余信息见“为什么这样”。</li>') +
    `</ul>` +
    (o.uncertainty ? `<h4>不确定</h4><p class="notice">${esc(cleanTech(o.uncertainty))}</p>` : '') +
    `<h4>最近修改</h4><div class="decision-list">` +
    (decisions.length ? decisions.map(d => `<p>${esc(decisionLines(d.kind, d.body, ctx.scene).join('；'))}</p>`).join('') : '<p class="muted">还没有修改记录。</p>') +
    `</div>` +
    `<h4>为什么这样？</h4><ul class="fact-list">${why.map(t => `<li>${esc(cleanTech(t))}</li>`).join('')}</ul>` +
    `<div class="card-buttons">` +
    `<button data-action="sources" class="secondary">查看来源</button>` +
    `<button data-action="history" class="secondary">查看历史</button>` +
    `<button data-action="edit" class="secondary">只改这件物品</button>` +
    `</div>`;
}
