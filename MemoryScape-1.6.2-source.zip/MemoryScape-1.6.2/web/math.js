/** Column-major matrices, right-handed coordinates, +Y up. No external runtime. */
export const identity = () => [1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1];
export function multiply(a,b) {
  const out=Array(16).fill(0);
  for(let c=0;c<4;c++) for(let r=0;r<4;r++) for(let k=0;k<4;k++) out[c*4+r]+=a[k*4+r]*b[c*4+k];
  return out;
}
export function transform(m,v,w=1) { return [0,1,2,3].map(r=>m[r]*v[0]+m[4+r]*v[1]+m[8+r]*v[2]+m[12+r]*w); }
export function normalize(v) { const l=Math.hypot(...v)||1;return v.map(x=>x/l); }
export const sub=(a,b)=>a.map((v,i)=>v-b[i]);
export const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
export const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
export function perspective(fov,aspect,near=.05,far=100) {
  const f=1/Math.tan(fov/2), nf=1/(near-far);
  return [f/aspect,0,0,0, 0,f,0,0, 0,0,(far+near)*nf,-1, 0,0,2*far*near*nf,0];
}
export function lookAt(eye,target,up=[0,1,0]) {
  const z=normalize(sub(eye,target)),x=normalize(cross(up,z)),y=cross(z,x);
  return [x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1];
}
export function trs(t=[0,0,0],q=[0,0,0,1],s=[1,1,1]) {
  const [x,y,z,w]=q,xx=x*x,yy=y*y,zz=z*z,xy=x*y,xz=x*z,yz=y*z,wx=w*x,wy=w*y,wz=w*z;
  return [(1-2*(yy+zz))*s[0],2*(xy+wz)*s[0],2*(xz-wy)*s[0],0,
    2*(xy-wz)*s[1],(1-2*(xx+zz))*s[1],2*(yz+wx)*s[1],0,
    2*(xz+wy)*s[2],2*(yz-wx)*s[2],(1-2*(xx+yy))*s[2],0,...t,1];
}
export function inverse(m) {
  const rows=Array.from({length:4},(_,r)=>[m[r],m[4+r],m[8+r],m[12+r],...Array.from({length:4},(_,c)=>+(r===c))]);
  for(let c=0;c<4;c++) {
    let p=c;for(let r=c+1;r<4;r++) if(Math.abs(rows[r][c])>Math.abs(rows[p][c])) p=r;
    if(Math.abs(rows[p][c])<1e-12) throw new Error('Singular matrix');
    [rows[c],rows[p]]=[rows[p],rows[c]];
    const f=rows[c][c];rows[c]=rows[c].map(v=>v/f);
    for(let r=0;r<4;r++) if(r!==c) {const v=rows[r][c];rows[r]=rows[r].map((x,k)=>x-v*rows[c][k]);}
  }
  return Array.from({length:16},(_,i)=>rows[i%4][4+Math.floor(i/4)]);
}
export function rayBox(origin,dir,min,max) {
  let lo=0,hi=Infinity;
  for(let i=0;i<3;i++) {
    if(Math.abs(dir[i])<1e-9) {if(origin[i]<min[i]||origin[i]>max[i])return null;continue;}
    let a=(min[i]-origin[i])/dir[i],b=(max[i]-origin[i])/dir[i];if(a>b)[a,b]=[b,a];
    lo=Math.max(lo,a);hi=Math.min(hi,b);if(lo>hi)return null;
  }
  return lo;
}
export function hexRgb(hex) {return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255);}
/** Intrinsic XYZ Euler -> quaternion, matching glTF/TRS export in the backend. */
export function eulerQuaternion(e=[0,0,0]) {
  const [x,y,z]=e.map(v=>v/2),c1=Math.cos(x),c2=Math.cos(y),c3=Math.cos(z),s1=Math.sin(x),s2=Math.sin(y),s3=Math.sin(z);
  return [s1*c2*c3+c1*s2*s3,c1*s2*c3-s1*c2*s3,c1*c2*s3+s1*s2*c3,c1*c2*c3-s1*s2*s3];
}
export function objectMatrix(object,bounds) {
  const t=object.transform,extent=bounds.max.map((v,i)=>Math.max(.0001,v-bounds.min[i]));
  let scale=t.size.map((v,i)=>v/extent[i]);
  if(t.fit==='uniform')scale=scale.map(()=>Math.min(...scale));
  const offset=[-(bounds.min[0]+bounds.max[0])/2,-bounds.min[1],-(bounds.min[2]+bounds.max[2])/2];
  return multiply(trs(t.position,eulerQuaternion(t.rotation),scale),trs(offset));
}

/** Fit actual display bounds, including tiny real-world objects and rotations. */
export function sceneFrame(scene,aspect=1) {
  // A photo display/poster may be classified as background but is still the
  // subject the user needs to see. Exclude only decorative backdrop geometry.
  const visible=scene.objects||[];
  const objects=visible.filter(o=>o.kind!=='background'||['photo','generate3d'].includes(o.generation?.strategy));
  if(!objects.length)return {target:[0,1,0],distance:9.6};
  const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
  for(const o of objects){const t=o.transform,m=trs(t.position,eulerQuaternion(t.rotation));
    for(const x of [-.5,.5])for(const y of [0,1])for(const z of [-.5,.5]){
      const point=transform(m,[x*t.size[0],y*t.size[1],z*t.size[2]]);
      for(let i=0;i<3;i++){lo[i]=Math.min(lo[i],point[i]);hi[i]=Math.max(hi[i],point[i]);}
    }
  }
  const radius=Math.max(.025,Math.hypot(...hi.map((v,i)=>v-lo[i]))/2);
  const halfFov=Math.min(.36,Math.atan(Math.tan(.36)*Math.max(.1,aspect)));
  return {target:lo.map((v,i)=>(v+hi[i])/2),distance:radius/Math.sin(halfFov)*1.25};
}
