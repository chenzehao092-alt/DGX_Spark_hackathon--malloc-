/** Original/derived/generated tracks are independent. No voice cloning in the browser. */
export class MemoryAudio {
 constructor(assetURL,onTime=()=>{}){this.assetURL=assetURL;this.onTime=onTime;this.cache=new Map();this.nodes=[];this.scene={audio:[],objects:[]};this.playing=false;this.offset=0;this.timer=setInterval(()=>this.tick(),100);}
 async ensure(){if(!this.context)this.context=new AudioContext();if(this.context.state==='suspended')await this.context.resume();}
 setScene(scene){const before=JSON.stringify(this.scene.audio),after=JSON.stringify(scene.audio);this.scene=scene;if(before!==after){this.stop();const wanted=new Set(scene.audio.map(t=>t.asset_id));for(const id of this.cache.keys())if(!wanted.has(id))this.cache.delete(id);}}
 async buffer(id){if(this.cache.has(id))return this.cache.get(id);const r=await fetch(this.assetURL(id));if(!r.ok)throw Error('音频素材不可用');const buffer=await this.context.decodeAudioData(await r.arrayBuffer());this.cache.set(id,buffer);return buffer;}
 async play(offset=this.offset){
  await this.ensure();this.stop(false);const epoch=this.epoch;this.offset=offset;this.duration=0;
  try{
   // Decode all tracks before scheduling a shared start time; network latency
   // must not change synchronization. A later stop/seek invalidates this request.
   const tracks=this.scene.audio.filter(t=>t.asset_id&&t.status==='ready');
   const buffers=await Promise.all(tracks.map(t=>this.buffer(t.asset_id)));
   if(epoch!==this.epoch)return;
   const startAt=this.context.currentTime+.04;
   for(let i=0;i<tracks.length;i++){
    const track=tracks[i],b=buffers[i],available=Math.max(0,b.duration-track.trim_start);
    const duration=Math.min(track.duration??available,available),end=track.start+duration;
    this.duration=Math.max(this.duration,end);if(duration<=0)continue;
    const local=Math.max(0,offset-track.start),remaining=duration-local;
    if(!track.loop&&remaining<=0)continue;
    const source=this.context.createBufferSource(),gain=this.context.createGain();source.buffer=b;source.loop=track.loop;source.loopStart=track.trim_start;source.loopEnd=track.trim_start+duration;gain.gain.value=track.gain;source.connect(gain);
    if(track.anchor){const o=this.scene.objects.find(x=>x.id===track.anchor);if(o){const p=this.context.createPanner();p.panningModel='HRTF';p.distanceModel='inverse';p.refDistance=4;p.maxDistance=100;const pos=o.transform.position;[p.positionX.value,p.positionY.value,p.positionZ.value]=[pos[0],pos[1]+o.transform.size[1]/2,pos[2]];gain.connect(p);p.connect(this.context.destination);}else gain.connect(this.context.destination);}else gain.connect(this.context.destination);
    const when=startAt+Math.max(0,track.start-offset),sampleOffset=track.trim_start+(track.loop?local%duration:local);
    if(track.loop)source.start(when,sampleOffset);else source.start(when,sampleOffset,remaining);
    this.nodes.push(source);
   }
   this.startedAt=startAt;this.playing=this.nodes.length>0;this.tick();
  }catch(e){if(epoch===this.epoch)this.stop();throw e;}
 }

 stop(reset=true){this.epoch=(this.epoch||0)+1;for(const n of this.nodes){try{n.stop();n.disconnect();}catch{}}this.nodes=[];if(this.playing&&this.context)this.offset+=Math.max(0,this.context.currentTime-this.startedAt);this.playing=false;if(reset)this.offset=0;this.tick();}
 seek(seconds){this.offset=Math.max(0,seconds);if(this.playing)return this.play(this.offset);this.tick();}
 listener(camera){if(!this.context||!camera)return;const l=this.context.listener,eye=camera.eye,target=camera.target;if(!eye||!target)return;const d=target.map((v,i)=>v-eye[i]),length=Math.hypot(...d)||1;[l.positionX.value,l.positionY.value,l.positionZ.value]=eye;[l.forwardX.value,l.forwardY.value,l.forwardZ.value]=d.map(v=>v/length);[l.upX.value,l.upY.value,l.upZ.value]=[0,1,0];}
 tick(){const t=this.playing&&this.context?this.offset+Math.max(0,this.context.currentTime-this.startedAt):this.offset;if(this.playing&&this.duration&&t>this.duration&&!this.scene.audio.some(a=>a.loop)){this.stop();return;}this.onTime({time:t,duration:this.duration||0,playing:this.playing});}
 dispose(){this.stop();clearInterval(this.timer);this.context?.close();}
}
