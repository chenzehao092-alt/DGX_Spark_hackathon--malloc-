// Conservative routing: observation asks never auto-apply a model suggestion.
// Mixed asks such as “看看尺寸，然后放大20%” stay ordinary edit requests.
export function observationRequest(text) {
  text=String(text||'').trim();
  if(!text||/删除|移除|去掉|加回|恢复|还原|放大|缩小|移动|调整|修改|改成|改为|变成|生成|重做|旋转|添加|增加|缩放|染色|取消|去除|扩大|缩短|加宽|加高|\b(edit|remove|resize|move|regenerate|add|restore)\b/i.test(text))return false;
  return /你(?:自己)?看看|帮我看看|看一(?:下|眼)|检查.*(画面|场景|布局|尺寸|大小|位置|模型)|尺寸.*不对|大小.*不对|位置.*不对|\b(review|inspect)\b/i.test(text);
}

export function geometryEvidenceLines(evidence) {
  if(evidence?.schema!=='display-geometry-v1')return [];
  const supported=new Set((evidence.supports||[]).map(r=>r.subject));
  const lines=(evidence.objects||[]).filter(o=>o.source==='validated_asset_bounds'&&o.upright&&o.floor_status==='at_floor'&&!supported.has(o.object_id)).map(o=>`${o.label}：当前模型包围盒已落地`);
  for(const r of evidence.supports||[])if(r.exact_for_upright_bounds&&r.source==='validated_asset_bounds'){
    const by=new Map((evidence.objects||[]).map(o=>[o.object_id,o.label]));
    lines.push(`${by.get(r.subject)||r.subject}与${by.get(r.target)||r.target}：${r.status==='box_contact'?'包围盒支撑高度一致':r.status==='box_gap'?'包围盒有支撑间隙':'包围盒有穿入'}`);
  }
  return lines;
}
