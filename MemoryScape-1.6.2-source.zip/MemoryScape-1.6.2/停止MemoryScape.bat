@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
call "%~dp0stop_memoryscape.bat" %*
set "MS_EXIT=%errorlevel%"
exit /b %MS_EXIT%
