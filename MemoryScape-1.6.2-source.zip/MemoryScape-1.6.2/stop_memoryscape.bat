@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1
if not exist ".venv\Scripts\python.exe" (
  echo No local Python environment was found. Run start_memoryscape.bat first.
  echo No service or model was stopped.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" scripts\desktop_stop.py
set "MS_EXIT=%errorlevel%"
if not "%MS_EXIT%"=="0" (
  echo Stop failed. Read the error above; the failure exit code has been preserved.
  pause
)
exit /b %MS_EXIT%
