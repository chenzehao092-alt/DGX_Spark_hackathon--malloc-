# 拾光 3D · MemoryScape 1.6.2

把有权使用的照片、原声和一句描述，组织成可以旋转查看、局部修改、保存和恢复的三维回忆。Windows 主机运行 UI 和 Agent；DGX Spark 运行 GPU 模型，目前使用 server6 代替。

这是可演示、可复现的工程原型，不是已通过真实 DGX Spark 验收的产品，也不保证单图建模的不可见背面与实物一致。

## 一键启动

1. 双击根目录的 `一键启动MemoryScape.bat`，打开 <http://127.0.0.1:8004/>。本机自动登录，不需要输入访问口令。
2. 在“StepFun 设置”输入自己的 API Key，保存并检查连接。
3. 添加照片、MP3 或日记，说明回忆内容，确认素材处理授权和方案，再生成。
4. 完成后旋转查看前、侧、背面；继续用一句话修改，通过“保存回忆”导出 `.memory.zip`。
5. 用完双击 `停止MemoryScape.bat`。关闭浏览器不等于停止后台。

首次安装需要联网和 Python 3.11–3.13，推荐 3.12。默认寻找 `py -3.12`；也可在 `configs/python-path.txt` 写基础 Python 的完整路径。程序在本目录建立独立 `.venv`，不能靠复制旧 `.venv` 迁移。若安装在没有模型配置的新机器上，界面可启动，但不能声称生成服务已经可用。

默认使用8004，避免与旧安装的8003冲突。端口被另一份应用占用时会提示，不会强行结束它。命令行可用 `一键启动MemoryScape.bat --port 8014 --no-browser` 指定端口。

## 模型放在哪里

| 部分 | 运行位置 | 用途 |
|---|---|---|
| UI、项目数据、Agent、CPU 校验 | Windows 主机 | 交互、编排、组装、版本和导出 |
| StepFun 多模态模型 | 配置的 StepFun API | 图片理解、对象拆分、规划、局部修改、多视角判断 |
| Step1X-Edit v1p2 | DGX Spark / 当前 server6 | 从源图准备独立物体参考图、执行图片修改 |
| Step1X-3D 及其依赖权重 | DGX Spark / 当前 server6 | 单主体几何与纹理生成 |

现有部署记录使用 `step-3.7-flash` 作为导演模型，实际可用模型以账号和界面配置为准。StepFun API Key 不等于本机访问令牌，也不等于模型节点令牌。

模型权重不在源码包内。首次部署按 [模型部署](docs/MODEL_DEPLOYMENT.md) 和 [本地图片节点](docs/LOCAL_IMAGE_NODE_20260929.md) 准备独立 GPU 环境，然后将示例配置填写为 `configs/deployment.toml`。

`lifecycle = "reuse"` 只连接已有服务，不上传代码、下载权重或重启模型；`managed` 允许启动已配置的专用节点，但仍不等于自动完成 GPU 环境和权重安装。不要借此影响其他用户的 GPU 任务。停止本机的 `reuse` 安装不会释放远端已有模型的显存。

## Agent 与质量闭环

输入照片和说明 → 多模态对象拆分/证据 → 类型化方案和范围校验 → 独立参考图 → 单件3D生成 → 空间组装 → 实际多角度检查 → 保存版本。

- 复杂场景拆成独立对象，而不是把整张大场景直接交给单图3D模型。用于建模的新参考要求完整单主体三分之四斜视图；保留平面原图和纯贴图修改不强制改视角。
- 单件真实 GLB 检查六向，全景检查八向。类型化缺陷与对象、视角、版本绑定，不用单张正面图代替完整检查。
- “··· → 检查并修复（最多一轮）”：多模态模型判断真实截图，最多处理三件物品、每件一个阶段，执行候选后复检；建议模式允许有效候选带质量提示采用，严格模式仅发布视觉通过的候选。
- 历史恢复优先使用真实旧资产、尺寸与配色。局部尺寸/配色等可用确定性工具执行，不把移动物体冒充删除或几何修复。
- 输入版本变化、锁定、跨对象证据、损坏资源和越权工具会被拒绝；503不会被写成成功，也不会因此无限重发付费请求。

默认启用资产多视角检查，`MS_ASSET_REVIEW_POLICY=warn`、`MS_REFERENCE_REVIEW_POLICY=warn`，视觉问题作为建议保留，不因视觉拒绝反复生成。实际生成失败、无效文件、范围和版本冲突仍阻断；建议模式的产物不会冒充质量合格。设为 `strict` 可恢复阻断式验收。导演把人数统计放进 scene 的常见格式偏差会自动规范，但人数冲突和任意未知字段仍拒绝。详见 [质量建议模式](docs/quality-advisory-mode.md)。

## 提交与验证

最终目录、启动说明和边界见 [00_最终交接说明.md](00_最终交接说明.md)；技术交接见 [最终版本交接](docs/FINAL_HANDOFF_20260929.md)。最新验证以 `docs/reports/v1.6.2-final-verification.json` 为准。历史报告保留原日期和当时的限制，不代表本版重新进行了真实 GPU 推理。

```powershell
.\.venv\Scripts\python.exe -m pytest -q
node --test
.\.venv\Scripts\python.exe scripts\verify_release.py
.\.venv\Scripts\python.exe scripts\build_submission.py --output 提交包\MemoryScape-1.6.2-source.zip
```

提交源码 ZIP，不要把运行过的整个目录压缩提交。发布按 SHA-256 白名单排除 `.env`、`data/`、真实配置、环境、缓存、测试相册和模型权重；打包拒绝覆盖已有文件。模型授权、团队信息、真实 DGX Spark 验收和赛事表单仍需参赛者确认。

## 文档索引

[用户说明](使用说明.md) · [提交说明](docs/SUBMISSION.md) · [执行修复设计](docs/V1_6_1_AUTOREPAIR.md) · [多模态研究与规划](docs/MULTIMODAL_3D_QUALITY_PLAN_20260929.md) · [Agent 工作流](docs/AGENT_WORKFLOW_20260929.md) · [架构](docs/ARCHITECTURE.md) · [安全](docs/SECURITY.md) · [第三方声明](THIRD_PARTY_NOTICES.md)
