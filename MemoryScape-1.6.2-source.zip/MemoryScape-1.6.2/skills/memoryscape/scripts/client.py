#!/usr/bin/env python
"""Runnable Skill client. The local MemoryScape API must already be running."""
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
from memoryscape.client import Client,ident


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--url');sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('projects');sub.add_parser('models');sub.add_parser('skills')
    create=sub.add_parser('create');create.add_argument('spec',type=Path)
    for name in ('scene','plans','plan'):
        q=sub.add_parser(name);q.add_argument('project')
    q=sub.add_parser('memory');q.add_argument('project');q.add_argument('--query',default='');q.add_argument('--selected')
    q=sub.add_parser('status');q.add_argument('job')
    q=sub.add_parser('upload');q.add_argument('project');q.add_argument('file',type=Path);q.add_argument('--role',choices=['scene','person','object','style','audio','diary'],default='scene');q.add_argument('--subject',default='');q.add_argument('--rights-confirmed',action='store_true')
    q=sub.add_parser('confirm');q.add_argument('project');q.add_argument('plan');q.add_argument('--version',type=int,required=True);q.add_argument('--input-revision',type=int,required=True);q.add_argument('--user-approved',action='store_true')
    q=sub.add_parser('edit');q.add_argument('project');q.add_argument('spec',type=Path)
    q=sub.add_parser('quality-repair');q.add_argument('project');q.add_argument('--version',type=int,required=True);q.add_argument('--input-revision',type=int,required=True);q.add_argument('--selected');q.add_argument('--max-objects',type=int,choices=(1,2,3),default=3);q.add_argument('--user-approved',action='store_true')
    q=sub.add_parser('export');q.add_argument('project');q.add_argument('output',type=Path);q.add_argument('--originals',action='store_true')
    a=p.parse_args();c=Client(a.url)
    if a.command=='projects':result=c.json('GET','/api/projects')
    elif a.command=='models':result=c.json('GET','/api/config')
    elif a.command=='skills':result=c.json('GET','/api/skills')
    elif a.command=='create':result=c.json('POST','/api/projects',json=json.loads(a.spec.read_text('utf-8')))
    elif a.command=='status':result=c.json('GET','/api/jobs/'+ident(a.job))
    else:
        base='/api/projects/'+ident(a.project)
        if a.command in ('scene','plans'):result=c.json('GET',base+'/'+a.command)
        elif a.command=='memory':result=c.json('GET',base+'/memory',params={'query':a.query,'selected':a.selected} if a.selected else {'query':a.query})
        elif a.command=='plan':result=c.json('POST',base+'/plan')
        elif a.command=='upload':
            if not a.rights_confirmed:p.error('Provide --rights-confirmed only after obtaining permission')
            if not a.file.is_file() or a.file.stat().st_size>128*1024*1024:p.error('File missing or above 128 MiB')
            with a.file.open('rb') as f:result=c.json('POST',base+'/sources',files={'file':(a.file.name,f)},data={'role':a.role,'subject':a.subject,'rights_confirmed':'true'})
        elif a.command=='confirm':
            if not a.user_approved:p.error('Show the plan and obtain user approval first')
            result=c.json('POST',base+'/plans/'+ident(a.plan)+'/confirm',json={'expected_version':a.version,'expected_input_revision':a.input_revision})
        elif a.command=='edit':result=c.json('POST',base+'/edit',json=json.loads(a.spec.read_text('utf-8')))
        elif a.command=='quality-repair':
            if not a.user_approved:p.error('Explain target scope, paid steps and one-round limit, then obtain user approval first')
            result=c.json('POST',base+'/quality-repair',json={'base_version':a.version,'input_revision':a.input_revision,
                'user_approved':True,'selected_object':a.selected,'max_objects':a.max_objects})
        elif a.command=='export':
            if a.output.exists():p.error('Output exists; choose a new filename')
            raw=c.call('GET',base+'/export',params={'originals':a.originals}).content
            a.output.parent.mkdir(parents=True,exist_ok=True)
            with a.output.open('xb') as f:f.write(raw)
            result={'output':str(a.output.resolve()),'bytes':len(raw)}
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,OSError) as e:print(str(e),file=sys.stderr);sys.exit(1)
