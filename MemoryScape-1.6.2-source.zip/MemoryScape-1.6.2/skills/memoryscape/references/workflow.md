# CLI examples

For explicitly authorized inspection **and** execution, read [quality.md](quality.md). Use `quality-repair PROJECT --version VERSION --input-revision REVISION --selected OBJECT --max-objects 1 --user-approved` with actual current IDs and revisions. Omit `--selected` for scene-wide scope (maximum3 objects). This command may call paid models and automatically publish only an accepted candidate; `review` is advisory-only.

Execute from the repository root; all IDs below are placeholders returned by earlier real calls.

```bash
python skills/memoryscape/scripts/client.py projects
python skills/memoryscape/scripts/client.py models
python skills/memoryscape/scripts/client.py create skills/memoryscape/references/project-example.json
python skills/memoryscape/scripts/client.py upload PROJECT photo.jpg --role scene --rights-confirmed
python skills/memoryscape/scripts/client.py plan PROJECT
python skills/memoryscape/scripts/client.py status JOB
python skills/memoryscape/scripts/client.py plans PROJECT
python skills/memoryscape/scripts/client.py confirm PROJECT PLAN --version 0 --input-revision 1 --user-approved
python skills/memoryscape/scripts/client.py scene PROJECT
python skills/memoryscape/scripts/client.py memory PROJECT
python skills/memoryscape/scripts/client.py edit PROJECT edit.json
python skills/memoryscape/scripts/client.py export PROJECT saved-memory.zip
```

`edit.json` contains `{"base_version":2,"selected_object":"balloon_1","prompt":"只把这个气球改为金色"}`. Use actual current values, not this example literally. The CLI fails rather than overwrite an existing export.

For historical restoration and precise resizing, read [editing.md](editing.md). Query-specific memory is available through `GET /api/projects/PROJECT/memory?query=...`, and tool cards through `GET /api/skills`. Neither endpoint generates assets or changes the project. The edit proposal uses `restore_object` or `resize` when appropriate; it does not require another GPU generation.

Use the real host URL printed by the launcher or `MS_APP_URL`; do not assume a historic port. For the current desktop workspace it is port 8003 (the generic client's legacy default is 8000):

```bash
python skills/memoryscape/scripts/client.py --url http://127.0.0.1:8003 skills
python skills/memoryscape/scripts/client.py --url http://127.0.0.1:8003 memory PROJECT --query "把底座加回来"
```

MCP is optional: install `python -m pip install -e ".[mcp]"`, configure your Agent host to run `python -m memoryscape.mcp_server` with an absolute working directory and private MS_APP_URL/MS_TOKEN environment. Default tools are read-only. MS_MCP_ALLOW_WRITES=true enables planning/confirmation/edit drafts but still checks explicit confirmation inputs and application constraints. Do not grant this to an untrusted client. Actual SDK/client handshake needs installation and testing; core UI/CLI do not depend on MCP.
