# Evidence-grounded 3D edits

Use the existing host API, not model-authored Blender code. This application operates in Y-up display units, with positions at the bottom centre. Dimensions are a presentation scale, not measurements inferred from a photo.

## Read, select, validate

Read `GET /api/projects/PROJECT/scene`, then `GET /api/projects/PROJECT/memory?query=URL_ENCODED_REQUEST`. Query memory exposes current objects, relevant historical snapshots, numeric intent and operation cards. Read `/api/skills` for supported tools. The user's latest explicit object name overrides stale selection. Multiple matching names require clarification.

Submit `edit` with the actual current `base_version`. Inspect the returned proposal and `validation`; the latter records structural checks, not visual acceptance. Approval remains a user action. Never describe a queued build as successful.

## Recover an object

“Bring the base back” means reuse its own pre-deletion state, not invent another base. `restore_intent.required` provides the object ID and historical version. The operation is:

```json
{"type":"restore_object","object_id":"base","source_version":13}
```

These example values are placeholders. The host resolves the real historical object, mesh asset, pose, dimensions and colour. It can repair a wrong replacement under the same stable ID. It does not roll back the entire project, move unrelated objects, or change lock permissions. Only compatible on/near relations are reattached, with offsets preserving current placements. Missing assets/dependencies, ambiguous history, locks, stale versions and budget overflow stop execution. After more than 200 versions, specify a known source version explicitly.

## Resize without collateral changes

For parametric geometry, use partial dimensions:

```json
{"type":"resize","object_id":"base","size_edit":{"width":2.16}}
```

The host retains height, depth, pose, asset and appearance. Non-cubic procedural boxes use stretch. For “increase width by 20%”, derive the new width from the current state, not an old description; numeric intent verifies it. Convert centimetres/millimetres to display metres.

For photos/real meshes, preserve aspect by default:

```json
{"type":"resize","object_id":"poster","size_edit":{"scale":1.2}}
```

Independent-axis deformation of photos/real meshes is not supported by resize unless they already have an explicit stretch transform. For intentional deformation, discuss the effect and use an explicitly authorized full transform. Bound frames follow their photo; do not independently resize their width/height.

## Generation versus editing

To cancel a whole-object colour override, use `{"type":"clear_tint","object_id":"REAL_CURRENT_ID"}` without colour, prompt or transform fields. `appearance_intent` disambiguates narrow original-colour requests and protects locked/ambiguous targets. The host reuses the existing immutable asset; it does not move the object, change size or send another request to StepFun/Step1X-3D. This displays the current asset's own texture/material, NOT a guarantee of the input photograph's exact colours. An already-clear tint is not a successful new edit. Regional recolouring or modifying a texture still needs an actual supported image/geometry workflow.

Model cards keep configuration separate from availability: `available=false`, `last_http_status` and `retry_after_seconds` describe a temporary inference cooldown. A successful GET models/capabilities check does not prove inference recovery. Do not repeatedly submit paid POSTs or advertise a missing configuration when the latest real request returned 503/429. Existing local tools remain usable. A changed endpoint/model/credential invalidates the old cooldown evidence.

For local size/pose edits, incident on/near offsets are reconciled to preserve other objects' current placements. A positive support offset is a gap, not proof of contact. Read `spatial_checks`; explicit contact edits must remove the gap. Conflicting/cyclic supports fail before layout execution. Builds with contradictory support heights or below-floor objects remain candidates for review rather than overwriting a saved scene. These checks are not a collision engine or a visual-quality guarantee.

Use procedural geometry for requested simple mathematical shapes; use photo for an original poster; use native generate3d for a photographed physical subject when true 3D is requested. Step1X-3D consumes a reference image, not a free text edit prompt. Shape/appearance changes require image editing followed by geometry generation; first check configured capability and actual service availability. Failure retains the saved version. It is not acceptable to substitute tint for unsupported shape or region edits.

Inspect the actual front/side/back render and exported GLB when accepting a generated shape. A photo plane is deliberately flat and cannot prove that a physical object was reconstructed. An embedded texture is evidence of a texture payload, not photorealism or PBR correctness. Do not claim animation, sculpting, exact faces or invisible surfaces without a corresponding implemented and verified tool.
