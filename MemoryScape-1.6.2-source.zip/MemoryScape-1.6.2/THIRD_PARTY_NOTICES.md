# Third-party and inherited code notices

MemoryScape application code is released under the root MIT License.

Selected code from the user-provided Evidence Theatre project is reused or adapted: `node/legacy_stepfun.py`, Step1X runtime patch scripts, and parts of the static GLB/math/viewer implementation. Its original MIT copyright notice is retained in `licenses/EvidenceTheatre-MIT.txt`. This package does not redistribute the user's private configurations, recorded GPU outputs, original archives or model weights.

No Three.js, font files, model weights, upstream StepFun repository copies, music samples or real human voice recordings are bundled. The fictional fixture images/meshes/test chord are procedurally created by this application. They must not be presented as photos of actual people or as StepFun-generated examples.

Python and optional JavaScript test dependencies retain their respective licenses; installation does not relicense them. Model checkouts, checkpoints, base diffusion/vision models, voice references and generated-media rights must be audited against their exact versions by the deployer. Downloading a public model is not itself a grant to use all portraits, music or voice references.

MCP server code targets the 1.x maintenance SDK range specified in pyproject.toml; the SDK is installed separately and its license is not replaced by this repository.
