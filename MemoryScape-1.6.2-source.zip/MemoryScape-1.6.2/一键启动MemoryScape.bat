@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
title MemoryScape - One-click Start
rem Portable entry: never depend on a previous installation directory.
rem Use a separate port instead of stopping another MemoryScape workspace.
call "%~dp0start_memoryscape.bat" --port 8004 %*
set "MS_EXIT=%errorlevel%"
exit /b %MS_EXIT%
