"""Bounded, offline GLB rasterization for inspection, not a PBR beauty renderer.

Uses the actual static mesh and embedded base-color texture, depth tests both
faces, and omits the presentation floor so the underside is never hidden.
No GPU, network, browser tab, executable model output, or external asset URI.
"""
from __future__ import annotations
import io
import time
import hashlib
import numpy as np
from PIL import Image
from .media import parse_glb
from .errors import AppError

VIEWS = {'front':(0,0,1), 'back':(0,0,-1), 'left':(-1,0,0),
         'right':(1,0,0), 'top':(0,1,0), 'bottom':(0,-1,0)}
RENDERER = 'mesh-inspection-cpu-v1'


def load_parts(raw,max_faces=200000):
    parse_glb(raw)  # Reject URI/animation/compression before any loader.
    import trimesh
    scene=trimesh.load(io.BytesIO(raw),file_type='glb',force='scene',process=False)
    parts=[];total=0
    for node in scene.graph.nodes_geometry:
        matrix,name=scene.graph[node];mesh=scene.geometry[name]
        vertices=trimesh.transform_points(mesh.vertices,matrix)
        faces=np.asarray(mesh.faces,dtype=np.int64);total+=len(faces)
        if total>max_faces:raise AppError('多视角检查超出面数预算；未用减面结果冒充原网格。',code='quality_render_unavailable')
        if not np.isfinite(vertices).all():raise AppError('网格包含非有限坐标。')
        visual=mesh.visual;material=getattr(visual,'material',None)
        image=getattr(material,'baseColorTexture',None)
        if image is None:image=getattr(material,'image',None)
        texture=None
        if image is not None:
            if image.width*image.height>32000000:raise AppError('质量检查贴图尺寸超限。')
            texture=np.asarray(image.convert('RGBA'))
        color=getattr(material,'baseColorFactor',None)
        if color is None:color=getattr(material,'diffuse',None)
        color=np.asarray(color if color is not None else [190,190,190,255],dtype=float)
        if color.max()>1:color=color/255
        if len(color)==3:color=np.r_[color,1.]
        uv=getattr(visual,'uv',None)
        if uv is not None:
            uv=np.asarray(uv,dtype=float)
            if len(uv)!=len(vertices) or not np.isfinite(uv).all():raise AppError('网格 UV 无效。')
        vc=np.asarray(visual.vertex_colors,dtype=float)/255 if visual.kind=='vertex' else None
        parts.append({'vertices':vertices,'faces':faces,'uv':uv,'texture':texture,'color':color,'vertex_colors':vc})
    if not parts or total==0:raise AppError('没有实际三角网格可供检查。')
    return parts


def render_views(raw, *, edge=384, check=lambda:None, seconds=90,scene=False):
    if not 128<=edge<=768:raise ValueError('Inspection resolution must be 128..768')
    parts=load_parts(raw,max_faces=400000 if scene else 200000);vertices=np.vstack([p['vertices'] for p in parts])
    lo,hi=vertices.min(axis=0),vertices.max(axis=0);center=(lo+hi)/2
    # Coordinates centered for numerical stability, preserving all geometry.
    for part in parts:part['vertices']=part['vertices']-center
    began=time.monotonic();results=[];sha=hashlib.sha256(raw).hexdigest()
    directions={**VIEWS,**({'oblique_front':(1,.7,1),'oblique_back':(-1,.7,-1)} if scene else {})}
    for name,direction in directions.items():
        check();axis=np.asarray(direction,dtype=float);axis/=np.linalg.norm(axis)
        up=np.array([0.,0.,1.]) if name in ('top','bottom') else np.array([0.,1.,0.])
        right=np.cross(up,axis);right/=np.linalg.norm(right);up=np.cross(axis,right)
        basis=np.stack([right,up,axis],axis=1)
        projected=(vertices-center)@basis
        span=max(np.ptp(projected[:,0]),np.ptp(projected[:,1]),1e-7)*1.18
        offset=(projected[:,:2].min(axis=0)+projected[:,:2].max(axis=0))/2
        image=np.full((edge,edge,3),238,dtype=np.uint8);depth=np.full((edge,edge),-np.inf)
        for part in parts:
            p=part['vertices']@basis
            xy=(p[:,:2]-offset)/span*edge+edge/2;xy[:,1]=edge-xy[:,1]
            # Batch only exact visibility tests; never simplify the mesh.
            # A triangle with no pixel center in its bbox cannot contribute.
            q_all=xy[part['faces']];z_all=p[part['faces'],2]
            low=np.maximum(0,np.ceil(q_all.min(axis=1)-.5-1e-4).astype(int))
            high=np.minimum(edge-1,np.floor(q_all.max(axis=1)-.5+1e-4).astype(int))
            denoms=(q_all[:,1,1]-q_all[:,2,1])*(q_all[:,0,0]-q_all[:,2,0])+(q_all[:,2,0]-q_all[:,1,0])*(q_all[:,0,1]-q_all[:,2,1])
            visible=(low<=high).all(axis=1)&(np.abs(denoms)>=1e-9)
            tiny=np.flatnonzero(visible&(low==high).all(axis=1))
            if len(tiny):
                q=q_all[tiny];xx=low[tiny,0]+.5;yy=low[tiny,1]+.5;den=denoms[tiny]
                a=((q[:,1,1]-q[:,2,1])*(xx-q[:,2,0])+(q[:,2,0]-q[:,1,0])*(yy-q[:,2,1]))/den
                b=((q[:,2,1]-q[:,0,1])*(xx-q[:,2,0])+(q[:,0,0]-q[:,2,0])*(yy-q[:,2,1]))/den
                visible[tiny]&=np.minimum(np.minimum(a,b),1-a-b)>=-1e-7
            face_vertices=part['vertices'][part['faces']]
            normals=np.cross(face_vertices[:,1]-face_vertices[:,0],face_vertices[:,2]-face_vertices[:,0])
            norms=np.linalg.norm(normals,axis=1);shades=.78+.22*np.abs(normals@axis)/np.maximum(norms,1e-12)
            for count,index in enumerate(np.flatnonzero(visible)):
                if count%256==0:
                    check()
                    if time.monotonic()-began>seconds:raise AppError('真实网格多视角渲染超时；未判为验收通过。',code='quality_render_unavailable')
                face=part['faces'][index];q=q_all[index];z=z_all[index]
                x0,y0=low[index];x1,y1=high[index];denom=denoms[index]
                yy,xx=np.mgrid[y0:y1+1,x0:x1+1];xx=xx+.5;yy=yy+.5
                a=((q[1,1]-q[2,1])*(xx-q[2,0])+(q[2,0]-q[1,0])*(yy-q[2,1]))/denom
                b=((q[2,1]-q[0,1])*(xx-q[2,0])+(q[0,0]-q[2,0])*(yy-q[2,1]))/denom
                c=1-a-b;weights=np.stack([a,b,c],axis=-1)
                d=a*z[0]+b*z[1]+c*z[2];region=depth[y0:y1+1,x0:x1+1]
                mask=(weights.min(axis=-1)>=-1e-7)&(d>region)
                if not mask.any():continue
                color=np.broadcast_to(part['color'],weights.shape[:2]+(4,)).copy()
                if part['vertex_colors'] is not None:color*=weights@part['vertex_colors'][face]
                if part['texture'] is not None and part['uv'] is not None:
                    uv=weights@part['uv'][face];tex=part['texture'];h,w=tex.shape[:2]
                    u=np.minimum(w-1,((uv[...,0]%1)*w).astype(int));v=np.minimum(h-1,((1-uv[...,1]%1)*h).astype(int))
                    color*=tex[v,u]/255
                mask&=color[...,3]>.02
                # Symmetric mild illumination; dark back textures stay visible.
                image[y0:y1+1,x0:x1+1][mask]=np.clip(color[...,:3]*shades[index]*255,0,255).astype(np.uint8)[mask]
                region[mask]=d[mask]
        coverage=float(np.isfinite(depth).mean());out=io.BytesIO();Image.fromarray(image).save(out,format='PNG')
        results.append({'name':name,'data':out.getvalue(),'camera':{'name':name,'direction':list(direction),
            'projection':'orthographic','up':up.tolist(),'center':center.tolist(),'span':float(span),
            'renderer':RENDERER,'width':edge,'height':edge,'asset_sha256':sha,'coverage':coverage}})
    return results


def mesh_checks(raw, *, textured=False):
    parts=load_parts(raw);facts=[];warnings=[]
    for i,p in enumerate(parts):
        face=p['vertices'][p['faces']]
        area=np.linalg.norm(np.cross(face[:,1]-face[:,0],face[:,2]-face[:,0]),axis=1)/2
        extent=np.ptp(p['vertices'],axis=0);threshold=max(float(extent.max())**2*1e-12,1e-20)
        degenerate=int((area<=threshold).sum())
        facts.append({'part':i,'triangles':len(face),'degenerate_faces':degenerate,
                      'has_uv':p['uv'] is not None,'has_texture':p['texture'] is not None})
        if degenerate>max(2,len(face)*.01):warnings.append('excessive_degenerate_faces')
    if textured and not any(p['texture'] is not None and p['uv'] is not None for p in parts):warnings.append('missing_embedded_texture_or_uv')
    return {'renderer':RENDERER,'parts':facts,'issues':sorted(set(warnings)),
            'limitation':'Not a proof of watertightness, self-intersection, anatomy, PBR material fidelity or real unseen surfaces.'}


def surface_signature(raw):
    """Order/material/UV independent triangle coordinates, rounded to 1e-6.
    Detects retexturing that secretly changes shape; not a topology proof.
    """
    rows=[]
    for part in load_parts(raw):
        triangles=np.round(part['vertices'][part['faces']],6)
        # Lexicographic vertex order within each triangle.
        order=np.lexsort((triangles[:,:,2],triangles[:,:,1],triangles[:,:,0]),axis=1)
        canonical=np.take_along_axis(triangles,order[:,:,None],axis=1).reshape(-1,9)
        rows.append(canonical)
    values=np.vstack(rows);values=values[np.lexsort(values[:,::-1].T)]
    values[values==0]=0  # Normalize negative zero.
    return hashlib.sha256(values.astype('<f8').tobytes()).hexdigest()
