from __future__ import annotations
import copy
import hashlib
import io
import json
import math
import stat
import time
import zipfile
from pathlib import Path,PurePosixPath
import numpy as np
import trimesh
from .db import dumps,uid
from .schemas import ProjectCreate,Scene
from .errors import AppError
from .config import ROOT


def scene_glb(service,project,version=None):
    snap=service.scene(project,version)
    return assemble_glb(service,project,Scene.model_validate(snap['scene']))


def assemble_glb(service,project,scene):
    """Serialize an unpublished candidate too, with the exact export transforms."""
    result=trimesh.Scene()
    missing=[]
    for o in scene.objects:
        if not o.asset_id:missing.append(o.label);continue
        raw=service.assets.read(o.asset_id,project)
        src=trimesh.load(io.BytesIO(raw),file_type='glb',force='scene',process=False)
        bounds=src.bounds;extent=np.maximum(bounds[1]-bounds[0],.0001)
        scale=np.array(o.transform.size)/extent
        if o.transform.fit=='uniform':scale[:]=min(scale)
        offset=np.array([(bounds[0,0]+bounds[1,0])/2,bounds[0,1],(bounds[0,2]+bounds[1,2])/2])
        # glTF + our application use intrinsic XYZ Euler; trimesh rxyz matches.
        rotation=trimesh.transformations.euler_matrix(*o.transform.rotation,axes='rxyz')
        world=trimesh.transformations.translation_matrix(o.transform.position)@rotation@np.diag([*scale,1])@trimesh.transformations.translation_matrix(-offset)
        for node in src.graph.nodes_geometry:
            transform,geometry=src.graph[node];mesh=src.geometry[geometry].copy()
            if o.tint:
                tint=np.array([int(o.tint[i:i+2],16)/255 for i in (1,3,5)])
                if hasattr(mesh.visual,'vertex_colors'):
                    colors=mesh.visual.vertex_colors.copy();colors[:,:3]=np.round(tint*255).astype('uint8');mesh.visual.vertex_colors=colors
                elif hasattr(mesh.visual,'material'):
                    mat=mesh.visual.material.copy()
                    if hasattr(mat,'baseColorFactor'):
                        base=np.array(mat.baseColorFactor if mat.baseColorFactor is not None else [255,255,255,255],dtype=float)
                        base[:3]=tint*255;mat.baseColorFactor=np.round(base).astype('uint8')
                        # Whole-object recoloring replaces texture RGB, preserving
                        # the alpha silhouette. Keep the original asset immutable.
                        if mat.baseColorTexture is not None:
                            from PIL import Image
                            original=mat.baseColorTexture.convert('RGBA')
                            neutral=Image.new('RGBA',original.size,(255,255,255,255))
                            neutral.putalpha(original.getchannel('A'));mat.baseColorTexture=neutral
                    mesh.visual.material=mat
            result.add_geometry(mesh,node_name=o.id+'_'+str(node),transform=world@transform)
    if missing:raise AppError('场景仍有未生成对象，不能导出为完整 GLB：'+', '.join(missing),409)
    if not result.geometry:raise AppError('没有可导出的三维资产。')
    result.metadata={'title':scene.title,'schema':'MemoryScape1.0','note':'Audio, diary and interaction are in the memory project, not this GLB.'}
    return result.export(file_type='glb')


def export_project(service,project,include_originals=False,version=None):
    p=service.project(project);snap=service.scene(project,version);scene=snap['scene'];sources=service.sources(project)
    ids=set()
    for o in scene['objects']:
        ids.update(x for x in [o['asset_id'],o['reference_asset_id']] if x)
    for a in scene['audio']:
        if a['asset_id']:ids.add(a['asset_id'])
    if include_originals:ids.update(s['id'] for s in sources)
    assets=[];payload={}
    extension={'image/png':'.png','image/jpeg':'.jpg','image/webp':'.webp','audio/wav':'.wav','audio/mpeg':'.mp3',
               'audio/mp4':'.m4a','audio/ogg':'.ogg','audio/flac':'.flac','audio/webm':'.webm','text/plain':'.txt','model/gltf-binary':'.glb'}
    for id in sorted(ids):
        a=service.assets.get(id,project);path='assets/'+id+extension.get(a['mime'],'.bin')
        payload[path]=service.assets.read(id,project)
        if sum(len(v) for v in payload.values())>700*1024*1024:raise AppError('回忆项目展开大小超过 700 MiB。请减小资产或不打包全部原件；完整原件可使用备份命令保存。',413)
        # Do not export private endpoint names, generation prompts or runtime paths.
        safe={'id':id,'path':path,'sha256':a['sha'],'filename':a['filename'],'mime':a['mime'],'kind':a['kind'],
              'provenance':a['provenance'],'parents':[x for x in a['parents'] if x in ids],
              'meta':{k:v for k,v in a['meta'].items() if k in ('size','bounds','triangles','duration','sample_rate','channels','width','height','bytes')}}
        assets.append(safe)
    source_info=[]
    if include_originals:
        source_info=[{k:s[k] for k in ['id','role','label','subject','note','crop']} for s in sources if s['id'] in ids]
    # If originals are omitted, keep explanatory uncertainty, not dangling private identifiers.
    scene=copy.deepcopy(scene)
    for o in scene['objects']:
        o['reference_ids']=[x for x in o['reference_ids'] if x in ids]
        if o['generation']['primary_source'] not in ids:o['generation']['primary_source']=None
    for a in scene['audio']:
        if a['source_id'] not in ids:a['source_id']=None
    pack={'format':'memoryscape','format_version':'1.0','title':p['title'],'diary':p['diary'],'requirements':p['requirements'],
          'style':p['style'],'mode':p['mode'],'version':snap['version'],'scene':scene,'assets':assets,'sources':source_info,
          'includes_originals':include_originals,'exported_at':time.time(),
          'notice':'私密资料与合成内容分开。分享前检查日记、照片和声音授权。静态场景不等同于精确真实复原。'}
    payload['project.json']=dumps(pack).encode('utf-8')
    for path in ['player.html','player.js','viewer.js','quality.js','math.js','glb.js','audio.js','player.css','favicon.svg']:
        file=ROOT/'web'/path
        if file.is_file():payload['player/'+path]=file.read_bytes()
    payload['START_VIEWER.py']=b'''"""Run python START_VIEWER.py and open http://127.0.0.1:8765/player/player.html"""\nimport http.server, os\nfrom pathlib import Path\nos.chdir(Path(__file__).resolve().parent)\nprint("Open http://127.0.0.1:8765/player/player.html")\nhttp.server.ThreadingHTTPServer(("127.0.0.1",8765),http.server.SimpleHTTPRequestHandler).serve_forever()\n'''
    payload['README.txt']='解压后运行 python START_VIEWER.py，浏览器打开显示的本机地址。无需模型服务器。也可在 MemoryScape 中导入整个 zip。不要通过公网直接暴露目录。分享包内包含日记和已选择保留的音轨。'.encode('utf-8')
    manifest={name:hashlib.sha256(raw).hexdigest() for name,raw in payload.items()}
    payload['manifest.json']=dumps(manifest).encode()
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,data in payload.items():z.writestr(name,data)
    raw=out.getvalue()
    if len(raw)>512*1024*1024:raise AppError('项目包超过 512 MiB，请降低纹理体积或另行备份原件。',413)
    return raw


def import_project(service,raw):
    """Import only a validated data subset; bundled player code is NEVER installed or executed."""
    if len(raw)>512*1024*1024:raise AppError('项目包超过 512 MiB。',413)
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            info=z.infolist()
            if len(info)>1500 or sum(x.file_size for x in info)>768*1024*1024:raise AppError('压缩包展开大小超限。')
            names=[]
            for item in info:
                path=PurePosixPath(item.filename)
                if path.is_absolute() or '..' in path.parts or '\\' in item.filename or ':' in item.filename or stat.S_ISLNK(item.external_attr>>16):raise AppError('压缩包含不安全路径。')
                if item.file_size>128*1024*1024 or (item.file_size>10*1024*1024 and item.file_size/max(1,item.compress_size)>250):raise AppError('压缩包项过大或压缩比例异常。')
                names.append(item.filename)
            if len(names)!=len(set(names)):raise AppError('压缩包含重复文件名。')
            manifest=json.loads(z.read('manifest.json'));pack=json.loads(z.read('project.json'))
            if not isinstance(manifest,dict) or pack.get('format')!='memoryscape' or pack.get('format_version')!='1.0':raise AppError('不支持的项目格式。')
            for name,sha in manifest.items():
                if name not in names or hashlib.sha256(z.read(name)).hexdigest()!=sha:raise AppError('项目包校验失败。')
            if 'project.json' not in manifest:raise AppError('主项目文件没有校验值。')
            validated_scene=Scene.model_validate(pack['scene'])
            ProjectCreate(title=(pack['title']+' · 导入')[:100],diary=pack.get('diary',''),requirements=pack.get('requirements',''),style=pack.get('style',''),mode=pack.get('mode','demo'))
            if len(pack.get('assets',[]))>256:raise AppError('资产数量超限。')
            blobs=[];old_ids=set();kinds={}
            for asset in pack['assets']:
                name=asset['path'];id=asset['id']
                if id in old_ids or name not in manifest or not name.startswith('assets/'):raise AppError('资产清单无效。')
                old_ids.add(id);data=z.read(name)
                if hashlib.sha256(data).hexdigest()!=asset['sha256']:raise AppError('资产摘要不匹配。')
                from .media import inspect
                actual_kind,actual_mime,_=inspect(data,asset['filename'])
                if actual_kind!=asset.get('kind') or actual_mime!=asset.get('mime'):raise AppError('资产清单类型与实际文件不一致。')
                kinds[id]=actual_kind
                blobs.append((asset,data))
            # Validate all scene references BEFORE making a project visible.
            for o in pack['scene']['objects']:
                if o.get('asset_id') and kinds.get(o['asset_id'])!='model':raise AppError('场景模型引用类型错误。')
                if o.get('reference_asset_id') and kinds.get(o['reference_asset_id'])!='image':raise AppError('场景参考图类型错误。')
                for ref in [o.get('asset_id'),o.get('reference_asset_id'),*o.get('reference_ids',[])]:
                    if ref and ref not in old_ids:raise AppError('场景引用缺失的资产。')
            for src in pack.get('sources',[]):
                from .schemas import SourceUpdate
                if src.get('id') not in old_ids:raise AppError('原始资料索引缺失。')
                SourceUpdate.model_validate({k:v for k,v in src.items() if k!='id'})
                if any(src.get(k) is None for k in ('label','role','subject','note')):raise AppError('原始资料字段无效。')
            for a in pack['scene']['audio']:
                if a.get('asset_id') and kinds.get(a['asset_id'])!='audio':raise AppError('音轨文件类型错误。')
                for ref in [a.get('asset_id'),a.get('source_id')]:
                    if ref and ref not in old_ids:raise AppError('场景音轨引用缺失资产。')
    except (zipfile.BadZipFile,KeyError,ValueError,TypeError) as e:
        raise AppError('项目包无效或损坏。') from e
    p=service.create_project(ProjectCreate(title=(pack['title']+' · 导入')[:100],diary=pack.get('diary',''),requirements=pack.get('requirements',''),
                                         style=pack.get('style',''),mode=pack.get('mode','demo'),remote_consent=False))
    remap={}
    for a,data in blobs:
        stored=service.assets.put(p['id'],data,a['filename'],'imported',extra={'original_provenance':a.get('provenance','unknown')})
        remap[a['id']]=stored['id']
    def rewrite(v):
        if isinstance(v,str):return remap.get(v,v)
        if isinstance(v,list):return [rewrite(x) for x in v]
        if isinstance(v,dict):return {k:rewrite(x) for k,x in v.items()}
        return v
    for src in pack.get('sources',[]):
        if src['id'] not in remap:continue
        service.db.execute('INSERT INTO sources VALUES(?,?,?,?,?,?,?,?)',(remap[src['id']],p['id'],src['role'],src['label'],src.get('subject',''),src.get('note',''),dumps(src['crop']) if src.get('crop') else None,time.time()))
    scene=Scene.model_validate(rewrite(pack['scene']))
    service.publish(p['id'],scene,0,'导入已保存场景；未运行任何模型')
    service.db.remember(p['id'],'import',{'source_version':pack['version'],'includes_originals':pack.get('includes_originals',False)})
    return service.project(p['id'])
