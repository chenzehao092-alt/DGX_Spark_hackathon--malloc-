"""Fictional, explicitly procedural fixture. Not output from a generative model."""
from __future__ import annotations
import io
import math
import numpy as np
from PIL import Image,ImageDraw
from .schemas import *
from .media import encode_wav
from .layout import solve_layout
from .db import dumps


def demo_plan(project,sources):
    refs=[s['id'] for s in sources if s['kind']=='image']
    def obj(id,label,kind,primitive,pos,size,color,caption=''):
        return SceneObject(id=id,label=label,kind=kind,transform=Transform(position=pos,size=size,fit='stretch'),color=color,caption=caption,
                           reference_ids=refs[:1],generation=Generation(primitive=primitive),
                           description='程序化演示对象；未调用人物或三维生成模型。',uncertainty='虚构示例，不代表上传照片中的真实人物。')
    objects=[obj('table','生日餐桌','furniture','table',[0,0,0],[3.5,1.17,1.92],'#bd9272'),
             obj('cake','十八岁生日蛋糕','food','cake',[0,1.17,0],[1.05,.95,1.05],'#dea8a2','18')]
    palette=['#809c92','#d8b06f','#b7aecb','#7e9eae','#c48278']
    coords=[(-1.65,0,-1.35),(-.82,0,-1.75),(0,0,-1.9),(.86,0,-1.65),(1.7,0,-1.2)]
    for i,pos in enumerate(coords):
        o=obj(f'person_{i+1}', '主角 · 帽子参考' if i==2 else f'朋友 {i+1}', 'person','person',list(pos),[.66,1.95 if i==2 else 1.8,.45],palette[i], 'party' if i==2 else '')
        o.transform.rotation=[0,(-pos[0])*.18,0];objects.append(o)
    for i,(x,z,col) in enumerate([(-2.6,-1.9,'#d6aa83'),(-2.9,-1.5,'#dcbdb9'),(2.55,-1.7,'#8fa59c'),(2.95,-1.55,'#d7bc86')]):
        objects.append(obj(f'balloon_{i+1}',f'气球 {i+1}','decoration','balloon',[x,0,z],[.72,2.75+(i%2)*.35,.72],col))
    objects.append(obj('keepsake','礼物盒','prop','box',[1.05,1.17,.18],[.46,.4,.4],'#8baba1'))
    objects.append(obj('memory_card','纪念日记卡','text','text',[-1.05,1.18,.3],[.5,.018,.33],'#f5e7cf','18 · MAKE A WISH'))
    tracks=[AudioTrack(id=f'original_{i+1}',label=s['label'],strategy='original',source_id=s['id'],anchor='table') for i,s in enumerate(sources) if s['kind']=='audio']
    scene=Scene(title=project['title'],story=project['diary'] or '十八岁的夏天，愿望还没有说出口，朋友已经替你记住了这一刻。',
                style=project['style'],objects=objects,audio=tracks,relations=[Relation(type='on',subject='cake',target='table')],
                assumptions=['所有人物与图片为程序示例；未识别真实人物。','音频为程序合成测试和弦，不是生日合唱。'],
                locked_facts=['锁定对象必须保持不变。','原始音频永不覆盖。'])
    # Budget is real even in demo: never silently claim all objects fit a smaller budget.
    if len(scene.objects)>project['budget']['max_objects']:
        from .errors import AppError
        raise AppError('示例需要至少 13 个对象的预算；请调高预算或建立真实自定义项目。')
    return ScenePlan(summary='规则演示：独立人物、蛋糕与装饰，先装配再局部编辑；没有调用任何大模型。',scene=solve_layout(scene),
                     confirmations=['示例中的五个人物都是程序化虚构形象。','精确人物重建需要真实模型与相应参考。'],warnings=['DEMO：这不是旗舰 LLM 的推理。'])


def illustration(kind):
    im=Image.new('RGB',(720,480),'#f1e7da');d=ImageDraw.Draw(im)
    d.rounded_rectangle((20,20,700,460),radius=28,fill='#e3d7c7')
    if kind=='scene':
        for x,col in zip([160,260,360,460,560],['#9cb0a4','#dbbc88','#b7abc7','#86a4b0','#c79587']):
            d.rounded_rectangle((x-30,180,x+30,310),radius=20,fill=col);d.ellipse((x-23,124,x+23,176),fill='#e5baa0')
        d.polygon([(155,290),(575,290),(630,360),(100,360)],fill='#bb9577');d.rectangle((145,360,165,420),fill='#8c735c');d.rectangle((555,360,575,420),fill='#8c735c')
        d.ellipse((320,283,400,313),fill='#f2d3bc');d.rectangle((320,260,400,300),fill='#d79996');d.ellipse((320,249,400,273),fill='#fff0db')
    elif kind=='cake':
        d.ellipse((175,345,545,401),fill='#bda680');d.rectangle((210,195,510,365),fill='#dcaca6');d.ellipse((210,155,510,235),fill='#fff0d8');d.rectangle((267,118,453,200),fill='#e6c0b2');d.ellipse((267,92,453,145),fill='#fff0d8')
        for x in (334,384):d.line((x,88,x,42),fill='#ac805e',width=8);d.ellipse((x-6,27,x+6,43),fill='#ffc875')
    else:
        d.rounded_rectangle((242,255,478,465),radius=58,fill='#b6aec6');d.ellipse((280,120,440,285),fill='#e5baa0');d.polygon([(264,133),(452,133),(358,28)],fill='#d6b979')
        for x in (330,390):d.ellipse((x-4,193,x+4,201),fill='#484036')
    d.text((38,438),'PROCEDURAL FIXTURE / NOT A REAL PHOTO',fill='#645c54')
    out=io.BytesIO();im.save(out,'PNG');return out.getvalue()


def seed_project(service):
    p=service.create_project(ProjectCreate(title='十八岁的夏天',diary='这是一个虚构的生日回忆示例。五位朋友、一个蛋糕、一张写着愿望的卡片。',
                                         requirements='制作朋友围桌的温暖生日场景，保留原声，蛋糕和气球可独立修改。',mode='demo'))
    for kind,role,label,subject in [('scene','scene','生日全景 · 程序插画',''),('cake','object','蛋糕特写 · 程序插画','蛋糕'),('person','person','帽子参考 · 程序插画','主角')]:
        s=service.add_source(p['id'],illustration(kind),f'demo-{kind}.png',role,label,subject,'自带虚构样例，不是真实照片。',True)
        service.db.execute('UPDATE assets SET provenance="procedural" WHERE id=?',(s['id'],))
    rate=16000;t=np.arange(rate*12)/rate
    signal=sum(np.sin(2*np.pi*f*t) for f in (261.63,329.63,392))/3
    env=np.minimum(t/.7,1)*np.minimum((12-t)/1.5,1)
    audio=encode_wav(signal*env*2000,rate)
    s=service.add_source(p['id'],audio,'demo-chord.wav','audio','12 秒测试和弦 · 非真实录音','','程序化测试音，不是朋友的合唱。',True)
    service.db.execute('UPDATE assets SET provenance="procedural" WHERE id=?',(s['id'],))
    return service.project(p['id'])
