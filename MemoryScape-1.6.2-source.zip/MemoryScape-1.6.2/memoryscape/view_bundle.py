"""Validate view coverage and provenance; client screenshots are not mesh proof."""
import math
import json
from typing import Literal
from pydantic import Field
from .schemas import Strict,Vec3,ID
from .errors import AppError
from .db import digest

ANGLES={'front':(0,0),'back':(math.pi,0),'left':(-math.pi/2,0),'right':(math.pi/2,0),
        'top':(0,math.pi/2),'bottom':(0,-math.pi/2),
        'oblique_front':(math.pi/4,.48),'oblique_back':(-3*math.pi/4,.48)}


class ViewCamera(Strict):
    protocol: Literal['view-bundle-v1']=Field(alias='schema')
    name: Literal['front','back','left','right','top','bottom','oblique_front','oblique_back']
    yaw: float
    pitch: float
    distance: float=Field(gt=0,le=1000)
    target: Vec3
    width: int=Field(ge=128,le=2048)
    height: int=Field(ge=128,le=2048)
    renderer: Literal['webgl2']
    object_id: ID | None = None
    hide_environment: Literal[True]
    failed_assets: list[str]=Field(default_factory=list,max_length=32)
    asset_ids: list[str]=Field(min_length=1,max_length=32)


def validate_camera(cam,scene):
    value=ViewCamera.model_validate(cam)
    expected=[o for o in scene['objects'] if value.object_id is None or o['id']==value.object_id]
    if not expected or any(not o['asset_id'] for o in expected):raise AppError('检查对象尚无实际网格。')
    if value.failed_assets or set(value.asset_ids)!={o['asset_id'] for o in expected}:raise AppError('截图的网格加载记录与当前检查范围不符。')
    yaw,pitch=ANGLES[value.name]
    delta=(value.yaw-yaw+math.pi)%(2*math.pi)-math.pi
    if abs(delta)>.025 or abs(value.pitch-pitch)>.025:raise AppError('截图方向与视角标签不符；未接受伪背面。')
    return {**value.model_dump(by_alias=True),'scene_hash':digest(scene)}


def validate_bundle(service,project,payload):
    ids=payload['render_ids']
    if len(set(ids))!=len(ids):raise AppError('不能重复同一截图作为多个方向。')
    scene=service.scene(project,payload['base_version'])['scene'];cameras=[]
    for rid in ids:
        r=service.db.one('SELECT * FROM renders WHERE id=? AND project=?',(rid,project))
        if not r or r['version']!=payload['base_version']:raise AppError('截图不属于当前场景版本。')
        camera=json.loads(r['camera'])
        if camera.get('schema')!='view-bundle-v1':raise AppError('六向复核不能使用旧的单视角证据。')
        bound=camera.pop('scene_hash',None)
        if bound!=digest(scene):raise AppError('截图的场景哈希已变化。',409,'version_conflict')
        valid=validate_camera(camera,scene)
        if valid['object_id']!=payload.get('selected_object'):raise AppError('截图目标与复核对象不符。')
        service.assets.read(r['asset_id'],project)  # Validate bytes, not just row.
        cameras.append(valid)
    names=[c['name'] for c in cameras]
    expected=set(ANGLES) if payload.get('selected_object') is None else set(list(ANGLES)[:6])
    if len(names)!=len(set(names)) or set(names)!=expected:raise AppError('视角覆盖不完整，必须包含背面、两侧、顶部和底部。',409,'view_coverage_incomplete')
    return {'mode':'canonical','views':names,'scope':'object' if payload.get('selected_object') else 'scene',
            'scene_hash':digest(scene),'screenshots_source':'authenticated-client-render-not-topology-proof'}
