"""Application launcher. GPU dependencies live in separate model-node environments."""
from __future__ import annotations
import argparse
import copy
import json
import logging
import os
import secrets
import shutil
import sys
from pathlib import Path
from .config import Settings,ROOT,load_env


class LocalAuthFilter(logging.Filter):
    """Drops uvicorn access-log lines for /auth/local so the one-time token
    in the query string never reaches logs."""

    def filter(self, record: logging.LogRecord) -> bool:
        return '/auth/local' not in record.getMessage()


def main():
    parser=argparse.ArgumentParser(prog='memoryscape')
    parser.add_argument('command',nargs='?',choices=['serve','setup','check','backup'],default='serve')
    parser.add_argument('--host',default='127.0.0.1');parser.add_argument('--port',type=int,default=8000)
    parser.add_argument('--data',type=Path);parser.add_argument('--models',type=Path);parser.add_argument('--output',type=Path)
    args=parser.parse_args();load_env(ROOT/'.env')
    kwargs={}
    if args.data:kwargs['data_dir']=args.data
    if args.models:kwargs['config_file']=args.models
    settings=Settings(**kwargs).initialize()
    if args.command=='setup':
        example=ROOT/'configs/models.example.toml'
        if not settings.config_file.exists() and example.exists():
            settings.config_file.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(example,settings.config_file)
        print('Workspace:',settings.data_dir)
        print('Local browser access is automatic; no access-token input is needed.')
        if (settings.data_dir/'access-token').is_file():
            print('Private administrator token file:',settings.data_dir/'access-token')
        else:print('Administrator credential is configured privately by the environment; it is not echoed.')
        print('Run: python -m memoryscape.cli serve');return
    if args.command=='check':
        from .service import Service
        from .providers import Providers
        print(json.dumps(Providers(Service(settings)).preflight(),ensure_ascii=False,indent=2));return
    if args.command=='backup':
        from .backup import backup
        target=args.output or ROOT/'backups'/('memoryscape-backup-'+__import__('datetime').datetime.now().strftime('%Y%m%d-%H%M%S')+'.zip')
        backup(settings,target);print('Backup:',target);return
    if args.host not in ('127.0.0.1','localhost','::1') and os.getenv('MS_ALLOW_NETWORK','false').lower()!='true':
        parser.error('Network binding requires MS_ALLOW_NETWORK=true, authorized hostnames and an approved TLS/reverse-proxy configuration.')
    print('\nMemoryScape / 拾光 3D',flush=True)
    print(f'Open http://{args.host}:{args.port}',flush=True)
    print('Local browser access is automatic; no access-token input is needed.' if settings.local_auto_login and args.host in ('127.0.0.1','localhost','::1')
          else 'Manual authentication enabled; use your privately configured access token.',flush=True)
    print('User data: '+str(settings.data_dir),flush=True)
    from .api import create_app
    from .security import ProcessLock
    # One app worker per SQLite workspace. Remote model nodes are independent.
    lock=ProcessLock(settings.data_dir/'app-process.lock');lock.acquire()
    try:
        import uvicorn
        from uvicorn.config import LOGGING_CONFIG
        log_config = copy.deepcopy(LOGGING_CONFIG)
        log_config.setdefault('filters', {})['local_auth'] = {'()': 'memoryscape.cli.LocalAuthFilter'}
        log_config['handlers']['access']['filters'] = ['local_auth']
        uvicorn.run(create_app(settings),host=args.host,port=args.port,workers=1,log_config=log_config)
    finally:lock.release()

if __name__=='__main__':main()
