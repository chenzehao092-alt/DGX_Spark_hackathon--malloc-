from __future__ import annotations
import contextlib
import hashlib
import json
import sqlite3
import time
import uuid
from pathlib import Path
from .errors import AppError


def uid(prefix='') -> str:
    return prefix + uuid.uuid4().hex[:24]


def dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value) -> str:
    return hashlib.sha256(dumps(value).encode()).hexdigest()


DDL = '''
CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, doc TEXT NOT NULL, head INTEGER NOT NULL DEFAULT 0,
 input_revision INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL, updated REAL NOT NULL);
CREATE TABLE IF NOT EXISTS assets(id TEXT PRIMARY KEY, project TEXT NOT NULL REFERENCES projects(id), sha TEXT NOT NULL,
 filename TEXT NOT NULL, kind TEXT NOT NULL, mime TEXT NOT NULL, meta TEXT NOT NULL, provenance TEXT NOT NULL,
 parents TEXT NOT NULL, created REAL NOT NULL);
CREATE INDEX IF NOT EXISTS asset_project ON assets(project,created);
CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY REFERENCES assets(id), project TEXT NOT NULL REFERENCES projects(id),
 role TEXT NOT NULL,label TEXT NOT NULL,subject TEXT NOT NULL,note TEXT NOT NULL,crop TEXT,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS versions(project TEXT NOT NULL REFERENCES projects(id),version INTEGER NOT NULL,scene TEXT NOT NULL,
 note TEXT NOT NULL,job TEXT,created REAL NOT NULL,PRIMARY KEY(project,version));
CREATE TABLE IF NOT EXISTS plans(id TEXT PRIMARY KEY,project TEXT NOT NULL REFERENCES projects(id),base_version INTEGER NOT NULL,
 input_revision INTEGER NOT NULL,body TEXT NOT NULL,status TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS proposals(id TEXT PRIMARY KEY, project TEXT NOT NULL REFERENCES projects(id), body TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending', created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,project TEXT REFERENCES projects(id),kind TEXT NOT NULL,payload TEXT NOT NULL,
 status TEXT NOT NULL,owner TEXT,lease REAL,attempts INTEGER NOT NULL DEFAULT 0,error TEXT,result TEXT,
 cancel INTEGER NOT NULL DEFAULT 0,idem TEXT,fp TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL);
CREATE UNIQUE INDEX IF NOT EXISTS job_idempotency ON jobs(project,idem) WHERE idem IS NOT NULL;
CREATE INDEX IF NOT EXISTS job_queue ON jobs(status,lease,created);
CREATE TABLE IF NOT EXISTS steps(job TEXT NOT NULL REFERENCES jobs(id),name TEXT NOT NULL,input_hash TEXT NOT NULL,
 status TEXT NOT NULL,result TEXT,remote TEXT,attempt INTEGER NOT NULL DEFAULT 0,error TEXT,updated REAL NOT NULL,
 PRIMARY KEY(job,name));
CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,project TEXT,job TEXT,kind TEXT NOT NULL,
 body TEXT NOT NULL,created REAL NOT NULL);
CREATE INDEX IF NOT EXISTS event_project ON events(project,seq);
CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY AUTOINCREMENT,project TEXT NOT NULL,object_id TEXT,
 kind TEXT NOT NULL,body TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS renders(id TEXT PRIMARY KEY,project TEXT NOT NULL,version INTEGER NOT NULL,
 asset_id TEXT NOT NULL REFERENCES assets(id),camera TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS agent_runs(root TEXT PRIMARY KEY,project TEXT NOT NULL REFERENCES projects(id),
 limits TEXT NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS agent_jobs(job TEXT PRIMARY KEY REFERENCES jobs(id),root TEXT NOT NULL REFERENCES agent_runs(root),started REAL);
CREATE TABLE IF NOT EXISTS agent_charges(root TEXT NOT NULL REFERENCES agent_runs(root),kind TEXT NOT NULL,
 charge_key TEXT NOT NULL,job TEXT NOT NULL REFERENCES jobs(id),created REAL NOT NULL,PRIMARY KEY(root,kind,charge_key));
CREATE TABLE IF NOT EXISTS agent_reviews(project TEXT NOT NULL REFERENCES projects(id),version INTEGER NOT NULL,
 input_revision INTEGER NOT NULL,job TEXT PRIMARY KEY REFERENCES jobs(id));
'''


class DB:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with contextlib.closing(self.connect()) as con:
            con.executescript(DDL)
            con.execute('PRAGMA user_version=2')

    def connect(self):
        c = sqlite3.connect(self.path, timeout=20, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA foreign_keys=ON')
        c.execute('PRAGMA journal_mode=WAL')
        c.execute('PRAGMA busy_timeout=20000')
        return c

    @contextlib.contextmanager
    def tx(self):
        c = self.connect()
        try:
            c.execute('BEGIN IMMEDIATE')
            yield c
            c.commit()
        except Exception:
            c.rollback()
            raise
        finally:
            c.close()

    def one(self, sql, args=()):
        with contextlib.closing(self.connect()) as c:
            r = c.execute(sql, args).fetchone()
            return dict(r) if r else None

    def all(self, sql, args=()):
        with contextlib.closing(self.connect()) as c:
            return [dict(r) for r in c.execute(sql, args).fetchall()]

    def execute(self, sql, args=()):
        with self.tx() as c:
            c.execute(sql, args)

    def event(self, project, job, kind, body, c=None):
        args = (project, job, kind, dumps(body), time.time())
        if c is not None:
            c.execute('INSERT INTO events(project,job,kind,body,created) VALUES(?,?,?,?,?)', args)
        else:
            self.execute('INSERT INTO events(project,job,kind,body,created) VALUES(?,?,?,?,?)', args)

    def remember(self, project, kind, body, object_id=None, c=None):
        args = (project, object_id, kind, dumps(body), time.time())
        if c is not None:
            c.execute('INSERT INTO memories(project,object_id,kind,body,created) VALUES(?,?,?,?,?)', args)
        else:
            self.execute('INSERT INTO memories(project,object_id,kind,body,created) VALUES(?,?,?,?,?)', args)

    def backup(self, output: Path):
        with contextlib.closing(self.connect()) as src, contextlib.closing(sqlite3.connect(output)) as dst:
            src.backup(dst)
