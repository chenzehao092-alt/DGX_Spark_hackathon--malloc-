"""Versioned contracts. Model output is data, never executable code."""
from __future__ import annotations
import math
from typing import Annotated, Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

ID = Annotated[str, Field(pattern=r'^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$')]
Vec3 = Annotated[list[float], Field(min_length=3, max_length=3)]
Color = Annotated[str, Field(pattern=r'^#[0-9a-fA-F]{6}$')]


class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False, validate_default=True)


class Budget(Strict):
    max_objects: int = Field(20, ge=1, le=32)
    max_generated_assets: int = Field(8, ge=0, le=16)
    max_parallel: int = Field(3, ge=1, le=3)
    max_review_rounds: int = Field(2, ge=0, le=2)
    max_director_calls: int = Field(32, ge=0, le=96)
    max_remote_jobs: int = Field(32, ge=0, le=96)
    max_job_seconds: int = Field(7200, ge=60, le=28800)


class ProjectCreate(Strict):
    title: str = Field('新的回忆', min_length=1, max_length=100)
    diary: str = Field('', max_length=15000)
    requirements: str = Field('', max_length=8000)
    style: str = Field('温暖、统一材质的风格化三维微缩场景', max_length=1000)
    mode: Literal['demo', 'real'] = 'demo'
    remote_consent: bool = False
    allow_synthetic_audio: bool = False
    audio_mode: Literal['passthrough', 'describe'] = 'passthrough'
    budget: Budget = Field(default_factory=Budget)


class ProjectUpdate(Strict):
    title: str | None = Field(None, min_length=1, max_length=100)
    diary: str | None = Field(None, max_length=15000)
    requirements: str | None = Field(None, max_length=8000)
    style: str | None = Field(None, max_length=1000)
    remote_consent: bool | None = None
    allow_synthetic_audio: bool | None = None
    audio_mode: Literal['passthrough', 'describe'] | None = None
    budget: Budget | None = None
    expected_input_revision: int = Field(ge=0)


class Crop(Strict):
    x: float = Field(0, ge=0, lt=1)
    y: float = Field(0, ge=0, lt=1)
    width: float = Field(1, gt=0, le=1)
    height: float = Field(1, gt=0, le=1)

    @model_validator(mode='after')
    def contained(self):
        if self.x + self.width > 1.000001 or self.y + self.height > 1.000001:
            raise ValueError('裁剪范围必须位于图片内部。')
        return self


class SourceUpdate(Strict):
    role: Literal['scene', 'person', 'object', 'style', 'audio', 'diary'] | None = None
    label: str | None = Field(None, max_length=100)
    subject: str | None = Field(None, max_length=100)
    note: str | None = Field(None, max_length=1000)
    crop: Crop | None = None


class Transform(Strict):
    position: Vec3 = Field(default_factory=lambda: [0, 0, 0])
    rotation: Vec3 = Field(default_factory=lambda: [0, 0, 0], description='XYZ Euler radians, Y up')
    size: Vec3 = Field(default_factory=lambda: [1, 1, 1], description='target displayed bounding size, not measurement')
    fit: Literal['uniform', 'stretch'] = 'uniform'

    @field_validator('position')
    @classmethod
    def within_world(cls, v):
        if any(abs(x) > 100 for x in v):
            raise ValueError('position exceeds 100 display units')
        return v

    @field_validator('size')
    @classmethod
    def positive(cls, v):
        if any(x < .01 or x > 50 for x in v):
            raise ValueError('size must be within 0.01..50')
        return v

    @field_validator('rotation')
    @classmethod
    def radians(cls, v):
        if any(abs(x) > 2*math.pi+.001 for x in v):
            raise ValueError('rotation is in radians within -2π..2π, not degrees')
        return v


class GeometryOptions(Strict):
    seed: int = Field(2026, ge=0, lt=2**31)
    textured: bool = True
    steps: int = Field(30, ge=4, le=80)
    guidance_scale: float = Field(7.5, ge=1, le=15)
    max_faces: int = Field(60000, ge=1000, le=200000)


class Generation(Strict):
    strategy: Literal['procedural', 'generate3d', 'photo', 'reuse'] = 'procedural'
    primitive: Literal['person', 'table', 'cake', 'balloon', 'box', 'sphere', 'cylinder', 'plane', 'chair', 'hat', 'text', 'frame'] = 'box'
    image_mode: Literal['original', 'crop', 'edit', 'text2image'] = 'original'
    primary_source: str | None = None
    crop: Crop | None = None
    image_prompt: str = Field('', max_length=4000)
    image_model: str | None = None
    geometry_model: str | None = None
    reuse_object: str | None = None
    frame_target: ID | None = None
    options: GeometryOptions = Field(default_factory=GeometryOptions)


class SceneObject(Strict):
    id: ID
    label: str = Field(max_length=100)
    kind: Literal['person', 'furniture', 'food', 'decoration', 'background', 'prop', 'text'] = 'prop'
    description: str = Field('', max_length=1500)
    reference_ids: list[str] = Field(default_factory=list, max_length=12)
    source_subject: str = Field('', max_length=100, description='User-confirmed association, not facial identification')
    transform: Transform = Field(default_factory=Transform)
    color: Color = '#d7ad70'
    tint: Color | None = None
    caption: str = Field('', max_length=100)
    locked: bool = False
    generation: Generation = Field(default_factory=Generation)
    asset_id: str | None = None
    reference_asset_id: str | None = None
    status: Literal['planned', 'ready', 'failed', 'generating'] = 'planned'
    provenance: Literal['procedural', 'generated', 'photo', 'imported'] = 'procedural'
    uncertainty: str = Field('不可见部分为生成性补全；展示尺寸不是实测。', max_length=1000)


class Relation(Strict):
    type: Literal['on', 'near', 'face', 'around']
    subject: ID
    target: ID
    offset: Vec3 = Field(default_factory=lambda: [0, 0, 0])
    radius: float = Field(2.2, ge=.1, le=30)
    angle: float = Field(0, ge=-6.284, le=6.284)


class AudioTrack(Strict):
    id: ID
    label: str = Field(max_length=100)
    strategy: Literal['original', 'enhance', 'tts', 'music'] = 'original'
    source_id: str | None = None
    asset_id: str | None = None
    model: str | None = None
    prompt: str = Field('', max_length=2000)
    start: float = Field(0, ge=0, le=3600)
    trim_start: float = Field(0, ge=0, le=3600)
    duration: float | None = Field(None, gt=0, le=3600)
    gain: float = Field(1, ge=0, le=2)
    loop: bool = False
    anchor: str | None = None
    status: Literal['planned', 'ready', 'failed'] = 'planned'


class Scene(Strict):
    schema_version: Literal['1.0'] = '1.0'
    title: str = Field('回忆场景', max_length=100)
    story: str = Field('', max_length=4000)
    style: str = Field('', max_length=1000)
    objects: list[SceneObject] = Field(default_factory=list, max_length=32)
    relations: list[Relation] = Field(default_factory=list, max_length=100)
    audio: list[AudioTrack] = Field(default_factory=list, max_length=12)
    background: Color = '#eee4d9'
    camera_position: Vec3 = Field(default_factory=lambda: [7, 5.5, 8])
    camera_target: Vec3 = Field(default_factory=lambda: [0, 1, 0])
    assumptions: list[str] = Field(default_factory=list, max_length=30)
    locked_facts: list[str] = Field(default_factory=list, max_length=30)

    @model_validator(mode='after')
    def references(self):
        ids = [o.id for o in self.objects]
        if len(set(ids)) != len(ids):
            raise ValueError('对象 ID 重复。')
        aids = [a.id for a in self.audio]
        if len(set(aids)) != len(aids):
            raise ValueError('音轨 ID 重复。')
        for r in self.relations:
            if r.subject not in ids or r.target not in ids or r.subject == r.target:
                raise ValueError('空间关系引用了不存在/相同的对象。')
        for a in self.audio:
            if a.anchor and a.anchor not in ids:
                raise ValueError('音轨绑定对象不存在。')
        for o in self.objects:
            if o.generation.strategy == 'reuse' and (o.generation.reuse_object not in ids or o.generation.reuse_object == o.id):
                raise ValueError('资产复用的目标无效。')
            target=o.generation.frame_target
            if target and (o.generation.strategy!='procedural' or o.generation.primitive!='frame' or
                           target not in ids or target==o.id or
                           next(x for x in self.objects if x.id==target).generation.strategy!='photo'):
                raise ValueError('边框只能绑定当前场景中的独立图片展示面。')
        return self


class ObjectEvidence(Strict):
    object_id: ID
    source_ids: list[str] = Field(default_factory=list,max_length=12)
    crop: Crop | None = None
    observed: list[str] = Field(default_factory=list,max_length=8)
    inferred: list[str] = Field(default_factory=list,max_length=8)
    required_parts: list[str] = Field(default_factory=list,max_length=8)
    forbidden_additions: list[str] = Field(default_factory=list,max_length=8)

    @field_validator('observed','inferred','required_parts','forbidden_additions')
    @classmethod
    def bounded_evidence(cls,values):
        if any(not v.strip() or len(v)>160 for v in values):raise ValueError('证据条目需为 1..160 字符')
        return values


class SceneEvidenceManifest(Strict):
    schema_version: Literal['1.0'] = '1.0'
    origin: Literal['multimodal','legacy_plan'] = 'multimodal'
    objects: list[ObjectEvidence] = Field(default_factory=list,max_length=32)
    shared_constraints: list[str] = Field(default_factory=list,max_length=16)

    @model_validator(mode='after')
    def distinct(self):
        if len({o.object_id for o in self.objects})!=len(self.objects):raise ValueError('拆分清单对象重复')
        if any(len(x)>300 for x in self.shared_constraints):raise ValueError('场景约束过长')
        return self


class ScenePlan(Strict):
    summary: str = Field(max_length=3000)
    scene: Scene
    reference_person_count: int | None = Field(None, ge=0, le=20, strict=True,
        description='主场景原图中可见的人物数，不猜遮挡的人。要求保留原图人数时必填；这是模型统计，仍需视觉复核。')
    confirmations: list[str] = Field(default_factory=list, max_length=20)
    warnings: list[str] = Field(default_factory=list, max_length=30)
    decomposition: SceneEvidenceManifest | None = None

    @model_validator(mode='before')
    @classmethod
    def canonical_person_count(cls, value):
        """Normalize one known metadata field, without ignoring arbitrary extras."""
        if not isinstance(value, dict) or not isinstance(value.get('scene'), dict):
            return value
        if 'reference_person_count' not in value['scene']:
            return value
        result = dict(value)
        scene = dict(value['scene'])
        count = scene.pop('reference_person_count')
        top = result.get('reference_person_count')
        if top is not None and count is not None and (type(top) is not type(count) or top != count):
            raise ValueError('顶层与 scene 中的 reference_person_count 冲突，不能猜测人数。')
        result['reference_person_count'] = top if top is not None else count
        result['scene'] = scene
        return result


class SizeEdit(Strict):
    """Partial dimensions or uniform relative scaling; no guessed pose."""
    width: float | None = Field(None, ge=.01, le=50)
    height: float | None = Field(None, ge=.01, le=50)
    depth: float | None = Field(None, ge=.01, le=50)
    scale: float | None = Field(None, ge=.01, le=50)

    @model_validator(mode='after')
    def exclusive(self):
        axes=any(v is not None for v in (self.width,self.height,self.depth))
        if axes == (self.scale is not None):
            raise ValueError('resize requires dimensions OR scale, not both/neither')
        return self


class Operation(Strict):
    object_id: str | None = None
    audio_id: str | None = None
    type: Literal['transform', 'resize', 'restore_object', 'tint', 'clear_tint', 'lock', 'regenerate', 'audio', 'caption', 'add', 'bind_frame', 'remove']
    size_edit: SizeEdit | None = None
    source_version: int | None = Field(None, ge=0)
    new_object: SceneObject | None = None
    target_id: ID | None = None
    transform: Transform | None = None
    color: Color | None = None
    locked: bool | None = None
    caption: str | None = Field(None, max_length=100)
    prompt: str | None = Field(None, max_length=4000)
    gain: float | None = Field(None, ge=0, le=2)
    start: float | None = Field(None, ge=0, le=3600)

    @model_validator(mode='after')
    def operands(self):
        if self.type == 'add':
            if self.new_object is None or self.object_id != self.new_object.id:
                raise ValueError('add requires new_object and matching object_id')
        elif self.new_object is not None:
            raise ValueError('new_object is only allowed for add')
        if self.type=='bind_frame' and not self.target_id:
            raise ValueError('bind_frame requires target_id')
        if self.type!='bind_frame' and self.target_id is not None:
            raise ValueError('target_id is only allowed for bind_frame')
        if self.type == 'audio':
            if not self.audio_id or (self.gain is None and self.start is None):
                raise ValueError('audio operation requires audio_id and gain/start')
        elif not self.object_id:
            raise ValueError('object_id required')
        required = {'transform':'transform', 'resize':'size_edit', 'restore_object':'source_version', 'tint':'color', 'lock':'locked', 'caption':'caption'}
        if self.type in required and getattr(self, required[self.type]) is None:
            raise ValueError(f'{required[self.type]} is required')
        allowed={'add':{'new_object'},'transform':{'transform'},'resize':{'size_edit'},'restore_object':{'source_version'},'tint':{'color'},'clear_tint':set(),
                 'lock':{'locked'},'regenerate':{'prompt'},'audio':{'gain','start'},'caption':{'caption'},'bind_frame':set(),'remove':set()}[self.type]
        for name in ('new_object','transform','size_edit','source_version','color','locked','caption','prompt','gain','start'):
            if name not in allowed and getattr(self,name) is not None:
                raise ValueError(f'{name} is not applicable to {self.type}')
        if self.type=='audio' and self.object_id is not None:
            raise ValueError('audio cannot specify object_id')
        if self.type!='audio' and self.audio_id is not None:
            raise ValueError('audio_id is only allowed for audio')
        return self


class Patch(Strict):
    base_version: int = Field(ge=0)
    explanation: str = Field('', max_length=3000)
    operations: list[Operation] = Field(default_factory=list, max_length=16)


class EditRequest(Strict):
    prompt: str = Field(min_length=1, max_length=4000)
    selected_object: str | None = None
    base_version: int = Field(ge=0)


class VisualFinding(Strict):
    object_id: ID
    view: Literal['front','back','left','right','top','bottom','oblique_front','oblique_back','all']
    severity: Literal['critical','major','minor']
    category: Literal['reference','geometry','texture','layout','coverage']
    evidence: str=Field(min_length=1,max_length=700)
    repair: Literal['prepare_reference','regenerate_geometry','retexture','relayout','inspect','none']


class ReviewReport(Strict):
    summary: str = Field(max_length=3000)
    findings: list[str] = Field(default_factory=list, max_length=20)
    patch: Patch
    needs_user: bool = False
    quality_verdict: Literal['accept','reject','uncertain'] = 'uncertain'
    view_findings: list[VisualFinding] = Field(default_factory=list,max_length=24)

    @model_validator(mode='after')
    def honest_verdict(self):
        if self.quality_verdict=='accept' and any(f.severity in ('major','critical') for f in self.view_findings):
            raise ValueError('严重缺陷不能被标为通过')
        return self


class RemoteRequest(Strict):
    capability: Literal['image.edit', 'image.generate', 'geometry.generate', 'geometry.texture', 'audio.describe', 'audio.enhance', 'audio.tts', 'music.generate']
    input_asset: str | None = None
    reference_asset: str | None = None
    prompt: str = Field('', max_length=6000)
    options: dict = Field(default_factory=dict)

    @model_validator(mode='after')
    def auxiliary_input(self):
        if self.capability=='geometry.texture' and not self.reference_asset:raise ValueError('贴图任务必须提供参考图素材ID')
        if self.capability!='geometry.texture' and self.reference_asset is not None:raise ValueError('此能力不接受第二份参考图')
        return self
