from __future__ import annotations
import json
import re
import time
from pathlib import Path
from .config import Settings
from .db import DB,dumps,digest,uid
from .errors import AppError
from .storage import Assets
from .schemas import ProjectCreate,ProjectUpdate,SourceUpdate,Scene,ScenePlan,Patch,Budget
from .layout import check_scene,task_graph,fit_frames
from .media import canonical_audio
from .memory import aliases,deletion_intent,retrieve_episodes,validate_edit_intent,historical_objects,restoration_intent,dimension_intent,appearance_intent
from .edit_tools import validate_box_size,resized_transform,restoration_explanation,SKILL_CARDS


class Service:
    def __init__(self, settings:Settings):
        self.settings=settings
        self.db=DB(settings.data_dir/'memoryscape.sqlite3')
        self.assets=Assets(self.db,settings.data_dir/'blobs',settings.max_upload)

    def create_project(self, spec:ProjectCreate):
        id=uid('p_');now=time.time();scene=Scene(title=spec.title,style=spec.style)
        with self.db.tx() as c:
            c.execute('INSERT INTO projects VALUES(?,?,0,0,?,?)',(id,dumps(spec.model_dump()),now,now))
            c.execute('INSERT INTO versions VALUES(?,0,?,?,NULL,?)',(id,dumps(scene.model_dump()),'创建项目',now))
            self.db.remember(id,'project_goal',{'requirements':spec.requirements,'diary':spec.diary},c=c)
        return self.project(id)

    def project(self,id):
        row=self.db.one('SELECT * FROM projects WHERE id=?',(id,))
        if not row:raise AppError('项目不存在。',404)
        doc=json.loads(row.pop('doc'))
        # Additive defaults for projects created before durable agent budgets.
        # Reading a legacy album never rewrites its stored user document.
        doc['budget']=Budget.model_validate(doc.get('budget',{})).model_dump()
        return {**doc,**row}

    def projects(self):
        return [self.project(r['id']) for r in self.db.all('SELECT id FROM projects ORDER BY updated DESC')]

    def update_project(self,id,change:ProjectUpdate):
        with self.db.tx() as c:
            row=c.execute('SELECT * FROM projects WHERE id=?',(id,)).fetchone()
            if not row:raise AppError('项目不存在。',404)
            if row['input_revision']!=change.expected_input_revision:raise AppError('资料已被另一操作更新，请刷新。',409,'version_conflict')
            doc=json.loads(row['doc']);updates=change.model_dump(exclude_unset=True);updates.pop('expected_input_revision')
            if any(v is None for v in updates.values()):raise AppError('项目字段不能为 null。')
            doc.update(updates);ProjectCreate.model_validate(doc)
            c.execute('UPDATE projects SET doc=?,input_revision=input_revision+1,updated=? WHERE id=?',(dumps(doc),time.time(),id))
            self.db.remember(id,'requirements_changed',updates,c=c)
        return self.project(id)

    def sources(self,project):
        self.project(project);rows=self.db.all('SELECT * FROM sources WHERE project=? ORDER BY created',(project,))
        for r in rows:
            r.update(self.assets.get(r['id'],project));r['crop']=json.loads(r['crop']) if r.get('crop') else None
        return rows

    def add_source(self,project,raw,filename,role,label='',subject='',note='',rights=False):
        self.project(project)
        if not rights:raise AppError('请确认你有权使用并上传该素材。')
        if role not in ('scene','person','object','style','audio','diary'):raise AppError('素材角色无效。')
        if len(self.sources(project))>=60:raise AppError('一个项目最多 60 份原始资料；请分组建立回忆。')
        a=self.assets.put(project,raw,filename,extra={'rights_confirmed':True})
        if a['kind']=='audio':
            pcm=canonical_audio(raw,Path(filename).suffix.lower())
            canonical=self.assets.put(project,pcm,'audio-model-input.wav','derived',[a['id']],{'operation':'canonicalize_16k_mono'})
            a['meta']['canonical_id']=canonical['id']
            self.db.execute('UPDATE assets SET meta=? WHERE id=?',(dumps(a['meta']),a['id']))
            role='audio'
        elif a['kind']=='text':role='diary'
        elif a['kind']=='model':role='object'
        with self.db.tx() as c:
            c.execute('INSERT INTO sources VALUES(?,?,?,?,?,?,NULL,?)',(a['id'],project,role,(label or filename)[:100],subject[:100],note[:1000],time.time()))
            c.execute('UPDATE projects SET input_revision=input_revision+1,updated=? WHERE id=?',(time.time(),project))
            self.db.event(project,None,'source.added',{'id':a['id'],'label':label or filename,'kind':a['kind']},c)
        return next(s for s in self.sources(project) if s['id']==a['id'])

    def update_source(self,project,id,spec:SourceUpdate):
        row=self.db.one('SELECT * FROM sources WHERE id=? AND project=?',(id,project))
        if not row:raise AppError('原始资料不存在。',404)
        changes=spec.model_dump(exclude_unset=True)
        if any(v is None and k!='crop' for k,v in changes.items()):raise AppError('资料字段不能为 null，裁剪除外。')
        if 'role' in changes:
            kind=self.assets.get(id,project)['kind']
            if kind=='image' and changes['role'] not in ('scene','person','object','style'):raise AppError('图片的素材角色不正确。')
            if kind=='audio' and changes['role']!='audio':raise AppError('音频必须保留音频角色。')
            if kind=='text' and changes['role']!='diary':raise AppError('文本必须保留文字角色。')
        row.update(changes)
        if spec.crop is not None:row['crop']=dumps(spec.crop.model_dump())
        elif 'crop' in changes:row['crop']=None
        with self.db.tx() as c:
            c.execute('UPDATE sources SET role=?,label=?,subject=?,note=?,crop=? WHERE id=?',
                      (row['role'],row['label'],row['subject'],row['note'],row['crop'],id))
            c.execute('UPDATE projects SET input_revision=input_revision+1,updated=? WHERE id=?',(time.time(),project))
        return next(s for s in self.sources(project) if s['id']==id)

    def remove_source(self, project, source_id):
        """Remove unused input only; never delete immutable blobs or version sources.

        The transaction serializes with plan confirmation and version publication.
        Pending plans become invalid through the normal input_revision check.
        """
        with self.db.tx() as c:
            if not c.execute('SELECT id FROM projects WHERE id=?', (project,)).fetchone():
                raise AppError('项目不存在。', 404)
            if not c.execute('SELECT id FROM sources WHERE project=? AND id=?', (project, source_id)).fetchone():
                raise AppError('素材不存在。', 404)
            if c.execute('SELECT id FROM jobs WHERE project=? AND status IN ("queued","running")', (project,)).fetchone():
                raise AppError('素材正在用于制作，请等这次制作完成后再操作。', 409)
            def references(value):
                if isinstance(value, dict):
                    return any(references(v) for v in value.values())
                if isinstance(value, list):
                    return any(references(v) for v in value)
                return value == source_id
            for row in c.execute('SELECT scene FROM versions WHERE project=?', (project,)).fetchall():
                if references(json.loads(row['scene'])):
                    raise AppError('这份素材已经用于保存的回忆，需要保留。可以新建一段回忆，只放入你想使用的素材。', 400)
            c.execute('DELETE FROM sources WHERE project=? AND id=?', (project, source_id))
            c.execute('UPDATE projects SET input_revision=input_revision+1,updated=? WHERE id=?', (time.time(), project))
            self.db.event(project, None, 'source.removed', {'source_id': source_id, 'original_retained': True}, c)
        return {'removed': source_id, 'original_retained': True}

    def dismiss_proposal(self, project, proposal_id):
        """Persist 'keep unchanged', so reloading never brings back a declined edit."""
        with self.db.tx() as c:
            row = c.execute('SELECT status FROM proposals WHERE id=? AND project=?', (proposal_id, project)).fetchone()
            if not row:
                raise AppError('修改建议不存在。', 404)
            if row['status'] == 'accepted':
                raise AppError('这次修改已经采用，可以从历史版本撤销。', 409)
            c.execute('UPDATE proposals SET status="dismissed" WHERE id=? AND project=?', (proposal_id, project))
        return {'status': 'dismissed'}

    def scene(self,project,version=None):
        p=self.project(project);v=p['head'] if version is None else version
        row=self.db.one('SELECT * FROM versions WHERE project=? AND version=?',(project,v))
        if not row:raise AppError('场景版本不存在。',404)
        return {'version':v,'scene':json.loads(row['scene']),'note':row['note'],'created':row['created']}

    def validate_scene_assets(self,project,scene:Scene):
        for o in scene.objects:
            if o.asset_id and self.assets.get(o.asset_id,project)['kind']!='model':raise AppError('场景网格引用错误。')
            if o.reference_asset_id and self.assets.get(o.reference_asset_id,project)['kind']!='image':raise AppError('场景参考图引用错误。')
            for ref in o.reference_ids:self.assets.get(ref,project)
        for a in scene.audio:
            if a.asset_id and self.assets.get(a.asset_id,project)['kind']!='audio':raise AppError('音轨引用错误。')
            if a.source_id:self.assets.get(a.source_id,project)

    def _commit(self,c,project,scene:Scene,base,note,job=None,allow_unlock=False):
        row=c.execute('SELECT head FROM projects WHERE id=?',(project,)).fetchone()
        if not row:raise AppError('项目不存在。',404)
        if row['head']!=base:raise AppError('场景已变化，旧任务不能覆盖新版本。',409,'version_conflict')
        # Compare canonical contracts, so new optional/default fields do not
        # falsely make unchanged legacy locked objects appear modified.
        old=Scene.model_validate(json.loads(c.execute('SELECT scene FROM versions WHERE project=? AND version=?',(project,base)).fetchone()['scene'])).model_dump()
        new={o.id:o.model_dump() for o in scene.objects}
        for o in old['objects']:
            if o['locked']:
                before=dict(o);after=dict(new.get(o['id'],{}))
                if allow_unlock and o['id'] in new:
                    before.pop('locked',None);after.pop('locked',None)
                if before!=after:raise AppError(f'已锁定「{o["label"]}」。请先显式解锁。',409,'object_locked')
        v=base+1;now=time.time()
        c.execute('INSERT INTO versions VALUES(?,?,?,?,?,?)',(project,v,dumps(scene.model_dump()),note[:1000],job,now))
        c.execute('UPDATE projects SET head=?,updated=? WHERE id=?',(v,now,project))
        self.db.event(project,job,'scene.version',{'version':v,'note':note},c)
        return v

    def publish(self,project,scene,base,note,job=None,allow_unlock=False):
        scene=Scene.model_validate(scene) if isinstance(scene,dict) else scene
        self.validate_scene_assets(project,scene)
        with self.db.tx() as c:
            # Recovery: a worker can die after a version commit but before job success.
            if job:
                existing=c.execute('SELECT version FROM versions WHERE project=? AND job=? ORDER BY version DESC LIMIT 1',(project,job)).fetchone()
                if existing:return existing['version']
            v=self._commit(c,project,scene,base,note,job,allow_unlock)
        return v

    def restore(self,project,version,expected):
        scene=Scene.model_validate(self.scene(project,version)['scene'])
        v=self.publish(project,scene,expected,f'从版本 {version} 恢复（新建版本，保留历史）')
        self.db.remember(project,'restore',{'from':version,'to':v})
        return self.scene(project,v)

    def job(self,id):
        r=self.db.one('SELECT * FROM jobs WHERE id=?',(id,))
        if not r:raise AppError('任务不存在。',404)
        r['payload']=json.loads(r['payload']);r['result']=json.loads(r['result']) if r['result'] else None
        r.pop('owner',None);r.pop('idem',None);r.pop('fp',None)
        r['steps']=self.steps(id)
        return r

    def steps(self,id):
        rows=self.db.all('SELECT * FROM steps WHERE job=? ORDER BY updated',(id,))
        for r in rows:
            r['result']=json.loads(r['result']) if r['result'] else None
            # Remote opaque task ids are safe; node URLs/tokens never stored here.
            r['remote']=json.loads(r['remote']) if r['remote'] else None
        return rows

    def enqueue_repair(self,project,request,idem=None):
        from .quality_repair import RepairRequest
        from .providers import Providers
        request=RepairRequest.model_validate(request)
        if idem:
            old=self.db.one('SELECT id,kind,payload FROM jobs WHERE project=? AND idem=?',(project,idem))
            if old:
                if old['kind']!='repair' or json.loads(old['payload']).get('approval_request')!=request.model_dump():
                    raise AppError('该幂等键已用于不同请求。',409,'idempotency_conflict')
                return self.job(old['id'])
        providers=Providers(self);model=providers.choose('brain.plan');card=providers.cards()[model]
        if 'vision.understand' not in card.get('capabilities',[]) or card.get('max_images',12)<9:
            raise AppError('自动修复需要支持多图理解的导演（至少9张）。',503,'repair_capability_unavailable')
        with self.db.tx() as c:
            p=self.project(project)
            if p['head']!=request.base_version or p['input_revision']!=request.input_revision:
                raise AppError('场景或素材版本已变化，请重新检查。',409,'version_conflict')
            if p['mode']!='real' or not p['remote_consent']:
                raise AppError('自动视觉修复需要真实模式和素材远端授权。',409,'remote_consent_required')
            scene=Scene.model_validate(self.scene(project)['scene'])
            if not scene.objects or any(not o.asset_id or o.status!='ready' for o in scene.objects):
                raise AppError('请先完成实际模型制作，不能检查占位物体。')
            ids={o.id for o in scene.objects}
            if request.selected_object and request.selected_object not in ids:
                raise AppError('所选物品不属于当前场景。')
            from .agent_contracts import target_scope
            intent=target_scope(request.prompt,[o.model_dump() for o in scene.objects],request.selected_object)
            if intent['needs_clarification']:raise AppError('修复目标名称有歧义，请明确物品。',409,'task_scope_ambiguous')
            requested=set(intent['object_ids']) if intent['scope']!='whole_scene' else set()
            if request.selected_object and requested and request.selected_object not in requested:
                raise AppError('所选物品和明确描述的修复对象不同，请重新选择。',409,'task_scope_violation')
            scope=[o.id for o in scene.objects if not o.locked and (not requested or o.id in requested)]
            if not scope:raise AppError('所选范围全部锁定，未自动解锁。',409,'object_locked')
            payload={**request.model_dump(),'scope_ids':scope,'scene':scene.model_dump(),
                'approval_request':request.model_dump(),
                'quality_profile':{'schema':'asset-quality-v1','policy':self.settings.asset_review_policy,'repair_attempts':0,
                    'edge':self.settings.quality_render_edge,'seconds':self.settings.quality_render_seconds}}
            if len(requested)==1:payload['selected_object']=next(iter(requested))
            # Idempotent replay does not consume another allowance. Caller
            # cannot supply a scene, scope, policy or a replacement root budget.
            jid=self.enqueue(project,'repair',payload,idem,c=c)
        return self.job(jid)

    def enqueue(self,project,kind,payload,idem=None,c=None,*,parent_job=None):
        self.project(project)
        if kind not in ('plan','build','edit','review','repair'):raise AppError('任务类型无效。')
        target_set=set(payload['targets']) if payload.get('targets') is not None else None
        needs_quality=kind=='build' and any(o.get('generation',{}).get('strategy')=='generate3d' and
            (target_set is None or o['id'] in target_set) and not (o.get('locked') and o.get('asset_id'))
            for o in payload.get('scene',{}).get('objects',[]))
        if needs_quality and self.settings.asset_review:
            payload={**payload}
            payload.setdefault('quality_profile',{'schema':'asset-quality-v1',
                'policy':self.settings.asset_review_policy,
                'repair_attempts':self.settings.quality_repair_attempts if self.settings.asset_review_policy=='strict' else 0,
                'edge':self.settings.quality_render_edge,'seconds':self.settings.quality_render_seconds})
        if idem and (len(idem)>120 or not idem.isascii()):raise AppError('Idempotency-Key 无效。')
        fp=digest({'kind':kind,'payload':payload});id=uid('j_');now=time.time()
        def insert(conn):
            if idem:
                old=conn.execute('SELECT id,fp FROM jobs WHERE project=? AND idem=?',(project,idem)).fetchone()
                if old:
                    if old['fp']!=fp:raise AppError('该幂等键已用于不同请求。',409,'idempotency_conflict')
                    return old['id']
            review_state=None
            if kind=='repair':
                live=conn.execute('SELECT head,input_revision FROM projects WHERE id=?',(project,)).fetchone()
                if live['head']!=payload['base_version'] or live['input_revision']!=payload['input_revision']:
                    raise AppError('修复提交时场景或资料已变化。',409,'version_conflict')
                if not payload.get('user_approved') or payload.get('quality_profile',{}).get('policy') not in ('strict','warn'):
                    raise AppError('自动修复需要本轮明确批准和服务端配置的验收策略。')
                if conn.execute('SELECT 1 FROM jobs WHERE project=? AND status IN ("queued","running")',(project,)).fetchone():
                    raise AppError('已有任务正在执行，未并行发起自动修复。',409,'repair_busy')
                if conn.execute('SELECT 1 FROM jobs WHERE project=? AND kind="repair" AND json_extract(payload,"$.base_version")=?',(project,live['head'])).fetchone():
                    raise AppError('当前版本已执行过自动修复；未重置预算或开始无限循环。请查看候选和具体问题。',409,'agent_budget_exhausted')
            if kind=='review':
                live=conn.execute('SELECT head,input_revision,doc FROM projects WHERE id=?',(project,)).fetchone()
                if payload.get('base_version')!=live['head']:raise AppError('截图版本已过期。',409,'version_conflict')
                for rid in payload.get('render_ids',[]):
                    render=conn.execute('SELECT version FROM renders WHERE id=? AND project=?',(rid,project)).fetchone()
                    if not render or render['version']!=live['head']:raise AppError('截图不属于当前项目版本。',409)
                limit=Budget.model_validate(json.loads(live['doc']).get('budget',{})).max_review_rounds
                used=conn.execute('SELECT COUNT(*) FROM jobs WHERE project=? AND kind="review" AND json_extract(payload,"$.base_version")=?',(project,live['head'])).fetchone()[0]
                if used>=limit:raise AppError('当前版本的截图复核预算已用完；客户端重置 round 也不会追加调用。',409,'agent_budget_exhausted')
                review_state=(project,live['head'],live['input_revision'],id)
                # A review of a freshly produced version shares that build's
                # root budget. Restored/manual versions may have no producer.
                producer=conn.execute('SELECT j.id FROM versions v JOIN jobs j ON j.id=v.job AND j.project=v.project WHERE v.project=? AND v.version=?',(project,live['head'])).fetchone()
                if producer and parent_job is None:parent_job_id=producer['id']
                else:parent_job_id=parent_job
            else:parent_job_id=parent_job
            conn.execute('INSERT INTO jobs(id,project,kind,payload,status,idem,fp,created,updated) VALUES(?,?,?,?,?,?,?,?,?)',
                         (id,project,kind,dumps(payload),'queued',idem,fp,now,now))
            from .agent_budget import attach
            attach(self,conn,id,project,parent_job_id)
            if review_state:conn.execute('INSERT INTO agent_reviews VALUES(?,?,?,?)',review_state)
            self.db.event(project,id,'job.queued',{'kind':kind},conn)
            return id
        if c is not None:return insert(c)
        with self.db.tx() as conn:result=insert(conn)
        return self.job(result)

    def confirm_plan(self,project,plan_id,expected_version,expected_input_revision,idem=None):
        # Head + input revision + plan confirmation are one transaction.
        with self.db.tx() as c:
            p=c.execute('SELECT * FROM projects WHERE id=?',(project,)).fetchone()
            plan=c.execute('SELECT * FROM plans WHERE id=? AND project=?',(plan_id,project)).fetchone()
            if not p or not plan:raise AppError('计划不存在。',404)
            if plan['status']!='pending':
                prior=c.execute('SELECT id FROM jobs WHERE project=? AND kind="build" AND json_extract(payload,"$.plan_id")=?',(project,plan_id)).fetchone()
                if prior:return self.job(prior['id'])
                raise AppError('该计划已处理。',409)
            if p['head']!=expected_version or p['input_revision']!=expected_input_revision or plan['input_revision']!=p['input_revision'] or plan['base_version']!=expected_version:
                raise AppError('资料或场景已经变化，需要重新规划。',409,'version_conflict')
            body=ScenePlan.model_validate(json.loads(plan['body']))
            from .layout import validate_portrait_only,validate_plan_layout
            validate_portrait_only(body,json.loads(p['doc']))
            body.scene=validate_plan_layout(body.scene)
            # Configuration can change after planning. Fail before committing
            # a draft or allocating GPU work if a required provider was removed.
            self.check_build_capabilities(body.scene)
            v=self._commit(c,project,body.scene,expected_version,'确认方案，建立布局草稿')
            c.execute('UPDATE plans SET status="accepted" WHERE id=?',(plan_id,))
            payload={'plan_id':plan_id,'scene':body.scene.model_dump(),'base_version':v,'input_revision':p['input_revision'],'targets':None,'production':json.loads(p['doc']),'source_meta':self.sources(project)}
            if body.decomposition:payload['decomposition']=body.decomposition.model_dump()
            origin=c.execute('SELECT id FROM jobs WHERE project=? AND kind="plan" AND json_extract(result,"$.plan_id")=? ORDER BY created DESC LIMIT 1',(project,plan_id)).fetchone()
            job_id=self.enqueue(project,'build',payload,idem,c,parent_job=origin['id'] if origin else None)
            self.db.remember(project,'plan_confirmed',{'plan_id':plan_id,'summary':body.summary,'locked_facts':body.scene.locked_facts},c=c)
        return self.job(job_id)

    def check_build_capabilities(self,scene,targets=None):
        from .providers import Providers
        providers=Providers(self)
        for obj in scene.objects:
            if targets is not None and obj.id not in targets:continue
            if obj.locked and obj.asset_id:continue
            gen=obj.generation
            if gen.strategy=='generate3d':
                providers.choose('geometry.generate',gen.geometry_model)
                if self.settings.asset_review and self.settings.asset_review_policy=='strict':
                    reviewer=providers.choose('brain.plan');card=providers.cards()[reviewer]
                    if 'vision.understand' not in card.get('capabilities',[]) or card.get('max_images',12)<9:
                        raise AppError('六向单件／八向全景验收需要支持图片理解且至少接受九张图的导演；未提交生成任务。')
                if self.settings.reference_review and self.settings.reference_review_policy=='strict':
                    reviewer=providers.choose('brain.plan')
                    if 'vision.understand' not in providers.cards()[reviewer].get('capabilities',[]):
                        raise AppError('真实三维生成前需要支持图片理解的导演来校验参考图，未提交生成任务。')
            if gen.strategy in ('generate3d','photo') and gen.image_mode in ('edit','text2image'):
                providers.choose('image.edit' if gen.image_mode=='edit' else 'image.generate',gen.image_model)

    def validate_additions(self,project,patch:Patch,scene:Scene):
        """Only explicitly described, bounded local decorations may be added.

        No model-supplied asset IDs, completed status or remote inference is
        accepted here. Expensive/new photographed subjects need a fresh plan.
        """
        ids={o.id for o in scene.objects};count=len(ids)
        budget=self.project(project)['budget']['max_objects']
        for op in patch.operations:
            if op.type!='add':continue
            obj=op.new_object;gen=obj.generation
            validate_box_size(obj)
            if obj.id in ids:raise AppError('新增对象 ID 已存在，请使用不同的 ID。')
            if gen.strategy!='procedural':raise AppError('局部新增只支持明确的程序几何；新增照片或模型主体请重新规划。')
            if obj.asset_id or obj.reference_asset_id or obj.status!='planned' or obj.locked or obj.provenance!='procedural':
                raise AppError('新增对象不能携带已有资产、完成状态或锁定状态。')
            if obj.reference_ids or gen.primary_source or gen.reuse_object or gen.crop or gen.image_mode!='original' or gen.image_prompt or gen.image_model or gen.geometry_model:
                raise AppError('程序几何新增不能引用素材或伪装成远端模型生成。')
            if gen.frame_target and gen.primitive!='frame':raise AppError('只有 frame 几何可以绑定图片展示面。')
            if gen.primitive=='frame' and obj.transform.fit!='stretch':
                raise AppError('镂空边框必须使用 fit=stretch，否则会按深度缩成小方框。')
            if gen.primitive=='frame':
                target=next((o for o in scene.objects if o.id==gen.frame_target),None)
                if not target or target.generation.strategy!='photo':
                    raise AppError('新增海报框必须填写 generation.frame_target，绑定已有图片展示面的真实 ID。')
            ids.add(obj.id);count+=1
            if count>budget:raise AppError('新增对象超过项目对象预算。')

    def fit_bound_frames(self,project,scene:Scene):
        # A uniform-fit photo can occupy less than its requested bounding box.
        # Compute its actual display extent for the frame, without changing
        # the existing photo (which may be locked).
        measured=scene.model_copy(deep=True);by={o.id:o for o in measured.objects}
        for target_id in {o.generation.frame_target for o in measured.objects if o.generation.frame_target}:
            target=by[target_id]
            if target.asset_id and target.transform.fit=='uniform':
                bounds=self.assets.get(target.asset_id,project)['meta']['bounds']
                extent=[max(.0001,bounds[1][i]-bounds[0][i]) for i in range(3)]
                scale=min(target.transform.size[i]/extent[i] for i in range(3))
                target.transform.size=[max(.01,e*scale) for e in extent]
        fitted=fit_frames(measured);result=scene.model_copy(deep=True)
        fitted_by={o.id:o for o in fitted.objects}
        for obj in result.objects:
            if obj.generation.frame_target:obj.transform=fitted_by[obj.id].transform
        return result

    def resolve_additions(self,project,patch:Patch,scene:Scene):
        self.validate_additions(project,patch,scene)
        by={o.id:o for o in scene.objects}
        for op in patch.operations:
            if op.type in ('transform','resize') and op.object_id in by:
                obj=by[op.object_id]
                transform=op.transform if op.type=='transform' else resized_transform(obj,op.size_edit)
                # Legacy uniform boxes may have an oversized target box. A
                # pose-only edit must not force an unrelated shape migration.
                if op.type=='resize' or transform.size!=obj.transform.size or transform.fit!=obj.transform.fit:
                    validate_box_size(obj,transform)
                if obj.generation.frame_target and (transform.position!=obj.transform.position or transform.rotation!=obj.transform.rotation or transform.size[:2]!=obj.transform.size[:2]):
                    raise AppError('边框自动贴合海报，不能独立修改宽高或位置；请修改绑定的海报。')
        for op in patch.operations:
            if op.type!='bind_frame':continue
            frame,target=by.get(op.object_id),by.get(op.target_id)
            if not frame or frame.generation.strategy!='procedural' or frame.generation.primitive!='frame' or not target or target.generation.strategy!='photo':
                raise AppError('bind_frame 只能把已有程序边框绑定到已有图片展示面。')
        result=patch.model_copy(deep=True);candidate=scene.model_copy(deep=True)
        if result.operations and all(op.type=='remove' for op in result.operations):
            result.explanation='从当前场景移除'+ '、'.join(by[op.object_id].label for op in result.operations if op.object_id in by)+'；其他物品的位置和外观保持不变，历史版本和原始素材保留。'
        additions=[op for op in result.operations if op.type=='add']
        if not additions:return result
        candidate.objects.extend(op.new_object for op in additions)
        fitted=self.fit_bound_frames(project,Scene.model_validate(candidate.model_dump()))
        by={o.id:o for o in fitted.objects}
        for op in additions:op.new_object=by[op.object_id]
        if len(additions)==len(result.operations) and all(op.new_object.generation.primitive=='frame' for op in additions):
            result.explanation='添加镂空程序几何边框，自动贴合原海报的尺寸和角度；原图、文字、排版和底座保持不变。'
        return result

    def resolve_restorations(self,project,patch:Patch,scene:Scene):
        """Load immutable snapshots on the server; never trust LLM asset IDs.

        Restore only named objects, reusing existing validated GLBs. Retain
        all other objects and their poses. On/near links are reattached with
        offsets from today's positions, never by moving unrelated objects.
        """
        result=scene.model_copy(deep=True);by={o.id:o for o in result.objects}
        ops=[op for op in patch.operations if op.type=='restore_object']
        ids={op.object_id for op in ops}
        if len(ids)!=len(ops) or any(op.type!='restore_object' and op.object_id in ids for op in patch.operations):
            raise AppError('同一对象不能重复恢复，或同时恢复和修改；请分两次操作。')
        links=[]
        for op in ops:
            if op.source_version>=patch.base_version:raise AppError('恢复来源必须是当前版本以前的真实历史版本。')
            historic=Scene.model_validate(self.scene(project,op.source_version)['scene'])
            saved=next((o for o in historic.objects if o.id==op.object_id),None)
            if not saved:raise AppError('该历史版本中没有指定对象，请重新选择恢复证据。')
            existing=by.get(op.object_id)
            if existing and existing.locked:raise AppError('恢复目标已锁定，请先显式解锁。',409,'object_locked')
            if not saved.asset_id or saved.status!='ready':raise AppError('该历史对象没有可复用的完成网格，不能声称已恢复；请重新制作。')
            from .media import glb_info
            glb_info(self.assets.read(saved.asset_id,project))
            saved=saved.model_copy(deep=True)
            # Permission/lock state is not an appearance preference.
            saved.locked=False
            if existing:result.objects[result.objects.index(existing)]=saved
            else:result.objects.append(saved)
            by[saved.id]=saved
            links.extend(r.model_copy(deep=True) for r in historic.relations if saved.id in (r.subject,r.target))
        if len(result.objects)>self.project(project)['budget']['max_objects']:raise AppError('恢复对象超过项目对象预算。')
        for relation in links:
            if relation.type not in ('on','near') or relation.subject not in by or relation.target not in by:continue
            if any(r.type==relation.type and r.subject==relation.subject for r in result.relations):continue
            s,t=by[relation.subject].transform,by[relation.target].transform
            relation.offset=[s.position[i]-t.position[i]-(t.size[1] if i==1 and relation.type=='on' else 0) for i in range(3)]
            result.relations.append(relation)
        result=Scene.model_validate(result.model_dump())
        task_graph(result)  # Missing/cyclic reuse and invalid bindings fail before commit.
        from .layout import topological
        topological({o.id:[r.target for r in result.relations if r.type=='on' and r.subject==o.id] for o in result.objects})
        self.validate_scene_assets(project,result)
        return result

    def apply_patch(self,project,patch:Patch,*,from_model=False,proposal_id=None):
        current=self.scene(project)
        if patch.base_version!=current['version']:raise AppError('修改基于旧版本，请重新分析。',409,'version_conflict')
        scene=Scene.model_validate(current['scene']);before=scene.model_copy(deep=True)
        objects={o.id:o for o in scene.objects};tracks={a.id:a for a in scene.audio}
        origin=None;contract=None
        if from_model and proposal_id:
            origin=self.db.one('SELECT id,payload FROM jobs WHERE project=? AND kind IN ("edit","review") AND json_extract(result,"$.proposal_id")=? ORDER BY created DESC LIMIT 1',(project,proposal_id))
            if origin:
                request=json.loads(origin['payload'])
                memory=self.memory(project,request.get('selected_object'),request.get('prompt',''),origin['id'])
                validate_edit_intent(patch,memory)
                from .agent_contracts import compile_contract
                contract=compile_contract(patch,memory)
                from .layout import validate_contact_edit
                validate_contact_edit(patch,scene,request.get('prompt',''))
        removed={op.object_id for op in patch.operations if op.type=='remove'}
        if len(removed)!=sum(op.type=='remove' for op in patch.operations) or any(op.type!='remove' and op.object_id in removed for op in patch.operations):
            raise AppError('同一对象不能重复删除或同时删除和修改。')
        for obj in scene.objects:
            if obj.id not in removed and obj.generation.strategy=='reuse' and obj.generation.reuse_object in removed:
                raise AppError('该物品仍被其他对象复用；请明确一并删除复用对象，未执行连带删除。')
        patch=self.resolve_additions(project,patch,scene)
        scene=self.resolve_restorations(project,patch,scene)
        objects={o.id:o for o in scene.objects}
        tracks={a.id:a for a in scene.audio}
        if patch.operations and all(op.type=='restore_object' for op in patch.operations):
            patch=patch.model_copy(deep=True)
            patch.explanation=restoration_explanation(patch,scene)
        regen=[]; moved=set()
        for op in patch.operations:
            if op.type=='restore_object':continue
            if op.type=='add':
                obj=op.new_object.model_copy(deep=True)
                scene.objects.append(obj);objects[obj.id]=obj;regen.append(obj.id)
                continue
            if op.type=='audio':
                a=tracks.get(op.audio_id)
                if not a:raise AppError('音轨不存在。')
                if op.gain is not None:a.gain=op.gain
                if op.start is not None:a.start=op.start
                continue
            obj=objects.get(op.object_id)
            if not obj:raise AppError('对象不存在。')
            if obj.locked and op.type!='lock':raise AppError(f'「{obj.label}」已锁定。',409,'object_locked')
            if from_model and op.type=='lock':raise AppError('模型不能修改用户锁定状态。')
            if op.type=='remove':
                scene.objects.remove(obj)
            elif op.type in ('transform','resize'):
                transform=op.transform if op.type=='transform' else resized_transform(obj,op.size_edit)
                if obj.generation.frame_target and (transform.position!=obj.transform.position or transform.rotation!=obj.transform.rotation or transform.size[:2]!=obj.transform.size[:2]):
                    raise AppError('边框自动贴合海报；要改变摆放或大小，请修改绑定的海报，未执行独立移动。')
                if obj.transform.position!=transform.position or obj.transform.size!=transform.size:moved.add(obj.id)
                obj.transform=transform
            elif op.type=='bind_frame':obj.generation.frame_target=op.target_id
            elif op.type=='tint':obj.tint=op.color
            elif op.type=='clear_tint':obj.tint=None
            elif op.type=='caption':obj.caption=op.caption
            elif op.type=='lock':obj.locked=op.locked
            elif op.type=='regenerate':
                if obj.generation.strategy=='reuse':raise AppError('复用对象应修改其原型。')
                if op.prompt and obj.generation.strategy=='procedural':
                    raise AppError('程序几何不接受自由文字形状编辑；请使用尺寸变换或新增已支持的几何类型，未执行此修改。')
                if op.prompt:obj.generation.image_prompt=op.prompt
                if op.prompt and obj.generation.strategy=='generate3d':obj.generation.image_mode='edit'
                obj.generation.options.seed=(obj.generation.options.seed+1)%(2**31)
                obj.status='planned';regen.append(obj.id)
        if removed:
            scene.relations=[r for r in scene.relations if r.subject not in removed and r.target not in removed]
            for track in scene.audio:
                if track.anchor in removed:track.anchor=None
            for obj in scene.objects:
                if obj.generation.frame_target in removed:obj.generation.frame_target=None
            if all(op.type=='remove' for op in patch.operations):
                patch=patch.model_copy(deep=True)
                patch.explanation='从当前场景移除'+ '、'.join(objects[oid].label for oid in sorted(removed))+'；其他物品的位置和外观保持不变，历史版本和原始素材保留。'
        # Local pose/size edits preserve other object placements. Reconcile
        # both ends of an incident relation, including support-height changes;
        # otherwise a later rebuild may jump to obsolete offsets. A nonzero
        # offset is still a gap, not a claim that the objects physically touch.
        for relation in scene.relations:
            if relation.type in ('on','near') and (relation.subject in moved or relation.target in moved):
                a=objects[relation.subject].transform;b=objects[relation.target].transform
                relation.offset=[a.position[i]-b.position[i]-(b.size[1] if i==1 and relation.type=='on' else 0) for i in range(3)]
        scene=self.fit_bound_frames(project,Scene.model_validate(scene.model_dump()))
        from .agent_contracts import verify_local_effects
        observation=verify_local_effects(before,scene,patch)
        if origin and self.job(origin['id'])['kind']=='review':
            from .display_geometry import validate_review_geometry
            observation['display_geometry']=validate_review_geometry(before,scene,self.assets,project)
        if patch.operations and all(op.type in ('restore_object','resize','clear_tint') for op in patch.operations) and scene.model_dump()==Scene.model_validate(current['scene']).model_dump():
            raise AppError('指定状态已经满足，没有实际变化，未创建重复版本。')
        if regen:self.check_build_capabilities(scene,regen)
        with self.db.tx() as c:
            if proposal_id:
                row=c.execute('SELECT status FROM proposals WHERE id=? AND project=?',(proposal_id,project)).fetchone()
                if not row or row['status']!='pending':raise AppError('该修改建议已处理或不存在。',409)
            if any(op.type in ('add','restore_object') for op in patch.operations):
                live=c.execute('SELECT doc FROM projects WHERE id=?',(project,)).fetchone()
                if len(scene.objects)>json.loads(live['doc'])['budget']['max_objects']:
                    raise AppError('新增对象超过项目最新对象预算。')
            if not patch.operations:raise AppError('没有可执行的修改，当前版本保持不变。')
            # A generated edit stays a candidate until assets succeed. Failed builds
            # must not leave an extra version containing only changed instructions.
            v=patch.base_version if regen else self._commit(c,project,scene,patch.base_version,patch.explanation or '局部编辑',allow_unlock=not from_model)
            if regen and c.execute('SELECT head FROM projects WHERE id=?',(project,)).fetchone()['head']!=v:
                raise AppError('修改基于旧版本，请重新分析。',409,'version_conflict')
            if proposal_id:c.execute('UPDATE proposals SET status="accepted" WHERE id=?',(proposal_id,))
            self.db.remember(project,'patch',{**patch.model_dump(),'applied_version':None if regen else v,'candidate_only':bool(regen)},c=c)
            self.db.remember(project,'execution_observation',{'version':None if regen else v,'proposal_id':proposal_id,'candidate_only':bool(regen),**observation},c=c)
            jid=None
            if regen:
                # Reused instances must receive the new asset too, but only if not locked.
                changed=set(regen)
                for _ in range(len(scene.objects)):
                    for o in scene.objects:
                        if o.generation.strategy=='reuse' and o.generation.reuse_object in changed and not o.locked:changed.add(o.id)
                jid=self.enqueue(project,'build',{'scene':scene.model_dump(),'base_version':v,'proposal_id':proposal_id,'targets':sorted(changed),'input_revision':self.project(project)['input_revision'],'production':{k:v for k,v in self.project(project).items() if k in ProjectCreate.model_fields},'source_meta':self.sources(project),'task_contract':contract},c=c,parent_job=origin['id'] if origin else None)
        return {'version':v,'scene':current['scene'] if regen else scene.model_dump(),'job_id':jid,'observation':observation,'task_contract':contract}

    def memory(self,project,selected=None,query='',exclude_job=None):
        p=self.project(project);scene=self.scene(project)
        catalog=scene['scene']['objects'];objects=catalog
        focus={selected} if selected else set()
        focus.update(o['id'] for o in catalog if any(name in query.lower() for name in aliases(o)))
        if selected:
            target={selected}
            for r in scene['scene']['relations']:
                if r['subject']==selected:target.add(r['target'])
                if r['target']==selected:target.add(r['subject'])
            for o in scene['scene']['objects']:
                if o['generation'].get('frame_target')==selected:target.add(o['id'])
                if o['id']==selected and o['generation'].get('frame_target'):target.add(o['generation']['frame_target'])
            focus.update(target)
            # Preserve the legacy selected-object API, but editing must see the
            # complete small scene so explicit names override stale selection.
            if not query:objects=[o for o in objects if o['id'] in target]
        history=self.db.all('SELECT kind,body,object_id,created FROM memories WHERE project=? ORDER BY id DESC LIMIT 12',(project,))
        for h in history:h['body']=json.loads(h['body'])
        episodes,retrieval=retrieve_episodes(self.db,project,scene['version'],query,focus,exclude_job)
        appearance=appearance_intent(query,catalog,selected)
        snapshots=historical_objects(self.db,project,scene['version'],query) if query and re.search(r'加回|放回来|找回|恢复|还原|\brestore\b',query,re.I) else []
        geometry_contracts=[]
        for o in catalog:
            g=o['generation']
            geometry_contracts.append({'object_id':o['id'],'strategy':g['strategy'],'primitive':g['primitive'],
                'editable_shape':'dimensions_of_defined_primitive' if g['strategy']=='procedural' else 'reference_image_then_generate3d' if g['strategy']=='generate3d' else 'original_photo_surface' if g['strategy']=='photo' else 'edit_reuse_prototype',
                'free_text_shape_prompt_executed':False if g['strategy']=='procedural' else None,
                'note':'程序对象的历史 image_prompt 不是网格特征证据；不能据此宣称圆角/雕花已完成。' if g['strategy']=='procedural' else '遮挡面属于补全，尺寸是展示单位，不是实测。'})
        from .memory import layered_memory
        from .display_geometry import scene_evidence
        return {'requirements':p['requirements'],'diary':p['diary'],'style':p['style'],'version':scene['version'],'selected_object':selected,
                'locked_facts':scene['scene']['locked_facts'],'locked_objects':[o['id'] for o in scene['scene']['objects'] if o['locked']],
                'objects':objects,'all_object_ids':[o['id'] for o in scene['scene']['objects']],
                'budget':p['budget'],'relations':scene['scene']['relations'],'audio':scene['scene']['audio'],'recent_decisions':list(reversed(history)),
                'memory_policy':'current_request > historical_preferences; current_scene > assistant_claims; locked_objects remain protected',
                'object_catalog':[{'id':o['id'],'label':o['label'],'aliases':sorted(aliases(o)),'locked':o['locked']} for o in catalog],
                'focus_object_ids':sorted(focus),'edit_intent':deletion_intent(query,catalog,selected),
                'historical_objects':snapshots,'restore_intent':{'authorized':False} if appearance.get('authorized') else restoration_intent(query,snapshots,selected),
                'appearance_intent':appearance,
                'spatial_checks':check_scene(Scene.model_validate(scene['scene'])),
                'dimension_intent':dimension_intent(query,catalog,selected),'skill_cards':SKILL_CARDS,
                'geometry_contracts':geometry_contracts,
                'display_geometry':scene_evidence(Scene.model_validate(scene['scene']),self.assets,project),
                'current_request':query,
                'episodic_history':episodes,'retrieval':retrieval,
                'memory_layers':layered_memory(self.db,project,p,scene,episodes,query,focus)}

    def preview(self,id):
        job=self.job(id)
        if job['kind']!='build':return None
        scene=Scene.model_validate(job['payload']['scene']);by={o.id:o for o in scene.objects};tracks={a.id:a for a in scene.audio}
        for step in job['steps']:
            if step['name'].startswith('asset:') and step['name'][6:] in by:
                o=by[step['name'][6:]]
                if step['status']=='succeeded':
                    o.asset_id=step['result']['asset_id'];o.status='ready';o.provenance=step['result']['provenance']
                    o.reference_asset_id=step['result'].get('reference_asset_id')
                elif step['status']=='failed':o.status='failed'
                elif step['status']=='running':o.status='generating'
            if step['name'].startswith('audio:') and step['status']=='succeeded':
                t=tracks.get(step['name'][6:])
                if t:t.asset_id=step['result']['asset_id'];t.status='ready'
        return {'base_version':job['payload']['base_version'],'scene':scene.model_dump(),'preview_only':True}

    def clone_source(self,project,id,spec:SourceUpdate):
        original=next((s for s in self.sources(project) if s['id']==id),None)
        if not original or original['kind']!='image':raise AppError('仅图片支持复制为独立参考。')
        if len(self.sources(project))>=60:raise AppError('素材数量上限 60。')
        a=self.assets.put(project,self.assets.read(id,project),original['filename'],original['provenance'],[id],
                          {'operation':'user-marked-reference-copy','rights_confirmed':True})
        values={'role':original['role'],'label':original['label']+' · 参考','subject':original['subject'],'note':original['note'],'crop':original['crop']}
        values.update(spec.model_dump(exclude_unset=True))
        if values['role'] not in ('scene','person','object','style'):raise AppError('图片角色无效。')
        if any(values[k] is None for k in ('label','subject','note')):raise AppError('资料文字字段不能为空值。')
        with self.db.tx() as c:
            c.execute('INSERT INTO sources VALUES(?,?,?,?,?,?,?,?)',(a['id'],project,values['role'],values['label'][:100],values['subject'],values['note'],dumps(values['crop']) if values['crop'] else None,time.time()))
            c.execute('UPDATE projects SET input_revision=input_revision+1,updated=? WHERE id=?',(time.time(),project))
        return next(s for s in self.sources(project) if s['id']==a['id'])

    def adopt_asset(self,project,object_id,asset_id,base_version):
        current=self.scene(project)
        if current['version']!=base_version:raise AppError('场景版本已变化，请刷新后再采用资产。',409,'version_conflict')
        sc=Scene.model_validate(current['scene']);o=next((o for o in sc.objects if o.id==object_id),None)
        if not o:raise AppError('对象不存在。',404)
        if o.locked:raise AppError('先显式解锁对象。',409,'object_locked')
        a=self.assets.get(asset_id,project)
        if a['kind']!='model':raise AppError('只能采用通过校验的 GLB 资产。')
        o.asset_id=asset_id;o.status='ready';o.provenance=a['provenance'] if a['provenance'] in ('generated','procedural','photo') else 'imported'
        # The geometry's own image lineage travels with it; don't retain an unrelated reference.
        o.reference_asset_id=next((id for id in a['parents'] if self.assets.get(id,project)['kind']=='image'),None)
        v=self.publish(project,sc,base_version,'用户确认采用已有资产：'+o.label)
        self.db.remember(project,'asset_adopted',{'object_id':object_id,'asset_id':asset_id,'version':v},object_id)
        return {'version':v,'scene':sc.model_dump()}
