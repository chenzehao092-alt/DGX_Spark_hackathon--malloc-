from __future__ import annotations
import math
import re
from .schemas import Scene,ScenePlan,Transform
from .errors import AppError


def topological(dependencies:dict[str,list[str]]) -> list[str]:
    todo={k:set(v) for k,v in dependencies.items()};order=[]
    if any(v not in todo for values in todo.values() for v in values):
        raise AppError('任务引用了不存在的依赖。')
    while todo:
        ready=sorted(k for k,v in todo.items() if not v)
        if not ready:raise AppError('场景或任务存在循环依赖。')
        order.extend(ready)
        for k in ready:todo.pop(k)
        for v in todo.values():v.difference_update(ready)
    return order


def fit_frames(scene:Scene) -> Scene:
    """Bind a hollow frame to exact photo bounds using renderer XYZ Euler.

    The director selects target, depth and colour, not fragile arithmetic.
    This also follows later photo moves/rotations without modifying its asset.
    """
    import trimesh
    result=scene.model_copy(deep=True);by={o.id:o for o in result.objects}
    for frame in result.objects:
        if not frame.generation.frame_target:continue
        target=by[frame.generation.frame_target].transform
        width,height=target.size[0]/.92,target.size[1]/.95
        rotation=trimesh.transformations.euler_matrix(*target.rotation,axes='rxyz')
        lower=height*.025
        try:
            frame.transform=Transform(position=[target.position[i]-float(rotation[i,1])*lower for i in range(3)],
                rotation=list(target.rotation),size=[width,height,frame.transform.size[2]],fit='stretch')
        except ValueError as e:
            raise AppError('贴合后的边框超过场景尺寸或位置上限，请缩小海报后再试。') from e
    return Scene.model_validate(result.model_dump())


def solve_layout(scene:Scene) -> Scene:
    result=scene.model_copy(deep=True);objects={o.id:o for o in result.objects}
    supports={r.subject:r for r in result.relations if r.type=='on'}
    if len(supports)!=sum(r.type=='on' for r in result.relations):
        raise AppError('一个物品不能同时声明多个 on 支撑面；请明确唯一支撑关系。')
    topological({o.id:([supports[o.id].target] if o.id in supports else []) for o in result.objects})
    for r in result.relations:
        subject,target=objects[r.subject],objects[r.target]
        if subject.locked:continue
        p,t=subject.transform,target.transform
        if r.type=='around':
            p.position=[t.position[0]+math.sin(r.angle)*r.radius,t.position[1]+r.offset[1],t.position[2]+math.cos(r.angle)*r.radius]
            p.rotation[1]=math.atan2(t.position[0]-p.position[0],t.position[2]-p.position[2])
        elif r.type=='near':
            p.position=[t.position[i]+r.offset[i] for i in range(3)]
    for oid in topological({o.id:([supports[o.id].target] if o.id in supports else []) for o in result.objects}):
        if oid not in supports or objects[oid].locked:continue
        r=supports[oid];p=objects[oid].transform;t=objects[r.target].transform
        p.position=[t.position[0]+r.offset[0],t.position[1]+t.size[1]+r.offset[1],t.position[2]+r.offset[2]]
    for r in result.relations:
        if r.type=='face' and not objects[r.subject].locked:
            s,t=objects[r.subject].transform,objects[r.target].transform
            s.rotation[1]=math.atan2(t.position[0]-s.position[0],t.position[2]-s.position[2])
    return fit_frames(Scene.model_validate(result.model_dump()))


def check_scene(scene:Scene) -> list[dict]:
    findings=[];by={o.id:o for o in scene.objects}
    for o in scene.objects:
        if o.transform.position[1]<-.02:
            findings.append({'object_id':o.id,'type':'below_floor','message':f'{o.label} 底部低于地面。'})
        if o.status=='failed':findings.append({'object_id':o.id,'type':'asset_failure','message':f'{o.label} 尚未生成成功；显示的是占位体。'})
        if o.generation.strategy=='generate3d' and not o.asset_id:
            findings.append({'object_id':o.id,'type':'missing_asset','message':f'{o.label} 缺少真实模型产物。'})
    for r in scene.relations:
        if r.type=='on':
            s,t=by[r.subject].transform,by[r.target].transform
            expected=t.position[1]+t.size[1]+r.offset[1]
            if abs(s.position[1]-expected)>.04:
                findings.append({'object_id':r.subject,'type':'support_mismatch','message':f'{by[r.subject].label} 与支撑面高度不符。','expected_y':expected})
            if abs(r.offset[1])>.04:
                findings.append({'object_id':r.subject,'type':'support_gap','message':f'{by[r.subject].label} 与支撑面存在间隙或穿入；offset 不为零，不能宣称紧贴。','gap_y':s.position[1]-t.position[1]-t.size[1]})
    return findings


def validate_plan_layout(scene:Scene,*,floating_tables=False) -> Scene:
    """Reject invalid new layouts while the director can still correct its plan.

    Do not silently move existing scenes or erase an intentional edit offset.
    An ``on`` relation in a new plan describes contact; floating arrangements
    must use a positional relation rather than claim a supporting surface.
    """
    solved=solve_layout(scene)
    people=[o for o in solved.objects if o.kind=='person']
    supports={r.subject:r for r in solved.relations if r.type=='on'}
    tables=[o for o in solved.objects if o.kind=='furniture'
            and (o.generation.primitive=='table' or re.search(r'桌子|餐桌|table',o.label,re.I))]
    for table in tables:
        if not floating_tables and table.generation.strategy=='procedural' and table.id not in supports and table.transform.position[1]>.04:
            raise AppError(f'规划布局未通过：{table.label} 是完整桌子，应落地或明确其支撑关系，不能把浮空薄盒子当桌子。'
                           '简单桌子使用 primitive=table、position.y=0；保留原图桌布外观时优先生成包含桌布的整个桌子。',code='invalid_plan_layout')
        t=table.transform
        for person in people:
            p=person.transform;dx=p.position[0]-t.position[0];dz=p.position[2]-t.position[2]
            # Conservative centre test in the table's local XZ footprint. A
            # neighbour reaching a hand over the table is not rejected.
            c,s=math.cos(t.rotation[1]),math.sin(t.rotation[1])
            x,z=c*dx-s*dz,s*dx+c*dz
            if (abs(x)<t.size[0]*.45 and abs(z)<t.size[2]*.45
                and p.position[1]<t.position[1]+t.size[1]-.04
                and p.position[1]+p.size[1]>t.position[1]+.04):
                positioning=[r for r in scene.relations if r.subject==person.id and r.type in ('on','near','around')]
                origin='；'.join(f'{r.type}(target={r.target}, offset={r.offset}, radius={r.radius}, angle={r.angle})'
                                for r in positioning) or '对象 transform.position（没有定位关系）'
                raise AppError(f'规划布局未通过：{person.label} 的身体中心位于 {table.label} 内部。'
                    f'对象 ID={person.id}，求解后底部位置={p.position}；桌子 ID={table.id}，'
                    f'底部={t.position}，尺寸={t.size}，Y旋转={t.rotation[1]}。生效定位：{origin}。'
                    'near/around/on 会覆盖对象 transform.position；只改对象位置不会修复仍然错误的定位关系。'
                    '请修正该人物的 relation.offset 或 around 半径/角度，或移除定位关系并给出独立位置，'
                    '使人物在桌边/桌后且身体与桌子留有空间；人物落地时底部 Y=0。'
                    '保持原图左右前后顺序，不移动蛋糕到人物位置，不增减人数。',code='invalid_plan_layout')
    for i,person in enumerate(people):
        for other in people[i+1:]:
            if math.dist(person.transform.position,other.transform.position)<.02:
                raise AppError(f'规划布局未通过：{person.label} 与 {other.label} 的底部位置重合。'
                    '请按原图分别安排位置，不能把多个人的 on.offset 都写成 [0,0,0]；'
                    '人物围坐在桌边不是站在桌面上。不要增加或减少人数。',code='invalid_plan_layout')
    for i,obj in enumerate(solved.objects):
        support=supports.get(obj.id)
        if not support or obj.kind not in ('food','prop') or obj.generation.strategy in ('photo','reuse'):continue
        for other in solved.objects[i+1:]:
            other_support=supports.get(other.id)
            if (other_support and other_support.target==support.target and other.kind in ('food','prop')
                and other.generation.strategy not in ('photo','reuse')
                and math.dist(obj.transform.position,other.transform.position)<.02):
                raise AppError(f'规划布局未通过：{obj.label} 与 {other.label} 重叠在同一支撑面中心。'
                               '请分别给出水平偏移；真正上下叠放时应声明物品之间的 on 关系。',code='invalid_plan_layout')
    invalid=[f for f in check_scene(solved)
             if f['type'] in ('below_floor','support_mismatch','support_gap')]
    if invalid:
        raise AppError('规划布局未通过：'+'；'.join(f['message'] for f in invalid)+
            ' position 是底部中心，地面 Y=0（背景平面也不能穿地面）；'
            'on 表示接触支撑面，offset.y 应为 0。只修正这些布局字段，再返回完整方案。',
            code='invalid_plan_layout')
    return solved


def fit_plan_primitives(plan:ScenePlan) -> tuple[ScenePlan,list[str]]:
    """Compile new box dimensions, never deform a generated/reference asset.

    A fresh procedural box has no existing shape to preserve. Its declared
    bounding dimensions specify the intended cuboid. Interpret those exactly
    instead of spending another director request on an omitted fitting flag.
    Edits and historical restoration continue to use their strict validators.
    """
    result=plan.model_copy(deep=True);changed=[]
    for obj in result.scene.objects:
        if (obj.generation.strategy=='procedural' and obj.generation.primitive=='box'
            and obj.status=='planned' and not obj.asset_id and not obj.reference_asset_id
            and not obj.locked and max(obj.transform.size)-min(obj.transform.size)>.001
            and obj.transform.fit!='stretch'):
            obj.transform.fit='stretch';changed.append(obj.id)
    if changed:
        result.warnings.append('简单长方体将按方案给出的宽、高、深构造；不会拉伸照片或真实人物模型。')
    return result,changed


def fit_plan_contacts(plan:ScenePlan,requirements:str='') -> tuple[ScenePlan,list[str]]:
    """Compile table contact heights for new food/props, not historical edits.

    ``on`` means contact, not an absolute height. Preserve the director's
    horizontal offsets and let solve_layout calculate height from the target.
    Do not repair people standing on a table or reinterpret floating requests.
    Those semantic errors still require a corrected plan.
    """
    result=plan.model_copy(deep=True);changed=[]
    for clause in re.split(r'[，,。；;\n]',requirements):
        floating=re.findall(r'悬浮|漂浮|浮空|\bfloat(?:ing)?\b',clause,re.I)
        # A mixed or positive float clause is not safely compilable. Retain
        # it for the director, even if a different clause forbids floating.
        if floating and (len(floating)>1 or not re.search(r'不要|不能|不许|不准|别',clause)):
            return result,changed
    by={obj.id:obj for obj in result.scene.objects}
    for relation in result.scene.relations:
        subject=by.get(relation.subject);target=by.get(relation.target)
        if (relation.type!='on' or subject is None or target is None
            or subject.kind not in ('food','prop') or target.kind!='furniture'
            or not (target.generation.primitive=='table' or re.search(r'桌子|餐桌|table',target.label,re.I))
            or subject.status!='planned' or subject.locked or subject.asset_id or subject.reference_asset_id
            or subject.generation.strategy not in ('generate3d','procedural')
            or abs(relation.offset[1])<1e-9):continue
        relation.offset[1]=0;changed.append(subject.id)
    if changed:
        result.warnings.append('新方案中的桌面物品按接触关系计算高度，水平摆放不变；没有移动旧场景或锁定对象。')
    return result,changed


def task_graph(scene:Scene) -> list[dict]:
    graph=[]
    for o in scene.objects:
        g=o.generation;asset=f'asset:{o.id}';deps=[]
        if g.strategy in ('generate3d','photo'):
            ref=f'reference:{o.id}'
            graph.append({'id':ref,'tool':'image.prepare_reference','object_id':o.id,'depends_on':[]})
            deps=[ref]
        elif g.strategy=='reuse':deps=[f'asset:{g.reuse_object}']
        graph.append({'id':asset,'tool':{'generate3d':'asset.generate_3d','photo':'asset.photo','reuse':'asset.reuse','procedural':'asset.procedural'}[g.strategy],
                      'object_id':o.id,'depends_on':deps})
    for track in scene.audio:
        graph.append({'id':f'audio:{track.id}','tool':f'audio.{track.strategy}','audio_id':track.id,'depends_on':[]})
    graph.append({'id':'assemble','tool':'scene.assemble','depends_on':[x['id'] for x in graph]})
    topological({x['id']:x['depends_on'] for x in graph})
    return graph


def validate_portrait_only(plan:ScenePlan,project:dict) -> ScenePlan:
    """Enforce explicit portrait-only requests from user project fields.

    Image text and source descriptions cannot authorize extra scene objects.
    Reject contradictory plans into the existing bounded correction loop.
    """
    clauses=re.split(r'[，,。；;\n]',str(project.get('requirements',''))+'\n'+str(project.get('diary','')))
    only=False;clean=False
    for clause in clauses:
        if re.search(r'不要|不能|不许|不准|别|是否|能否|[?？]',clause):continue
        if re.search(r'(?:单独保留|只保留|仅保留|只要)\s*(?:这张图中的|图中的|照片中的)?\s*(?:人像|人物|角色)',clause):only=True
        if re.search(r'(?:去掉|去除|移除|删除)[^。；;]*(?:背景|对话框|气泡|文字)',clause):clean=True
    if not only:return plan
    if not plan.scene.objects or any(o.kind!='person' for o in plan.scene.objects):
        raise AppError('用户明确要求只保留人像：仅可建立人物对象，不能添加文本、对话框、边框、背景或底座；请重新规划，不把原图文字另做成对象。')
    for obj in plan.scene.objects:
        gen=obj.generation
        if gen.strategy not in ('photo','generate3d') or not gen.primary_source:
            raise AppError('只保留人像必须使用原始人物参考图，不能用程序几何或凭空生成替代。')
        if clean and (gen.image_mode!='edit' or not gen.image_prompt.strip()):
            raise AppError('用户要求去掉背景/对话框：人物必须安排 image.edit 和明确的清理提示词，不能用未处理的原图或裁剪宣称完成。')
    return plan


def validate_plan_execution(plan:ScenePlan,project:dict) -> None:
    """Reject promises that the selected execution path cannot perform.

    Report independent errors together so one bounded correction can fix both
    reference preparation and placement. Never rewrite an accepted scene.
    """
    errors=[]
    request=str(project.get('requirements',''))+'\n'+str(project.get('diary',''))
    ground_people=bool(re.search(
        r'(?:人物|人们|大家|朋友们)[^。；;\n]{0,60}(?:不是|不要|不能)[^。；;\n]{0,24}(?:站|坐|放)[^。；;\n]{0,16}(?:桌面|桌(?:子)?上)',request)
        or re.search(r'(?:所有|每个|每位)?人物[^。；;\n]{0,16}(?:落地|站在地面)',request))
    by={obj.id:obj for obj in plan.scene.objects}
    positioned={}
    for relation in plan.scene.relations:
        if relation.type not in ('on','near','around'):continue
        if relation.subject in positioned:
            errors.append(f'{by[relation.subject].label} 同时有多个定位关系 '
                          f'{positioned[relation.subject]} 和 {relation.type}，会互相覆盖。'
                          '每个对象只保留一个 on/near/around；朝向可另外使用 face。')
        positioned[relation.subject]=relation.type
    for obj in plan.scene.objects:
        gen=obj.generation
        if gen.strategy in ('generate3d','photo') and gen.image_prompt.strip() and gen.image_mode in ('original','crop'):
            errors.append(f'{obj.label} 有图片编辑提示词，却使用 {gen.image_mode}，该模式不会执行提示词。'
                          '需要提取、清理或补全主体时使用 image_mode=edit 和 image_model；'
                          '只有完全不做图片修改时才保留 original/crop 并清空 image_prompt。')
    if ground_people:
        for relation in plan.scene.relations:
            subject=by.get(relation.subject);target=by.get(relation.target)
            if (relation.type=='on' and subject and subject.kind=='person' and target
                and (target.generation.primitive=='table' or target.kind=='furniture' and re.search(r'桌',target.label))):
                errors.append(f'{subject.label} 被声明 on {target.label}，会站到桌面，违反人物在桌边地面的要求。'
                              '移除人物对桌子的 on；人物 position.y=0，用 near/around 或独立位置安排在桌边。蛋糕才放桌面。')
    if errors:raise AppError('规划执行意图未通过：'+'；'.join(errors)[:3800],code='invalid_plan_execution')


def validate_plan(plan:ScenePlan,project:dict,sources:list[dict],capabilities:dict) -> ScenePlan:
    validate_portrait_only(plan,project)
    validate_plan_execution(plan,project)
    preserve_count=bool(re.search(r'保留[^。\n]{0,45}(?:人数|人物数量)',str(project.get('requirements',''))))
    if preserve_count and any(o.kind=='person' for o in plan.scene.objects) and plan.reference_person_count is None:
        raise AppError('要求保留原图人数：请填写 reference_person_count 并逐人建立对象；无法确定则请先请求清晰原图，不猜人数。')
    if plan.reference_person_count is not None:
        actual=sum(o.kind=='person' for o in plan.scene.objects)
        if actual!=plan.reference_person_count:
            raise AppError(f'人物数量不一致：参考统计为 {plan.reference_person_count} 人，场景只有 {actual} 个人物对象。'
                '请依据原图修正完整方案，不能只在 summary 中承诺保留人数。')
    budget=project['budget'];scene=plan.scene;by={s['id']:s for s in sources}
    if len(scene.objects)>budget['max_objects']:
        raise AppError('计划超过对象总预算。')
    if sum(o.generation.strategy=='generate3d' for o in scene.objects)>budget['max_generated_assets']:
        raise AppError('计划超过三维生成预算。')
    whole_scene_refs={}
    for o in scene.objects:
        from .edit_tools import validate_box_size
        validate_box_size(o)
        for ref in o.reference_ids:
            if ref not in by or by[ref]['kind']!='image':raise AppError('计划包含无效图片来源。')
        g=o.generation
        if g.primary_source and (g.primary_source not in by or by[g.primary_source]['kind']!='image'):
            raise AppError(f'{o.label} 的主参考图无效。')
        if g.strategy in ('photo','generate3d') and not g.primary_source and g.image_mode!='text2image':
            raise AppError(f'{o.label} 需要一张主参考图。')
        if (g.strategy=='photo' and by.get(g.primary_source,{}).get('role')=='scene'
            and g.image_mode in ('original','crop') and not g.crop and not by[g.primary_source].get('crop')
            and re.search(r'桌布|地毯|桌垫|花纹|tablecloth|rug',o.label,re.I)):
            raise AppError(f'{o.label} 不能用未处理的整张场景图冒充局部花纹。'
                '当前 photo 是竖直展示平面，不是水平桌布材质。保留桌布时优先给完整桌子安排 image.edit + generate3d，'
                '参考图保留桌子自身的桌布并移除人物和蛋糕；不要再拆出独立的整图桌布。')
        if g.strategy=='generate3d':
            cap=capabilities.get(g.geometry_model or '',{})
            if 'geometry.generate' not in cap.get('capabilities',[]):raise AppError(f'{o.label} 指定的三维模型不可用。')
            if cap.get('available') is False:raise AppError(f'{o.label} 的三维服务已配置，但暂时不可用。')
            source=by.get(g.primary_source,{})
            if source.get('role')=='scene' and g.image_mode in ('original','crop') and not g.crop and not source.get('crop'):
                if g.primary_source in whole_scene_refs:
                    raise AppError('多个独立对象不能重复使用同一张未拆分的场景整图建模；请为每个主体选取独立区域、使用图片编辑分离，或请求单物体参考图。')
                whole_scene_refs[g.primary_source]=o.id
            if g.options.steps<50:
                warning=f'{o.label} 使用 {g.options.steps} 步快速采样，不能据此判断最终建模质量；正式质量对照建议使用 50 步。'
                if warning not in plan.warnings:plan.warnings.append(warning)
        if g.image_mode in ('edit','text2image') and g.strategy in ('generate3d','photo'):
            key='image.edit' if g.image_mode=='edit' else 'image.generate'
            if key not in capabilities.get(g.image_model or '',{}).get('capabilities',[]):raise AppError(f'{o.label} 的图片模型不支持 {key}。')
            if capabilities.get(g.image_model or '',{}).get('available') is False:
                raise AppError(f'{o.label} 的图片服务已配置，但暂时不可用；最近返回 HTTP {capabilities[g.image_model].get("last_http_status",503)}，请稍后重试。')
            if not g.image_prompt.strip():raise AppError('图片生成/编辑必须提供提示词。')
        if o.asset_id or o.reference_asset_id or o.status!='planned':
            raise AppError('规划模型不能自行填写已生成的资产或完成状态。')
    for a in scene.audio:
        if a.strategy in ('original','enhance') and (a.source_id not in by or by[a.source_id]['kind']!='audio'):
            raise AppError('音轨原始素材无效。')
        if a.strategy in ('music','tts') and not project['allow_synthetic_audio']:
            raise AppError('未授权添加合成语音或音乐；原声不会被自动替换。')
        if a.strategy!='original':
            cap={'tts':'audio.tts','enhance':'audio.enhance','music':'music.generate'}[a.strategy]
            if cap not in capabilities.get(a.model or '',{}).get('capabilities',[]):raise AppError(f'音频模型不支持 {cap}。')
        if a.asset_id or a.status!='planned':raise AppError('计划中不可引用未执行的音频产物。')
    task_graph(scene)
    clauses=re.split(r'[，,。；;\n]',str(project.get('requirements',''))+'\n'+str(project.get('diary','')))
    floating_tables=any(not re.search(r'不要|不能|不许|不准|别|是否|能否|[?？]',clause)
        and re.search(r'(?:桌子|餐桌|table)[^。\n]{0,20}(?:悬浮|漂浮)|(?:悬浮|漂浮)[^。\n]{0,20}(?:桌子|餐桌|table)',clause,re.I)
        for clause in clauses)
    plan.scene=validate_plan_layout(scene,floating_tables=floating_tables)
    return plan


def validate_contact_edit(patch,scene:Scene,prompt:str):
    """Validate explicit contact/ground/stretch requests; never rewrite intent.

    Incorrect model coordinates are sent back through the bounded correction
    loop instead of publishing a geometrically contradictory success message.
    Arbitrary placements remain allowed when contact/ground was not requested.
    """
    objects={o.id:o for o in scene.objects}
    from .edit_tools import resized_transform
    changed={op.object_id:(op.transform if op.type=='transform' else resized_transform(objects[op.object_id],op.size_edit))
             for op in patch.operations if op.type in ('transform','resize') and op.object_id in objects}
    transforms={oid:changed.get(oid,o.transform) for oid,o in objects.items()}
    if any(word in prompt for word in ('紧贴','贴合','不要悬空','不悬空','无额外间隙','不留间隙')):
        for relation in scene.relations:
            if relation.type!='on' or not ({relation.subject,relation.target}&changed.keys()):continue
            subject,target=transforms[relation.subject],transforms[relation.target]
            height=target.position[1]+target.size[1]
            if abs(subject.position[1]-height)>.001:
                raise AppError(f'用户要求紧贴支撑面：{objects[relation.subject].label} 的 position.y 应为 {height:g}，不能为 {subject.position[1]:g}。size[1] 是高度，size[2] 是深度，不得混用。')
    if any(word in prompt for word in ('落在地面','放在地面','放到地面','落地')):
        supported={r.subject for r in scene.relations if r.type=='on'}
        for oid,t in changed.items():
            if oid not in supported and abs(t.position[1])>.001:
                raise AppError(f'用户要求落地：{objects[oid].label} 的 position.y 应为 0。position 是底部中心，不是几何中心。')
    if any(word in prompt for word in ('长宽高分别','分别缩放','不保持原','不必保持原')):
        for oid,t in changed.items():
            old=objects[oid]
            if old.generation.strategy=='procedural' and old.generation.primitive=='box' and max(t.size)-min(t.size)>.001 and t.fit!='stretch':
                raise AppError(f'用户允许长宽高分别改变：{old.label} 必须使用 transform.fit=stretch，否则 uniform 会保持立方体比例，无法实现指定的长方体尺寸。')
    return patch
