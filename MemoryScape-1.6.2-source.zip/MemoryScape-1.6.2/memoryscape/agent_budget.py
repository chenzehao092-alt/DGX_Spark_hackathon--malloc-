"""SQLite-backed root-request inference budgets; polling is not inference."""
import json
import time
from .db import dumps,uid
from .errors import AppError
from .schemas import Budget


def attach(service,c,job_id,project,parent_job=None):
    root=None
    if parent_job:
        parent=c.execute('SELECT project FROM jobs WHERE id=?',(parent_job,)).fetchone()
        if not parent or parent['project']!=project:raise AppError('预算父任务不属于本项目。',409)
        linked=c.execute('SELECT root FROM agent_jobs WHERE job=?',(parent_job,)).fetchone()
        root=linked['root'] if linked else parent_job
    root=root or job_id
    limits=Budget.model_validate(service.project(project)['budget']).model_dump()
    c.execute('INSERT OR IGNORE INTO agent_runs VALUES(?,?,?,?)',(root,project,dumps(limits),time.time()))
    c.execute('INSERT OR IGNORE INTO agent_jobs(job,root) VALUES(?,?)',(job_id,root))
    return root


def check_deadline(ctx):
    with ctx.db.tx() as c:
        row=c.execute('SELECT * FROM agent_jobs WHERE job=?',(ctx.id,)).fetchone()
        if not row:
            attach(ctx.service,c,ctx.id,ctx.project)
            row=c.execute('SELECT * FROM agent_jobs WHERE job=?',(ctx.id,)).fetchone()
        limits=json.loads(c.execute('SELECT limits FROM agent_runs WHERE root=?',(row['root'],)).fetchone()['limits'])
        now=time.time();started=row['started']
        if started is None:
            c.execute('UPDATE agent_jobs SET started=? WHERE job=?',(now,ctx.id));started=now
        if now-started>limits['max_job_seconds']:
            raise AppError('任务执行时间预算已用完；远端编号和候选产物保留，不再自动调用。',409,'agent_budget_exhausted')


def charge(ctx,kind,key=None):
    if kind not in ('director','remote_job'):raise ValueError('unknown inference category')
    ctx.check();key=key or uid('call_')
    with ctx.db.tx() as c:
        row=c.execute('SELECT root FROM agent_jobs WHERE job=?',(ctx.id,)).fetchone();root=row['root']
        if c.execute('SELECT 1 FROM agent_charges WHERE root=? AND kind=? AND charge_key=?',(root,kind,key)).fetchone():return
        limits=json.loads(c.execute('SELECT limits FROM agent_runs WHERE root=?',(root,)).fetchone()['limits'])
        maximum=limits['max_director_calls' if kind=='director' else 'max_remote_jobs']
        used=c.execute('SELECT COUNT(*) FROM agent_charges WHERE root=? AND kind=?',(root,kind)).fetchone()[0]
        if used>=maximum:raise AppError('本轮请求的模型调用预算已用完；没有追加推理或覆盖当前版本。',409,'agent_budget_exhausted')
        c.execute('INSERT INTO agent_charges VALUES(?,?,?,?,?)',(root,kind,key,ctx.id,time.time()))
        ctx.db.event(ctx.project,ctx.id,'agent.budget_charged',{'kind':kind,'used':used+1,'limit':maximum,'root_job':root},c)


def snapshot(service,job_id):
    row=service.db.one('SELECT r.* FROM agent_runs r JOIN agent_jobs j ON j.root=r.root WHERE j.job=?',(job_id,))
    if not row:return None
    counts=service.db.all('SELECT kind,COUNT(*) used FROM agent_charges WHERE root=? GROUP BY kind',(row['root'],))
    return {'root_job':row['root'],'limits':json.loads(row['limits']),
            'used':{k:next((r['used'] for r in counts if r['kind']==k),0) for k in ('director','remote_job')},
            'note':'计数为调用预留（含失败/不确定结果）；远端查询和检查点复用不计推理。'}
