"""Durable job/step state. Long remote jobs are reattached, never blindly resubmitted."""
from __future__ import annotations
import json
import threading
import time
import traceback
from .db import dumps,digest,uid
from .errors import AppError,Cancelled


class JobContext:
    def __init__(self,service,job,owner):
        self.service,self.db,self.job,self.owner=service,service.db,job,owner
        self.id,self.project=job['id'],job['project']

    def check(self):
        row=self.db.one('SELECT cancel,owner,status FROM jobs WHERE id=?',(self.id,))
        if not row or row['cancel']:raise Cancelled()
        if row['owner']!=self.owner or row['status']!='running':raise AppError('任务执行租约已转移。',409,'lease_lost')
        from .agent_budget import check_deadline
        check_deadline(self)

    def charge(self,kind,key=None):
        from .agent_budget import charge
        charge(self,kind,key)

    def emit(self,kind,body):
        self.check();self.db.event(self.project,self.id,kind,body)

    def remote_ref(self,name):
        row=self.db.one('SELECT remote FROM steps WHERE job=? AND name=?',(self.id,name))
        return json.loads(row['remote']) if row and row['remote'] else None

    def set_remote(self,name,ref):
        self.check()
        self.db.execute('UPDATE steps SET remote=?,updated=? WHERE job=? AND name=?',(dumps(ref),time.time(),self.id,name))

    def step(self,name,input_data,fn):
        self.check();fp=digest(input_data)
        with self.db.tx() as c:
            row=c.execute('SELECT * FROM steps WHERE job=? AND name=?',(self.id,name)).fetchone()
            if row and row['input_hash']!=fp:raise AppError(f'检查点 {name} 输入已变化，需新建任务。',409)
            if row and row['status']=='succeeded':return json.loads(row['result'])
            if row:
                c.execute('UPDATE steps SET status="running",attempt=attempt+1,error=NULL,updated=? WHERE job=? AND name=?',(time.time(),self.id,name))
            else:
                c.execute('INSERT INTO steps(job,name,input_hash,status,attempt,updated) VALUES(?,?,?,"running",1,?)',(self.id,name,fp,time.time()))
            self.db.event(self.project,self.id,'step.started',{'step':name},c)
        started=time.perf_counter()
        try:
            value=fn();self.check()
            with self.db.tx() as c:
                c.execute('UPDATE steps SET status="succeeded",result=?,error=NULL,updated=? WHERE job=? AND name=?',(dumps(value),time.time(),self.id,name))
                self.db.event(self.project,self.id,'step.completed',{'step':name,'elapsed_seconds':round(time.perf_counter()-started,3)},c)
            return value
        except Exception as e:
            self.db.execute('UPDATE steps SET status=?,error=?,updated=? WHERE job=? AND name=?',
                            ('cancelled' if isinstance(e,Cancelled) else 'failed',str(e)[:800],time.time(),self.id,name))
            self.db.event(self.project,self.id,'step.failed',{'step':name,'error':str(e)[:500]})
            raise


class Worker:
    def __init__(self,service,handler):
        self.service,self.db,self.handler=service,service.db,handler
        self.owner=uid('worker_');self.stop_event=threading.Event();self.thread=None

    def claim(self):
        now=time.time()
        with self.db.tx() as c:
            row=c.execute('SELECT * FROM jobs WHERE cancel=0 AND (status="queued" OR (status="running" AND lease<?)) ORDER BY created LIMIT 1',(now,)).fetchone()
            if not row:return None
            c.execute('UPDATE jobs SET status="running",owner=?,lease=?,attempts=attempts+1,updated=? WHERE id=?',
                      (self.owner,now+self.service.settings.lease_seconds,now,row['id']))
            self.db.event(row['project'],row['id'],'job.started',{'attempt':row['attempts']+1,'recovered':row['status']=='running'},c)
        return self.service.job(row['id'])

    def run_once(self):
        job=self.claim()
        if not job:return False
        ctx=JobContext(self.service,job,self.owner);done=threading.Event()
        def heartbeat():
            while not done.wait(max(1,self.service.settings.lease_seconds/3)):
                self.db.execute('UPDATE jobs SET lease=? WHERE id=? AND owner=? AND status="running"',
                                (time.time()+self.service.settings.lease_seconds,job['id'],self.owner))
        heart=threading.Thread(target=heartbeat,daemon=True);heart.start()
        try:
            result=self.handler(ctx)
            ctx.check();status=result.pop('_status','succeeded')
            self.db.execute('UPDATE jobs SET status=?,result=?,error=NULL,lease=NULL,updated=? WHERE id=? AND owner=?',
                            (status,dumps(result),time.time(),job['id'],self.owner))
            self.db.event(job['project'],job['id'],'job.finished',{'status':status})
        except Cancelled as e:
            self.db.execute('UPDATE jobs SET status="cancelled",error=?,lease=NULL,updated=? WHERE id=? AND owner=?',(str(e),time.time(),job['id'],self.owner))
        except Exception as e:
            traceback.print_exc()
            self.db.execute('UPDATE jobs SET status="failed",error=?,lease=NULL,updated=? WHERE id=? AND owner=?',(str(e)[:1200],time.time(),job['id'],self.owner))
            self.db.event(job['project'],job['id'],'job.failed',{'error':str(e)[:800]})
        finally:done.set();heart.join(timeout=2)
        return True

    def loop(self):
        while not self.stop_event.is_set():
            try:
                if not self.run_once():self.stop_event.wait(self.service.settings.poll_seconds)
            except Exception:
                traceback.print_exc();self.stop_event.wait(1)

    def start(self):
        if self.thread and self.thread.is_alive():return
        self.thread=threading.Thread(target=self.loop,name='memoryscape-worker',daemon=True);self.thread.start()

    def stop(self):
        # Active remote task is not killed; a new worker reattaches after the lease expires.
        self.stop_event.set()
        if self.thread:self.thread.join(timeout=2)
