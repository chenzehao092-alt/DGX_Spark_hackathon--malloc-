"""App-lifetime connection supervision, without inference or remote deployment.

Only an operator-configured loopback SSH forward can be repaired. Cloud
checks are bounded GET requests; credentials, addresses and PIDs are never
included in the public snapshot. Jobs have their own bounded recovery wait.
"""
from __future__ import annotations
import copy
import hashlib
import json
import logging
import os
import random
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit
import httpx
from .config import ROOT, endpoint, tomllib

log=logging.getLogger('memoryscape.connections')


def retry_delay(attempt, base=2.0, cap=30.0, jitter=random.uniform):
    return min(cap,base*2**min(max(0,attempt-1),10))*jitter(.8,1.0)


def probe_model(settings, name, conf, transport=None):
    result={'model':name,'state':'offline','checked_at':time.time(),'inference_verified':False}
    try:
        base=endpoint(conf);token=os.getenv(conf.get('token_env',''),'')
        if conf.get('require_token',True) and not token:
            return {**result,'state':'needs_configuration','reason':'credential_missing'}
        protocol=conf.get('protocol','node-v1')
        path='/models' if protocol in ('chat','stepfun-images') else '/v1/capabilities'
        with httpx.Client(timeout=3 if protocol=='node-v1' else 8,trust_env=False,
                          follow_redirects=False,transport=transport) as client:
            with client.stream('GET',base+path,headers={'Authorization':'Bearer '+token} if token else {}) as response:
                result['http_status']=response.status_code
                if response.status_code in (401,403):
                    return {**result,'state':'needs_configuration','reason':'authentication_failed'}
                if not response.is_success:return {**result,'reason':'http_error'}
                raw=bytearray()
                for chunk in response.iter_bytes():
                    raw.extend(chunk)
                    if len(raw)>1024*1024:raise ValueError('oversized capabilities')
                data=json.loads(raw)
        if not isinstance(data,dict):raise ValueError('invalid metadata')
        if protocol=='node-v1':
            if not set(conf.get('capabilities',[])).issubset(data.get('capabilities',[])):
                return {**result,'state':'needs_configuration','reason':'capability_mismatch'}
            if settings.test_models is None and data.get('execution_mode')=='contract-test':
                return {**result,'state':'needs_configuration','reason':'test_node_not_native'}
            if name=='geometry' and settings.test_models is None and (
                data.get('execution_mode')!='native' or
                data.get('fingerprint',{}).get('runtime_revision')!='memoryscape-1.5-desktop'):
                return {**result,'state':'needs_configuration','reason':'runtime_mismatch'}
        elif not isinstance(data.get('data'),list):raise ValueError('invalid models list')
        return {**result,'state':'connected','reason':'metadata_verified'}
    except (httpx.HTTPError,OSError):return {**result,'reason':'network_unreachable'}
    except (ValueError,TypeError,KeyError):
        return {**result,'state':'needs_configuration','reason':'invalid_metadata'}


class ConnectionMonitor:
    def __init__(self,settings,transport=None):
        self.settings,self.transport=settings,transport
        self.stop_event=threading.Event();self.thread=None
        self.lock=threading.Lock();self.states={};self.next_checks={};self.failures={}
        self.config_hashes={};self.reconnects=0;self.next_reconnect={}

    def snapshot(self):
        with self.lock:
            models=copy.deepcopy(list(self.states.values()))
        try:
            seen={m['model'] for m in models}
            models.extend({'model':name,'state':'checking','inference_verified':False}
                for name,conf in self.settings.models().items() if conf.get('enabled') and name not in seen)
        except (OSError,ValueError):pass
        return {'monitor_running':bool(self.thread and self.thread.is_alive()),
                'models':models,'reconnections':self.reconnects,
                'note':'仅连接与能力检查，不等于模型推理或生成质量验收。'}

    def publish(self,name,value):
        with self.lock:
            previous=self.states.get(name,{})
            self.states[name]=value
        if previous.get('state')!=value.get('state'):
            # Fixed fields only; do not log errors containing URLs or credentials.
            log.info('Model %s connection state: %s',name,value['state'])

    def tunnel_config(self,name,conf):
        if os.getenv('MS_AUTORECONNECT','1').lower() in ('0','false','no'):return None
        if name not in ('geometry','image') or conf.get('protocol','node-v1')!='node-v1':return None
        path=Path(os.getenv('MS_DEPLOYMENT_FILE',str(ROOT/'configs/deployment.toml')))
        if not path.is_file():return None
        from scripts.desktop_node import validate_remote
        remote=tomllib.loads(path.read_text('utf-8')).get('remote' if name=='geometry' else 'image_remote',{})
        if not remote:return None
        validate_remote(remote)
        if remote.get('kind','geometry')!=name:return None
        address=urlsplit(endpoint(conf))
        if address.hostname not in ('127.0.0.1','localhost') or address.port!=remote['local_port']:return None
        return remote

    def tick(self):
        now=time.monotonic()
        models={name:conf for name,conf in self.settings.models().items() if conf.get('enabled')}
        with self.lock:
            self.states={name:value for name,value in self.states.items() if name in models}
        probes={}
        # Local recovery must not wait for slow cloud connectivity checks.
        for name,conf in sorted(models.items(),key=lambda item:item[1].get('protocol','node-v1')!='node-v1'):
            if self.stop_event.is_set():return
            token=os.getenv(conf.get('token_env',''),'')
            fingerprint=hashlib.sha256(json.dumps(conf,sort_keys=True).encode()+token.encode()).hexdigest()
            if self.config_hashes.get(name)!=fingerprint:
                self.next_checks[name]=0;self.failures[name]=0;self.config_hashes[name]=fingerprint
            if now<self.next_checks.get(name,0):continue
            node=conf.get('protocol','node-v1')=='node-v1'
            group=(conf.get('url'),conf.get('url_env'),token) if not node else (name,)
            if group in probes:state={**probes[group],'model':name}
            else:state=probe_model(self.settings,name,conf,self.transport);probes[group]=state
            self.next_checks[name]=now+(10 if node else 60)
            failures=0 if state['state']=='connected' else self.failures.get(name,0)+1
            self.failures[name]=failures
            state['consecutive_failures']=failures
            try:remote=self.tunnel_config(name,conf)
            except (OSError,ValueError,KeyError):
                remote=None;state={**state,'state':'needs_configuration','reason':'invalid_deployment'}
            if remote and state['state']=='offline':
                state['state']='reconnecting'
                state['next_retry_seconds']=max(0,round(self.next_reconnect.get(name,0)-now))
                self.publish(name,state)
                if now>=self.next_reconnect.get(name,0):
                    delay=retry_delay(failures)
                    self.next_reconnect[name]=now+delay
                    try:
                        from scripts.desktop_node import ensure_tunnel
                        ensure_tunnel(self.settings,remote,token,self.stop_event)
                        checked=probe_model(self.settings,name,conf,self.transport)
                        if checked['state']=='connected':
                            state={**checked,'consecutive_failures':0}
                            self.failures[name]=0;self.reconnects+=1;self.next_reconnect[name]=0
                    except (RuntimeError,OSError,ValueError):
                        state['reason']='ssh_retry_pending';state['next_retry_seconds']=round(delay)
                    self.next_checks[name]=time.monotonic()+min(10,delay)
            self.publish(name,state)
        # Runtime-only evidence, never part of the source distribution.
        try:
            pending=self.settings.data_dir/'connection-status.pending'
            pending.write_text(json.dumps(self.snapshot(),ensure_ascii=False),'utf-8')
            os.replace(pending,self.settings.data_dir/'connection-status.json')
        except OSError:pass

    def loop(self):
        while not self.stop_event.is_set():
            try:self.tick()
            except Exception:
                # A malformed/temporarily replaced configuration must not kill supervision.
                log.warning('Connection monitor check failed; will retry without changing models.')
            self.stop_event.wait(2)

    def start(self):
        if self.settings.test_models is not None:return
        if self.thread and self.thread.is_alive():return
        self.stop_event.clear()
        self.thread=threading.Thread(target=self.loop,name='connection-monitor',daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread:self.thread.join(timeout=5)
