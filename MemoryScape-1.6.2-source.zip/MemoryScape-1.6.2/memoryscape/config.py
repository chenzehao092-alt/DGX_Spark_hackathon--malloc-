from __future__ import annotations
import os
import secrets
try:
    import tomllib
except ModuleNotFoundError:  # isolated GPU runtime may still use Python 3.10
    import tomli as tomllib
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]


def load_env(path: Path) -> None:
    """Small deliberately non-executable .env reader. Does not interpolate shell code."""
    if not path.is_file():
        return
    for raw in path.read_text('utf-8').splitlines():
        s = raw.strip()
        if not s or s.startswith('#') or '=' not in s:
            continue
        k, v = s.split('=', 1)
        k, v = k.strip(), v.strip()
        if k.replace('_', '').isalnum() and not k[0].isdigit():
            if len(v) >= 2 and v[0] == v[-1] and v[0] in ('"', "'"):
                v = v[1:-1]
            os.environ.setdefault(k, v)


@dataclass
class Settings:
    data_dir: Path = field(default_factory=lambda: Path(os.getenv('MS_DATA_DIR', str(ROOT/'data'))).resolve())
    config_file: Path = field(default_factory=lambda: Path(os.getenv('MS_MODELS_FILE', str(ROOT/'configs/models.toml'))).resolve())
    token: str = field(default_factory=lambda: os.getenv('MS_TOKEN', ''))
    host: str = '127.0.0.1'
    port: int = 8000
    start_worker: bool = True
    max_upload: int = 128 * 1024 * 1024
    max_output: int = 128 * 1024 * 1024
    max_project_zip: int = 512 * 1024 * 1024
    max_parallel: int = 3
    lease_seconds: int = 45
    poll_seconds: float = 0.2
    remote_poll_seconds: float = 2.0
    remote_wait_seconds: int = 7200
    connection_grace_seconds: float = 180
    chat_timeout: int = 240
    # Production image-conditioned models receive independent visual review.
    # Policy below determines whether a visual rejection blocks geometry.
    reference_review: bool = True
    asset_review: bool = field(default_factory=lambda: os.getenv('MS_ASSET_REVIEW','1')=='1')
    asset_review_policy: str = field(default_factory=lambda: os.getenv('MS_ASSET_REVIEW_POLICY','warn'))
    decomposition_required: bool = True
    quality_render_edge: int = 384
    quality_render_seconds: int = 90
    # At most ONE additional object candidate. Provider failures do not retry.
    quality_repair_attempts: int = field(default_factory=lambda: int(os.getenv('MS_QUALITY_REPAIR_ATTEMPTS','1')))
    # User-selected workflow-first mode: visual concerns remain recorded, but
    # do not prevent valid model outputs from reaching geometry. Strict mode
    # is still available without weakening format/authentication checks.
    reference_review_policy: str = field(default_factory=lambda: os.getenv('MS_REFERENCE_REVIEW_POLICY','warn'))
    local_auto_login: bool = field(default_factory=lambda: os.getenv('MS_LOCAL_AUTO_LOGIN','1')=='1')
    allowed_hosts: list[str] = field(default_factory=lambda: ['localhost', '127.0.0.1', '[::1]', 'testserver'])
    test_models: dict | None = None

    def initialize(self):
        if self.reference_review_policy not in ('strict','warn'):
            raise ValueError('MS_REFERENCE_REVIEW_POLICY must be strict or warn')
        if self.asset_review_policy not in ('strict','warn'):raise ValueError('MS_ASSET_REVIEW_POLICY must be strict or warn')
        if self.quality_repair_attempts not in (0,1):raise ValueError('MS_QUALITY_REPAIR_ATTEMPTS must be 0 or 1')
        if not 128<=self.quality_render_edge<=768 or not 1<=self.quality_render_seconds<=180:raise ValueError('Quality renderer bounds invalid')
        self.data_dir = Path(self.data_dir).resolve()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_file = Path(self.config_file)
        key_path = self.data_dir/'access-token'
        if not self.token:
            if key_path.is_file():
                self.token = key_path.read_text().strip()
            else:
                self.token = secrets.token_urlsafe(36)
                fd = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, 'w') as f:
                    f.write(self.token+'\n')
        if len(self.token) < 24:
            raise ValueError('MS_TOKEN 必须至少 24 字符；不接受演示通用密钥。')
        extras = os.getenv('MS_ALLOWED_HOSTS', '')
        self.allowed_hosts = list(dict.fromkeys(self.allowed_hosts + [x.strip() for x in extras.split(',') if x.strip()]))
        return self

    def models(self) -> dict:
        if self.test_models is not None:
            return self.test_models
        if not self.config_file.is_file():
            return {}
        raw = tomllib.loads(self.config_file.read_text('utf-8'))
        return raw.get('models', {})


def endpoint(conf: dict) -> str:
    base = os.getenv(conf.get('url_env', ''), '') or conf.get('url', '')
    p = urlsplit(base)
    if p.scheme not in ('http', 'https') or not p.hostname or p.username or p.query or p.fragment:
        raise ValueError('模型 URL 无效。只接受部署者配置的 HTTP(S) 端点，不接受用户动态 URL。')
    if p.scheme == 'http' and p.hostname not in ('localhost', '127.0.0.1', '::1') and not conf.get('allow_plain_http', False):
        raise ValueError('非回环模型连接必须使用 HTTPS 或明确配置 allow_plain_http；建议使用 SSH 隧道。')
    return base.rstrip('/')
