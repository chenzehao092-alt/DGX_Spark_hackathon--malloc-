from __future__ import annotations
import hashlib
import json
import os
import re
import time
from pathlib import Path
from .db import DB,dumps,uid
from .errors import AppError
from .media import inspect


class Assets:
    def __init__(self, db:DB, root:Path, max_size:int=128*1024*1024):
        self.db,self.root,self.max_size=db,Path(root).resolve(),max_size
        self.root.mkdir(parents=True,exist_ok=True)

    def path(self, sha:str) -> Path:
        if not re.fullmatch('[0-9a-f]{64}',sha):
            raise AppError('Invalid blob hash')
        return self.root/sha[:2]/sha

    def put(self, project:str, raw:bytes, filename:str, provenance='original', parents=None, extra=None) -> dict:
        if len(raw)>self.max_size:
            raise AppError('文件超过配置上限。',413)
        kind,mime,meta=inspect(raw,filename)
        if extra:meta.update(extra)
        meta['bytes']=len(raw)
        parents=parents or []
        for parent in parents:self.get(parent,project)
        sha=hashlib.sha256(raw).hexdigest();path=self.path(sha)
        path.parent.mkdir(exist_ok=True)
        if not path.exists():
            temp=path.with_name(uid('pending_'));temp.write_bytes(raw);os.replace(temp,path)
        name=re.sub(r'[\x00-\x1f/\\]', '_', filename)[-180:]
        record={'id':uid('a_'),'project':project,'sha':sha,'filename':name,'kind':kind,'mime':mime,
                'meta':meta,'provenance':provenance,'parents':parents,'created':time.time()}
        self.db.execute('INSERT INTO assets VALUES(?,?,?,?,?,?,?,?,?,?)',
                        (record['id'],project,sha,name,kind,mime,dumps(meta),provenance,dumps(parents),record['created']))
        return record

    def get(self, id:str, project:str|None=None):
        row=self.db.one('SELECT * FROM assets WHERE id=?',(id,))
        if not row or (project is not None and row['project']!=project):
            raise AppError('素材不存在或不属于当前项目。',404,'asset_not_found')
        row['meta']=json.loads(row['meta']);row['parents']=json.loads(row['parents'])
        return row

    def read(self,id:str,project:str|None=None):
        row=self.get(id,project);path=self.path(row['sha'])
        if not path.is_file():raise AppError('本地素材文件缺失，请恢复备份。',409,'asset_missing')
        data=path.read_bytes()
        if hashlib.sha256(data).hexdigest()!=row['sha']:
            raise AppError('素材校验失败，已阻止加载。',409,'asset_corrupted')
        return data

    def list(self,project):
        return [self.get(r['id'],project) for r in self.db.all('SELECT id FROM assets WHERE project=? ORDER BY created',(project,))]
