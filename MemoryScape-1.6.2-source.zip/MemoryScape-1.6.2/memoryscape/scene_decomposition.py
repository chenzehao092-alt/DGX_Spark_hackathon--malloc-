"""Multimodal evidence is scoped data, not verified physical measurements."""
from .errors import AppError


def validate_decomposition(plan,sources,required=True):
    manifest=plan.decomposition
    if manifest is None:
        if required and any(o.generation.strategy=='generate3d' for o in plan.scene.objects):
            raise AppError('请补充 decomposition：逐个主体的来源、原图可见事实、补全部分和完整组成；不能只给整场景提示词。')
        return plan
    if required and manifest.origin!='multimodal':raise AppError('新多模态规划不能冒充旧计划转换。')
    by={o.id:o for o in plan.scene.objects};source_by={s['id']:s for s in sources}
    if {e.object_id for e in manifest.objects}!=set(by):raise AppError('拆分清单必须与场景对象一一对应，不能遗漏或重复人物。')
    for entry in manifest.objects:
        obj=by[entry.object_id];g=obj.generation
        if any(s not in source_by for s in entry.source_ids):raise AppError('拆分证据引用了不存在的素材。')
        if g.primary_source and g.primary_source not in entry.source_ids:raise AppError('单件主参考必须出现在它的拆分来源清单。')
        if g.strategy=='generate3d' and not entry.required_parts:raise AppError('单件建模清单须明确完整组成部分。')
        if entry.crop:
            if not g.primary_source or source_by[g.primary_source]['kind']!='image':raise AppError('选区必须绑定实际图片来源。')
            if g.crop and g.crop!=entry.crop:raise AppError('拆分选区与下游实际裁剪不一致。')
            g.crop=entry.crop
    return plan


def object_constraints(payload,object_id):
    value=payload.get('decomposition') or {}
    entry=next((e for e in value.get('objects',[]) if e['object_id']==object_id),{})
    return {'object_evidence':entry,'shared_constraints':value.get('shared_constraints',[]),
            'scope':'observed/inferred are model-labelled evidence, not verified identity or depth'}
