"""Renderer-aligned bounding-box evidence, not inferred physical measurements.

Matches web/math.js objectMatrix: scale to bounds, anchor bottom centre, then
rotate intrinsic XYZ and translate. Rotated box bounds are conservative; they
do not prove detailed mesh contact, topology, collisions or source fidelity.
"""
from __future__ import annotations
import itertools
import math
from .errors import AppError
from .edit_tools import resized_transform


def object_evidence(obj, bounds=None):
    t=obj.transform
    extent=[max(.0001,bounds[1][i]-bounds[0][i]) for i in range(3)] if bounds else list(t.size)
    factors=[t.size[i]/extent[i] for i in range(3)]
    if t.fit=='uniform':factors=[min(factors)]*3
    display=[extent[i]*factors[i] for i in range(3)]
    x,y,z=[angle/2 for angle in t.rotation]
    c1,c2,c3=math.cos(x),math.cos(y),math.cos(z);s1,s2,s3=math.sin(x),math.sin(y),math.sin(z)
    qx,qy,qz,qw=(s1*c2*c3+c1*s2*s3,c1*s2*c3-s1*c2*s3,c1*c2*s3+s1*s2*c3,c1*c2*c3-s1*s2*s3)
    rotation=[[1-2*(qy*qy+qz*qz),2*(qx*qy-qw*qz),2*(qx*qz+qw*qy)],
              [2*(qx*qy+qw*qz),1-2*(qx*qx+qz*qz),2*(qy*qz-qw*qx)],
              [2*(qx*qz-qw*qy),2*(qy*qz+qw*qx),1-2*(qx*qx+qy*qy)]]
    corners=[]
    for a,b,c in itertools.product((-.5,.5),(0,1),(-.5,.5)):
        local=[a*display[0],b*display[1],c*display[2]]
        corners.append([t.position[i]+sum(rotation[i][j]*local[j] for j in range(3)) for i in range(3)])
    lo=[min(c[i] for c in corners) for i in range(3)];hi=[max(c[i] for c in corners) for i in range(3)]
    upright=abs(t.rotation[0])<1e-6 and abs(t.rotation[2])<1e-6
    return {'object_id':obj.id,'label':obj.label,'asset_id':obj.asset_id,
            'source':'validated_asset_bounds' if bounds else 'requested_dimensions_not_actual_mesh',
            'requested_size':list(t.size),'display_size':display,'anchor_position':list(t.position),
            'world_bounds':[lo,hi],'bottom_y':lo[1],'top_y':hi[1],'upright':upright,
            'floor_status':'below_floor' if lo[1]<-.02 else 'at_floor' if abs(lo[1])<=.02 else 'above_floor',
            'visual_fidelity_verified':False}


def scene_evidence(scene,assets,project):
    objects=[]
    for obj in scene.objects:
        bounds=assets.get(obj.asset_id,project)['meta'].get('bounds') if obj.asset_id else None
        objects.append(object_evidence(obj,bounds))
    by={o['object_id']:o for o in objects};supports=[]
    for relation in scene.relations:
        if relation.type!='on':continue
        subject,target=by[relation.subject],by[relation.target]
        gap=subject['bottom_y']-target['top_y']
        supports.append({'subject':relation.subject,'target':relation.target,'gap_y':gap,
                         'status':'box_contact' if abs(gap)<=.04 else 'box_gap' if gap>0 else 'box_penetration',
                         'exact_for_upright_bounds':subject['upright'] and target['upright'],
                         'source':'validated_asset_bounds' if subject['source']==target['source']=='validated_asset_bounds' else 'requested_dimensions_not_actual_mesh',
                         'detailed_mesh_contact_proven':False})
    return {'schema':'display-geometry-v1','coordinate_system':'+Y up; ground Y=0; intrinsic XYZ radians',
            'position_semantics':'bottom-centre anchor before rotation, NOT geometric centre',
            'unit':'display_units_not_measured_metres','objects':objects,'supports':supports,
            'limitation':'bounding boxes, not exact mesh contact/collision or physical measurements'}


def pose_candidate(scene,patch):
    """Read-only pose simulation for pre-proposal validation; no asset changes."""
    result=scene.model_copy(deep=True);by={o.id:o for o in result.objects}
    for op in patch.operations:
        if op.type=='transform' and op.object_id in by:by[op.object_id].transform=op.transform.model_copy(deep=True)
        elif op.type=='resize' and op.object_id in by:by[op.object_id].transform=resized_transform(by[op.object_id],op.size_edit)
    return result


def validate_review_geometry(before,after,assets,project):
    """A visual critic may not break an already valid upright floor/support
    contact. Explicit user edits retain their separate intent/permission gate.
    """
    old=scene_evidence(before,assets,project);new=scene_evidence(after,assets,project)
    by={o['object_id']:o for o in new['objects']};supported={r.subject for r in before.relations if r.type=='on'}
    old_objects={o.id:o for o in before.objects};after_objects={o.id:o for o in after.objects}
    touched={oid for oid in old_objects.keys()&after_objects.keys() if old_objects[oid].transform!=after_objects[oid].transform}
    for evidence in old['objects']:
        oid=evidence['object_id'];candidate=by.get(oid)
        if oid not in touched or candidate is None or old_objects[oid].kind=='background':continue
        if not (evidence['upright'] and candidate['upright']):continue  # Rotated AABB is only an approximation.
        if oid not in supported and evidence['floor_status']=='at_floor' and candidate['floor_status']!='at_floor':
            raise AppError(f'复核建议破坏已有落地约束：{evidence["label"]} 当前底部 Y={evidence["bottom_y"]:g}，'
                f'建议后 Y={candidate["bottom_y"]:g}。position 是底部中心，不是中心，不能减/加半个高度假定悬空。',409,'review_geometry_conflict')
        if evidence['floor_status']!='below_floor' and candidate['floor_status']=='below_floor':
            raise AppError('复核建议使物品穿入地面，未生成可采用建议。',409,'review_geometry_conflict')
    new_supports={(r['subject'],r['target']):r for r in new['supports']}
    for relation in old['supports']:
        key=(relation['subject'],relation['target']);candidate=new_supports.get(key)
        if candidate is None or not set(key)&touched:continue
        if relation['status']=='box_contact' and relation['exact_for_upright_bounds'] and candidate['exact_for_upright_bounds'] and candidate['status']!='box_contact':
            raise AppError('复核建议破坏已有支撑关系：'+relation['subject']+'；请保留当前实际包围盒接触高度，不能只移动支撑物而让上面的物品悬空或穿入。',409,'review_geometry_conflict')
    return new
