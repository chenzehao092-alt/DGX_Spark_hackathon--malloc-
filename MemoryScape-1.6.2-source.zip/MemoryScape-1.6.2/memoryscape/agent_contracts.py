"""Grounded edit contracts: model suggestions cannot expand their own authority.

The server compiles effects from typed operations, verifies local results, and
freezes that candidate as the preservation baseline for asynchronous production.
These are semantic/structural checks, not a promise of visual fidelity.
"""
from __future__ import annotations
import re
from .db import digest
from .errors import AppError
from .memory import aliases, validate_edit_intent
from .schemas import Scene, Patch


def target_scope(prompt, objects, selected=None):
    # Longest non-overlapping names win: 海报边框 must not also select 海报.
    text=prompt.lower(); matches={}
    for obj in objects:
        for name in aliases(obj):
            pattern=re.escape(name)
            if re.fullmatch(r'[a-z0-9_\-]+',name):pattern=r'(?<![a-z0-9_\-])'+pattern+r'(?![a-z0-9_\-])'
            for match in re.finditer(pattern,text):
                matches.setdefault((match.start(),match.end()),set()).add(obj['id'])
    occupied=set(); targets=set(); ambiguous=False
    for (start,end),ids in sorted(matches.items(),key=lambda pair:pair[0][1]-pair[0][0],reverse=True):
        positions=set(range(start,end))
        if occupied & positions:continue
        occupied.update(positions);targets.update(ids);ambiguous|=len(ids)>1
    global_scope=bool(re.search(r'所有|全部|整体|全景|整个场景|布局|检查画面|检查场景|\ball\b|\bscene\b',text))
    if not targets and selected and not global_scope:targets={selected}
    return {'object_ids':sorted(targets),'needs_clarification':ambiguous and not global_scope,
            'scope':'whole_scene' if global_scope else 'named_or_selected' if targets else 'unspecified'}


def compile_contract(patch:Patch, memory):
    validate_edit_intent(patch,memory)
    scope=target_scope(memory.get('current_request',''),memory['objects'],memory.get('selected_object'))
    # Restore IDs can be absent from today's catalogue; immutable history is
    # resolved independently by the existing restoration validator.
    allowed=set(scope['object_ids'])|set(memory.get('restore_intent',{}).get('required',{}))
    targets={op.object_id for op in patch.operations if op.object_id}
    if scope['needs_clarification'] and patch.operations:
        raise AppError('物品名称对应多个对象，请明确目标，未猜测或执行。',409,'task_scope_ambiguous')
    existing={o['id'] for o in memory['objects']}
    if allowed and scope['scope']!='whole_scene' and (targets & existing)-allowed:
        raise AppError('本次操作超出明确指定的物品范围；不能用修改另一物品代替。',409,'task_scope_violation')
    return {'schema':'task-spec-v1','base_version':patch.base_version,'request':memory.get('current_request',''),
            'scope':scope,'target_ids':sorted(targets),'operations':[op.type for op in patch.operations],
            'preserve_object_ids':sorted(existing-targets),'approval_required':True,
            'postconditions':['typed_operation_effects_only','preserve_unrelated_state','locked_objects_unchanged'],
            'quality_policy':'advisory-not-visual-fidelity-proof'}


def _leaves(value, prefix=''):
    if isinstance(value,dict):
        out={}
        for key,item in value.items():out.update(_leaves(item,prefix+'.'+key if prefix else key))
        return out
    # Vectors/lists are indivisible here; exact axis contracts are additionally
    # enforced by resized_transform + validate_edit_intent.
    return {prefix:value}


def _differences(before,after):
    a,b=_leaves(before),_leaves(after)
    missing=object()
    return sorted(key for key in a.keys()|b.keys() if a.get(key,missing)!=b.get(key,missing))


def verify_local_effects(before:Scene,after:Scene,patch:Patch):
    old={o.id:o.model_dump() for o in before.objects};new={o.id:o.model_dump() for o in after.objects}
    effects={};removed=set();added=set();restored=set();audio={}
    expected={o.id:o.model_copy(deep=True) for o in before.objects};expected_values={}
    from .edit_tools import resized_transform
    fields={'transform':{'transform'},'resize':{'transform.size','transform.fit'},'tint':{'tint'},
            'clear_tint':{'tint'},'lock':{'locked'},'caption':{'caption'},'bind_frame':{'generation.frame_target'},
            'regenerate':{'generation.image_prompt','generation.image_mode','generation.options.seed','status'}}
    for op in patch.operations:
        if op.type=='remove':removed.add(op.object_id)
        elif op.type=='add':added.add(op.object_id)
        elif op.type=='restore_object':restored.add(op.object_id)
        elif op.type=='audio':audio.setdefault(op.audio_id,set()).update(k for k in ('gain','start') if getattr(op,k) is not None)
        else:
            effects.setdefault(op.object_id,set()).update(fields[op.type])
            obj=expected.get(op.object_id)
            if obj is None:continue  # Normal executor rejects missing operands.
            if op.type=='transform':obj.transform=op.transform.model_copy(deep=True)
            elif op.type=='resize':obj.transform=resized_transform(obj,op.size_edit)
            elif op.type=='tint':obj.tint=op.color
            elif op.type=='clear_tint':obj.tint=None
            elif op.type=='lock':obj.locked=op.locked
            elif op.type=='caption':obj.caption=op.caption
            elif op.type=='bind_frame':obj.generation.frame_target=op.target_id
            elif op.type=='regenerate':
                if op.prompt:obj.generation.image_prompt=op.prompt
                if op.prompt and obj.generation.strategy=='generate3d':obj.generation.image_mode='edit'
                obj.generation.options.seed=(obj.generation.options.seed+1)%(2**31);obj.status='planned'
            expected_values[op.object_id]=obj.model_dump()
    if old.keys()-new.keys()!=removed or new.keys()-old.keys()!=added|(restored-old.keys()):
        raise AppError('对象增删结果与确认的操作不一致，已保留当前版本。',409,'task_postcondition_failed')
    touched=removed|added|restored|set(effects)
    observed=[]
    for oid in old.keys() & new.keys():
        paths=_differences(old[oid],new[oid]);allowed=effects.get(oid,set()).copy()
        frame_target=new[oid]['generation'].get('frame_target')
        if frame_target in touched or 'generation.frame_target' in allowed:allowed.add('transform')
        if old[oid]['generation'].get('frame_target') in removed:allowed.add('generation.frame_target')
        if oid in restored:allowed={''}
        if old[oid]['locked'] and any(op.object_id==oid and op.type!='lock' for op in patch.operations):
            raise AppError('锁定对象不能由任务合约绕过。',409,'object_locked')
        if any(not any(path==a or path.startswith(a+'.') or a=='' for a in allowed) for path in paths):
            raise AppError('执行结果改变了未授权字段：'+oid+'；当前版本不变。',409,'task_postcondition_failed')
        if oid in expected_values:
            wanted=_leaves(expected_values[oid]);actual=_leaves(new[oid])
            for key in wanted:
                # Bound frame pose is derived from the target's actual extent.
                if key.startswith('transform.') and new[oid]['generation'].get('frame_target'):continue
                if any(key==field or key.startswith(field+'.') for field in effects.get(oid,set())) and actual.get(key)!=wanted[key]:
                    raise AppError('指定操作的实际字段值不符合确认结果：'+oid+'；当前版本不变。',409,'task_postcondition_failed')
        if paths:observed.append({'object_id':oid,'changed_fields':paths})
    a,b=before.model_dump(),after.model_dump()
    for key in a.keys()-{'objects','relations','audio'}:
        if a[key]!=b[key]:raise AppError('局部编辑不允许改写场景全局事实。',409,'task_postcondition_failed')
    # Relation cleanup/offset reconciliation is allowed only incident to a
    # touched object; unrelated relation and audio records remain identical.
    untouched=lambda r:r['subject'] not in touched and r['target'] not in touched
    if [r for r in a['relations'] if untouched(r)]!=[r for r in b['relations'] if untouched(r)]:
        raise AppError('未指定的空间关系被改变。',409,'task_postcondition_failed')
    old_audio={t['id']:t for t in a['audio']};new_audio={t['id']:t for t in b['audio']}
    if old_audio.keys()!=new_audio.keys():raise AppError('局部编辑不能增删未授权音轨。',409,'task_postcondition_failed')
    for tid,track in old_audio.items():
        allowed=audio.get(tid,set()).copy()
        if track.get('anchor') in removed:allowed.add('anchor')
        if set(_differences(track,new_audio[tid]))-allowed:
            raise AppError('未指定的音频内容被改变。',409,'task_postcondition_failed')
        for op in patch.operations:
            if op.type=='audio' and op.audio_id==tid:
                for key in ('gain','start'):
                    value=getattr(op,key)
                    # Last explicit setting for this field is authoritative.
                    settings=[getattr(v,key) for v in patch.operations if v.type=='audio' and v.audio_id==tid and getattr(v,key) is not None]
                    if value is not None and new_audio[tid][key]!=settings[-1]:raise AppError('音频参数与确认操作不一致。',409,'task_postcondition_failed')
    return {'schema':'execution-observation-v1','verified':True,'changed_objects':observed,
            'removed_ids':sorted(removed),'added_ids':sorted(added),'restored_ids':sorted(restored),
            'unchanged_ids':sorted(oid for oid in old.keys()&new.keys() if old[oid]==new[oid]),
            'before_sha256':digest(a),'candidate_sha256':digest(b),'visual_quality_verified':False}


def verify_build_preservation(before:Scene,after:Scene,targets):
    old={o.id:o.model_dump() for o in before.objects};new={o.id:o.model_dump() for o in after.objects}
    if old.keys()!=new.keys():raise AppError('制作不能改变已确认的对象清单。',409,'task_postcondition_failed')
    affected=set(targets)
    for _ in old:
        for r in before.relations:
            if r.target in affected:affected.add(r.subject)
        for oid,o in old.items():
            if o['generation'].get('frame_target') in affected:affected.add(oid)
    observed=[]
    for oid in old:
        paths=_differences(old[oid],new[oid]);allowed=set()
        if oid in affected and any(r.subject==oid for r in before.relations):allowed.add('transform.position')
        if oid in affected and old[oid]['generation'].get('frame_target'):allowed.add('transform')
        if oid in targets:allowed|={'asset_id','reference_asset_id','status','provenance','transform.size'}
        if old[oid]['locked']:allowed=set()
        if any(not any(path==a or path.startswith(a+'.') for a in allowed) for path in paths):
            raise AppError('制作改变了未授权对象或字段：'+oid+'；只保留候选产物。',409,'task_postcondition_failed')
        if paths:observed.append({'object_id':oid,'changed_fields':paths})
    a,b=before.model_dump(),after.model_dump()
    if any(a[key]!=b[key] for key in a.keys()-{'objects'}):
        raise AppError('制作不能改写已确认的关系、音频和全局事实。',409,'task_postcondition_failed')
    return {'schema':'execution-observation-v1','verified':True,'changed_objects':observed,
            'unchanged_ids':sorted(oid for oid in old if old[oid]==new[oid]),'visual_quality_verified':False}
