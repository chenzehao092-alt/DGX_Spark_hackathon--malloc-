"""Deterministic procedural assets used when explicitly planned, never claimed as model inference."""
from __future__ import annotations
import io
import math
import numpy as np
import trimesh
from PIL import Image,ImageDraw


def rgb(hexcolor):
    return [int(hexcolor[i:i+2],16) for i in (1,3,5)] + [255]


def procedural_glb(kind:str,color='#d7ad70',caption='') -> bytes:
    scene=trimesh.Scene()
    def add(mesh,pos=(0,0,0),col=color,name=None,rot=None):
        if rot is not None:mesh.apply_transform(rot)
        mesh.apply_translation(pos)
        mesh.visual=trimesh.visual.ColorVisuals(mesh=mesh,face_colors=rgb(col))
        scene.add_geometry(mesh,node_name=name or f'part_{len(scene.geometry)}')
    def box(s,p,col=color):add(trimesh.creation.box(extents=s),p,col)
    def sphere(r,p,col=color,scale=(1,1,1),sub=2):
        m=trimesh.creation.icosphere(subdivisions=sub,radius=r);m.apply_scale(scale);add(m,p,col)
    def cyl(r,h,p,col=color,n=32):
        m=trimesh.creation.cylinder(radius=r,height=h,sections=n)
        m.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]));add(m,p,col)
    if kind=='frame':
        # Four real solid bars, open centre. Normalised bounds are 1x1x1;
        # stretch to the requested width/height/depth. Never cover the photo
        # with a solid box or claim this local geometry is model inference.
        box([.04,1,1],[-.48,.5,0]);box([.04,1,1],[.48,.5,0])
        box([.92,.025,1],[0,.0125,0]);box([.92,.025,1],[0,.9875,0])
    elif kind=='table':
        box([3.4,.17,1.85],[0,1.04,0],color)
        box([3.5,.05,1.92],[0,1.145,0],'#f7ead8')
        for x in (-1.43,1.43):
            for z in (-.7,.7):box([.13,1,.13],[x,.50,z],'#967358')
    elif kind=='cake':
        cyl(.52,.04,[0,.02,0],'#e8c889');cyl(.46,.38,[0,.23,0],color)
        cyl(.465,.06,[0,.43,0],'#fff3df');cyl(.31,.24,[0,.58,0],color)
        cyl(.315,.035,[0,.71,0],'#fff3df')
        for t in range(12):
            a=t*math.tau/12;sphere(.05,[math.cos(a)*.40,.48,math.sin(a)*.40],'#f0b2ae',sub=1)
        for x in (-.09,.09):
            cyl(.02,.22,[x,.82,0],'#c6af7d',12)
            sphere(.045,[x,.967,0],'#ffd483',scale=(.6,1.5,.6),sub=1)
        for a in (0,2.1,4.2):sphere(.065,[.22*math.cos(a),.755,.22*math.sin(a)],'#ba6466',sub=1)
    elif kind=='person':
        # All demo persons are invented low-poly mannequins, not reconstructed people.
        skin='#e7bba0';hair='#423831';pants='#485c68'
        for x in (-.13,.13):
            cyl(.09,.60,[x,.36,0],pants,12)
            box([.18,.11,.32],[x,.07,.055],'#f5ece0')
        sphere(.29,[0,1.01,0],color,scale=(1,1.3,.65))
        for x in (-.34,.34):
            cyl(.072,.52,[x,.92,0],color,12);sphere(.074,[x,.635,0],skin,sub=1)
        cyl(.085,.15,[0,1.39,0],skin,12)
        sphere(.235,[0,1.64,0],skin,scale=(.92,1.1,.95))
        sphere(.23,[0,1.75,-.03],hair,scale=(1,.69,1))
        for x in (-.078,.078):sphere(.017,[x,1.68,.212],'#39343a',sub=1)
        if caption:
            cone=trimesh.creation.cone(radius=.23,height=.39,sections=24)
            cone.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]));add(cone,[0,1.89,0],'#d5b97d')
            sphere(.047,[0,2.28,0],'#f4dcc1',sub=1)
    elif kind=='balloon':
        sphere(.42,[0,1.47,0],color,scale=(1,1.18,1))
        cyl(.007,1.05,[0,.53,0],'#b8a587',8)
        sphere(.035,[0,1.04,0],color,scale=(1,1.6,1),sub=1)
    elif kind=='chair':
        box([.85,.12,.85],[0,.58,0]);box([.85,.8,.12],[0,1,-.38])
        for x in (-.33,.33):
            for z in (-.33,.33):box([.09,.54,.09],[x,.27,z],'#9c7960')
    elif kind=='hat':
        m=trimesh.creation.cone(radius=.35,height=.7,sections=32)
        m.apply_transform(trimesh.transformations.rotation_matrix(-math.pi/2,[1,0,0]));add(m,[0,0,0])
    elif kind=='sphere':sphere(.5,[0,.5,0])
    elif kind=='cylinder':cyl(.5,1,[0,.5,0])
    elif kind in ('plane','text'):
        box([1,.012,1],[0,.006,0])
    elif kind=='box':box([1,1,1],[0,.5,0])
    else:raise ValueError('Unsupported procedural primitive: '+kind)
    return scene.export(file_type='glb')


def photo_glb(raw:bytes) -> bytes:
    with Image.open(io.BytesIO(raw)) as src:
        im=src.convert('RGBA');im.thumbnail((1536,1536));w=im.width/im.height
        mesh=trimesh.Trimesh(vertices=[[-w/2,0,0],[w/2,0,0],[w/2,1,0],[-w/2,1,0]],faces=[[0,1,2],[0,2,3]],process=False)
        mat=trimesh.visual.material.PBRMaterial(baseColorTexture=im,metallicFactor=0,roughnessFactor=1,doubleSided=True)
        mesh.visual=trimesh.visual.TextureVisuals(uv=[[0,0],[1,0],[1,1],[0,1]],material=mat)
        return trimesh.Scene(mesh).export(file_type='glb')
