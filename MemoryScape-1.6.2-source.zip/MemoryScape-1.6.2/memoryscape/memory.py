"""Grounded, version-aware edit memory. History is evidence, not instructions.

The small (<=32 objects) scene is the authoritative semantic state. Bounded
episodic retrieval uses entity links and lexical relevance, without an extra
embedding service or sending private material to another vendor.
"""
from __future__ import annotations
import json
import re


def terms(text):
    text=str(text).lower()
    values=set(re.findall(r'[a-z0-9_]+',text))
    for run in re.findall(r'[\u4e00-\u9fff]+',text):
        values.update(run[i:i+2] for i in range(len(run)-1))
    return values


def aliases(obj):
    names={obj['id'].lower(),obj['label'].lower()}
    label=obj['label']
    if any(w in label for w in ('底座','支座','托座')):
        names.update(('底座','支座','托座'))
    if obj['generation'].get('primitive')=='frame':names.update(('边框','框框','相框'))
    if obj['generation'].get('strategy')=='photo' and '海报' in label:names.add('海报')
    if '宠物' in label:names.add('宠物')
    return {n for n in names if n}


def historical_deletion_words(prompt):
    """Past-deletion evidence is not a new command to delete an object."""
    prompt=re.sub(r'(?:删除|删掉|移除|去掉)(?:前|之前|以前)(?=的|原|[，,。；;]|$)','历史',prompt)
    return re.sub(r'(?:刚才|刚刚|之前|以前|上次|已经|已)(?:删除|删掉|移除|去掉)(?:了)?(?=的|过的)','历史',prompt)


def deletion_intent(prompt,objects,selected=None):
    """Recognize only explicit whole-object deletion; never guess subparts.

    Complex requests remain the director's task, with deletion postconditions
    for any unambiguous clauses. Negations/questions do not authorize deletion.
    """
    # Temporal evidence in a recovery request is not a fresh deletion verb.
    # Keep actual subsequent clauses ("恢复底座，然后删除海报") intact.
    if re.search(r'恢复|还原|加回|找回|放回来|\brestore\b',prompt,re.I):
        prompt=historical_deletion_words(prompt)
    result={'required_remove_ids':[],'remove_authorized':False,
            'delete_only':False,'needs_clarification':False,'candidate_ids':[]}
    if not re.search(r'删除|删掉|移除|去掉|remove\b|delete\b',prompt,re.I):return result
    clauses=re.split(r'[，,。；;\n]|并且|然后|并(?=把|将|移动|调整|保留)',prompt)
    ids=set();candidates=set();deletions=0;other_action=False
    for clause in clauses:
        match=re.search(r'删除|删掉|移除|去掉|remove\b|delete\b',clause,re.I)
        if not match:
            if clause.strip() and not re.search(r'保留|保持|不动|不变',clause):other_action=True
            continue
        if re.search(r'不要|不能|别|不许|不准|不删除|不移除|是否|能否|可以.*吗|[?？]',clause):
            continue
        # "把底座删除" and "删除底座" are both supported.
        noun=clause[:match.start()]+clause[match.end():]
        # Removing bumps, lettering or a hat is an appearance/part edit, not
        # authorization to delete the complete ball, photo or person. Leave
        # supported reference-image editing to the capability validator.
        if re.search(r'凹凸|皱纹|划痕|背景|上的|里面的|背面|正面|反面|的文字|的帽子',noun):
            other_action=True
            continue
        noun=re.sub(r'请|帮我|给我|我要|我想|把|将|这个|那个|这件|那件|选中的|选中|刚才|刚刚|之前|上次|下面|下方|底下|一下|吧|掉|仅|只|的|[\s.!！]','',noun).lower()
        hits=[o['id'] for o in objects if noun in aliases(o)]
        if not noun and selected in {o['id'] for o in objects}:hits=[selected]
        if not hits and noun in ('它','这','那') and selected in {o['id'] for o in objects}:hits=[selected]
        deletions+=1;candidates.update(hits)
        if len(hits)==1:ids.update(hits)
        else:result['needs_clarification']=True
    result.update(required_remove_ids=sorted(ids),candidate_ids=sorted(candidates),
                  remove_authorized=bool(deletions),delete_only=bool(deletions and not other_action))
    return result


def validate_edit_intent(patch,memory):
    from .errors import ProviderError
    appearance=memory.get('appearance_intent',{})
    if appearance.get('authorized'):
        oid=appearance.get('target_id')
        if appearance.get('needs_clarification') or oid in memory['locked_objects']:
            if patch.operations:raise ProviderError('恢复配色的目标不明确或已锁定；请询问，不替换成重生成或移动。')
            return
        obj=next(o for o in memory['objects'] if o['id']==oid)
        clears=[op for op in patch.operations if op.type=='clear_tint' and op.object_id==oid]
        if obj.get('tint') is None:
            if patch.operations and appearance.get('appearance_only'):raise ProviderError('当前物品没有整体染色；不能声称清除染色或偷偷重新生成。')
        elif len(clears)!=1 or (appearance.get('appearance_only') and len(patch.operations)!=1):
            raise ProviderError('本轮恢复已有配色必须仅使用 clear_tint 移除 '+oid+' 的整体染色，保留网格、位置、尺寸与其他物品；不能以 regenerate/tint/历史整对象恢复代替。')
    restore=memory.get('restore_intent',{})
    restored=[op for op in patch.operations if op.type=='restore_object']
    if restored and not restore.get('authorized'):
        raise ProviderError('本轮未授权恢复历史对象；不得根据旧请求执行恢复。')
    if restore.get('authorized'):
        if restore.get('needs_clarification'):
            if patch.operations:raise ProviderError('历史恢复目标或版本不明确。请返回空操作并询问，不能猜测尺寸或新增替代品。')
            return
        required=restore.get('required',{})
        if set(required)&set(memory['locked_objects']):
            if patch.operations:raise ProviderError('恢复目标已锁定；请先显式解锁，不能改变其他物品替代。')
            return
        actual={op.object_id:op.source_version for op in restored}
        if actual!=required or len(restored)!=len(required):
            raise ProviderError('恢复必须使用 restore_object 与历史证据中的 ID/版本 '+json.dumps(required,ensure_ascii=False)+'；不能 add 新底座、transform 猜尺寸或遗漏恢复。')
        if restore.get('restore_only') and len(restored)!=len(patch.operations):
            raise ProviderError('本轮仅恢复指定对象，不能同时移动海报、改色或重建其他物品。')
    validate_dimension_intent(patch,memory)
    intent=memory.get('edit_intent',{})
    query=memory.get('current_request','')
    if re.search(r'背景|背面|正面|反面',query) and re.search(r'颜色|色|配色',query) and any(op.type=='tint' for op in patch.operations):
        raise ProviderError('本轮要求背景或某一面的颜色；tint 是整个对象的配色，不能替换成底座/边框改色或整个海报染色。未支持时返回空操作并如实说明。')
    removed={op.object_id for op in patch.operations if op.type=='remove'}
    required=set(intent.get('required_remove_ids',[]))
    if removed and not intent.get('remove_authorized'):
        raise ProviderError('本轮没有明确授权删除独立对象；不得根据旧历史或否定句删除。')
    if intent.get('needs_clarification'):
        if patch.operations:raise ProviderError('删除目标不明确或不是独立对象。返回空操作并询问目标，不能替代删除为移动/改色。')
        return
    if intent.get('delete_only') and required:
        if required & set(memory['locked_objects']):
            if patch.operations:raise ProviderError('要删除的对象已锁定；返回空操作并请求先显式解锁，不能移动其他对象代替。')
            return
        if removed!=required or any(op.type!='remove' for op in patch.operations):
            raise ProviderError('本轮仅要求删除 '+', '.join(sorted(required))+'；必须只返回这些对象的 remove。不能以移动海报、绑定边框或改色代替删除。')
    elif required and not required.issubset(removed) and patch.operations:
        raise ProviderError('本轮明确要求删除 '+', '.join(sorted(required))+'，不能只执行其他修改而漏掉删除。')


def historical_objects(db,project,current,query):
    """Latest pre-deletion snapshots, even after a bad replacement is added.

    Versions, not an assistant's claims, are the only source of truth. Scan
    at most 201 versions; arbitrary earlier versions require an explicit ID.
    """
    from .schemas import Scene
    rows=db.all('SELECT version,scene FROM versions WHERE project=? AND version<=? ORDER BY version DESC LIMIT 201',(project,current))
    scenes={r['version']:Scene.model_validate(json.loads(r['scene'])).model_dump() for r in rows}
    found={}
    for r in rows:
        before=scenes.get(r['version']-1)
        if before is None:continue
        present={o['id'] for o in scenes[r['version']]['objects']}
        for obj in before['objects']:
            if obj['id'] not in present and obj['id'] not in found:
                found[obj['id']]={'object_id':obj['id'],'source_version':r['version']-1,
                    'removed_at_version':r['version'],'object':obj,
                    'relations':[v for v in before['relations'] if obj['id'] in (v['subject'],v['target'])]}
    explicit=re.search(r'(?:版本\s*(\d+)|第\s*(\d+)\s*版)',query)
    if explicit:
        version=int(explicit.group(1) or explicit.group(2))
        row=db.one('SELECT scene FROM versions WHERE project=? AND version=? AND version<?',(project,version,current))
        found={}
        if row:
            snapshot=Scene.model_validate(json.loads(row['scene'])).model_dump()
            for obj in snapshot['objects']:
                found[obj['id']]={'object_id':obj['id'],'source_version':version,'removed_at_version':None,
                    'object':obj,'relations':[r for r in snapshot['relations'] if obj['id'] in (r['subject'],r['target'])]}
    values=list(found.values())
    matches=[v for v in values if any(name in query.lower() for name in aliases(v['object']))]
    return (matches or values)[:32]


def active_clauses(prompt):
    """Names in preservation clauses are not additional modification targets."""
    clauses=re.split(r'[，,。；;\n]',prompt)
    return '，'.join(c for c in clauses if not re.search(r'保持|保留|不变|不动',c)
                    or re.search(r'恢复|还原|加回|找回|放回来|(?:宽|高|深)(?:度)?\s*(?:改|设|调整|增加|减少|到|=|\d)',c))


def restoration_intent(prompt,snapshots,selected=None):
    restore_verb=r'加回来|加回|放回来|找回|恢复|还原|\brestore\b'
    trigger=re.search(restore_verb,prompt,re.I)
    result={'authorized':False,'required':{},'needs_clarification':False,'restore_only':False}
    if not trigger or re.search(r'是否|能否|[?？]|可以.*吗',prompt):return result
    prompt=historical_deletion_words(prompt)
    # A preservation constraint such as "不要重新计算大小" must not veto
    # "恢复底座". Negation is scoped to its own restoration clause; a
    # conflicting explicit negative restoration still vetoes the request.
    negative=r'不要|别|不许|不能|不准|不恢复|不还原|do not|don\x27t|must not|cannot|never'
    clauses=[c.strip() for c in re.split(r'[，,。；;\n]|然后|并且|同时|并(?=把|将|恢复|还原|加回|找回|放回来)|(?=不要|别|不许|不能|不准)',prompt) if c.strip()]
    recovery=[]
    for clause in clauses:
        verbs=list(re.finditer(restore_verb,clause,re.I))
        if not verbs:continue
        if any(re.search(negative,clause[:v.start()],re.I) for v in verbs):return result
        recovery.append(clause)
    if not recovery:return result
    result['authorized']=True
    # Subpart recovery requires a supported modelling tool, not replacing the
    # whole photographed person/poster with a historical object.
    action='，'.join(recovery)
    if re.search(r'上的|的帽子|的文字|背面|正面|局部',action):
        result['needs_clarification']=True;return result
    hits=[s for s in snapshots if any(re.search(r'(?<![a-z0-9_])'+re.escape(n)+r'(?![a-z0-9_])',action.lower()) if n.isascii() else n in action
                                     for n in aliases(s['object']))]
    if not hits and re.search(r'它|这个|这件|选中',prompt):hits=[s for s in snapshots if s['object_id']==selected]
    # Multiple explicit objects are not guessed from a shared alias.
    if len(hits)!=1:result['needs_clarification']=True;return result
    result['required']={hits[0]['object_id']:hits[0]['source_version']}
    other_actions='，'.join(c for c in clauses if not re.search(negative,c,re.I) and not re.search(r'保持|保留|不变|不动',c))
    result['restore_only']=not re.search(r'再(?:把|将|调整|改变)|改为|改成|放大|缩小|增加|减少|删除|删掉|移除|移动|旋转|转动',other_actions)
    return result


def appearance_intent(prompt,objects,selected=None):
    """Recognize original-colour recovery, not arbitrary regional recolouring.

    Only the overlay can be removed deterministically. Embedded colours are
    the current asset's evidence, not proof of pixel-perfect source recovery.
    """
    result={'authorized':False}
    if re.search(r'尺寸|大小|形状|网格|删除前|加回|找回|放回来',prompt):return result
    reset=bool(re.search(r'(恢复|还原).*(原|最初|最开始).*(配色|颜色)|取消.*整体染色|清除.*整体染色',prompt))
    reset=reset or bool(re.search(r'参考|按照|按',prompt) and re.search(r'最开始|最初|原图|原始.*(?:图片|照片)',prompt) and re.search(r'颜色|配色|涂色',prompt))
    if re.search(r'(?:改成|改为|设为|涂成).*(?:红|蓝|绿|黄|白|黑|紫)',prompt):return result
    if not reset or re.search(r'不要恢复|不要还原|不恢复|不还原|别恢复|别还原|是否|能否|[?？]',prompt):return result
    result.update(authorized=True,needs_clarification=True,appearance_only=not bool(re.search(r'移动|旋转|放大|缩小|新增|删除|加回|尺寸|宽度|高度|深度',active_clauses(prompt))))
    if re.search(r'背景|背面|正面|反面|局部|的帽子|的文字',prompt):return result
    action=active_clauses(prompt)
    hits=[o for o in objects if any(re.search(r'(?<![a-z0-9_])'+re.escape(n)+r'(?![a-z0-9_])',action.lower()) if n.isascii() else n in action for n in aliases(o))]
    named=re.search(r'(?:恢复|还原|取消|清除)(.+?)(?:原|最初|最开始|整体染色)',action)
    if not hits and named and re.sub(r'它|这个|这件|选中的|选中|的|到|\s','',named.group(1)):
        return result  # An explicit unknown noun must not become the selected pet.
    if not hits and selected:hits=[o for o in objects if o['id']==selected]
    generic=bool(re.match(r'^(?:请|帮我|给我)?(?:恢复|还原)(?:到)?(?:原|最初|最开始)|^(?:取消|清除)整体染色|^不是(?:全部|全).*?(?:参考|按照|按).*(?:图片|照片|原图).*(?:颜色|配色)',action.strip()))
    if not hits and generic:hits=[o for o in objects if o.get('tint') is not None]
    if len(hits)==1:result.update(target_id=hits[0]['id'],needs_clarification=False)
    return result


def dimension_intent(prompt,objects,selected=None):
    """A narrow exact numeric contract; broader language stays with the LLM."""
    if re.search(r'不要|别|不许|不能|是否|能否|[?？]|可以.*吗',prompt):return {}
    values={};axes={'宽':0,'高':1,'深':2}
    for match in re.finditer(r'(宽|高|深)(?:度)?\s*(?:改为|改成|设为|设置为|调整为|变为|为|是|=|到)?\s*(\d+(?:\.\d+)?)\s*(厘米|cm|毫米|mm|米|m)?',prompt,re.I):
        value=float(match.group(2));unit=(match.group(3) or '').lower()
        values[axes[match.group(1)]]=value*(.01 if unit in ('厘米','cm') else .001 if unit in ('毫米','mm') else 1)
    for match in re.finditer(r'(宽|高|深)(?:度)?\s*(增加|减少)\s*(\d+(?:\.\d+)?)\s*%',prompt):
        values[axes[match.group(1)]]=('relative',1+float(match.group(3))/100*(1 if match.group(2)=='增加' else -1))
    if not values:return {}
    action=active_clauses(prompt)
    hits=[o for o in objects if any(re.search(r'(?<![a-z0-9_])'+re.escape(n)+r'(?![a-z0-9_])',action.lower()) if n.isascii() else n in action for n in aliases(o))]
    if not hits:hits=[o for o in objects if o['id']==selected]
    if len(hits)!=1:return {'needs_clarification':True}
    obj=hits[0]
    values={i:obj['transform']['size'][i]*v[1] if isinstance(v,tuple) else v for i,v in values.items()}
    return {'target_id':obj['id'],'values':values,'size_only':not re.search(r'移动|旋转|转动|位置|摆放|改色|颜色|删除|新增|恢复|加回|紧贴|贴合|悬空|落地|地面',action),
            'needs_clarification':False}


def validate_dimension_intent(patch,memory):
    from .errors import ProviderError
    from .schemas import SceneObject
    from .edit_tools import resized_transform
    intent=memory.get('dimension_intent',{})
    if not intent:return
    if intent.get('needs_clarification'):
        if patch.operations:raise ProviderError('数值尺寸的目标不明确，先询问具体物品，不依据选中状态猜测多个同名物品。')
        return
    oid=intent['target_id'];obj=next(o for o in memory['objects'] if o['id']==oid)
    if oid in memory['locked_objects']:
        if patch.operations:raise ProviderError('尺寸目标已锁定，请先解锁。')
        return
    edits=[op for op in patch.operations if op.object_id==oid and op.type in ('resize','transform')]
    if len(edits)!=1:raise ProviderError('必须准确修改 '+oid+' 的指定尺寸，不得换成其他对象、改色或空操作。')
    op=edits[0];t=op.transform if op.type=='transform' else resized_transform(SceneObject.model_validate(obj),op.size_edit)
    for i,v in intent['values'].items():
        if abs(t.size[int(i)]-v)>1e-6:raise ProviderError(f'尺寸约束不符：{oid} size[{i}] 必须为 {v:g}，不是 {t.size[int(i)]:g}。')
    if intent['size_only']:
        if len(patch.operations)!=1:raise ProviderError('本轮仅改尺寸，不能同时修改其他物品。')
        if t.position!=obj['transform']['position'] or t.rotation!=obj['transform']['rotation']:
            raise ProviderError('本轮仅改尺寸，必须保留位置和旋转。')
        if any(abs(t.size[i]-obj['transform']['size'][i])>1e-6 for i in range(3) if i not in intent['values']):
            raise ProviderError('未指定的尺寸轴必须保持原值。若需照片等比例放大，请先说明比例要求，不能偷偷改变其他轴。')


def scene_delta(before,after):
    from .schemas import Scene
    before=Scene.model_validate(before).model_dump();after=Scene.model_validate(after).model_dump()
    old={o['id']:o for o in before['objects']};new={o['id']:o for o in after['objects']}
    changes=[]
    for oid in sorted(old.keys()|new.keys()):
        if oid not in new:changes.append({'object_id':oid,'label':old[oid]['label'],'action':'removed'})
        elif oid not in old:changes.append({'object_id':oid,'label':new[oid]['label'],'action':'added'})
        else:
            fields=[k for k in ('transform','tint','caption','locked','asset_id','generation') if old[oid].get(k)!=new[oid].get(k)]
            if fields:changes.append({'object_id':oid,'label':new[oid]['label'],'action':'changed','fields':fields})
    return changes


def retrieve_episodes(db,project,current,query='',focus=(),exclude_job=None):
    # Explicit bounded scan, separate from the UI's legacy recent-decision log.
    versions=db.all('SELECT version,scene,note,created FROM versions WHERE project=? AND version<=? ORDER BY version DESC LIMIT 201',(project,current))
    by_version={v['version']:v for v in versions};episodes=[]
    restores=db.all('SELECT body,created FROM memories WHERE project=? AND kind="restore" ORDER BY id DESC LIMIT 200',(project,))
    for v in versions:
        before=by_version.get(v['version']-1)
        if not before:continue
        changes=scene_delta(json.loads(before['scene']),json.loads(v['scene']))
        if not changes:continue
        # Never turn a model-written version note into a verified fact.
        episodes.append({'kind':'version_evidence','version':v['version'],'created':v['created'],
                         'verified_changes':changes,'historical_only':v['version']!=current,
                         'superseded_by_restore':any(r['created']>v['created'] for r in restores)})
    jobs=db.all('SELECT id,payload,result,status,created FROM jobs WHERE project=? AND kind="edit" ORDER BY created DESC LIMIT 200',(project,))
    proposal_rows=db.all('SELECT id,status FROM proposals WHERE project=? ORDER BY created DESC LIMIT 400',(project,))
    proposals={r['id']:r['status'] for r in proposal_rows}
    for job in jobs:
        if job['id']==exclude_job:continue
        request=json.loads(job['payload']);result=json.loads(job['result']) if job['result'] else {}
        proposal_id=result.get('proposal_id');patch=result.get('patch',{})
        episodes.append({'kind':'user_turn','job_id':job['id'],'created':job['created'],
                         'user_request':request.get('prompt',''),'base_version':request.get('base_version'),
                         'selected_object':request.get('selected_object'),'job_status':job['status'],
                         'proposal_status':proposals.get(proposal_id,'not_created'),
                         'suggested_operations':[{'type':op['type'],'object_id':op.get('object_id')} for op in patch.get('operations',[])],
                         'historical_only':True,'note':'用户历史请求/模型建议不是当前事实；是否改变以版本证据和当前场景为准。'})
    keywords=terms(query);focus=set(focus)
    def relevance(e):
        text=json.dumps(e,ensure_ascii=False);entity_ids={v.get('object_id') for k in ('verified_changes','suggested_operations') for v in e.get(k,[])}
        return len(keywords & terms(text))+4*len(focus & entity_ids)
    # Always retain the three latest episodes, then retrieve older relevant ones.
    latest=sorted(episodes,key=lambda e:e['created'],reverse=True)[:3]
    ranked=sorted((e for e in episodes if e not in latest and relevance(e)>0),key=lambda e:(relevance(e),e['created']),reverse=True)[:9]
    result=sorted(latest+ranked,key=lambda e:e['created'])
    return result,{'method':'entity_links+lexical_bigrams+recency','scanned_turns':len(jobs),
                   'scanned_versions':len(versions),'returned':len(result),'scan_limit':200}


def layered_memory(db,project,p,scene,episodes,query,focus):
    """Separate immutable current evidence from preferences and past outcomes.

    No assistant-written explanation is promoted into a fact or durable rule.
    This is bounded entity/lexical retrieval, not an embedding implementation
    or a reproduction of A-MEM/LongMemEval benchmark performance.
    """
    facts={'source':'immutable_scene_version','version':scene['version'],'as_of':scene.get('created'),
           'status':'current','objects':scene['scene']['objects'],'relations':scene['scene']['relations'],
           'locked_facts':scene['scene']['locked_facts'],'audio':scene['scene']['audio']}
    preferences=[{'source':'user_project_document','input_revision':p['input_revision'],'as_of':p['updated'],
                  'status':'current','requirements':p['requirements'],'diary':p['diary'],'style':p['style']}]
    historical=[{**e,'status':'superseded' if e.get('superseded_by_restore') else 'historical',
                 'must_not_reexecute':True} for e in episodes if e['kind']=='user_turn']
    # Execution observations contain field diffs produced by code, not the
    # model's claim that it deleted/restored/resized an object.
    rows=db.all('SELECT body,created FROM memories WHERE project=? AND kind="execution_observation" ORDER BY id DESC LIMIT 200',(project,))
    experiences=[];focus=set(focus);keywords=terms(query)
    for row in rows:
        body=json.loads(row['body'])
        if body.get('candidate_only') or not body.get('verified'):continue
        ids=set(body.get('removed_ids',[])+body.get('restored_ids',[])+body.get('added_ids',[]))
        ids.update(change['object_id'] for change in body.get('changed_objects',[]))
        rank=4*len(ids&focus)+len(keywords&terms(json.dumps(body,ensure_ascii=False)))
        experiences.append((rank,{'source':'server_verified_field_diff','as_of':row['created'],
                                 'status':'historical','must_not_reexecute':True,'observation':body}))
    experiences.sort(key=lambda e:(e[0],e[1]['as_of']),reverse=True)
    return {'schema':'grounded-memory-layers-v1','facts':facts,'preferences':preferences,
            'historical_user_intents':historical,'experiences':[e[1] for e in experiences[:6]],
            'precedence':['current_user_request','current_version_facts','current_user_preferences','historical_evidence'],
            'abstention_policy':'missing_or_ambiguous_evidence_requires_clarification_not_fabrication',
            'scan_limit':200}
