from __future__ import annotations
import json
from starlette.responses import JSONResponse


class BodyLimit:
    """Bound requests including chunked bodies; the limit applies before multipart parsing."""
    def __init__(self,app,limit=130*1024*1024,overrides=None):self.app,self.limit,self.overrides=app,limit,overrides or {}
    async def __call__(self,scope,receive,send):
        if scope['type']!='http':return await self.app(scope,receive,send)
        limit=self.overrides.get(scope.get('path',''),self.limit)
        headers=dict(scope.get('headers',[]))
        try:length=int(headers.get(b'content-length',b'0'))
        except ValueError:
            return await JSONResponse({'error':'bad_content_length'},status_code=400)(scope,receive,send)
        if length<0 or length>limit:
            return await JSONResponse({'error':'request_too_large'},status_code=413)(scope,receive,send)
        count=0;started=False
        class TooLarge(Exception):pass
        async def bounded():
            nonlocal count
            msg=await receive()
            if msg['type']=='http.request':
                count+=len(msg.get('body',b''))
                if count>limit:raise TooLarge()
            return msg
        async def observe(msg):
            nonlocal started
            if msg['type']=='http.response.start':started=True
            await send(msg)
        try:await self.app(scope,bounded,observe)
        except TooLarge:
            if not started:await JSONResponse({'error':'request_too_large'},status_code=413)(scope,receive,send)


class ProcessLock:
    """Cross-platform process lock; released by the OS after a crash."""
    def __init__(self,path):self.path=path;self.file=None
    def acquire(self):
        import os
        self.file=open(self.path,'a+b')
        try:
            if os.name=='nt':
                import msvcrt
                if self.file.tell()==0:self.file.write(b'0');self.file.flush()
                self.file.seek(0);msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except (OSError,IOError) as e:
            self.file.close();self.file=None
            raise RuntimeError('该数据目录已有一个模型网关进程；使用单进程或独立数据目录。') from e
    def release(self):
        if self.file:self.file.close();self.file=None
