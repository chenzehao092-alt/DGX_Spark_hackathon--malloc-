"""Consistent database snapshot + hash-verified immutable blobs. No model keys."""
from pathlib import Path
import contextlib
import hashlib
import json
import tempfile
import zipfile
import sqlite3
from .service import Service
from .db import dumps
from .errors import AppError


def backup(settings,output:Path):
    output=Path(output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    service=Service(settings);checks={}
    with tempfile.TemporaryDirectory() as tmp:
        db=Path(tmp)/'memoryscape.sqlite3';service.db.backup(db)
        # Read asset hashes from the snapshot, not a database still receiving new writes.
        with contextlib.closing(sqlite3.connect(db)) as c:hashes={r[0] for r in c.execute('SELECT DISTINCT sha FROM assets')}
        temp=output.with_suffix('.pending')
        try:
            with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
                raw=db.read_bytes();z.writestr('memoryscape.sqlite3',raw);checks['memoryscape.sqlite3']=hashlib.sha256(raw).hexdigest()
                for sha in hashes:
                    path=service.assets.path(sha);data=path.read_bytes()
                    if hashlib.sha256(data).hexdigest()!=sha:raise AppError('备份时发现素材校验失败：'+sha)
                    name='blobs/'+sha[:2]+'/'+sha;z.writestr(name,data);checks[name]=sha
                z.writestr('manifest.json',dumps(checks))
                z.writestr('README.txt','Private backup: contains original photos, audio and diaries. Not a public submission artifact. Stop the application, verify all hashes, then restore into an empty data directory. Access tokens and model credentials are intentionally excluded.')
            temp.replace(output)
        except Exception:
            temp.unlink(missing_ok=True);raise
    return output
