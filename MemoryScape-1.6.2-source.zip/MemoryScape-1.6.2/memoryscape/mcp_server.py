"""Optional MCP 1.x stdio gateway. Read-only unless the operator enables writes."""
from __future__ import annotations
import os
from .client import Client,ident


def build_server():
    from mcp.server.fastmcp import FastMCP
    mcp=FastMCP('MemoryScape')
    def client():return Client()
    def writes():
        if os.getenv('MS_MCP_ALLOW_WRITES','false').lower()!='true':
            raise ValueError('Read-only server. Operator must explicitly enable MS_MCP_ALLOW_WRITES.')

    @mcp.tool()
    def list_projects() -> list:
        """List private local projects. Do not reveal diaries to unrelated requests."""
        return client().json('GET','/api/projects')

    @mcp.tool()
    def get_scene(project_id: str) -> dict:
        """Read the authoritative current scene and its version."""
        return client().json('GET',f'/api/projects/{ident(project_id)}/scene')

    @mcp.tool()
    def get_memory(project_id: str, selected_object: str='') -> dict:
        """Read goals, recent decisions and optional object-local state."""
        return client().json('GET',f'/api/projects/{ident(project_id)}/memory',params={'selected':ident(selected_object)} if selected_object else {})

    @mcp.tool()
    def get_job(job_id: str) -> dict:
        """Read actual asynchronous status. Never claim success from submission alone."""
        return client().json('GET',f'/api/jobs/{ident(job_id)}')

    @mcp.tool()
    def get_model_capabilities() -> dict:
        """Configured capabilities, not proof of loaded weights or successful GPU execution."""
        return client().json('GET','/api/config')

    @mcp.tool()
    def plan_scene(project_id: str, user_confirmed_remote_processing: bool=False) -> dict:
        """Enqueue planning only with explicit user approval. Does not execute the costly asset plan."""
        writes()
        if not user_confirmed_remote_processing:raise ValueError('User approval required')
        return client().json('POST',f'/api/projects/{ident(project_id)}/plan')

    @mcp.tool()
    def confirm_plan(project_id: str, plan_id: str, expected_version: int, expected_input_revision: int, user_confirmed_generation: bool=False) -> dict:
        """Start costly generation only after showing the actual plan and receiving user approval."""
        writes()
        if not user_confirmed_generation:raise ValueError('User must confirm the plan and resource use')
        return client().json('POST',f'/api/projects/{ident(project_id)}/plans/{ident(plan_id)}/confirm',json={'expected_version':expected_version,'expected_input_revision':expected_input_revision})

    @mcp.tool()
    def request_local_edit(project_id: str, base_version: int, instruction: str, selected_object: str="") -> dict:
        """Draft a bounded edit proposal, preserving locked objects. Does not approve it."""
        writes()
        return client().json('POST',f'/api/projects/{ident(project_id)}/edit',json={'base_version':base_version,'prompt':instruction,'selected_object':ident(selected_object) if selected_object else None})
    return mcp


def main():build_server().run(transport='stdio')
if __name__=='__main__':main()
