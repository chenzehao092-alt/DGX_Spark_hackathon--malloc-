from __future__ import annotations
import asyncio
import base64
import hashlib
import hmac
import json
import secrets
import time
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI,UploadFile,File,Form,Header,Request,Depends,HTTPException
from fastapi.responses import FileResponse,JSONResponse,RedirectResponse,Response,StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel,Field,ConfigDict
from typing import Literal
from . import __version__
from .config import Settings,ROOT
from .db import dumps,uid
from .errors import AppError
from .schemas import ProjectCreate,ProjectUpdate,SourceUpdate,Patch,EditRequest,Scene
from .quality_repair import RepairRequest
from .service import Service
from .jobs import Worker
from .pipeline import Pipeline
from .security import BodyLimit
from .layout import task_graph,check_scene
from .exporting import export_project,import_project,scene_glb
from .settings_api import register as register_settings


class Confirm(BaseModel):
    model_config=ConfigDict(extra='forbid')
    expected_version:int=Field(ge=0)
    expected_input_revision:int=Field(ge=0)

class Restore(BaseModel):
    version:int=Field(ge=0)
    expected_version:int=Field(ge=0)

class AdoptRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    base_version:int=Field(ge=0)
    asset_id:str=Field(min_length=1,max_length=100)


class ReviewRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    base_version:int=Field(ge=0)
    render_ids:list[str]=Field(min_length=1,max_length=8)
    coverage_mode:Literal['legacy','canonical']='legacy'
    prompt:str=Field('检查布局、对象数量和明显外观问题，只提出必要局部修改。',max_length=2000)
    round:int=Field(0,ge=0,le=1)
    selected_object:str|None=Field(None,max_length=80)


def create_app(settings=None,providers=None):
    settings=(settings or Settings()).initialize();service=Service(settings);pipe=Pipeline(service,providers);worker=Worker(service,pipe)
    from .connections import ConnectionMonitor
    monitor=ConnectionMonitor(settings)
    @asynccontextmanager
    async def lifespan(app):
        if settings.start_worker:
            monitor.start();worker.start()
        yield
        monitor.stop()
        worker.stop()
    app=FastAPI(title='MemoryScape · 拾光 3D',version=__version__,lifespan=lifespan,docs_url=None,redoc_url=None)
    app.state.service=service;app.state.worker=worker;app.state.pipeline=pipe
    app.state.connection_monitor=monitor
    app.add_middleware(BodyLimit,limit=settings.max_upload+2*1024*1024,overrides={'/api/import':settings.max_project_zip+2*1024*1024})
    def authorized(request:Request):
        bearer=request.headers.get('Authorization','').removeprefix('Bearer ')
        if bearer and secrets.compare_digest(bearer,settings.token):return
        cookie=request.cookies.get('ms_session','')
        try:
            expires,signature=cookie.split('.',1)
            valid=hmac.new(settings.token.encode(),expires.encode(),hashlib.sha256).hexdigest()
            if int(expires)>time.time() and secrets.compare_digest(signature,valid):return
        except (ValueError,TypeError):pass
        raise HTTPException(401,'需要本机访问令牌。')
    def set_local_session(response,request):
        exp=str(int(time.time()+12*3600))
        signature=hmac.new(settings.token.encode(),exp.encode(),hashlib.sha256).hexdigest()
        response.set_cookie('ms_session',exp+'.'+signature,httponly=True,samesite='strict',
                            secure=request.url.scheme=='https',max_age=12*3600)
    def local_navigation(request):
        # Loopback peer AND literal allowed local host prevent DNS rebinding.
        # Do not create a session through third-party fetches/embedded frames.
        peer=request.client.host if request.client else ''
        if peer not in ('127.0.0.1','::1') or request.url.hostname not in ('127.0.0.1','localhost','::1'):return False
        if any(k in request.headers for k in ('x-forwarded-for','forwarded','x-forwarded-host')):return False
        if request.headers.get('sec-fetch-site','none') not in ('none','same-origin'):return False
        if request.headers.get('sec-fetch-mode','navigate')!='navigate':return False
        if request.headers.get('sec-fetch-dest','document')!='document':return False
        origin=request.headers.get('origin')
        return not origin or origin==f'{request.url.scheme}://{request.headers.get("host")}'
    @app.middleware('http')
    async def guard(request:Request,call_next):
        host=request.headers.get('host','').rsplit(':',1)[0] if ':' in request.headers.get('host','') else request.headers.get('host','')
        if host not in settings.allowed_hosts:
            return JSONResponse({'message':'主机名未授权。配置 MS_ALLOWED_HOSTS 后重启。'},status_code=400)
        origin=request.headers.get('origin')
        if request.method not in ('GET','HEAD','OPTIONS') and origin:
            expected=f'{request.url.scheme}://{request.headers.get("host")}'
            if origin!=expected:return JSONResponse({'message':'拒绝跨站请求。'},status_code=403)
        response=await call_next(request)
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['Referrer-Policy']='no-referrer'
        response.headers['X-Frame-Options']='DENY'
        response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
        if request.url.path.startswith(('/api/', '/web/')) or request.url.path == '/':
            response.headers['Cache-Control']='no-store'
        return response
    @app.exception_handler(AppError)
    async def app_error(request,e):return JSONResponse({'error':e.code,'message':e.message},status_code=e.status)
    @app.exception_handler(RequestValidationError)
    async def validation_error(request,e):
        # Pydantic's default response includes rejected input values, which may
        # be a password/API key. Return locations/messages, never input data.
        return JSONResponse({'message':'输入字段无效，请检查配置。','detail':[
            {k:x[k] for k in ('loc','msg','type') if k in x} for x in e.errors()]},status_code=422)
    register_settings(app, settings, Depends(authorized))
    @app.get('/auth/local')
    def auth_local(request:Request,token:str=''):
        """Loopback-only auto-login for the one-click launcher.

        Only accepts requests whose TCP peer is 127.0.0.1 / ::1 (a browser on
        this machine). The token must match the host Access Token exactly; on
        success the same ms_session cookie as POST /api/session is issued and
        the browser is redirected to / so the token leaves the address bar.
        Remote/network clients cannot use this entry point and must log in
        with the access token as before.
        """
        peer=(request.client.host if request.client else '') or ''
        if peer not in ('127.0.0.1','::1','localhost'):
            raise HTTPException(403,'仅允许本机自动登录。')
        if not token or not secrets.compare_digest(token,settings.token):
            raise HTTPException(403,'访问令牌不正确。')
        exp=str(int(time.time()+12*3600))
        sig=hmac.new(settings.token.encode(),exp.encode(),hashlib.sha256).hexdigest()
        resp=RedirectResponse(url='/',status_code=302)
        resp.headers['Cache-Control']='no-store'
        resp.set_cookie('ms_session',exp+'.'+sig,httponly=True,samesite='strict',
                        secure=request.url.scheme=='https',max_age=12*3600)
        return resp
    @app.get('/health')
    def health():return {'app':'MemoryScape','version':__version__,'status':'ok','gpu_inference_tested_here':False,
                        'workspace_id':hashlib.sha256(str(settings.data_dir).encode()).hexdigest()[:16]}
    @app.post('/api/session')
    def session(request:Request):
        token=request.headers.get('Authorization','').removeprefix('Bearer ')
        if not secrets.compare_digest(token,settings.token):raise HTTPException(401,'访问令牌不正确。')
        exp=str(int(time.time()+12*3600));sig=hmac.new(settings.token.encode(),exp.encode(),hashlib.sha256).hexdigest()
        response=JSONResponse({'ok':True})
        response.set_cookie('ms_session',exp+'.'+sig,httponly=True,samesite='strict',secure=request.url.scheme=='https',max_age=12*3600)
        return response
    @app.delete('/api/session',dependencies=[Depends(authorized)])
    def logout():
        r=JSONResponse({'ok':True});r.delete_cookie('ms_session');return r
    @app.get('/api/config',dependencies=[Depends(authorized)])
    def config():return {'version':__version__,'models':list(pipe.providers.cards().values()),'workspace':'single-user private workspace',
                        'max_upload_mb':settings.max_upload//1024//1024,'renderer':'native-webgl2-static-glb','supports_offline':True}
    @app.get('/api/connectivity',dependencies=[Depends(authorized)])
    def connectivity():return monitor.snapshot()
    @app.get('/api/openapi',dependencies=[Depends(authorized)])
    def openapi():return app.openapi()
    @app.get('/api/projects',dependencies=[Depends(authorized)])
    def projects():return service.projects()
    @app.post('/api/projects',dependencies=[Depends(authorized)])
    def create(spec:ProjectCreate):return service.create_project(spec)
    @app.post('/api/demo',dependencies=[Depends(authorized)])
    def demo():
        from .demo import seed_project
        return seed_project(service)
    @app.get('/api/projects/{id}',dependencies=[Depends(authorized)])
    def project(id:str):return service.project(id)
    @app.patch('/api/projects/{id}',dependencies=[Depends(authorized)])
    def update_project(id:str,spec:ProjectUpdate):return service.update_project(id,spec)
    @app.get('/api/projects/{id}/sources',dependencies=[Depends(authorized)])
    def sources(id:str):return service.sources(id)
    @app.post('/api/projects/{id}/sources',dependencies=[Depends(authorized)])
    async def upload(id:str,file:UploadFile=File(...),role:str=Form('scene'),label:str=Form(''),subject:str=Form(''),note:str=Form(''),rights_confirmed:bool=Form(False)):
        raw=await file.read(settings.max_upload+1)
        return await asyncio.to_thread(service.add_source,id,raw,file.filename or 'upload.bin',role,label,subject,note,rights_confirmed)
    @app.delete('/api/projects/{id}/sources/{sid}',dependencies=[Depends(authorized)])
    def remove_source(id:str,sid:str):return service.remove_source(id,sid)
    @app.patch('/api/projects/{id}/sources/{sid}',dependencies=[Depends(authorized)])
    def update_source(id:str,sid:str,spec:SourceUpdate):return service.update_source(id,sid,spec)
    @app.post('/api/projects/{id}/sources/{sid}/clone',dependencies=[Depends(authorized)])
    def clone_source(id:str,sid:str,spec:SourceUpdate):return service.clone_source(id,sid,spec)
    @app.post('/api/projects/{id}/objects/{oid}/asset',dependencies=[Depends(authorized)])
    def adopt_asset(id:str,oid:str,spec:AdoptRequest):return service.adopt_asset(id,oid,spec.asset_id,spec.base_version)
    @app.post('/api/preflight',dependencies=[Depends(authorized)])
    def preflight():return pipe.providers.preflight()
    @app.get('/api/projects/{id}/assets/{aid}',dependencies=[Depends(authorized)])
    def asset(id:str,aid:str):
        a=service.assets.get(aid,id);service.assets.read(aid,id)
        return FileResponse(service.assets.path(a['sha']),media_type=a['mime'],filename=a['filename'],content_disposition_type='inline')
    @app.get('/api/projects/{id}/assets',dependencies=[Depends(authorized)])
    def assets(id:str):service.project(id);return service.assets.list(id)
    @app.get('/api/projects/{id}/scene',dependencies=[Depends(authorized)])
    def scene(id:str,version:int|None=None):return service.scene(id,version)
    @app.get('/api/projects/{id}/versions',dependencies=[Depends(authorized)])
    def versions(id:str):
        service.project(id);return service.db.all('SELECT version,note,created,job FROM versions WHERE project=? ORDER BY version DESC',(id,))
    @app.post('/api/projects/{id}/restore',dependencies=[Depends(authorized)])
    def restore(id:str,req:Restore):return service.restore(id,req.version,req.expected_version)
    @app.get('/api/projects/{id}/memory',dependencies=[Depends(authorized)])
    def memory(id:str,selected:str|None=None,query:str=''):return service.memory(id,selected,query[:4000])
    @app.get('/api/skills',dependencies=[Depends(authorized)])
    def skill_cards():
        from .edit_tools import SKILL_CARDS
        return SKILL_CARDS
    @app.get('/api/projects/{id}/checks',dependencies=[Depends(authorized)])
    def checks(id:str):return check_scene(Scene.model_validate(service.scene(id)['scene']))
    @app.post('/api/projects/{id}/plan',dependencies=[Depends(authorized)])
    def plan(id:str,idempotency_key:str|None=Header(None)):
        p=service.project(id)
        if p['mode']=='real':pipe.providers.conf(pipe.providers.choose('brain.plan'),id)
        return service.enqueue(id,'plan',{'base_version':p['head'],'input_revision':p['input_revision'],'ui_prompt':p['requirements']},idempotency_key)
    @app.get('/api/projects/{id}/plans',dependencies=[Depends(authorized)])
    def plans(id:str):
        service.project(id);rows=service.db.all('SELECT * FROM plans WHERE project=? ORDER BY created DESC',(id,))
        for r in rows:r['body']=json.loads(r['body'])
        return rows
    @app.post('/api/projects/{id}/plans/{pid}/confirm',dependencies=[Depends(authorized)])
    def confirm(id:str,pid:str,req:Confirm,idempotency_key:str|None=Header(None)):
        return service.confirm_plan(id,pid,req.expected_version,req.expected_input_revision,idempotency_key)
    @app.post('/api/projects/{id}/patch',dependencies=[Depends(authorized)])
    def patch(id:str,req:Patch):return service.apply_patch(id,req)
    @app.post('/api/projects/{id}/edit',dependencies=[Depends(authorized)])
    def edit(id:str,req:EditRequest,idempotency_key:str|None=Header(None)):
        if req.base_version!=service.project(id)['head']:raise AppError('请切回当前场景版本后编辑。',409)
        return service.enqueue(id,'edit',req.model_dump(),idempotency_key)
    @app.get('/api/projects/{id}/proposals',dependencies=[Depends(authorized)])
    def proposals(id:str):
        service.project(id);rows=service.db.all('SELECT * FROM proposals WHERE project=? ORDER BY created DESC',(id,))
        for r in rows:r['body']=json.loads(r['body'])
        return rows
    @app.post('/api/projects/{id}/proposals/{pid}/dismiss',dependencies=[Depends(authorized)])
    def dismiss_proposal(id:str,pid:str):return service.dismiss_proposal(id,pid)
    @app.post('/api/projects/{id}/proposals/{pid}/apply',dependencies=[Depends(authorized)])
    def apply_proposal(id:str,pid:str):
        row=service.db.one('SELECT * FROM proposals WHERE id=? AND project=?',(pid,id))
        if not row:raise AppError('修改建议不存在。',404)
        return service.apply_patch(id,Patch.model_validate(json.loads(row['body'])),from_model=True,proposal_id=pid)
    @app.post('/api/projects/{id}/renders',dependencies=[Depends(authorized)])
    async def render(id:str,version:int=Form(...),camera:str=Form(...),file:UploadFile=File(...)):
        if service.project(id)['head']!=version:raise AppError('截图版本已过期。',409,'version_conflict')
        if len(camera)>2000:raise AppError('相机信息过长。')
        try:cam=json.loads(camera)
        except ValueError as e:raise AppError('相机信息必须为 JSON。') from e
        if not isinstance(cam,dict):raise AppError('相机信息必须为 JSON 对象。')
        try:dumps(cam)
        except (ValueError,TypeError) as e:raise AppError('相机信息不能包含非有限值。') from e
        if cam.get('schema')=='view-bundle-v1':
            from .view_bundle import validate_camera
            from pydantic import ValidationError
            try:cam=validate_camera(cam,service.scene(id,version)['scene'])
            except ValidationError as e:raise AppError('多视角相机协议无效：'+str(e)[:700]) from e
        raw=await file.read(4*1024*1024+1)
        if len(raw)>4*1024*1024:raise AppError('单张复核截图上限 4 MiB。',413)
        if cam.get('schema')=='view-bundle-v1':
            import io
            from PIL import Image,ImageStat
            try:
                with Image.open(io.BytesIO(raw)) as image:
                    if image.size!=(cam['width'],cam['height']):raise AppError('截图尺寸与相机记录不符。')
                    if max(ImageStat.Stat(image.convert('RGB')).stddev)<1:raise AppError('截图为空白，不能验收。')
            except OSError as e:raise AppError('截图无法读取。') from e
        a=service.assets.put(id,raw,'render.png','rendered',extra={'version':version,'camera':cam})
        if a['kind']!='image':raise AppError('截图必须是图片。')
        rid=uid('view_');service.db.execute('INSERT INTO renders VALUES(?,?,?,?,?,?)',(rid,id,version,a['id'],dumps(cam),time.time()))
        return {'id':rid,'asset_id':a['id'],'version':version}
    @app.post('/api/projects/{id}/review',dependencies=[Depends(authorized)])
    def review(id:str,req:ReviewRequest,idempotency_key:str|None=Header(None)):
        p=service.project(id)
        if req.round>=p['budget']['max_review_rounds']:raise AppError('已达到本轮自动复核预算。')
        if req.coverage_mode=='canonical':
            from .view_bundle import validate_bundle
            validate_bundle(service,id,req.model_dump())
        return service.enqueue(id,'review',req.model_dump(),idempotency_key)
    @app.post('/api/projects/{id}/quality-repair',dependencies=[Depends(authorized)])
    def quality_repair(id:str,req:RepairRequest,idempotency_key:str|None=Header(None)):
        return service.enqueue_repair(id,req.model_dump(),idempotency_key)
    @app.get('/api/jobs/{id}/budget',dependencies=[Depends(authorized)])
    def job_budget(id:str):
        service.job(id)
        from .agent_budget import snapshot
        return snapshot(service,id)
    @app.get('/api/projects/{id}/jobs',dependencies=[Depends(authorized)])
    def project_jobs(id:str):
        service.project(id);return [service.job(r['id']) for r in service.db.all('SELECT id FROM jobs WHERE project=? ORDER BY created DESC LIMIT 30',(id,))]
    @app.get('/api/jobs/{id}',dependencies=[Depends(authorized)])
    def job(id:str):return service.job(id)
    @app.get('/api/jobs/{id}/preview',dependencies=[Depends(authorized)])
    def preview(id:str):return service.preview(id)
    @app.post('/api/jobs/{id}/cancel',dependencies=[Depends(authorized)])
    def cancel(id:str):
        service.job(id)
        service.db.execute('UPDATE jobs SET cancel=1,status=CASE WHEN status="queued" THEN "cancelled" ELSE status END,updated=? WHERE id=?',(time.time(),id))
        return service.job(id)
    @app.post('/api/jobs/{id}/retry',dependencies=[Depends(authorized)])
    def retry(id:str):
        j=service.job(id)
        if j['status'] not in ('failed','cancelled','partial'):raise AppError('只能恢复终止或部分失败任务。',409)
        if j['kind']!='build':
            project=service.project(j['project'])
            if j['payload'].get('base_version',project['head'])!=project['head'] or j['payload'].get('input_revision',project['input_revision'])!=project['input_revision']:
                raise AppError('场景或素材已变化，请重新描述修改，不能重试旧任务。',409,'version_conflict')
        if j['kind']=='build':
            current=service.scene(j['project'])
            if j['status']!='partial' and (j['payload']['base_version']!=current['version'] or j['payload'].get('input_revision')!=service.project(j['project'])['input_revision']):
                raise AppError('场景或素材已变化，请重新描述修改，不能重试旧任务。',409,'version_conflict')
            retry_scene=Scene.model_validate(current['scene'] if j['status']=='partial' else j['payload']['scene'])
            targets=[o.id for o in retry_scene.objects if o.status=='failed'] if j['status']=='partial' else j['payload'].get('targets')
            service.check_build_capabilities(retry_scene,targets)
        if j['status']=='partial' and j['kind']=='build':
            current=service.scene(j['project']);sc=Scene.model_validate(current['scene'])
            targets=[o.id for o in sc.objects if o.status=='failed']
            target_audio=[a.id for a in sc.audio if a.status=='failed']
            if not targets and not target_audio:raise AppError('当前版本没有失败对象或音轨。')
            return service.enqueue(j['project'],'build',{'base_version':current['version'],'scene':sc.model_dump(),'targets':targets,'target_audio_ids':target_audio,'input_revision':service.project(j['project'])['input_revision'],'production':{k:v for k,v in service.project(j['project']).items() if k in ProjectCreate.model_fields}})
        # Recheck under the write lock. Two clicks/clients must not both reset
        # an already queued/running job or advance its remote retry counter.
        with service.db.tx() as c:
            live=c.execute('SELECT status,payload FROM jobs WHERE id=?',(id,)).fetchone()
            if not live or live['status']!=j['status'] or live['payload']!=dumps(j['payload']):
                raise AppError('任务状态刚刚有了变化，请刷新后查看。',409,'version_conflict')
            project=c.execute('SELECT head,input_revision FROM projects WHERE id=?',(j['project'],)).fetchone()
            if j['payload'].get('base_version',project['head'])!=project['head'] or j['payload'].get('input_revision',project['input_revision'])!=project['input_revision']:
                raise AppError('场景或素材已变化，请重新提交修改，不能重试旧任务。',409,'version_conflict')
            payload={**j['payload'],'retry_generation':j['payload'].get('retry_generation',0)+1}
            c.execute('UPDATE jobs SET status="queued",cancel=0,error=NULL,owner=NULL,lease=NULL,payload=?,updated=? WHERE id=?',(dumps(payload),time.time(),id))
            service.db.event(j['project'],id,'job.retry_requested',{'generation':payload['retry_generation']},c)
        return service.job(id)
    @app.get('/api/projects/{id}/events',dependencies=[Depends(authorized)])
    def events(id:str,after:int=0):
        service.project(id);rows=service.db.all('SELECT * FROM events WHERE project=? AND seq>? ORDER BY seq LIMIT 300',(id,after))
        for r in rows:r['body']=json.loads(r['body'])
        return rows
    @app.get('/api/projects/{id}/stream',dependencies=[Depends(authorized)])
    async def stream(id:str,request:Request,after:int=0):
        service.project(id)
        async def chunks():
            cursor=after
            while not await request.is_disconnected():
                rows=events(id,cursor)
                for row in rows:
                    cursor=row['seq'];yield f'id: {cursor}\ndata: {dumps(row)}\n\n'
                if not rows:yield ': keepalive\n\n'
                await asyncio.sleep(1)
        return StreamingResponse(chunks(),media_type='text/event-stream',headers={'X-Accel-Buffering':'no'})
    @app.get('/api/projects/{id}/export',dependencies=[Depends(authorized)])
    def export(id:str,originals:bool=False,version:int|None=None):
        raw=export_project(service,id,originals,version)
        return Response(raw,media_type='application/zip',headers={'Content-Disposition':'attachment; filename="memoryscape-project.memory.zip"'})
    @app.get('/api/projects/{id}/scene.glb',dependencies=[Depends(authorized)])
    def glb(id:str,version:int|None=None):
        return Response(scene_glb(service,id,version),media_type='model/gltf-binary',headers={'Content-Disposition':'attachment; filename="memoryscape-scene.glb"'})
    @app.post('/api/import',dependencies=[Depends(authorized)])
    async def import_pack(file:UploadFile=File(...)):
        data=await file.read(settings.max_project_zip+1)
        return await asyncio.to_thread(import_project,service,data)
    @app.get('/')
    def index(request:Request):
        response=FileResponse(ROOT/'web/index.html')
        if settings.local_auto_login and local_navigation(request):set_local_session(response,request)
        return response
    app.mount('/web',StaticFiles(directory=ROOT/'web'),name='web')
    return app
