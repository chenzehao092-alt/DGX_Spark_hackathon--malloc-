from __future__ import annotations
import hashlib
import io
import json
import math
import mimetypes
import os
import shutil
import struct
import subprocess
import tempfile
import wave
from pathlib import Path
import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError
from .errors import AppError

Image.MAX_IMAGE_PIXELS = 32_000_000


def parse_glb(raw: bytes) -> dict:
    if len(raw) < 20 or raw[:4] != b'glTF':
        raise AppError('不是二进制 glTF/GLB。')
    _, version, length = struct.unpack_from('<4sII', raw)
    if version != 2 or length != len(raw):
        raise AppError('GLB 版本或长度不正确。')
    offset, doc = 12, None
    while offset < length:
        if offset+8 > length:
            raise AppError('GLB 块头损坏。')
        size, kind = struct.unpack_from('<II', raw, offset)
        offset += 8
        if size % 4 or offset+size > length:
            raise AppError('GLB 块超出文件边界。')
        if kind == 0x4E4F534A:
            if doc is not None or size > 8*1024*1024:
                raise AppError('GLB JSON 大小或块数量异常。')
            try:
                doc = json.loads(raw[offset:offset+size].decode('utf-8'))
            except (ValueError, UnicodeDecodeError) as e:
                raise AppError('GLB JSON 无法解析。') from e
        offset += size
    if not isinstance(doc, dict) or not doc.get('meshes'):
        raise AppError('GLB 没有可显示的网格。')
    if len(doc.get('nodes', [])) > 2000 or len(doc.get('accessors', [])) > 20000:
        raise AppError('GLB 对象过多。')
    # Block network and local-file resolution before passing data to any loader.
    for item in doc.get('buffers', []) + doc.get('images', []):
        if 'uri' in item:
            raise AppError('仅接收贴图/缓冲嵌入 GLB 的静态资产；外部 URI 与 data URI 均禁用。')
    unsupported = {'KHR_draco_mesh_compression', 'EXT_meshopt_compression', 'KHR_texture_basisu'}
    if unsupported.intersection(doc.get('extensionsUsed', [])):
        raise AppError('首版不接受 Draco/Meshopt/KTX2 压缩；请导出未压缩静态 GLB。')
    if doc.get('animations') or doc.get('skins'):
        raise AppError('首版接收静态资产；请先烘焙姿态、去除骨骼与动画。')
    vertices = sum(int(x.get('count', 0)) for x in doc.get('accessors', []) if x.get('type')=='VEC3')
    if vertices > 12_000_000:
        raise AppError('GLB 顶点预算超限。')
    return doc


def glb_info(raw: bytes) -> dict:
    doc = parse_glb(raw)
    import trimesh
    try:
        scene = trimesh.load(io.BytesIO(raw), file_type='glb', force='scene', process=False)
        bounds = scene.bounds
        if bounds is None or not np.isfinite(bounds).all():
            raise ValueError('invalid bounds')
        size = bounds[1] - bounds[0]
        if max(size) <= 1e-7 or max(size) > 1e7:
            raise ValueError('invalid scale')
        triangles = sum(len(g.faces) for g in scene.geometry.values())
        if triangles > 1_000_000:
            raise ValueError('too many triangles')
        return {'bounds': bounds.tolist(), 'size': size.tolist(), 'triangles': triangles,
                'meshes': len(scene.geometry), 'materials': len(doc.get('materials', []))}
    except Exception as e:
        raise AppError(f'GLB 网格检查失败：{type(e).__name__}') from e


def wav_info(raw: bytes) -> dict:
    try:
        with wave.open(io.BytesIO(raw), 'rb') as w:
            rate, n, channels, width = w.getframerate(), w.getnframes(), w.getnchannels(), w.getsampwidth()
            if not 8000 <= rate <= 192000 or channels not in (1,2) or width not in (1,2,3,4):
                raise ValueError('invalid audio format')
            duration = n/rate
            if not 0 < duration <= 1800:
                raise ValueError('audio exceeds 30 minutes or empty')
            data = w.readframes(n)
            if len(data) != n*channels*width:
                raise ValueError('truncated PCM data')
            return {'duration':duration, 'sample_rate':rate, 'channels':channels, 'sample_width':width}
    except (wave.Error, ValueError, EOFError) as e:
        raise AppError('需要有效的 PCM WAV，时长 0–30 分钟；压缩格式需要 FFmpeg。') from e


def inspect(raw: bytes, filename: str) -> tuple[str, str, dict]:
    if not raw:
        raise AppError('文件为空。')
    if raw[:4] == b'glTF':
        return 'model', 'model/gltf-binary', glb_info(raw)
    if raw[:4] == b'RIFF' and raw[8:12] == b'WAVE':
        try:
            return 'audio', 'audio/wav', wav_info(raw)
        except AppError:
            return 'audio', 'audio/wav', {'needs_conversion':True}
    try:
        with Image.open(io.BytesIO(raw)) as im:
            if im.format not in ('PNG','JPEG','WEBP') or getattr(im,'n_frames',1) != 1:
                raise AppError('仅支持单帧 PNG、JPEG、WebP。')
            if min(im.size) < 8 or im.width * im.height > Image.MAX_IMAGE_PIXELS:
                raise AppError('图片尺寸应不小于 8 像素且不超过 3200 万像素。')
            meta={'width':im.width,'height':im.height,'mode':im.mode}
            mime=Image.MIME[im.format]
            im.verify()
            return 'image',mime,meta
    except (UnidentifiedImageError, OSError):
        pass
    except (Image.DecompressionBombError, Image.DecompressionBombWarning) as e:
        raise AppError('图片解压尺寸超限。') from e
    suffix = Path(filename).suffix.lower()
    audio_mime={'.mp3':'audio/mpeg','.m4a':'audio/mp4','.ogg':'audio/ogg','.flac':'audio/flac','.webm':'audio/webm','.wav':'audio/wav'}
    if suffix in audio_mime:
        # Validate by decoding in a sandboxed temporary directory before storing.
        pcm = canonical_audio(raw, suffix)
        return 'audio',audio_mime[suffix],{**wav_info(pcm),'needs_conversion':True}
    if suffix in ('.txt','.md'):
        try:
            text=raw.decode('utf-8-sig')
            if '\x00' in text or len(text)>100_000:
                raise ValueError('invalid text')
            return 'text','text/plain',{'characters':len(text)}
        except (ValueError,UnicodeDecodeError) as e:
            raise AppError('文本应为 UTF-8，最多 100000 字符。') from e
    raise AppError('不支持该格式。上传 PNG/JPEG/WebP、常用音频、UTF-8 文本或自包含静态 GLB。')


def image_copy(raw: bytes, crop: dict | None = None, max_edge: int = 1536, alpha: bool = False) -> bytes:
    with Image.open(io.BytesIO(raw)) as src:
        im=ImageOps.exif_transpose(src).convert('RGBA')
        if not alpha:
            # Dropping alpha directly exposes arbitrary hidden RGB (often black)
            # to the Director/image editor instead of the visible reference.
            background=Image.new('RGBA',im.size,(255,255,255,255))
            im=Image.alpha_composite(background,im).convert('RGB')
        if crop:
            from .schemas import Crop
            c=Crop.model_validate(crop)
            w,h=im.size
            box=(int(c.x*w),int(c.y*h),int((c.x+c.width)*w),int((c.y+c.height)*h))
            if box[2]-box[0]<8 or box[3]-box[1]<8:
                raise AppError('选区过小，至少需要 8×8 像素。')
            im=im.crop(box)
        im.thumbnail((max_edge,max_edge), Image.Resampling.LANCZOS)
        out=io.BytesIO();im.save(out,format='PNG')
        return out.getvalue()


def ffmpeg_executable() -> str:
    """Prefer a deployed FFmpeg; desktop wheels supply a local fallback.

    Discovery never downloads an executable or changes the system PATH.
    The desktop bootstrap installs the pinned imageio-ffmpeg dependency.
    """
    exe = shutil.which('ffmpeg')
    if exe:
        return exe
    try:
        from imageio_ffmpeg import get_ffmpeg_exe
        return get_ffmpeg_exe()
    except (ImportError, RuntimeError, OSError) as e:
        raise AppError('该音频需要 FFmpeg 解码工具。请重新运行一键启动以安装依赖，或转换为 PCM 16-bit WAV。',
                       code='audio_decoder_unavailable') from e


def canonical_audio(raw: bytes, suffix='.wav') -> bytes:
    """Convert a *copy*, never the original. No network protocols in ffmpeg input."""
    try:
        info=wav_info(raw)
        if info['sample_width']==2:
            with wave.open(io.BytesIO(raw),'rb') as w:
                samples=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1, info['channels']).astype(np.float64).mean(axis=1)
            if info['sample_rate'] != 16000:
                count=max(1, round(len(samples)*16000/info['sample_rate']))
                samples=np.interp(np.arange(count)*info['sample_rate']/16000, np.arange(len(samples)),samples)
            return encode_wav(samples,16000)
    except AppError:
        pass
    exe=ffmpeg_executable()
    with tempfile.TemporaryDirectory(prefix='memoryscape-audio-') as d:
        src=Path(d)/('input'+suffix);out=Path(d)/'output.wav';src.write_bytes(raw)
        try:
            subprocess.run([exe,'-nostdin','-v','error','-protocol_whitelist','file,pipe','-i',str(src),
                            '-t','1801','-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',str(out)],
                           check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=90,
                           creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
            data=out.read_bytes();wav_info(data);return data
        except (subprocess.SubprocessError,OSError) as e:
            raise AppError('音频解码失败/超时，或超过 30 分钟。') from e


def encode_wav(samples, rate=16000) -> bytes:
    a=np.clip(samples,-32768,32767).astype('<i2')
    b=io.BytesIO()
    with wave.open(b,'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(a.tobytes())
    return b.getvalue()


def audio_chunks(raw: bytes, seconds=25, overlap=2):
    pcm=canonical_audio(raw)
    with wave.open(io.BytesIO(pcm),'rb') as w:
        rate=w.getframerate();samples=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2')
    stride=(seconds-overlap)*rate
    if stride<=0:
        raise ValueError('invalid stride')
    for start in range(0,len(samples),stride):
        stop=min(len(samples),start+seconds*rate)
        yield start/rate,stop/rate,encode_wav(samples[start:stop],rate)
        if stop==len(samples):break
