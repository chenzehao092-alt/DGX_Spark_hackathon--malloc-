"""Bounded, deterministic modelling tools, not executable LLM scripts."""
from .schemas import Transform
from .errors import AppError


def validate_box_size(obj, transform=None):
    t=transform or obj.transform
    if (obj.generation.strategy=='procedural' and obj.generation.primitive=='box'
            and max(t.size)-min(t.size)>.001 and t.fit!='stretch'):
        raise AppError(f'{obj.label} 的长方体尺寸必须使用 fit=stretch；uniform 会缩为立方体，无法满足指定长宽高。')


def resized_transform(obj, edit):
    data=obj.transform.model_dump()
    if edit.scale is not None:
        data['size']=[v*edit.scale for v in data['size']]
    else:
        # Exact per-axis deformation is valid for parametric geometry. Photos
        # and generated meshes retain their aspect unless a full transform is
        # explicitly requested; never silently stretch a photographed person.
        if obj.generation.strategy!='procedural' and obj.transform.fit!='stretch':
            raise AppError('照片或真实模型的独立轴尺寸编辑会改变比例；请使用 resize.scale 等比例缩放，或明确授权形变后使用 transform。')
        for i,value in enumerate((edit.width,edit.height,edit.depth)):
            if value is not None:data['size'][i]=value
        data['fit']='stretch'
    try:result=Transform.model_validate(data)
    except ValueError as exc:raise AppError('调整后的尺寸超过 0.01..50 展示单位，请减小缩放比例。') from exc
    validate_box_size(obj,result)
    return result


def restoration_explanation(patch,scene):
    by={o.id:o for o in scene.objects}
    return '按历史记录恢复'+ '、'.join(by[op.object_id].label for op in patch.operations)+'的网格、尺寸和配色；复用原资产，不重新生成，其他物品保持不变。'


SKILL_CARDS=[
    {'id':'history.restore_object','operation':'restore_object','cost':'local_no_inference',
     'when':'把删除的物品加回来、恢复原来的尺寸/外观',
     'contract':'只传 object_id/source_version；从本项目真实历史取回网格、尺寸、配色。不得新建猜测替代品。'},
    {'id':'geometry.resize','operation':'resize','cost':'local_no_inference',
     'when':'尺寸调整或整体放大缩小',
     'contract':'size_edit 的 width/height/depth 只用于程序几何或用户已授权 fit=stretch 的物品，只改明确轴，保留其他尺寸与位置旋转。真实模型/照片且 fit=uniform 时必须 resize.scale 等比例缩放（目标高度/当前高度）；不能直接 resize.height 拉伸人物，不能与独立轴混用。'},
    {'id':'geometry.frame','operation':'add / bind_frame','cost':'local_procedural',
     'when':'给已有图片加镂空边框',
     'contract':'绑定真实 photo 对象，后端自动贴合，不猜宽高；已有框不重复添加。'},
    {'id':'appearance.tint','operation':'tint','cost':'local_no_inference',
     'when':'独立物品整体改色',
     'contract':'不代表改材质、单面重绘或形状；不得用改色替代不支持的要求。'},
    {'id':'appearance.clear_tint','operation':'clear_tint','cost':'local_no_inference',
     'when':'取消整体染色，显示当前资产本身的配色/纹理',
     'contract':'只移除 tint；保留资产、尺寸和摆放。不调用图片或三维模型，不保证生成资产与原照片逐像素一致。'},
    {'id':'asset.regenerate','operation':'regenerate','cost':'image_edit_then_remote_3d',
     'when':'照片主体的形状/局部外观修改',
     'contract':'Step1X-3D 输入图片，不直接接受文字；先核对 image.edit 能力及服务可用性，失败保留已保存版本。'},
    {'id':'scene.remove','operation':'remove','cost':'local_no_inference',
     'when':'明确删除独立对象',
     'contract':'只移出当前场景；不移动其他物品、不删除历史或原始素材；歧义需询问。'}]
