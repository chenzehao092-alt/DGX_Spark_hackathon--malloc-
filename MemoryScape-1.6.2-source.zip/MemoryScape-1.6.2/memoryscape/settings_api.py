"""Settings API: model endpoint configuration + local secret storage.

Design rules enforced here:
- Secrets (tokens) are written ONLY to <data_dir>/local-secrets.env on this
  machine. They are never returned by the API, never written to frontend
  localStorage or logs; sent only to the configured model endpoint when called.
- Non-secret model fields are updated in the operator's models.toml using
  line-level edits that preserve comments, unknown fields, ordering and
  unrelated sections. A backup is created before writing and the write is
  atomic (temp file + os.replace), so a failed write leaves the original
  untouched.
- Preflight reuses the existing Providers.preflight() probe; this module only
  maps its results to structured statuses. It never sends user materials.
"""
from __future__ import annotations
import os
import json
import re
import time
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit
from fastapi import APIRouter
from pydantic import BaseModel, Field, ConfigDict, field_validator

from .config import load_env

# token_env names must match configs/models.example.toml / host.env.example
TOKEN_ENV = {
    'director': 'DIRECTOR_TOKEN',
    'geometry': 'GEOMETRY_NODE_TOKEN',
    'image': 'IMAGE_NODE_TOKEN',
    'audio': 'AUDIO_NODE_TOKEN',
    'enhancement': 'ENHANCE_NODE_TOKEN',
    'image_generation': 'IMAGE_API_NODE_TOKEN',
}
# UI surface: the four main model services.
NODE_KINDS = ('director', 'geometry', 'image', 'audio')
SECRETS_NAME = 'local-secrets.env'
BACKUP_PREFIX = 'settings-backup-models'
BACKUP_KEEP = 10
STEPFUN_URL = 'https://api.stepfun.com/v1'
STEP_PLAN_URL = 'https://api.stepfun.com/step_plan/v1'


def stepfun_api_mode(base: str) -> str | None:
    p = urlsplit(base or '')
    if p.scheme != 'https' or p.hostname not in ('api.stepfun.com', 'api.stepfun.ai') or p.username or p.query or p.fragment:
        return None
    return {'/v1': 'standard', '/step_plan/v1': 'step_plan'}.get(p.path.rstrip('/'))

SECTION_RE = re.compile(r'^\s*\[models\.([A-Za-z0-9_]+)\]\s*$')
KEY_RE = re.compile(r'^\s*([A-Za-z0-9_]+)\s*=')


# ---------------------------------------------------------------- secrets file

def secrets_path(settings) -> Path:
    return Path(settings.data_dir) / SECRETS_NAME


def _token_value(settings, env_key: str) -> str:
    """Resolve a token from the running process or the local secrets file."""
    value = os.environ.get(env_key, '')
    if value:
        return value
    path = secrets_path(settings)
    if not path.is_file():
        return ''
    for line in path.read_text('utf-8').splitlines():
        s = line.strip()
        if s.startswith(env_key + '='):
            return s.split('=', 1)[1].strip().strip('"').strip("'")
    return ''


def load_local_secrets(settings) -> None:
    """Load persisted local secrets into os.environ for this process."""
    path = secrets_path(settings)
    if path.is_file():
        load_env(path)


def _save_secrets(settings, values: dict) -> None:
    """values: token_env -> plaintext. Empty string means 'leave unchanged'."""
    path = secrets_path(settings)
    existing = {}
    if path.is_file():
        for line in path.read_text('utf-8').splitlines():
            s = line.strip()
            if s and not s.startswith('#') and '=' in s:
                k, v = s.split('=', 1)
                existing[k.strip()] = v.strip()
    changed = False
    for env_key, plain in values.items():
        if plain:
            existing[env_key] = plain
            os.environ[env_key] = plain
            changed = True
    if not changed:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    with open(tmp, 'w', encoding='utf-8', newline='\n') as f:
        f.write('# Local secrets for MemoryScape. Never commit, never share.\n')
        for env_key in TOKEN_ENV.values():
            if env_key in existing:
                f.write(f'{env_key}={existing[env_key]}\n')
    os.replace(tmp, path)


# ---------------------------------------------------------------- models.toml

def _toml_string(value: str) -> str:
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n') + '"'


def _format_field(key: str, value) -> str:
    if key == 'enabled' and value in ('true', 'false'):
        return f'{key} = {value}\n'
    if key=='capabilities':
        if not isinstance(value,list) or not all(isinstance(v,str) and len(v)<=80 for v in value):
            raise ValueError('Capability updates require a string list')
        return f'{key} = {json.dumps(value,ensure_ascii=False)}\n'
    return f'{key} = {_toml_string(str(value))}\n'


def _update_toml_lines(text: str, updates: dict) -> str:
    """Line-level edits. updates: {section: {key: value}}.

    Existing key lines are replaced in place; new keys are inserted at the end
    of their section. Comments, unknown fields and other sections are kept.
    """
    lines = text.splitlines(keepends=True)
    section_header = {}  # section -> line index
    section_ends = {}    # section -> last content line index
    key_line = {}        # (section, key) -> line index
    current = None
    for i, line in enumerate(lines):
        m = SECTION_RE.match(line)
        if m:
            current = m.group(1)
            section_header.setdefault(current, i)
            continue
        if current is not None:
            section_ends[current] = i
            mm = KEY_RE.match(line)
            if mm:
                key_line.setdefault((current, mm.group(1)), i)
    replacements = {}   # line index -> new line
    insert_at = {}      # line index -> [fields]
    new_sections = []   # [(section, [fields])] appended at end
    for sec, fields in updates.items():
        pending = []
        for key, value in fields.items():
            if key.startswith('_'):
                continue
            if (sec, key) in key_line:
                replacements[key_line[(sec, key)]] = _format_field(key, value)
            else:
                pending.append((key, value))
        if pending:
            anchor = section_ends.get(sec, section_header.get(sec))
            if anchor is None:
                new_sections.append((sec, pending))
            else:
                insert_at.setdefault(anchor, []).extend(pending)
    out = []
    for i, line in enumerate(lines):
        out.append(replacements.get(i,line))
        if i in insert_at:
            if out[-1] and not out[-1].endswith('\n'):out.append('\n')
            for key, value in insert_at[i]:
                out.append(_format_field(key, value))
    for sec, pending in new_sections:
        out.append(f'\n[models.{sec}]\n')
        for key, value in pending:
            out.append(_format_field(key, value))
    return ''.join(out)


def _write_models_toml(settings, updates: dict) -> Path:
    """Apply updates (section -> {key: value}) to the models file with backup + atomic write."""
    config_file = Path(settings.config_file)
    config_file.parent.mkdir(parents=True, exist_ok=True)
    backup_dir = Path(settings.data_dir)
    backup_dir.mkdir(parents=True, exist_ok=True)
    if config_file.is_file():
        stamp = time.strftime('%Y%m%d-%H%M%S')
        backup = backup_dir / f'{BACKUP_PREFIX}-{stamp}.toml'
        import shutil
        shutil.copyfile(config_file, backup)
        backups = sorted(backup_dir.glob(f'{BACKUP_PREFIX}-*.toml'))
        for old in backups[:-BACKUP_KEEP]:
            try:
                old.unlink()
            except OSError:
                pass
    if config_file.is_file():
        text = config_file.read_text('utf-8')
    else:
        # A clean source package has no private models.toml. Keep complete,
        # disabled capability cards when first enabling the cloud or node,
        # rather than create enabled sections with missing capabilities.
        example = Path(__file__).resolve().parents[1] / 'configs/models.example.toml'
        text = example.read_text('utf-8') if example.is_file() else ''
    new_text = _update_toml_lines(text, updates)
    tmp = config_file.with_suffix('.toml.tmp')
    tmp.write_text(new_text, encoding='utf-8', newline='\n')
    os.replace(tmp, config_file)  # atomic: a failed write leaves the original intact
    return config_file


# ---------------------------------------------------------------- view / apply

def current(settings) -> dict:
    """Structured read view. Never includes secret values."""
    models = settings.models()
    view = {}
    for kind in NODE_KINDS:
        conf = models.get(kind, {}) or {}
        env_key = conf.get('token_env', TOKEN_ENV[kind])
        model = os.getenv(conf.get('model_env', ''), '') or conf.get('model', '') or ''
        view[kind] = {
            'base_url': conf.get('url', '') or '',
            'model': model,
            'enabled': bool(conf.get('enabled', False)),
            'token_configured': bool(_token_value(settings, env_key)),
            'label': conf.get('label', kind),
        }
        if kind == 'image':
            view[kind]['api_mode'] = stepfun_api_mode(conf.get('url', '')) if conf.get('protocol') == 'stepfun-images' else None
            view[kind]['api_region'] = ('international' if urlsplit(conf.get('url', '')).hostname == 'api.stepfun.ai' else 'cn') if view[kind]['api_mode'] else None
    return view


class ModelsUpdate(BaseModel):
    model_config = ConfigDict(extra='forbid')
    director_base_url: str = Field('', max_length=500)
    director_model: str = Field('', max_length=200)
    director_token: str = Field('', max_length=2000)
    geometry_url: str = Field('', max_length=500)
    geometry_token: str = Field('', max_length=2000)
    image_url: str = Field('', max_length=500)
    image_token: str = Field('', max_length=2000)
    audio_url: str = Field('', max_length=500)
    audio_token: str = Field('', max_length=2000)
    @field_validator('director_token','geometry_token','image_token','audio_token')
    @classmethod
    def no_secret_newlines(cls, value):
        if '\r' in value or '\n' in value:raise ValueError('密钥不能包含换行。')
        return value

class StepFunUpdate(BaseModel):
    model_config = ConfigDict(extra='forbid')
    api_key: str = Field('', max_length=2000)
    image_api_mode: Literal['standard', 'step_plan'] | None = None
    image_api_region: Literal['cn', 'international'] | None = None

    @field_validator('api_key')
    @classmethod
    def valid_key(cls, value):
        if '\r' in value or '\n' in value or (value.strip() and len(value.strip()) < 10):
            raise ValueError('API Key 格式无效。')
        return value.strip()

def apply_stepfun(settings, update: StepFunUpdate) -> dict:
    # Switching the billing path never requires reading a saved secret back
    # into the browser. Empty input retains the already configured key.
    if not update.api_key and not _token_value(settings, 'DIRECTOR_TOKEN'):
        raise ValueError('请先配置 StepFun API Key。')
    existing=settings.models()
    director=existing.get('director',{})
    director_url=director.get('url', '')
    selected=director.get('model','') if stepfun_api_mode(director_url) else ''
    updates={
        # The legacy vision model is not necessarily offered on Step Plan.
        # Image billing selection must not silently replace a working director.
        'director': {'url':director_url if selected else STEPFUN_URL, 'enabled':'true',
                     'protocol':'chat', 'token_env':'DIRECTOR_TOKEN',
                     'model':selected or 'step-1o-turbo-vision'},
    }
    # A key refresh must not replace an explicitly connected local image
    # node. Cloud image APIs have a different lifecycle from the director.
    image=existing.get('image',{})
    if not (image.get('enabled') and image.get('protocol')=='node-v1' and image.get('url')):
        image_url=image.get('url', '') if image.get('protocol')=='stepfun-images' else ''
        if update.image_api_mode is not None or update.image_api_region is not None:
            mode=update.image_api_mode or stepfun_api_mode(image_url) or 'standard'
            origin=image_url if stepfun_api_mode(image_url) else director_url
            region=update.image_api_region or ('international' if urlsplit(origin).hostname=='api.stepfun.ai' else 'cn')
            # Keys are region-specific. A billing change must not silently
            # send a China-region key to the international API (or vice versa).
            host='api.stepfun.ai' if region=='international' else 'api.stepfun.com'
            image_url=f'https://{host}/' + ('step_plan/v1' if mode=='step_plan' else 'v1')
        elif not stepfun_api_mode(image_url):
            image_url=STEPFUN_URL
        updates['image']={'url':image_url, 'enabled':'true',
                  'protocol':'stepfun-images', 'token_env':'DIRECTOR_TOKEN',
                  'model':image.get('model') if image.get('protocol')=='stepfun-images' and image.get('model') else 'step-image-edit-2'}
    _write_models_toml(settings,updates)
    _save_secrets(settings, {'DIRECTOR_TOKEN': update.api_key})
    return current(settings)


def _validate_url(value: str) -> str:
    value = (value or '').strip().rstrip('/')
    if not value:
        return ''
    from urllib.parse import urlsplit
    p = urlsplit(value)
    if p.scheme not in ('http', 'https') or not p.hostname or p.username or p.query or p.fragment:
        raise ValueError('模型 URL 无效：只接受 http(s) 端点，不能包含用户名、查询串或片段。')
    return value


def apply(settings, update: ModelsUpdate) -> dict:
    """Persist non-secret fields into models.toml and secrets into local file."""
    urls = {
        'director': _validate_url(update.director_base_url),
        'geometry': _validate_url(update.geometry_url),
        'image': _validate_url(update.image_url),
        'audio': _validate_url(update.audio_url),
    }
    toml_updates = {}
    for kind, url in urls.items():
        toml_updates[kind] = {'url': url, 'enabled': 'true' if url else 'false'}
    if update.director_model:
        toml_updates['director']['model'] = update.director_model.strip()
    _write_models_toml(settings, toml_updates)
    _save_secrets(settings, {
        TOKEN_ENV['director']: update.director_token.strip(),
        TOKEN_ENV['geometry']: update.geometry_token.strip(),
        TOKEN_ENV['image']: update.image_token.strip(),
        TOKEN_ENV['audio']: update.audio_token.strip(),
    })
    return current(settings)


# ---------------------------------------------------------------- preflight

def _classify_error(error: str) -> str:
    if '401' in error or '403' in error or '缺少' in error or '密钥' in error:
        return 'unauthorized'
    if 'HTTP' in error or 'Expecting' in error or 'JSON' in error.lower() or 'decode' in error.lower():
        return 'invalid_response'
    return 'unreachable'


def preflight_status(settings, providers) -> dict:
    """Structured status per model kind. Reuses Providers.preflight() probes."""
    models = settings.models()
    configured = {}
    for kind in NODE_KINDS:
        conf = models.get(kind, {}) or {}
        has_url = bool(conf.get('url', '') or os.getenv(conf.get('url_env', ''), ''))
        configured[kind] = bool(conf.get('enabled', False)) and has_url
    probe = providers.preflight()
    checks = {c['model']: c for c in probe['checks']}
    out = {}
    for kind in NODE_KINDS:
        env_key = models.get(kind, {}).get('token_env', TOKEN_ENV[kind])
        token_configured = bool(_token_value(settings, env_key))
        if not configured[kind]:
            out[kind] = {'status': 'not_configured', 'configured': False,
                         'token_configured': token_configured,
                         'detail': '未配置 URL 或未启用。'}
            continue
        check = checks.get(kind)
        last=providers.inference_status(kind)
        retry=providers.retry_after(kind)
        if retry:
            out[kind]={'status':'unavailable','configured':True,'token_configured':token_configured,
                       'retry_after_seconds':retry,'last_http_status':last['http_status'],
                       'detail':f'最近一次真实推理返回 HTTP {last["http_status"]}，服务暂时不可用；约 {retry} 秒后可重试。'}
            continue
        if check is None:
            out[kind] = {'status': 'unreachable', 'configured': True,
                         'token_configured': token_configured, 'detail': '探测未覆盖该节点。'}
        elif check['connection'] == 'ok':
            out[kind] = {'status': 'connected', 'configured': True,
                         'token_configured': token_configured, 'detail': check['advertised']}
        else:
            error = check.get('error', '')
            out[kind] = {'status': _classify_error(error), 'configured': True,
                         'token_configured': token_configured, 'detail': error[:300]}
    for kind,check in out.items():
        last=providers.inference_status(kind)
        if last:check['last_inference']=last
    return {'checks': out, 'note': probe['note']}


# ---------------------------------------------------------------- routes

def register(app, settings, authorize) -> None:
    """Mount /api/settings/* routes. authorize is api.py's auth dependency."""
    load_local_secrets(settings)
    router = APIRouter(prefix='/api/settings', dependencies=[authorize])

    @router.get('/models')
    def get_models():
        return current(settings)

    @router.post('/models')
    def post_models(update: ModelsUpdate):
        try:
            return apply(settings, update)
        except ValueError as e:
            from fastapi import HTTPException
            raise HTTPException(400, str(e)) from e

    @router.post('/preflight')
    def preflight():
        from .service import Service
        from .providers import Providers
        providers = Providers(Service(settings))
        return preflight_status(settings, providers)

    @router.post('/stepfun')
    def post_stepfun(update: StepFunUpdate):
        try:
            return apply_stepfun(settings, update)
        except ValueError as e:
            from fastapi import HTTPException
            raise HTTPException(400, str(e)) from e

    app.include_router(router)
