from __future__ import annotations
import base64
import hashlib
import json
import math
import os
import random
import re
import threading
import time
import uuid
import weakref
import httpx
from urllib.parse import quote
from .config import endpoint
from .db import dumps,digest
from .errors import AppError,ProviderError,Cancelled
from .media import image_copy


# Shared across worker/provider instances; no secret or prompt is used as a
# dictionary key. Weak references release unused endpoint locks naturally.
_IMAGE_LOCK_GUARD=threading.Lock()
_IMAGE_LOCKS=weakref.WeakValueDictionary()


def parse_json(text: str) -> dict:
    if not isinstance(text,str) or len(text)>200_000:raise ProviderError('模型输出为空或过大。')
    text=text.strip()
    if text.startswith('```') and text.endswith('```'):
        text='\n'.join(text.splitlines()[1:-1])
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:raise ValueError('duplicate JSON key')
            out[k]=v
        return out
    try:out=json.loads(text,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite')))
    except (ValueError,TypeError) as e:
        if isinstance(e,json.JSONDecodeError):
            detail=f'JSON 语法错误：{e.msg}，第 {e.lineno} 行、第 {e.colno} 列。'
        else:detail='JSON 含重复字段或非有限数字。'
        error=ProviderError('模型未返回合法且唯一键的 JSON；未执行自由文本。'+detail,code='provider_invalid_json')
        # Ephemeral repair data only; never logged, executed, or published.
        error.invalid_document=text[:50000]
        raise error from e
    if not isinstance(out,dict):
        error=ProviderError('模型必须返回 JSON 对象，不能返回数组或字符串。',code='provider_invalid_json')
        error.invalid_document=text[:50000];raise error
    return out


class Providers:
    def __init__(self,service,transport=None):
        self.service,self.settings,self.transport=service,service.settings,transport

    def cards(self):
        result={}
        for name,conf in self.settings.models().items():
            if not conf.get('enabled',False):continue
            try:endpoint(conf)
            except ValueError:continue
            result[name]={'id':name,'label':conf.get('label',name),'capabilities':conf.get('capabilities',[]),
                          'model':os.getenv(conf.get('model_env',''),'') or conf.get('model',''),
                          'revision':conf.get('revision','operator-not-recorded'),
                          'description':conf.get('description',''),
                          'max_images':conf.get('max_images',12),'state':'configured_not_gpu_verified'}
            # Configuration and inference availability are different facts.
            retry=self.retry_after(name)
            result[name].update(available=not bool(retry),retry_after_seconds=retry)
            if retry:
                result[name].update(state='temporarily_unavailable',last_http_status=self.inference_status(name).get('http_status',503))
        return result

    def _status_fingerprint(self,name):
        conf=self.settings.models().get(name,{})
        # Include a private credential digest, never the credential itself.
        return digest({'url':conf.get('url') or os.getenv(conf.get('url_env',''),''),
                       'model':os.getenv(conf.get('model_env',''),'') or conf.get('model',''),
                       'protocol':conf.get('protocol'),'credential':hashlib.sha256(os.getenv(conf.get('token_env',''),'').encode()).hexdigest()})

    def _safe_diagnostic(self,value,limit=300):
        if not isinstance(value,(str,int)) or isinstance(value,bool):return ''
        text=str(value)
        secrets=[self.settings.token]
        secrets.extend(os.getenv(c.get('token_env',''),'') for c in self.settings.models().values())
        # Upstream errors are untrusted and can echo an Authorization header.
        # Redact before truncating so even partial tokens cannot reach storage.
        for secret in sorted(set(s for s in secrets if s),key=len,reverse=True):
            for encoded in (secret,quote(secret,safe=''),json.dumps(secret)[1:-1],base64.b64encode(secret.encode()).decode()):
                text=text.replace(encoded,'[redacted]')
        text=re.sub(r'(?i)bearer\s+[^\s,;"<>]+','Bearer [redacted]',text)
        text=re.sub(r'data:[^\s]+','[data omitted]',text)
        text=re.sub(r'[A-Za-z0-9+/=_-]{180,}','[long value omitted]',text)
        return ' '.join(text.split())[:limit]

    def _http_diagnostics(self,response):
        """Only retain bounded, redacted structured error fields, never a raw
        response body, headers, request prompt or image payload."""
        request_id=response.headers.get('x-request-id') or response.headers.get('request-id') or response.headers.get('x-stepfun-request-id') or ''
        body=bytearray()
        try:
            for chunk in response.iter_bytes():
                body.extend(chunk[:8192-len(body)])
                if len(body)>=8192:break
            value=json.loads(body)
        except (ValueError,UnicodeDecodeError,httpx.HTTPError):value={}
        if not isinstance(value,dict):value={}
        error=value.get('error',{})
        if not isinstance(error,dict):error={}
        fields={'request_id':request_id or error.get('request_id') or value.get('request_id'),
                'error_code':error.get('code') or error.get('type') or value.get('code'),
                'error_message':error.get('message') or value.get('message') or value.get('msg')}
        limits={'request_id':128,'error_code':100,'error_message':300}
        return {k:clean for k,v in fields.items() if (clean:=self._safe_diagnostic(v,limits[k]))}

    def inference_status(self,name):
        path=self.settings.data_dir/'provider-status'/(hashlib.sha256(name.encode()).hexdigest()+'.json')
        try:
            if path.stat().st_size>4096:return {}
            value=json.loads(path.read_text('utf-8'))
            if not isinstance(value,dict):return {}
            status,at=value.get('http_status'),value.get('at')
            if type(status) is not int or not 100<=status<=599:return {}
            if type(at) not in (int,float) or not math.isfinite(at) or not 0<=at<=time.time()+5:return {}
            if value.get('fingerprint') not in (None,self._status_fingerprint(name)):return {}
            delay=value.get('retry_after_seconds',60)
            if type(delay) not in (int,float) or not math.isfinite(delay) or not 0<=delay<=86400:delay=60
            out={'http_status':status,'at':at,'retry_after_seconds':delay}
            for key,limit in (('request_id',128),('error_code',100),('error_message',300)):
                if isinstance(value.get(key),str):out[key]=self._safe_diagnostic(value[key],limit)
            return out
        except (OSError,ValueError,TypeError):return {}

    def retry_after(self,name):
        if self.settings.models().get(name,{}).get('protocol')!='stepfun-images':return 0
        status=self.inference_status(name)
        if status.get('http_status',0)<500 and status.get('http_status')!=429:return 0
        return max(0,math.ceil(status['retry_after_seconds']-(time.time()-status['at'])))

    def record_inference(self,name,status,retry_after=None,diagnostics=None):
        # Honor upstream Retry-After; a transient failure without guidance only
        # pauses manual retries briefly. This is not a promise of recovery.
        delay=60 if status>=500 or status==429 else 0
        if retry_after is not None and delay:
            try:
                from email.utils import parsedate_to_datetime
                from datetime import timezone
                if str(retry_after).strip().isdigit():seconds=int(retry_after)
                else:
                    date=parsedate_to_datetime(str(retry_after))
                    if date.tzinfo is None:date=date.replace(tzinfo=timezone.utc)
                    seconds=math.ceil(date.timestamp()-time.time())
                if 0<=seconds<=86400:delay=seconds
            except (ValueError,TypeError,OverflowError):pass
        path=self.settings.data_dir/'provider-status'/(hashlib.sha256(name.encode()).hexdigest()+'.json')
        # Do not append another UUID to the 64-character final filename:
        # ordinary nested Windows installations can exceed MAX_PATH.
        temp=path.with_name('pending_'+uuid.uuid4().hex+'.tmp')
        try:
            path.parent.mkdir(parents=True,exist_ok=True)
            value={'http_status':status,'at':time.time(),'retry_after_seconds':delay,'fingerprint':self._status_fingerprint(name)}
            for key,limit in (('request_id',128),('error_code',100),('error_message',300)):
                if isinstance((diagnostics or {}).get(key),str):value[key]=self._safe_diagnostic(diagnostics[key],limit)
            temp.write_text(json.dumps(value,ensure_ascii=False),'utf-8')
            os.replace(temp,path)
        except OSError:
            # Telemetry failure must not turn a successful paid inference into
            # a failed/retried inference. The actual outcome remains authoritative.
            pass
        finally:
            try:temp.unlink(missing_ok=True)
            except OSError:pass

    def _unavailable(self,name):
        status=self.inference_status(name)
        raise ProviderError(f'{name} 已配置，但最近真实推理返回 HTTP {status.get("http_status",503)}；服务暂时不可用，约 {self.retry_after(name)} 秒后可重试。已保存版本不变。',code='provider_unavailable')

    def choose(self,capability,preferred=None):
        cards=self.cards()
        if preferred:
            if preferred in cards and capability in cards[preferred]['capabilities']:
                if not cards[preferred]['available']:self._unavailable(preferred)
                return preferred
            raise ProviderError(f'指定模型 {preferred} 不支持 {capability} 或未配置。')
        for name,card in cards.items():
            if capability in card['capabilities'] and card['available']:return name
        for name,card in cards.items():
            if capability in card['capabilities']:self._unavailable(name)
        raise ProviderError(f'没有已配置的 {capability} 模型。请修改 configs/models.toml；未使用演示回退。')

    def conf(self,name,project):
        p=self.service.project(project)
        if p['mode']!='real':raise ProviderError('演示项目不会调用远端模型。请新建真实项目。')
        if not p['remote_consent']:raise ProviderError('未授权向配置的模型节点发送资料。')
        conf=self.settings.models().get(name)
        if not conf or not conf.get('enabled'):raise ProviderError('模型未启用。')
        try:base=endpoint(conf)
        except ValueError as e:raise ProviderError(str(e)) from e
        headers={}
        key=os.getenv(conf.get('token_env',''),'')
        if key:headers['Authorization']='Bearer '+key
        elif conf.get('require_token',True):raise ProviderError(f'{name} 缺少环境变量 {conf.get("token_env", "token_env")}。')
        return conf,base,headers

    def _request(self,name,project,method,path,*,body=None,files=None,headers=None,timeout=None,binary=False):
        conf,base,h=self.conf(name,project)
        h.update(headers or {})
        try:
            with httpx.Client(timeout=timeout or 40,follow_redirects=False,trust_env=False,transport=self.transport) as client:
                with client.stream(method,base+'/'+path.lstrip('/'),json=body,files=files,headers=h) as r:
                    if r.status_code>=300:raise ProviderError(f'{name} 返回 HTTP {r.status_code}。请查看受信节点日志；未自动切换模型。',
                        code='provider_transient' if r.status_code in (502,503,504) else 'provider_http_error')
                    data=bytearray()
                    for chunk in r.iter_bytes():
                        data.extend(chunk)
                        if len(data)>self.settings.max_output:raise ProviderError('模型响应超过本地主机的文件大小上限。')
                    if binary:return bytes(data)
                    try:return json.loads(data)
                    except (ValueError,UnicodeDecodeError) as e:raise ProviderError(f'{name} 响应不是合法 JSON。') from e
        except httpx.TimeoutException as e:raise ProviderError(f'{name} 请求超时。异步任务保留远端编号，恢复时重新查询。',code='provider_timeout') from e
        except httpx.ConnectError as e:raise ProviderError(f'{name} 暂时无法建立连接。',code='provider_connect') from e
        except httpx.HTTPError as e:raise ProviderError(f'{name} 网络连接失败。',code='provider_network') from e

    def _node_request(self,ctx,name,method,path,**kwargs):
        """Retry transport failures only for reads or idempotent job submission.

        Never replay a cloud request, uncertain asset upload, cancellation or
        explicit remote retry. A connect failure before sending an asset is safe
        to wait/retry. An already saved remote job ID stays authoritative.
        """
        node=self.settings.models().get(name,{}).get('protocol','node-v1')=='node-v1'
        safe=node and (method=='GET' or (method=='POST' and path=='v1/jobs' and kwargs.get('headers',{}).get('Idempotency-Key')))
        started=time.monotonic();attempt=0;announced=False
        while True:
            ctx.check()
            try:
                request_kwargs=dict(kwargs)
                if safe and self.settings.connection_grace_seconds>0:
                    budget=self.settings.connection_grace_seconds-(time.monotonic()-started)
                    request_kwargs['timeout']=min(request_kwargs.get('timeout') or 40,max(.1,budget))
                result=self._request(name,ctx.project,method,path,**request_kwargs)
                if announced:ctx.emit('remote.reconnected',{'model':name,'attempts':attempt})
                return result
            except ProviderError as e:
                retryable=e.code in ('provider_connect','provider_network','provider_timeout','provider_transient')
                unsent_asset=node and method=='POST' and path=='v1/assets' and e.code=='provider_connect'
                if not (safe or unsent_asset) or not retryable:raise
                remaining=self.settings.connection_grace_seconds-(time.monotonic()-started)
                if remaining<=0:
                    raise ProviderError('等待模型连接恢复超时；已保留远端任务编号和原有素材，可稍后继续。',code='connection_recovery_timeout') from e
                if not announced:
                    ctx.emit('remote.reconnecting',{'model':name,'remote_id_preserved':method=='GET' and path.startswith('v1/jobs/')})
                    announced=True
                attempt+=1;delay=min(remaining,min(5,.5*2**min(attempt-1,4))*random.uniform(.8,1.0))
                until=time.monotonic()+delay
                while time.monotonic()<until:
                    ctx.check();time.sleep(min(.2,max(0,until-time.monotonic())))

    def chat(self,project,system,user,images=None,model_id=None):
        name=self.choose('brain.plan',model_id);conf,_,_=self.conf(name,project)
        images=images or []
        if len(images)>conf.get('max_images',12):raise ProviderError('本轮图片数超过旗舰端点配置上限；请缩小素材组而不是静默忽略图片。')
        content=[{'type':'text','text':user}]
        for caption,raw in images:
            png=image_copy(raw,max_edge=conf.get('image_max_edge',1536))
            content += [{'type':'text','text':caption},
                        {'type':'image_url','image_url':{'url':'data:image/png;base64,'+base64.b64encode(png).decode()}}]
        model=os.getenv(conf.get('model_env',''),'') or conf.get('model','')
        if not model:raise ProviderError('旗舰 model 名称未配置。')
        payload={'model':model,'messages':[{'role':'system','content':system},{'role':'user','content':content}],
                 'stream':False,'max_tokens':conf.get('max_tokens',10000),'temperature':0.1}
        effort=conf.get('reasoning_effort')
        if effort is not None:
            if effort not in ('low','medium','high'):
                raise ProviderError('reasoning_effort 配置只允许 low/medium/high；请按端点真实能力配置。',code='provider_configuration')
            payload['reasoning_effort']=effort
        if conf.get('json_mode',True):payload['response_format']={'type':'json_object'}
        out=self._request(name,project,'POST','chat/completions',body=payload,timeout=self.settings.chat_timeout)
        try:
            if out['choices'][0].get('finish_reason')=='length':raise ProviderError(
                f'旗舰 JSON 因 token 上限被截断（max_tokens={payload["max_tokens"]}），请调整模型输出/推理预算；未执行截断方案。',
                code='provider_output_truncated')
            answer=parse_json(out['choices'][0]['message']['content'])
        except (KeyError,IndexError,TypeError) as e:raise ProviderError('旗舰返回格式不是已配置的 chat/completions 协议。') from e
        return answer

    def remote(self,ctx,step_name,capability,*,data=None,filename='input.png',prompt='',options=None,model_id=None,reference_data=None):
        name=self.choose(capability,model_id);conf,_,_=self.conf(name,ctx.project)
        if conf.get('protocol')=='stepfun-images':
            return self.stepfun_image(name,ctx,capability,data,prompt,options or {})
        if conf.get('protocol','node-v1')!='node-v1':raise ProviderError('该能力需要 MemoryScape node-v1 异步网关。')
        ref=ctx.remote_ref(step_name)
        # The request fingerprint does not include temporary URLs or browser state.
        fingerprint={'model':name,'revision':conf.get('revision'),'capability':capability,
                   'input':hashlib.sha256(data).hexdigest() if data else None,'prompt':prompt,'options':options or {}}
        if capability=='geometry.texture':
            if not reference_data or not data:raise ProviderError('贴图必须提供真实网格和已验收的参考图。')
            fingerprint['reference']=hashlib.sha256(reference_data).hexdigest()
        elif reference_data is not None:raise ProviderError('此模型任务不接受第二份输入。')
        fp=digest(fingerprint)
        if ref and ref.get('fingerprint')!=fp:raise ProviderError('远端任务的输入或模型版本已经变化，请新建任务。')
        if not ref:
            artifact=None
            if data is not None:
                uploaded=self._node_request(ctx,name,'POST','v1/assets',files={'file':(filename,data,'application/octet-stream')})
                artifact=uploaded['id']
            auxiliary={}
            if reference_data is not None:
                uploaded=self._node_request(ctx,name,'POST','v1/assets',files={'file':('reference.png',reference_data,'image/png')})
                auxiliary['reference_asset']=uploaded['id']
            # Idempotency survives a host crash between POST and saving job_id.
            key=digest({'job':ctx.id,'step':step_name,'fingerprint':fp})
            if hasattr(ctx,'charge'):ctx.charge('remote_job',key)
            resp=self._node_request(ctx,name,'POST','v1/jobs',body={'capability':capability,'input_asset':artifact,'prompt':prompt,'options':options or {},**auxiliary},
                               headers={'Idempotency-Key':key})
            if resp.get('execution_mode')=='contract-test' and self.settings.test_models is None:
                raise ProviderError('远端是协议测试节点，不允许在真实项目中充当真实模型。')
            ref={'model':name,'job_id':resp['id'],'fingerprint':fp}
            ctx.set_remote(step_name,ref)
        started=time.monotonic();last_status=None
        while True:
            try:ctx.check()
            except Cancelled:
                try:self._request(name,ctx.project,'POST',f'v1/jobs/{ref["job_id"]}/cancel',body={})
                except Exception:pass
                raise
            out=self._node_request(ctx,name,'GET',f'v1/jobs/{ref["job_id"]}')
            if out.get('execution_mode')=='contract-test' and self.settings.test_models is None:
                raise ProviderError('协议测试节点不能用于真实项目。')
            if out['status']!=last_status:
                ctx.emit('remote.status',{'step':step_name,'model':name,'remote_id':ref['job_id'],'status':out['status']});last_status=out['status']
            if out['status']=='succeeded':
                if 'report' in out['result']:
                    return {'report':out['result']['report'],'model':name,'remote_id':ref['job_id'],'metrics':out.get('metrics',{})}
                output=out['result']['asset']
                raw=self._node_request(ctx,name,'GET',f'v1/assets/{output["id"]}',binary=True)
                if hashlib.sha256(raw).hexdigest()!=output['sha256']:raise ProviderError('远端产物 SHA256 校验不一致。')
                return {'data':raw,'filename':output['filename'],'model':name,'remote_id':ref['job_id'],'metrics':out.get('metrics',{})}
            if out['status'] in ('failed','cancelled'):
                generation=ctx.job['payload'].get('retry_generation',0)
                if generation>ref.get('last_explicit_retry',0):
                    if hasattr(ctx,'charge'):ctx.charge('remote_job',digest({'remote':ref['job_id'],'retry':generation}))
                    self._request(name,ctx.project,'POST',f'v1/jobs/{ref["job_id"]}/retry',body={})
                    ref['last_explicit_retry']=generation;ctx.set_remote(step_name,ref);continue
                raise ProviderError(f'{name} 的远端任务 {out["status"]}：{out.get("error", "请检查节点")[:500]}')
            if time.monotonic()-started>self.settings.remote_wait_seconds:raise ProviderError('远端任务仍未完成。保留任务编号，稍后恢复查询。')
            time.sleep(self.settings.remote_poll_seconds)

    def stepfun_image(self,name,ctx,capability,data,prompt,options):
        fingerprint=self._status_fingerprint(name)
        with _IMAGE_LOCK_GUARD:
            lock=_IMAGE_LOCKS.get(fingerprint)
            if lock is None:
                lock=threading.Lock();_IMAGE_LOCKS[fingerprint]=lock
        while True:
            ctx.check()
            if lock.acquire(timeout=.2):break
        try:
            # A sibling reference may have failed while this one was waiting.
            # Recheck the cooldown inside the shared endpoint lock so a single
            # unavailable engine is not hit by all scene objects concurrently.
            if self.retry_after(name):self._unavailable(name)
            return self._stepfun_image_locked(name,ctx,capability,data,prompt,options)
        finally:lock.release()

    def _stepfun_image_locked(self,name,ctx,capability,data,prompt,options):
        ctx.check()
        conf,base,headers=self.conf(name,ctx.project)
        model=conf.get('model','step-image-edit-2')
        if len(prompt)>512:raise ProviderError('StepFun 图片编辑提示词最多 512 字，请精简后重试。')
        try:
            with httpx.Client(timeout=600,trust_env=False,follow_redirects=False,transport=self.transport) as client:
                fields={'model':model,'prompt':prompt,'response_format':'b64_json',
                        'seed':str(options.get('seed',2026)), 'steps':'8','cfg_scale':'1.0'}
                if capability=='image.edit':
                    if data is None:raise ProviderError('图片编辑需要参考照片。')
                    path='/images/edits';request={'data':fields,'files':{'image':('reference.png',image_copy(data),'image/png')}}
                elif capability=='image.generate':
                    path='/images/generations';request={'json':fields}
                else:raise ProviderError('StepFun 图片接口不支持该能力。')
                if hasattr(ctx,'charge'):ctx.charge('remote_job')
                with client.stream('POST',base+path,headers=headers,**request) as r:
                    if not r.is_success:
                        details=self._http_diagnostics(r)
                        self.record_inference(name,r.status_code,r.headers.get('Retry-After'),details)
                        from .settings_api import stepfun_api_mode
                        channel='Step Plan 订阅入口' if stepfun_api_mode(base)=='step_plan' else '已配置入口'
                        reason='；'.join(f'{label}：{details[key]}' for key,label in
                            (('error_code','上游错误码'),('error_message','上游说明'),('request_id','请求编号')) if details.get(key))
                        hint=''
                        if r.status_code in (401,403):hint='请检查该入口的密钥及订阅权限。'
                        elif r.status_code==402:hint='请检查该入口的可用额度；不会自动切换计费渠道。'
                        raise ProviderError(f'StepFun {model}（{channel}）返回 HTTP {r.status_code}；{reason + "；" if reason else ""}{hint}未使用演示替代。',
                            code='provider_transient' if r.status_code in (429,500,502,503,504) else 'provider_http_error')
                    body=bytearray()
                    for chunk in r.iter_bytes():
                        body.extend(chunk)
                        if len(body)>self.settings.max_output:raise ProviderError('图片响应过大。')
                    request_id=r.headers.get('x-request-id','cloud-image')
                raw=base64.b64decode(json.loads(body)['data'][0]['b64_json'],validate=True)
                png=image_copy(raw)
                self.record_inference(name,200,diagnostics={'request_id':request_id})
        except (httpx.HTTPError,ValueError,KeyError,IndexError,TypeError) as e:
            raise ProviderError('StepFun 图片请求失败或未返回合法 base64 图片。') from e
        ctx.check()
        return {'data':png,'filename':'stepfun-image.png','model':name,
                'remote_id':request_id,
                'metrics':{'execution_mode':'native-cloud','upstream_model':model}}

    def preflight(self):
        """Connectivity/capability check only. Never sends user materials or claims GPU inference."""
        results=[]
        for name,card in self.cards().items():
            conf=self.settings.models()[name]
            try:
                base=endpoint(conf);key=os.getenv(conf.get('token_env',''),'')
                if conf.get('require_token',True) and not key:raise ValueError('缺少节点密钥环境变量')
                path='/models' if conf.get('protocol') in ('chat','stepfun-images') else '/v1/capabilities'
                with httpx.Client(timeout=8,follow_redirects=False,trust_env=False,transport=self.transport) as c:
                    r=c.get(base+path,headers={'Authorization':'Bearer '+key} if key else {})
                    if not r.is_success:raise ValueError(f'HTTP {r.status_code}')
                    data=r.json()
                results.append({'model':name,'connection':'ok','advertised':data,'inference_verified':False})
            except Exception as e:results.append({'model':name,'connection':'failed','error':str(e).split('http')[0][:200],'inference_verified':False})
        return {'checks':results,'note':'仅网络和能力检查；必须用授权样例完成实际生成，才能记录实机验收。'}
