"""MemoryScape application. No model weights or GPU frameworks are imported here."""
__version__ = "1.6.2-submission"
