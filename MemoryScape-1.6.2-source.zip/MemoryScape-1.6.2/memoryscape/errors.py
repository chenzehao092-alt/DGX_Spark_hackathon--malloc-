class AppError(Exception):
    def __init__(self, message: str, status: int = 422, code: str = 'invalid_request'):
        super().__init__(message)
        self.message, self.status, self.code = message, status, code


class Cancelled(AppError):
    def __init__(self):
        super().__init__('任务已取消；已经生成的产物仍可保留。', 409, 'cancelled')


class ProviderError(AppError):
    def __init__(self, message: str, code: str = 'provider_error'):
        super().__init__(message, 502, code)
