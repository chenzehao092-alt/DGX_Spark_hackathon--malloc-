"""Restricted host API client shared by Skill and MCP; never accepts model node URLs."""
from __future__ import annotations
import os
import re
from pathlib import Path
from urllib.parse import urlsplit
import httpx


def ident(value: str) -> str:
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,99}',value):
        raise ValueError('Invalid project/object/job identifier')
    return value


class Client:
    def __init__(self, url: str|None=None, token: str|None=None):
        self.url=(url or os.getenv('MS_APP_URL','http://127.0.0.1:8000')).rstrip('/')
        parsed=urlsplit(self.url)
        if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.query or parsed.fragment:
            raise ValueError('Invalid application URL')
        if parsed.scheme=='http' and parsed.hostname not in ('localhost','127.0.0.1','::1'):
            raise ValueError('Use localhost SSH forwarding or HTTPS for a remote application')
        self.token=token or os.getenv('MS_TOKEN','')
        if not self.token:
            from .config import ROOT
            p=Path(os.getenv('MS_DATA_DIR',str(ROOT/'data')))/'access-token'
            if p.is_file():self.token=p.read_text('utf-8').strip()
        if len(self.token)<24:raise ValueError('Set MS_TOKEN or start the local application to create data/access-token')

    def call(self, method: str, path: str, **kwargs):
        if not path.startswith('/api/') or '..' in path:raise ValueError('Only application API paths are allowed')
        with httpx.Client(base_url=self.url,headers={'Authorization':'Bearer '+self.token},timeout=240,trust_env=False,follow_redirects=False) as c:
            r=c.request(method,path,**kwargs)
            if r.status_code>=300:
                try:detail=r.json().get('message',r.json().get('detail','request rejected'))
                except ValueError:detail='request rejected'
                raise RuntimeError(f'HTTP {r.status_code}: {str(detail)[:2000]}')
            return r

    def json(self, method: str, path: str, **kwargs):return self.call(method,path,**kwargs).json()
