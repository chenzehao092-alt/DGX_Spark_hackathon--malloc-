# 1.5 桌面版实机验收 · 2026-09-27

环境：Windows 本机 UI/API，server6 临时代替 DGX Spark。未冒充 DGX ARM64 硬件验收。

本文件记录首次桌面启动/停止验收；随后针对用户实际海报操作的修复、UI 原生下载及第二次实物三维验收，见 [当前 UI 验收记录](UI_ACCEPTANCE_20260927.md)。下文首次验收的计数及测试数据整理状态不代表之后新增的用户项目。

真实输入：[Wikimedia Commons 的 Canon EOS Rebel T5 实物照片](https://commons.wikimedia.org/wiki/File:Canon_EOS_Rebel_T5_without_lens_(2).jpg)，作者 Hiàn，CC0 1.0。不是程序化气球、已有缓存 GLB 或合同测试节点。

## 实际通过

- StepFun `step-1o-turbo-vision` 看真实照片、输出规划，经过严格 JSON/预算/能力校验。
- CPU U2Net 分割普通 RGB 照片；Step1X-3D 50 步几何，512 分辨率、12 步纹理；原生模式 native。
- 生成相机网格 60,000 三角面，原生节点任务耗时 356.535 秒。
- 本机场景 GLB 约 1.82 MB，2 meshes（相机与底座）、1 material、1 texture、1 embedded image，长度与结构校验通过。
- 用真实 UI 对话调用 StepFun 修改摆放，确认保存到版本 5；底座 Y=0、相机 Y=0.01，支撑关系无额外间隙，保留原生网格和纹理。
- 用真实 UI“保存回忆”，保存 WebGL 预览图；完整导出 ZIP 校验通过。
- Python 测试 144 通过，1 个可选 MCP 测试跳过；前端测试 48 通过。
- 从正式目录实际执行 Windows BAT 启动成功；第二次执行复用相同本机服务、隧道和远端模型 PID。
- 实际执行停止 BAT 成功：8002 / 19103 监听关闭，本项目远端 PID 退出、GPU 3 显存降至 1 MiB；未终止其他用户的进程。

![真实 WebGL 预览](real-preview.png)

生成结果有背面补全、纹理噪声和分割/几何碎片，不宣称 1:1 或最高质量。这是实际模型结果，不修图隐藏误差。

## 未通过 / 未验证

StepFun `step-image-edit-2` 两次真实图片编辑请求均返回 HTTP 503，未替换为假图。最近过载的接口会暂时从规划能力中移除 30 分钟，以免把“模型列表可访问”误当作推理可用。
[官方图片接口说明](https://platform.stepfun.ai/docs/en/api-reference/images/edits)通知该模型在 2026-10-10 下线；之后需替换服务或部署本地编辑模型。
音频模型推理没有部署验收，原声导入/播放不等于音频理解。低显存 CPU 卸载路径有代码，但本次最终验收使用空闲 24 GB 卡，没有将卸载路径标为实测通过。

测试项目和原始测试运行数据从正常 data 目录移出，保留可恢复备份；正式 UI 不带验收项目。
本机备份：`E:\llm_workspace\projects\MemoryScape_3D相册\_验收备份\MemoryScape-1.5-20260927-验收数据`。
远端备份：`/data/chenzh/experiments/memoryscape-1.5/backups/acceptance-20260927/geometry`。
这些备份含私有配置，不应对外分享；可公开的真实预览图单独放在 `docs/real-preview.png`。
