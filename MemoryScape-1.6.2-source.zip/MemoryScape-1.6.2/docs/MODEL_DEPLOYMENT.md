> **简洁版说明（RC2）：** 普通界面已移除物品属性、模型节点和执行日志入口。本文保留的模型/工程工作由开发者通过配置、CLI 与 API 完成；面向用户的操作以 [SIMPLE_UI.md](SIMPLE_UI.md) 为准。

# 模型部署：主机 + 多 3090/4090，随后迁移 DGX Spark

本文件是可执行接入步骤与验收条件，不是已完成 GPU 部署证明。本次环境没有你的模型权重、节点权限或 DGX Spark。核心应用已测试，模型 native 驱动沿用/适配官方接口和你上传的已改造环境，仍须逐项真实运行。

## 1. 保留主机与模型的环境隔离

主机按 README 使用 Python 3.11–3.13。每种模型保留其已经跑通的 PyTorch/CUDA/Transformers/Diffusers 虚拟环境；在那个环境中额外安装 `requirements-node.txt`。节点脚本从源码导入，不要求在旧 Python 模型环境安装主机 pyproject。

```bash
# 在远端该模型已有虚拟环境中执行；不要覆盖已验证的 Torch。
python -m pip install -r requirements-node.txt
python scripts/start-node.py --host 127.0.0.1 --port 9103
```

上面的启动需要先设置下一节的环境变量。requirements-node 不包含 GPU 模型依赖，不能替代上游安装。先复现官方最小推理，再接网关；不要同时升级模型、驱动、推理框架和应用。

## 2. 几何 + 纹理节点

复制 `configs/node-geometry.env.example` 到**公开仓库之外**的私有路径，填 `MODEL_REPO`、`MODEL_PATH`、节点密钥、权重/运行库 revision。随机密钥示例：

```bash
python -c "import secrets;print(secrets.token_urlsafe(36))"
set -a
source /secure/geometry.env
set +a
python scripts/start-node.py --port 9103
```

双卡示例：`CUDA_VISIBLE_DEVICES=0,1`，`GEOMETRY_DEVICE=cuda:0`，`TEXTURE_DEVICE=cuda:1`。这些编号相对可见设备列表，不是永远指机器物理 0/1。单卡阶段卸载：二者同为 `cuda:0`，`SINGLE_GPU_STAGED=true`。旗舰服务占卡应与此资源池明确错开。

上传工程的 `GeometryBackend` 已保留为 `node/legacy_stepfun.py`，新 `Geometry` 包装器修复连续阶段卸载调用的回迁逻辑。纹理准备不套全局 `torch.inference_mode()`，以免破坏需梯度的渲染步骤。`max_faces` 对导出网格实际执行减面，仍须检查可见质量。

`scripts/patch_step1x3d_*.py` 是针对既定上游布局的幂等补丁，不适用于所有新版本。执行前复制/提交上游代码；先设置明确的 MODEL_REPO，不使用任何私人默认路径。补丁找不到预期文本应停止，不盲目替换。低分辨率纹理路径只有在运行库实际打补丁、`PATCHED_STEP1X_RUNTIME=true` 时才使用。发布前记录补丁后的 Git diff/commit。

不要把官方环境的耗时搬到 3090/4090 或 Spark。尤其人物质量、面数、贴图和峰值内存必须使用自己的素材验证。Step1X-3D 当前适配是图像条件静态模型；不接受任意自由文本直控几何。把要求落实到参考图或程序布局。

## 3. 图片节点

使用 `configs/node-image.env.example`，启动端口 9102。该驱动明确针对 **Step1X-Edit v1p2**、`Step1XEditPipelineV1P2`、`final_images` 输出；官方 README 指定的 v1p2 Diffusers 分支与普通 pip diffusers 不可混用。模型路径/分支提交必须固定。

`IMAGE_CPU_OFFLOAD=true` 只是降低常驻占用的可选方式，不保证你的卡一定容纳所有输入。先测单张图编辑，不要误把该驱动注册为原生 text2image。纯文生图通过单独的可选 image-api 驱动接入，需与真实服务接口测试。

## 4. 音频节点

使用 `configs/node-audio.env.example`、Step-Audio2 原生环境，端口 9104。音频描述输入是标准化后片段；原始素材不覆盖。分段覆盖非语音事件，不根据用户日记倒推“听到了生日歌”。时间标识为片段级，不是自动精确声源定位。

TTS 是额外能力：填写固定 `AUTHORIZED_VOICE_WAV`、确认 `VOICE_LICENSE_CONFIRMED=true`，并在主机能力卡增加 `audio.tts`。声音必须有授权，不通过用户上传录音临时克隆声纹。只需要原声时，完全不必启用 TTS。没有音乐 native 驱动，不启用 `music.generate`。

## 5. 旗舰节点

旗舰需要真实支持多图的 `/v1/chat/completions` 接口。主机将每张缩放后的图片按带素材 ID 的 image_url 消息发送，并提供结构化音频报告、日记、需求与能力卡。配置 `DIRECTOR_MODEL` 为服务实际暴露的模型名；不能只写“旗舰”两个字。

选择模型、量化和张量并行属于部署者职责；3090/4090 的多张显卡不会自动成为共享显存。这里没有提供未经实机验证的通用 vLLM 启动命令。对既有可用端点做：两张明显不同照片 → 合法 JSON → 引用两份真实素材 → 合法 plan → 渲染复核 的验收。JSON 模式不支持时可关闭配置，服务端仍严格解析；截断/未知字段会失败而非静默采用。

## 6. 主机 SSH 隧道

```bash
ssh -N -o ExitOnForwardFailure=yes -o ServerAliveInterval=30 \
  -L 9101:127.0.0.1:9101 -L 9102:127.0.0.1:9102 \
  -L 9103:127.0.0.1:9103 -L 9104:127.0.0.1:9104 user@MODEL_HOST
```

`MODEL_HOST` 是你有权限的实际服务器；不同机器分别建立隧道。正常核对 SSH 主机指纹，不关闭 host-key 检查。将主机 `.env` 的 DIRECTOR_TOKEN/IMAGE_NODE_TOKEN/GEOMETRY_NODE_TOKEN/AUDIO_NODE_TOKEN 与各服务对应起来，填 `configs/models.toml` 并逐项 enabled=true。浏览器不直接访问这些端口。

## 7. 远端协议与恢复语义

网关提供能力、输入上传、任务提交/查询/取消/显式重试、产物下载；读取 `node/gateway.py` 或 tests/test_node_protocol.py 的实际请求。输入和产物检查格式与哈希；提交使用幂等键；模型 prompt 不能指定文件路径或网络地址。主机保存远端任务编号，下载失败恢复不会再次推理。每个模型节点一次一个任务，跨节点可以并行。

服务健康不是模型性能证明。节点权重懒加载；第一次真实调用可能暴露依赖/内存问题。不得在比赛视频中把 health/capabilities=true 当成模型推理成功。远端临时素材存储在 MS_NODE_DATA，需要部署者制定私有保留和清理策略；本版本不自动跨用户清理共享节点。

## 8. Spark 迁移验收

复用主机与协议，重新验证 Arm/Blackwell 的容器、Torch、编译扩展与模型加载。不要把 x86 wheel 直接拷入，也不要假定双卡脚本在单 APU 上可用。建议单节点并发 1 起步，分阶段加载，逐步测真实峰值。

实机顺序：环境采集 → 单对象几何 → 纹理 → 连续两次调用 → 音频描述 → 多图旗舰计划 → 完整场景 → 局部修订 → 导出导入。连续两次调用尤其用于发现阶段卸载后 device 未迁回的问题。

```bash
python scripts/capture_environment.py acceptance/spark-environment.json
python scripts/job_report.py PROJECT_ID acceptance/spark-project.json
```

另保存实际模型网关日志、真实资产 SHA、截图、模型/量化/补丁版本与节点对应关系。比较固定流水线和本系统时，控制模型、素材、硬件和生成预算；单独报告多机并行收益。wall time 包含排队等待，不等于 GPU kernel time。未实测的栏目保持“未执行”，不能填估计值。
