# 1.5.2 持续连接修复与实机验证

日期：2026-09-28。当前主机安装 `E:/Memoryv2.0/MemoryScape`，UI `http://127.0.0.1:8003/`。server6 仍是 DGX Spark 的临时代替节点；本次没有重新部署模型或验证真实 Spark 硬件。

## 故障与修复

此前本机 SSH 日志记录连接被重置，本机转发端口不再监听；UI 的“已连接”仅表示本机 API，不表示模型可访问。加入 MP3 又会强制选择未启用的 `audio.describe`，错误被笼统呈现为创作服务未接通。

1. `memoryscape/connections.py` 在 FastAPI 生命周期启动守护线程。原生节点健康时约每 10 秒检查一次，云端约每 60 秒读取一次模型元数据；同端点同密钥去重，不发送用户素材或发起推理。临时网络失败持续退避重连，延迟上限 30 秒并带抖动。线程随本机后台停止，而不是随浏览器关闭停止。
2. `scripts/desktop_node.py` 用 `ServerAliveInterval=10`、`ServerAliveCountMax=3`、TCP 保活和转发失败退出检测维护 SSH。启动锁避免重复建隧道；进程 PID、启动时间、命令和部署身份需匹配。端口被未知程序占用时不抢占，不降低主机指纹校验，不结束其他用户进程。运行期只恢复 SSH，不调用部署/模型启动流程。
3. `memoryscape/providers.py` 提供最多 180 秒的单次连接恢复窗口。已保存远端任务编号继续 GET 查询，安全提交保持同一个 Idempotency-Key。没有幂等保证的云端推理、可能已经发送的上传、取消和显式任务重试不会被盲目重放。等待期间响应取消；超时保留素材、远端编号与检查点供后续恢复。后台隧道守护不因任务恢复超时而退出。
4. `scripts/desktop_stop.py` 对经校验的进程加入 5 秒退出等待，避免 Windows 进程处于短暂退出阶段被误报未停止；整个进程核验子命令最多 30 秒。
5. `/api/connectivity` 只返回缓存的模型名、状态、固定原因码、检查时间和重连次数。需要本机认证；不输出令牌、远端地址、日志或命令行。UI 分别显示本机/StepFun/3D，明确网络健康不是推理验收。
6. `audio_mode` 默认 `passthrough`，兼容旧项目。上传音乐原样加入音轨，确定性补齐模型可能遗漏的原声音轨，不猜测歌名、歌词、说话人或事件。点音频素材可选择整个项目的“理解录音内容”；该模式需要单独配置音频理解模型，缺少模型时明确报错，不能静默假装分析。

## 实机证据

升级后 `/health` 返回 `1.5.2-desktop`，`/api/connectivity` 的 `monitor_running=true`。director、image 的云端元数据及 geometry 原生能力查询均 HTTP 200；这不是图片编辑推理已通过的证据。

在无活动任务时，仅断开本项目已核验的本机 SSH 隧道：旧 PID 44640，新 PID 37052。状态经历 `connected → reconnecting → connected`，自动恢复耗时 **8.83 秒**（包含核验/停止时间）。期间连续 9 次本机 `/health` 均成功。远端模型 PID 前后均为 **3162413**，没有停止/重启 GPU 模型，没有干扰其他用户。

运行期证据保存在主安装的 `data/connection-resilience-test.json`、`data/connection-status.json` 和 `data/ssh-tunnel.log`；这些运行文件不放入源码交付包。

通过浏览器重试用户原生日规划任务 `j_6a3b916c5de0490ba3377840` 后，状态 `succeeded`，UI 显示待确认方案与“原样保留作背景音；本次没有分析歌曲或录音内容”。该验证时点项目为 3 份素材、输入修订 5、HEAD 0；原 MP3 为 1,503,750 字节、37.5335 秒，上传 SHA-256 与用户原件一致。报告模式为 `passthrough`，音轨 `strategy=original` 指向真实上传原件。助手仅点了原规划“再试一次”，没有确认方案或提交 build，也没有宣称方案视觉质量已经验收。

交付前的最新只读检查发现随后已有生日 build 请求：`j_fd463e3bf18c45369234969f` 为 `partial`，重试 `j_8796bef8c7214bcf9a8949bc` 为 `failed`。人物与蛋糕参考编辑明确返回 `StepFun step-image-edit-2 HTTP 503`，因此对应 3D 生成依赖未执行；不能把画面中的程序桌子、礼物等当作完整生日场景已成功。当前 HEAD 2、输入修订仍为 5，背景音保留，模型元数据连接仍 HTTP 200。这证明“网络/API 能连接”和“付费图片推理成功”是不同状态；自动 SSH 重连不能修复云端 503。没有继续自动重发这些推理。

## 回归测试

- Python：**422 passed, 1 skipped**，耗时 56.35 秒。跳过的是未安装的可选 MCP 服务模块；另有一项上游 Starlette/AnyIO 弃用警告，不是测试失败。
- JavaScript：**77 passed, 0 failed**。
- 覆盖只读检查与密钥脱敏、认证/协议失败不自动修复、端口冲突不抢占、限速退避、守护退出、SSH 保活参数、原任务编号恢复、同幂等键提交、未知上传结果不重发、恢复超时、取消、背景音原件保留、显式音频理解失败及旧项目兼容。
- `contracts/*.schema.json` 与 `contracts/openapi.json` 从修复后代码重新导出。

## 使用与边界

仍然双击 `start_memoryscape.bat`。配置了 `deployment.toml` 且没有使用 `--skip-node` 时，守护会在本机应用运行期间持续尝试恢复所配置的回环转发。启动时暂时无法接通模型不再阻止打开本地工作台，但后台不会替你从零下载/部署模型；必须已有可用节点、SSH 授权与节点令牌。`--skip-node` 明确禁用 SSH 自动恢复。

断网、休眠、远端宕机、无效密钥和云服务过载无法保证“永不断线”。本次保证的是持续检测、有限速的自动重连、安全恢复既有任务和如实呈现错误；不是无限重发请求。180 秒等待是单次请求的恢复预算，不替代原异步任务整体超时。HTTP 401/403 需要正确配置；HTTP 429 需遵守限流；StepFun 图片编辑的历史 HTTP 503 不能由 SSH 修复。

当前 reuse 部署停止 BAT 只停止已核验的本机服务和隧道，远端模型与显存仍保留。不分享 `data/`、`.env` 或实际 `configs/models.toml`。迁移到真实 DGX Spark 后需重新做 GPU 推理与硬件兼容验收。

设计依据：[OpenSSH 保活与转发选项](https://man.openbsd.org/ssh_config#ServerAliveInterval)、[AWS 超时、重试、退避与抖动说明](https://aws.amazon.com/builders-library/timeouts-retries-and-backoff-with-jitter/)。本项目采用限速重试与幂等保护；不把这些方法当作网络或推理质量的绝对保证。
