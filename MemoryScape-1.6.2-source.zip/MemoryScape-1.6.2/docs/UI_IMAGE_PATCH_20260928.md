# MemoryScape 增量修复包

本补丁基于 Alice 本机 Memoryv2.0/Memoryv2.0/MemoryScape，包含本次修改的 8 个源代码/测试文件。不是完整工程，也不包含运行环境或模型部署配置。

## 修改内容

1. `web/settings.js`：保存 StepFun Key 后复用 Preflight；Director connected 时关闭设置弹层，再显示主界面成功 toast。失败时保留弹层，直接显示真实状态；区分保存失败和保存后连接失败；提交后清空密钥输入，不写浏览器存储。
2. `web/tests/settings.test.js`：增加保存、连接成功、连接失败、异常响应及保存失败等前端回归测试。
3. `memoryscape/layout.py`：为明确的“单独保留人像/只保留人物”等请求添加规划约束。拒绝额外文字、边框、底座等非人物对象；清理背景/对话框等任务要求安排图片编辑。错误计划进入既有的最多三轮模型纠错流程。该检查只覆盖明确的人像限定表达，不代表任意自然语言任务均已验证。
4. `memoryscape/prompts.py`：明确人像清理的规划规则；原图文字不能覆盖用户删除要求；区分平面图片展示与立体人物，禁止把占位体当作成功结果。
5. `memoryscape/service.py`：确认计划时再次执行人物限定检查，防止旧的待确认错误计划绕过校验。
6. `tests/test_portrait_intent.py`：新增人像限定、图片清理、模型纠错、旧计划确认拒绝等测试。
7. `memoryscape/providers.py`：取消一次 503/500/429 后固定锁定图片服务 30 分钟。优先按上游 Retry-After（秒数或 HTTP 日期）冷却；没有有效提示时默认 60 秒。兼容旧状态文件，不自动循环重试，不宣称冷却结束等于恢复。
8. `tests/test_reliability_contracts.py`：更新冷却测试，增加 Retry-After、旧状态兼容、单次失败不自动重试等回归测试。

## 给组员的应用方式

- 使用相同 Memoryv2.0 基础版本：先备份现有文件，再按包内相对路径覆盖这 8 个文件。
- 如果组员已改过这些文件：逐项合并差异，不要直接覆盖他们的改动。
- 覆盖后重启实际提供页面的 MemoryScape 后端，再刷新网页。仅刷新网页不能加载 Python 后端修改。
- 不需要迁移数据库、不需要安装新依赖。

Windows 验证命令（在项目根目录执行）：

```powershell
node --test web/tests/*.test.js
.\.venv\Scripts\python.exe -m pytest -q
```

## 已完成的验证

- Settings 修复：73 项前端测试通过；真实 Chrome/Playwright 桌面页面验证 6 个模拟响应场景，包括 connected、unauthorized、unreachable、invalid_response、检查请求异常、保存失败。
- 人像规划修复：全量后端测试 349 passed、1 skipped。跳过项因缺少可选 mcp 包。
- 冷却修复（最后一次改动）：相关后端测试 62 passed；本次最后改动后没有再次运行全量后端测试。
- 实际云端诊断：模型列表 200 且包含 step-image-edit-2；合成圆形图片编辑返回 503，错误类型 engine_overloaded。云端过载尚未修复，本补丁不能保证图片服务恢复。

## 没有包含或解决的内容

- API Key、`.env`、`data/local-secrets.env`、访问令牌、SSH 私钥、数据库、素材和日志均不在包内。
- 没有改一键启动脚本、自动登录逻辑、3D 模型协议、服务部署架构或追迹 UI。
- 没有接通服务器上的 3D 节点。Alice 当前目录缺少实际 deployment.toml，geometry 配置未启用。
- StepFun 官方公告 step-image-edit-2 将于 2026-10-10 下线： https://platform.stepfun.com/docs/zh/guides/image-offline-notice
- 本机将某条回忆保存为第 3 版、移除误加文字和边框的操作属于本地数据修改，不在代码包内，不应向组员传整个 data 目录。

临时诊断、重启和浏览器检查脚本未列入补丁；它们含本机路径，仅用于这次验证，不是项目运行所需文件。
