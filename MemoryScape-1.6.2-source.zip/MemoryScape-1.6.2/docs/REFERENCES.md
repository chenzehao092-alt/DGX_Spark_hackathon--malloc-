# 实现依据、上游与许可

核对日期：2026-09-24。以下是接口与部署资料，不是本工程实际 GPU 成绩证明。安装前固定提交/权重版本，最新上游变动不自动构成本工程兼容承诺。

| 项目 | 官方来源 | 本工程关系 |
|---|---|---|
| Step1X-3D | https://github.com/stepfun-ai/Step1X-3D / inference.py | 几何、纹理接口；沿用上传工程的已改造适配器，未分发权重或完整上游 |
| Step1X-Edit | https://github.com/stepfun-ai/Step1X-Edit | 明确针对 v1p2 的 Diffusers 版本；v1p1/其他新模型不是可互换类名 |
| Step-Audio2 | https://github.com/stepfun-ai/Step-Audio2 | 原生音频消息格式、音频描述和固定授权音色 Token2wav 路径 |
| MCP Python SDK | https://github.com/modelcontextprotocol/python-sdk/tree/v1.x | 使用 FastMCP 1.x，安装限制 mcp>=1.28,<2；主线 2.x 不直接混用 |
| DGX Spark | https://docs.nvidia.com/dgx/dgx-spark/ / https://docs.nvidia.com/dgx/dgx-spark-porting-guide/index.html | Arm/Blackwell 平台迁移依据；实际部署以实机为准 |
| glTF | https://github.com/KhronosGroup/glTF/tree/main/specification/2.0 | 支持静态子集，导出完整项目还需自定义音轨/日记/交互描述 |
| Agent Skills | https://agentskills.io/specification | Skill Markdown、脚本与按需参考资料的组织方式 |
| FastAPI / Pydantic / trimesh | 各项目官方文档与许可证 | 主机 API、强类型约束、程序资产、网格检查和导出 |

主机依赖版本固定在 pyproject.toml，模型环境不合并进主机依赖。应用源码 MIT，不表示给外部模型权重或用户照片重新许可。保留上传工程 MIT 声明于 licenses/EvidenceTheatre-MIT.txt；详细说明在根目录 THIRD_PARTY_NOTICES.md。
